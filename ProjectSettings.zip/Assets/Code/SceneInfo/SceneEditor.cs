using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using ZLib;
using ZTool.Res;
using ZTool.Table;

namespace MapEditor
{

    /// <summary>
    /// 编辑器入口
    /// </summary>
    public class SceneEditor
    {



        #region GUI

        //是否可以显示GUI
        bool canShowGUI = true;
        public GameObject go;
        /// <summary>
        /// 数据资源显示
        /// </summary>
        public void OnGUI()
        {
            if (GUILayout.Button(" TTTTTTTTTTTTTTT "))
            {
                Debug.Log(Sprite.count);
                //CameraMove.GetInst().CameraLookAtTarget(go);
            }

            if (GUI.Button(new Rect(Screen.width - 200, 0, 200, 50), "返回地图列表"))
            {
                OnUnloadScene();
            }

            if (!canShowGUI)
                return;

            if (!SceneManager.GetInst().Scene_list_load_over)
            {
                //正在加载服务器资源
                winRect = GUI.Window(1, winRect, DrawWindow, "加载服务器资源");

            }
            else
            {
                if (SceneManager.GetInst().IsServerListEmpty())
                {
                    //场景资源加载失败
                    winRect = GUI.Window(2, winRect, DrawWindow, "加载服务器资源");
                }
                else
                {
                    //资源配置加载完成 在显示GUI数据
                    if (isResManifestDone)
                        winRect = GUI.Window(3, winRect, DrawServerList, "服务器场景资源数据列表");
                }
            }


        }


        //是否 res manifest 加载完成
        bool isResManifestDone = false;

        public void OnUpdate()
        {

            //设置资源是否加载完成
            if (!isResManifestDone)
            {
                if (ResManifest.instance.IsDone)
                    isResManifestDone = true;
            }
        }


        #region 显示场景列表资源加载，和失败

        const int WinWidth = 800;
        const int WinHeight = 600;
        //编辑器属性窗口设置
        Rect winRect = new Rect(Screen.width / 2 - WinWidth / 2, Screen.height / 2 - WinHeight / 2, WinWidth, WinHeight);

        /// <summary>
        /// 绘制数据窗口
        /// </summary>
        /// <param name="id"></param>
        void DrawWindow(int id)
        {
            if (id == 1)
            {
                GUILayout.BeginHorizontal();

                GUIDrawLabel("场景资源数据正在加载中", -1);

                GUILayout.EndHorizontal();
            }
            else if (id == 2)
            {
                GUILayout.BeginHorizontal();

                GUIDrawLabel("场景资源数据加载失败", -1);

                GUILayout.EndHorizontal();
            }

        }

        /// <summary>
        /// GUI 绘制 Label
        /// </summary>
        /// <param name="show"></param>
        /// <param name="fontSize"></param>
        void GUIDrawLabel(string show, int fontSize = -1)
        {
            if (fontSize > 0)
                GUI.skin.label.fontSize = fontSize;

            GUI.Label(new Rect(160, WinHeight * 0.5f - 20, WinWidth, WinHeight), show);
        }


        #endregion

        #region 显示服务器场景资源数据列表

        //存储滚动条位置变量
        Vector2 scrollPosi = Vector2.zero;


        /// <summary>
        /// 加载场景资源数据
        /// </summary>
        /// <param name="id"></param>
        void OnLoadScene(Scene scene)
        {
            if (scene == null || scene.map_id < 0)
                return;

            //加载场景资源数据
            if (SceneManager.GetInst().LoadScene(scene))
                canShowGUI = false;
        }

        void OnUnloadScene()
        {
            SceneManager.GetInst().UnloadScene();
            canShowGUI = true;
        }

        /// <summary>
        /// 绘制服务器列表数据
        /// </summary>
        /// <param name="id"></param>
        void DrawServerList(int id)
        {
            scrollPosi = GUILayout.BeginScrollView(scrollPosi);

            var sceneList = SceneManager.GetInst().SceneList;
            for (int i = 0; i < sceneList.Count; i++)
            {
                if (sceneList[i] != null)
                {
                    if (GUILayout.Button(" [ " + sceneList[i].id + " ]  " + sceneList[i].name_i18n))
                    {
                        OnLoadScene(sceneList[i]);
                    }
                }

            }

            GUILayout.EndScrollView();
        }

        #endregion

        #endregion

    }
}
