using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace MapEditor
{
    /// <summary>
    /// 场景资源数据管理
    /// </summary>
    public class SceneManager : MonoBehaviour
    {

        #region 单例

        /// <summary>
        /// 单例
        /// </summary>
        static SceneManager instance;
        public static SceneManager GetInst()
        {
            if (instance == null)
            {
                GameObject go = new GameObject("SceneManager");
                go.AddComponent<SceneManager>();
            }
            return instance;
        }

        SceneEditor editor;
        void Awake()
        {
            instance = this;
            editor=  new SceneEditor();

        }

        #endregion

        #region 更新数据

        /// <summary>
        /// 更新数据信息
        /// </summary>
        void Update()
        {
            editor.OnUpdate();
            //获取鼠标位置
            GetMousePos();

            //更新所有数据操作
            UpdateAllOperation();
        }

        /// <summary>
        /// 更新所有数据操作
        /// </summary>
        void UpdateAllOperation()
        {

            PathManager.GetInst().Update();

            InstanceBorder.InstanceBorderManager.Instance.OnUpdate();

            OfflineGatherManager.instance.OnUpdate();
        }

        #endregion

        #region 加载场景资源数据

        //场景资源加载进度
        float loadProgress = 0f;

        //是否正在加载场景资源数据
        public bool IsLoadScene { get; private set; }

        //当前正在加载，显示的地图id
        public int CurrShowMapId { get; private set; }

        //当前显示的场景信息数据
        public Scene CurrScene { get; private set; }

        public bool Scene_list_load_over
        {
            get
            {
                return scene_list_load_over;
            }

            set
            {
                scene_list_load_over = value;
            }
        }

        public bool IsServerListEmpty()
        {
            return SceneList == null || SceneList.Count <= 0;
        }

        /// <summary>
        /// 加载场景资源数据
        /// </summary>
        /// <param name="id"></param>
        public bool LoadScene(Scene scene)
        {
            if (scene == null || UGEMapMeta.GetMapMeta(scene.map_id) == null)
            {
                GUINotice.Show("<color=red>找不到map的Meta : <color=yellow>" + scene.map_id + "</color></color>");
                return false;
            }

            CurrScene = scene;

            CurrShowMapId = scene.map_id;
            //设置为正在加载场景资源数据
            IsLoadScene = true;

            //加载地图
            UGE.mapMgr.LoadMap(CurrShowMapId);
            RenderSettings.fog = false;
            return true;
        }
        public bool UnloadScene()
        {
            try
            {
                if (CurrScene != null)
                {
                    UGE.mapMgr.UnloadMap();
                    SpriteManager.GetInst().Reset();
                    AirWallManager.Instance.Reset();
                    QuestAreaManager.Instance.Reset();
                    InstanceBorder.InstanceBorderManager.Instance.Reset();
                    OfflineGatherManager.instance.Reset();
                    showGUI = false;
                }
            }
            catch (System.Exception ex)
            {
                Debug.Log(ex.Message);
            }
            return true;
        }

        /// <summary>
        /// 地图资源数据加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="ea"></param>
        public void OnSceneLoadOver(System.Object sender, XEventArgs ea)
        {
            if (TMapManager.EVENT_COMPLETE == ea.name)
            {
                //TTrace.Enable = false;
                //isMapLoaded = true;
                //mapGridMgr.Startup(currMapID);
                //MonsterSceneMnanger.StartUp(currSceneID);//获取场景怪 
                //MonsterPrefabMnanger.StartUp();
                //mapMonsterMgr.InitData(currMapID, currSceneID);
                //straMgr.InitData(currMapID, currSceneID);
                //ttMgr.InitData(currSceneID);
                //jpMgr.InitData(currMapID);
                //giMgr.InitData(currMapID);

                //场景资源数据加载完成
                IsLoadScene = false;
                showGUI = true;
                Debug.LogError("地图资源数据加载完成");

                //可以请求加载NavMesh 网格信息了
                NavMeshManager.GetInst().GetNavMeshFromMap();
            }
            else if (ea.name == TMapManager.EVENT_PROCESS)
            {
                loadProgress = (int)ea.data;

            }
        }

        #endregion

        #region 绘制数据

        //是否正在显示一些数据操作界面
        bool showOperation = false;

        //是否显示GUI 操作数据
        bool showGUI = false;

        //功能操作
        enum FunctionEnum
        {
            NAVMESH,                            //Navmesh 数据
            PATH,                               //轨迹（巡逻轨迹，相机运动轨迹等）
            QUEST,                              //任务
            NPC,                                                            //npc 操作
            AIRWALL,
            PatrolPath,
            INSTANCEBORDER,
            Sound,
            OfflineGather,
        }

        /// <summary>
        /// 绘制数据
        /// </summary>
        void OnGUI()
        {
            editor.OnGUI();

            if (IsLoadScene)
            {
                if (loadProgress > 75)
                {
                    GUILayout.HorizontalSlider((float)(loadProgress - 75) / 25f, 0f, 1f);
                    GUILayout.Label(string.Format("加载地图进度： {0} %", (loadProgress - 75) * 4));

                    return;
                }
            }

            if (!showGUI)
                return;

            //GUI 绘制
            if (!showOperation)
                NavMeshManager.GetInst().OnGUI();

            if (GUILayout.Button("编辑NavMesh", GUILayout.Width(300)))
            {
                showOperation = !showOperation;
                HideAllOperation();

                ShowOperation(FunctionEnum.NAVMESH);
            }

            //绘制地图场景操作
            if (GUILayout.Button("编辑轨迹点", GUILayout.Width(150)))
            {
                HideAllOperation();

                ShowOperation(FunctionEnum.PATH);
            }

            if (GUILayout.Button("编辑任务区域范围", GUILayout.Width(150)))
            {
                HideAllOperation();

                ShowOperation(FunctionEnum.QUEST);
            }

            if (GUILayout.Button("编辑NPC", GUILayout.Width(150)))
            {
                HideAllOperation();

                ShowOperation(FunctionEnum.NPC);
            }

            if (GUILayout.Button("编辑空气墙", GUILayout.Width(150)))
            {
                HideAllOperation();

                ShowOperation(FunctionEnum.AIRWALL);
            }

            if (GUILayout.Button("编辑巡逻路径", GUILayout.Width(150)))
            {
                HideAllOperation();

                ShowOperation(FunctionEnum.PatrolPath);
            }

            if (GUILayout.Button("编辑副本边界", GUILayout.Width(150)))
            {
                HideAllOperation();

                ShowOperation(FunctionEnum.INSTANCEBORDER);
            }

            if (GUILayout.Button("Sound Emitter plant", GUILayout.Width(150)))
            {
                HideAllOperation();
                ShowOperation(FunctionEnum.Sound);
            }

            if (GUILayout.Button("OfflineGather", GUILayout.Width(150)))
            {
                HideAllOperation();
                ShowOperation(FunctionEnum.OfflineGather);
            }

            //显示所有的GUI数据操作
            OnShowAllGUI();
        }

        /// <summary>
        /// 隐藏所有操作
        /// </summary>
        void HideAllOperation()
        {
            //NavMeshManager.GetInst()


            NpcManager.Instance.Enable = false;//-----

            PathManager.GetInst().Enable = false;

            QuestManager.Instance.Enable = false;

            AirWallManager.Instance.Enable = false;

            PatrolPathManager.Instance.Enable = false;

            InstanceBorder.InstanceBorderManager.Instance.Enable = false;

            SoundEmitterManager.Instance.Enable = false;

            OfflineGatherManager.instance.Enable = false;
        }

        /// <summary>
        /// 显示功能操作
        /// </summary>
        /// <param name="func"></param>
        void ShowOperation(FunctionEnum func)
        {
            switch (func)
            {
                case FunctionEnum.NAVMESH:
                    break;
                case FunctionEnum.PATH:
                    PathManager.GetInst().Show();
                    break;
                case FunctionEnum.QUEST:
                    QuestManager.Instance.Show();
                    break;
                case FunctionEnum.NPC:
                    NpcManager.Instance.Show();
                    break;
                case FunctionEnum.AIRWALL:
                    AirWallManager.Instance.Show();
                    break;
                case FunctionEnum.PatrolPath:
                    PatrolPathManager.Instance.Show();
                    break;
                case FunctionEnum.INSTANCEBORDER:
                    InstanceBorder.InstanceBorderManager.Instance.Show();
                    break;
                case FunctionEnum.Sound:
                    SoundEmitterManager.Instance.Show();
                    break;
                case FunctionEnum.OfflineGather:
                    OfflineGatherManager.instance.OnShow();
                    break;
            }

            showOperation = true;
        }

        /// <summary>
        /// 显示所有GUI操作数据
        /// </summary>
        void OnShowAllGUI()
        {

            NpcManager.Instance.OnGUI();
            PathManager.GetInst().OnGUI();
            QuestManager.Instance.OnGUI();
            AirWallManager.Instance.OnGUI();
            PatrolPathManager.Instance.OnGUI();
            InstanceBorder.InstanceBorderManager.Instance.OnGUI();
            SoundEmitterManager.Instance.OnGUI();
            OfflineGatherManager.instance.OnGUI();
        }

        /// <summary>
        /// 绘制数据
        /// </summary>
        void OnRenderObject()
        {
            //绘制网格数据
            NavMeshManager.GetInst().OnRenderObject();

            //绘制NavMesh 组成的Mesh
            NavMeshManager.GetInst().OnShowNavMeshSurface();


            NpcManager.Instance.OnRenderObject();
            //绘制Path
            PathManager.GetInst().OnRenderObject();
        }

        #endregion

        #region 获取当前鼠标在场景中的位置

        //当前鼠标位置转换成场景中的位置
        public static Vector3 MousePos;

        //鼠标点中的tran
        public static Transform MouseTran;

        /// <summary>
        /// 获取当前鼠标在场景中的位置
        /// </summary>
        void GetMousePos()
        {
            Camera cam = Camera.main;
            if (cam != null)
            {
                RaycastHit hitInfo;
                Ray ray = cam.ScreenPointToRay(Input.mousePosition);
                Debug.DrawRay(ray.origin, ray.direction);
                if (Physics.Raycast(ray, out hitInfo, 1500, GameLayer.GetInst().LayerMask))
                {
                    MousePos = hitInfo.point;
                    MouseTran = hitInfo.transform;
                }
            }
        }

        //鼠标是否在UI区域，UI 区域时不要响应鼠标对3D世界的操作（比如刷阻挡点和种怪等)
        //屏幕上部高度为200的地方，屏幕左边宽度为200的地方，是UI预留区域，点击3D世界不予响应
        public bool IsInUIArea()
        {
            if (Input.mousePosition.x < 250)
            {
                return true;
            }
            if (Input.mousePosition.y > Screen.height - 250)
            {
                return true;
            }
            return false;
        }

        #endregion


        #region 把当前场景中编辑的数据存储到服务器中

        /// <summary>
        /// 数据存储到服务器中
        /// </summary>
        public void SendToServer()
        {
            GUINotice.Confirm("是否把当前场景中的信息上传到 服务器", ConfirmSendToServer);
        }

        public void SendToServerNoNotify()
        {
            ConfirmSendToServer();
        }


        /// <summary>
        /// 确认要上传到服务器
        /// </summary>
        void ConfirmSendToServer()
        {
            //上传服务器数据确认
            //开始检测数据，上传到服务器

            if (NpcManager.Instance.Enable)
            {
                //发送删除数据
                SpriteManager.GetInst().SendRemoveSpriteInfo();
                //发送新建数据
                SpriteManager.GetInst().SendNewCreateInfo();

                //发送修改数据
                SpriteManager.GetInst().SendModifyInfo();

            }

            if (PathManager.GetInst().Enable)
            {
                //发送删除数据
                SpriteManager.GetInst().SendRemovePathInfo();
                //发送新建数据
                SpriteManager.GetInst().SendInsertNewPathInfo();

                //发送修改数据
                SpriteManager.GetInst().SendUpdatePathInfo();

            }

            if (QuestManager.Instance.Enable)
            {
                //发送删除数据
                QuestAreaManager.Instance.SendDeleteInfo();
                //发送新建数据
                QuestAreaManager.Instance.SendNewCreateInfo();

                //发送修改数据
                QuestAreaManager.Instance.SendUpdateInfo();


            }

            if (AirWallManager.Instance.Enable)
            {
                //发送删除数据
                AirWallManager.Instance.SendDeleteInfo();
                //发送新建数据
                AirWallManager.Instance.SendNewCreateInfo();

                //发送修改数据
                AirWallManager.Instance.SendUpdateInfo();

            }

            if (SoundEmitterManager.Instance.Enable)
            {
                //发送删除数据
                SoundEmitterManager.Instance.SendDeleteInfo();
                //发送新建数据
                SoundEmitterManager.Instance.SendNewCreateInfo();

                //发送修改数据
                SoundEmitterManager.Instance.SendUpdateInfo();

            }
            UpdateSceneDataByAddOrChangeSoundGroup();
        }


        /// <summary>
        /// 因添加或更换音效组而产生的更新
        /// </summary>
        void UpdateSceneDataByAddOrChangeSoundGroup()
        {
            Debug.Log("send update");
            if (CurrScene == null)
            {
                return;
            }
            if (CurrScene.isDirty)
            {
                var form = CurrScene.SerializeToForm();
                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.Scene_UPDATE, form, ONSendUpdateOver, CurrScene.id));
            }
        }

        private void ONSendUpdateOver(WWWMessage arg1, object arg2)
        {
            UnityEngine.Debug.Log("update over");
            int id = (int)arg2;
            if (arg1.success)
            {
                CurrScene.isDirty = false;
            }
            else
            {
                Debug.LogErrorFormat("数据id为{0}更新失败 !\n {1}", id, arg1);
                GUINotice.Show(arg1.msg[0]);
            }
        }


        #endregion

        #region 地图列表数据

        //标识场景资源数据是否加载完成
        bool scene_list_load_over = false;

        //场景数据资源列表
        public List<Scene> SceneList = null;

        /// <summary>
        /// 开始加载服务器列表资源数据
        /// </summary>
        public void StartLoadServerSceneList()
        {
            StartCoroutine(LoadServerData(Config.SERVER_LIST_URL, LoadServerSceneInfo));
        }

        private IEnumerator LoadServerData(string url, System.Action<string> action)
        {
            if (string.IsNullOrEmpty(url))
                yield return null;

            //using (WWW www = new WWW(url))
            WWW www = new WWW(url);
            {
                yield return www;

                if (action != null)
                {
                    if (!string.IsNullOrEmpty(www.error))
                        Debug.LogError(" www is error " + www.error + "      " + url);
                    string json = www.text.Replace("\"true\"", "true").Replace("\"false\"", "false");
                    action(json);
                }
                www.Dispose();
            }
        }

        /// <summary>
        /// 加载服务器场景资源信息
        /// </summary>
        /// <param name="www"></param>
        /// <param name="parameter"></param>
        void LoadServerSceneInfo(string text)
        {


            //资源加载失败，返回
            if (string.IsNullOrEmpty(text))
            {
                Debug.LogError("返回了场景列表数据为空");
                return;
            }


            //解析服务器列表数据
            string[] strs = text.Split('\n');
            if (strs == null || strs.Length == 0)
                return;

            //数据清理
            if (SceneList == null)
                SceneList = new List<Scene>();
            SceneList.Clear();

            //存储场景资源数据信息
            for (int i = 0; i < strs.Length; i++)
            {
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                Scene info = JsonUtility.FromJson(strs[i], typeof(Scene)) as Scene;
                if (info == null)
                    continue;

                //存储数据信息
                SceneList.Add(info);
            }

            //设置场景资源数据加载完成
            Scene_list_load_over = true;
        }


        #endregion

    }
}


