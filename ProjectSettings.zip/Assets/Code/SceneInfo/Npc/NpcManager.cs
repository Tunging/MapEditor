using UnityEngine;
using System.Collections.Generic;
using NavMesh.Camera;
using System;
using System.Collections;
using ZTool.Table;
using Tgame.Game.Table;

namespace MapEditor
{

    /// <summary>
    /// 怪物编辑，种怪
    /// </summary>
    public class NpcManager
    {

        #region 单例

        static NpcManager instance;
        public static NpcManager Instance
        {
            get
            {
                if (instance == null)
                    instance = new NpcManager();
                return instance;
            }
        }

        private NpcManager()
        {
            //属性数据编辑修改
            sceneNpcPro = new NpcProEditor();
        }

        #endregion

        #region 属性控制

        //是否启用
        public bool Enable { get; set; }

        //npc 属性 控制
        NpcProEditor sceneNpcPro;


        #endregion

        #region 更新当前选中显示的数据

        /// <summary>
        /// 设置显示编辑的 sprite数据
        /// </summary>
        public void SetShowEditorSprite(SpriteInfo info)
        {
            if (sceneNpcPro != null)
                sceneNpcPro.SetCurrEditorInfo(info);
        }

        #endregion

        #region 数据更新

        /// <summary>
        /// 显示操作信息
        /// </summary>
        public void Show()
        {
            if (Enable)
                return;

            Enable = true;

            if (modelList != null)
            {
                modelList.Clear();
            }
            SpriteManager.GetInst().Reset();

            //获取服务器模型数据信息
            GetNpcModelInfo();
        }
        
        #endregion
        #region 获取服务器模型数据列表

        //怪物数据列表
        List<NpcModel> modelList;

        /// <summary>
        /// 获取服务器怪物信息数据
        /// </summary>
        void GetNpcModelInfo()
        {
            var tableNpcTempList = Table_Npc.GetAllPrimaryList();

            //数据清理
            if (modelList == null)
                modelList = new List<NpcModel>();
            modelList.Clear();

            foreach (var tableNpc in tableNpcTempList)
            {
                if (tableNpc == null)
                {
                    Debug.LogError("npc data is null ");
                    continue;
                }
                
                var tableResource = Table_Npc_Resource.GetPrimary(tableNpc.resource_id);
                if (tableResource == null)
                {
                    Debug.LogError("npc resource is null ,id = " + tableNpc.resource_id);
                    continue;
                }
                var tableModel = Table_Client_Model.GetPrimary(tableResource.model_id);
                if (tableModel == null)
                {
                    Debug.LogError("client model is null , id= " + tableResource.model_id);
                    continue;
                }

                var info = new NpcModel
                {
                    id = tableNpc.id,
                    name_i18n = tableNpc.name_i18n,
                    //level = npc.level,
                    resources_id = tableResource.id,
                    path = tableModel.path,
                    model_scale = tableResource.model_scale
                };

                //存储数据信息
                modelList.Add(info);
            }

            GetServerSceneNpc();
        }

        /// <summary>
        /// 获取npc 模型数据
        /// </summary>
        /// <param name="npcId">npc id </param>
        /// <returns></returns>
        public NpcModel GetNpcModel(int npcId)
        {
            if (npcId <= 0)//|| modelList == null || modelList.Count == 0)
                return null;

            for (int i = 0; i < modelList.Count; i++)
            {
                if (modelList[i] != null && modelList[i].id == npcId)
                    return modelList[i];
            }

            return null;
        }

        #endregion

        #region 获取服务器 scene_npc 数据列表

        //存储服务器上已经存在的 scene npc 数据
        List<SpriteInfo> sceneNpcList = null;

        /// <summary>
        /// 获取服务器中 scene npc 数据
        /// </summary>
        void GetServerSceneNpc()
        {
            //开始请求数据
            string url = string.Format("{0}{1}", Config.NPC_LIST, SceneManager.GetInst().CurrScene.id);
            SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(url, GetServerSceneNpcInfoOver));
        }

        /// <summary>
        /// 获取 scene npc 信息数据完成
        /// </summary>
        /// <param name="www"></param>
        /// <param name="parameter"></param>
        void GetServerSceneNpcInfoOver(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                GUINotice.Show("<color=red> 找不到当前场景中的 Npc 信息数据 </color>");
                return;
            }

            //解析服务器列表数据
            string[] strs = text.Split('\n');
            if (strs == null || strs.Length == 0)
                return;

            //数据清理
            if (sceneNpcList == null)
                sceneNpcList = new List<SpriteInfo>();
            sceneNpcList.Clear();

            //存储场景资源数据信息
            for (int i = 0; i < strs.Length; i++)
            {
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                string json = strs[i].ToLower().Replace("\"true\"", "true").Replace("\"false\"", "false");
                SpriteInfo info = JsonUtility.FromJson(strs[i], typeof(SpriteInfo)) as SpriteInfo;
                if (info == null)
                    continue;

                //存储数据信息
                sceneNpcList.Add(info);
            }
            Debug.Log("-----------------------------             " + sceneNpcList.Count + "       =====================");
            //数据加载完成，那么就需要在场景中创建出来
            for (int i = 0; i < sceneNpcList.Count; i++)
            {
                SpriteManager.GetInst().CreateServerSprite(sceneNpcList[i]);
            }
        }

        #endregion



        #region 数据绘制

        //编辑器属性窗口设置
        Rect winRect = new Rect(300, 0, 600, 220);

        /// <summary>
        /// 数据绘制
        /// </summary>
        public void OnGUI()
        {
            if (!Enable)
                return;

            //显示GUI操作面板数据
            ShowGUIOperation();

            //绘制monster 属性数据
            if (sceneNpcPro != null)
                sceneNpcPro.OnGUI();

            //处理鼠标操作
            ProcessMouseEvent();
        }

        /// <summary>
        /// 绘制对象数据
        /// </summary>
        public void OnRenderObject()
        {
            if (!Enable)
                return;

            if (sceneNpcPro != null)
                sceneNpcPro.OnRenderObject();
        }

        #region 显示GUI数据操作

        //gui显示操作数据
        string[] guiOperationArr = new string[] { "关闭全部", "显示Npc模型列表", "显示已存在Npc列表" };
        int subViewIdx = 0;

        /// <summary>
        /// 显示GUI操作
        /// </summary>
        void ShowGUIOperation()
        {
            subViewIdx = GUILayout.SelectionGrid(subViewIdx, guiOperationArr, 2, GUILayout.Width(300), GUILayout.Height(60));
            switch (subViewIdx)
            {
                case 0:
                    showModelList = false;
                    showNpcList = false;
                    break;
                case 1:
                    showModelList = true;
                    break;
                case 2:
                    showNpcList = true;
                    break;
            }

            //显示怪物列表数据
            OnShowNpcModelList();

            //显示已经存在的npc列表数据
            OnShowHaveNpcList();
        }

        #endregion

        #region 显示Npc 模型列表

        //位置控制
        Rect modelListRect = new Rect(0, 300, 300, Screen.height - 300 - 20);
        Vector2 modelListScrollPosi = new Vector2();

        //是否显示模型列表数据
        bool showModelList = true;

        /// <summary>
        /// 显示模型列表数据
        /// </summary>
        void OnShowNpcModelList()
        {
            if (modelList == null || modelList.Count == 0
                || !showModelList)
                return;

            modelListRect = GUI.Window(2, modelListRect, DrawModelList, "npc_model列表");
        }

        /// <summary>
        /// 绘制怪物列表数据
        /// </summary>
        /// <param name="id"></param>
        void DrawModelList(int id)
        {
            GUILayout.Label("左键点击两下：种NPC");
            GUILayout.Label("左键点击一下：选中NPC");
            //GUILayout.Label("右键点击一下：删除Npc");
            GUILayout.Label("右键点击两下：清除预览");
            GUILayout.Label("Delete：删除NPC");

            modelListScrollPosi = GUILayout.BeginScrollView(modelListScrollPosi);

            for (int i = 0; i < modelList.Count; i++)
            {
                if (modelList[i] != null)
                {
                    if (GUILayout.Button(modelList[i].id + "_" + modelList[i].name_i18n))
                    {
                        SpriteManager.GetInst().LoadModel(modelList[i].id, modelList[i].resources_id, modelList[i].path, modelList[i].name_i18n);
                    }
                }
            }

            GUILayout.EndScrollView();
        }

        #endregion

        #region 显示已经存在的 Npc 列表

        //是否显示已经存在的npc列表数据
        bool showNpcList = false;

        //显示已经存在的npc列表数据
        void OnShowHaveNpcList()
        {
            if (!showNpcList)
                return;

            SpriteManager.GetInst().SpriteOnGUI();
        }

        #endregion

        #endregion


        #region 鼠标操作种怪，取消等操作

        /// <summary>
        /// 处理鼠标事件
        /// </summary>
        void ProcessMouseEvent()
        {

            //移除对象数据
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                var sprite = SpriteManager.GetInst().GetSpriteFromPos();
                if (sprite != null)
                {
                    SpriteManager.GetInst().RemoveSpriteFromList(sprite);
                    SetShowEditorSprite(null);
                }
            }

            //对焦当前选中的目标
            if (Input.GetKeyDown(KeyCode.F))
            {
                if (sceneNpcPro != null && sceneNpcPro.Data != null && sceneNpcPro.Data.sprite != null)
                {
                    CameraMove.GetInst().CameraLookAtTarget(sceneNpcPro.Data.sprite.gameObject);
                }
            }

            //获取鼠标事件
            var e = Event.current;
            if (e == null || !e.isMouse)
                return;

            if (e.clickCount == 1)
            {
                //if(e.button == 0)
                //{
                //    //左键一下 选中目标
                //    var sprite = SpriteManager.GetInst().GetSpriteFromPos();
                //    if(sprite != null)
                //    {
                //        //当前选中了一个 monster
                //        SetShowEditorSprite(sprite.data);
                //    }
                //    //else
                //    //{
                //    //    //设置为未选中目标
                //    //    SetShowEditorSprite(null);
                //    //}
                //}
                //else if(e.button == 1)
                //{
                //    //右键一下 删除选中目标
                //    var sprite = SpriteManager.GetInst().GetSpriteFromPos();
                //    if(sprite != null)
                //    {
                //        SpriteManager.GetInst().RemoveSpriteFromPos();
                //        SetShowEditorSprite(null);
                //    }
                //}
            }
            else if (e.clickCount == 2)
            {
                if (e.button == 0)
                {
                    //左键两下 种怪
                    //当前已经有模型选中显示，并且不是正在加载新的 model
                    if (SpriteManager.GetInst().ShowSprite() && !SpriteManager.GetInst().IsLoadModel)
                    {
                        var m = SpriteManager.GetInst().CreateNewSprite();
                        //设置好被编辑的目标
                        SetShowEditorSprite(m.data);
                    }

                }
                else if (e.button == 1)
                {
                    //右键两下 取消当前鼠标怪物预览
                    if (SpriteManager.GetInst().ShowSprite())
                    {
                        SpriteManager.GetInst().UnLoadShowSprite();
                        SetShowEditorSprite(null);
                    }
                }
            }
        }

        #endregion



        //#region 检测当前鼠标是否点中了GUI

        ///// <summary>
        ///// 鼠标是否点在了 GUI区域
        ///// </summary>
        ///// <returns></returns>
        //public bool IsInUIArea()
        //{
        //    if (Enable)
        //        return false;

        //    if(monsterList != null && monsterList.Count > 0)
        //    {
        //        Vector2 pos = Input.mousePosition;
        //        if (pos.x <= 300 && pos.y <= 600)
        //            return true;
        //    }

        //    return false;
        //}

        //#endregion
    }

}
