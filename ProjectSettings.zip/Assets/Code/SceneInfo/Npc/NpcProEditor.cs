using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using TransformGizmos;

namespace MapEditor
{

    /// <summary>
    /// 怪物属性编辑
    /// </summary>
    public class NpcProEditor
    {

        //初始化数据
        public NpcProEditor()
        {
            //加载描边效果
            LoadOutLineShader();
        }

        #region 属性数据

        //当前选中的 npc 属性
        SpriteInfo data;
        public SpriteInfo Data { get { return data; } }

        //子窗口要显示的东西
        int subViewIdx = 0;

        //子窗口显示数组名字
        //副本中显示
        string[] subViewArrCopy = { "基础数据", "波次", "方向", "巡逻" };

        //世界场景显示
        string[] subViewArr = { "基础数据", "复活", "方向", "巡逻" };

        //巡逻方式
        string[] patrolType = { "不巡逻", "随机点" };//, "往返路线", "随机路线" };
        //当前选择的巡逻路点 id
        int currSelectPatrolId = -1;

        //转角, 转向角度
        Vector3 angleAix = Vector3.zero;

        #endregion


        #region 操作绘制

        /// <summary>
        /// 设置当前编辑的数据
        /// </summary>
        /// <param name="info"></param>
        public void SetCurrEditorInfo(SpriteInfo info)
        {
            //如果当前已经有 显示模型，那么去除模型描边效果
            if (data != null && data.sprite != null)
                HideOutLine(data.sprite.gameObject);

            data = info;
            //给当前选中模型添加描边效果
            if (data != null && data.sprite != null)
                ShowOutLine(data.sprite.gameObject);

            //默认设置为已修改
            if (data != null && data.isSynchronizationServer)
                data.isSynchronizationServer = false;

            //设置轨迹数据
            NpcPatrolEditor.GetInst().SetEditorInfo(data);
        }

        Rect winRect = new Rect(300, 0, 600, 300);

        /// <summary>
        /// 数据绘制
        /// </summary>
        public void OnGUI()
        {
            winRect = GUI.Window(1, winRect, DrawWindow, " NPC 属性编辑");

            //巡逻GUI
            if (subViewIdx == 3)
                NpcPatrolEditor.GetInst().PatrolGUI();
        }

        ///npc属性窗口
        void DrawWindow(int id)
        {

            if (Data == null)
            {
                GUILayout.Label("当前未选中怪");
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("保存到服务器", GUILayout.Height(30)))
                {
                    SceneManager.GetInst().SendToServer();
                }
                GUILayout.EndHorizontal();
                return;
            }

            GUILayout.Label("当前地图：" + Data.scene_id + " 当前选中怪：<color=red>" + Data.name_i18n + "</color> 【NPC ID：<color=red>" + Data.guid + "</color>】\n位置【x：" + Data.pos.x + "】【y:" + Data.pos.y + "】【z：" + Data.pos.z + "】"
                + "\n当前角度：" + data.angle);// Math.Round(SetNpcRangle(Data.dy, Data.dx)) + " 向量：" + (float)Data.dx + "_" + (float)Data.dy);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("保存到服务器", GUILayout.Height(30)))
            {
                SceneManager.GetInst().SendToServer();
            }
            GUILayout.EndHorizontal();


            //功能子窗口
            if (SceneManager.GetInst().CurrScene.type == 0)
                subViewIdx = GUILayout.SelectionGrid(subViewIdx, subViewArr, subViewArr.Length, GUILayout.Width(550), GUILayout.Height(30));
            else if (SceneManager.GetInst().CurrScene.type == 1)
                subViewIdx = GUILayout.SelectionGrid(subViewIdx, subViewArrCopy, subViewArrCopy.Length, GUILayout.Width(550), GUILayout.Height(30));

            switch (subViewIdx)
            {

                case 0:
                    //设置基础数据
                    GUILayout.BeginVertical();
                    if (Data.isServer)
                        GUILayout.Label("guid: <color=red>" + Data.guid + "</color>");
                    else
                        Data.guid = GUIUtils.NumberField("guid: ", Data.guid);

                    DrawChangeNpcTemplate();

                    //设置名字
                    Data.name = GUIUtils.StrField("Name:", Data.name);
                    Data.name_i18n = GUIUtils.StrField("Name_i18n:", Data.name_i18n);

                    Data.is_hidden = GUIUtils.BoolField("是否隐藏，隐藏时只能通过AI刷新:", Data.is_hidden);

                    //Data.AddPatrolPos、
                    Data.group_id = GUIUtils.NumberField("group_id:", Data.group_id);

                    Data.enter_scene_delay_time = GUIUtils.NumberField("enter_scene_delay_time", Data.enter_scene_delay_time);

                    GUILayout.EndVertical();
                    break;
                case 1:
                    if (SceneManager.GetInst().CurrScene.type == 0)
                    {
                        //世界地图
                        GUILayout.BeginHorizontal();

                        Data.relive_interval = GUIUtils.NumberField("复活时间间隔（ms）", Data.relive_interval);
                        GUILayout.EndHorizontal();
                    }
                    else if (SceneManager.GetInst().CurrScene.type == 1)
                    {
                        //副本
                        GUILayout.BeginHorizontal();

                        Data.is_join_refresh = GUILayout.Toggle(Data.is_join_refresh, "是否影响下一波刷新", GUILayout.Height(25));
                        Data.refresh_sequence = GUIUtils.NumberField("在第几波刷新", Data.refresh_sequence);
                        Data.refresh_delay_time = GUIUtils.NumberField("设置刷新延迟时间(ms)", Data.refresh_delay_time);

                        GUILayout.EndHorizontal();

                        //副本中才有刷新波次的概念
                        GUILayout.BeginHorizontal();

                        if (GUILayout.Button("查看波次", GUILayout.Height(30)))
                        {
                            if (Data.refresh_sequence > 0)
                            {
                                int len = UGE.trmContainers.sprsContainer.transform.childCount;
                                for (int i = 0; i < len; i++)
                                {
                                    Transform tran = UGE.trmContainers.sprsContainer.GetChild(i);
                                    int type = int.Parse(tran.name.Split('_')[0]);
                                    if (type != Data.refresh_sequence)
                                    {
                                        tran.gameObject.SetActive(false);
                                    }
                                    else
                                        tran.gameObject.SetActive(true);
                                }
                            }

                        }
                        if (GUILayout.Button("查看全部", GUILayout.Height(30)))
                        {
                            int len = UGE.trmContainers.sprsContainer.transform.childCount;
                            for (int i = 0; i < len; i++)
                            {
                                Transform tran = UGE.trmContainers.sprsContainer.GetChild(i);
                                tran.gameObject.SetActive(true);
                            }
                        }
                        GUILayout.EndHorizontal();
                    }
                    break;
                case 2:

                    //方向
                    GUILayout.BeginHorizontal();

                    angleAix.x = GUIUtils.NumberField("X轴旋转角度", angleAix.x);
                    angleAix.y = GUIUtils.NumberField("Y轴旋转角度", angleAix.y);
                    angleAix.z = GUIUtils.NumberField("Z轴旋转角度", angleAix.z);

                    GUILayout.EndHorizontal();

                    if (GUILayout.Button("查看方向", GUILayout.Height(30)))
                    {

                        Quaternion rotation = Quaternion.Euler(angleAix);
                        Data.sprite.transform.localRotation = rotation;
                        Vector3 forward = Data.sprite.transform.forward;

                        //设置朝向
                        //Data.dx = GameUtils.Round(forward.x);
                        //Data.dy = GameUtils.Round(forward.y);
                        //Data.dz = GameUtils.Round(forward.z);

                        Data.angle = data.sprite.transform.eulerAngles.y;
                    }
                    break;
                case 3:
                    //巡逻
                    data.patrol_type = GUILayout.SelectionGrid(data.patrol_type, patrolType, patrolType.Length, GUILayout.Width(550), GUILayout.Height(30));
                    if (data.patrol_type > 0)
                    {
                        //有巡逻数据的时候，显示巡逻数据
                        GUILayout.Label("左键双击：新加点， Delete 移除点  ");
                        Data.patrol_rest_time = GUIUtils.NumberField("巡逻休息时间（ms）", Data.patrol_rest_time);
                    }

                    break;
            }

            //设置是否显示 patrol
            Data.ShowOrHideAllPatrolPos(subViewIdx == 3 ? data.patrol_type < 1 ? false : true : false);
        }

        private void DrawChangeNpcTemplate()
        {
            GUILayout.BeginHorizontal();
            //GUILayout.Label("template id :");
            int templateid = Data.npc_id;
            templateid = GUIUtils.NumberField("template id", templateid);
            Data.npc_id = templateid;
            if (GUILayout.Button("<color=#ff0000>应用新模板</color>"))
            {
                var sprite = SpriteManager.GetInst().UpdateSpriteShow(Data);
                if (sprite != null)
                {
                    Data.cached_npc_id = Data.npc_id;

                    Data.isSynchronizationServer = false;
                }
                else
                {
                    Data.npc_id = Data.cached_npc_id;
                    SpriteManager.GetInst().UpdateSpriteShow(Data);
                }
            }
            GUILayout.EndHorizontal();
        }

        //绘制数据
        public void OnRenderObject()
        {
            //绘制巡逻数据
            NpcPatrolEditor.GetInst().OnRenderObject();
        }

        #endregion


        #region 显示模型描边

        //模型描边shader
        Shader outLine;
        List<Shader> tempShader = new List<Shader>();


        //描边材质球，以及显示描边之前的材质球个数
        Material outLineMat;
        List<int> matCountList = new List<int>();

        /// <summary>
        /// 加载描边shader
        /// </summary>
        void LoadOutLineShader()
        {
            if (outLine == null)
                outLine = Resources.Load<Shader>("Shader/OutLine");

            if (outLineMat == null)
                outLineMat = Resources.Load<Material>("Materials/OutLine");
        }

        /// <summary>
        /// 显示模型描边效果
        /// </summary>
        void ShowOutLine(GameObject go)
        {
            if (go == null)
                return;

            Renderer[] renderer = go.GetComponentsInChildren<Renderer>();
            if (renderer != null && renderer.Length > 0)
            {
                for (int i = 0; i < renderer.Length; i++)
                {
                    List<Material> mats = new List<Material>();
                    mats.AddRange(renderer[i].materials);
                    matCountList.Add(mats.Count);

                    mats.Add(outLineMat);

                    renderer[i].materials = mats.ToArray();
                }
            }


            ////遍历当前模型上所有的 renderer, 并且保存，替换当前正在使用的shader
            //SkinnedMeshRenderer[] tempskin = go.GetComponentsInChildren<SkinnedMeshRenderer>();
            //if (tempskin != null)
            //{

            //    for (int i = 0; i < tempskin.Length; i++)
            //    {
            //        tempShader.Add(tempskin[i].material.shader);
            //        tempskin[i].material.shader = outLine;
            //    }
            //}
        }

        /// <summary>
        /// 隐藏模型描边效果
        /// </summary>
        /// <param name="go"></param>
        void HideOutLine(GameObject go)
        {
            if (go == null)
                return;

            Renderer[] renderer = go.GetComponentsInChildren<Renderer>();
            if (renderer != null && renderer.Length > 0)
            {
                for (int i = 0; i < renderer.Length; i++)
                {
                    if (matCountList.Count <= i)
                        continue;

                    List<Material> mats = new List<Material>();
                    for (int j = 0; j < matCountList[i]; j++)
                    {
                        mats.Add(renderer[i].materials[j]);
                    }
                    renderer[i].materials = mats.ToArray();
                }
            }

            matCountList.Clear();

            ////遍历当前模型上所有的 renderer, 并且还原shader
            //SkinnedMeshRenderer[] tempskin = go.GetComponentsInChildren<SkinnedMeshRenderer>();
            //if (tempskin != null)
            //{
            //    for (int i = 0; i < tempskin.Length; i++)
            //    {
            //        tempskin[i].material.shader = tempShader[0];
            //        tempShader.RemoveAt(0);
            //    }
            //}
            //tempShader.Clear();
        }

        #endregion


        #region 角度转换

        //获取角度数据
        float SetNpcRangle(double x1, double y1)
        {
            float angleline = (float)(Math.Atan2(y1, x1) * 180 / Math.PI);//= *Mathf.Deg2Rad;
            return angleline;
        }

        #endregion

    }

}
