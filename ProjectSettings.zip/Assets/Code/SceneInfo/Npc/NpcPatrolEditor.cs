﻿using NavMesh.Camera;
using TransformGizmos;
using UnityEngine;

namespace MapEditor
{

    /// <summary>
    /// scene npc 巡逻数据编辑
    /// </summary>
    public class NpcPatrolEditor
    {

        #region 单例

        static NpcPatrolEditor instance;
        public static NpcPatrolEditor GetInst()
        {
            if (instance == null)
                instance = new NpcPatrolEditor();
            return instance;
        }

        /// <summary>
        /// 初始化
        /// </summary>
        public NpcPatrolEditor()
        {
            LoadPatrolPointMat();
        }

        #endregion

        #region 数据编辑

        public SpriteInfo Data { get; private set; }

        //当前选择的 轨迹点id
        int currSelectPatrolId;

        /// <summary>
        /// 设置显示编辑数据
        /// </summary>
        /// <param name="info"></param>
        public void SetEditorInfo(SpriteInfo info)
        {
            //隐藏所有的 轨迹点数据
            if (Data != null)
                Data.ShowOrHideAllPatrolPos(false);

            Data = info;

            //显示所有的轨迹点数据
            if (Data != null)
            {
                Data.ShowOrHideAllPatrolPos(true);
                //如果还没有同步 轨迹点数据，那么就同步数据
                if (!Data.isSyncPatrolPoints)
                {
                    Data.StringToPatrolPos();
                    if(Data.patrolPosList != null && Data.patrolPosList.Count > 0)
                    {
                        for (int i = 0; i < Data.patrolPosList.Count; i++)
                        {
                            //创建 轨迹点对象数据
                            CreatePatrolPoint(Data.patrolPosList[i]);
                        }
                    }
                }
            }
        }

        #endregion

        #region 逻辑更新

        /// <summary>
        /// 创建新的 巡逻点数据
        /// </summary>
        public SpritePatrolPoint CreatePatrolPoint(Vector3 pos)
        {
            var go = new GameObject();
            var sprite = go.AddComponent<SpritePatrolPoint>();
            sprite.transform.parent = Data.sprite.transform;

            //添加存储 巡逻点数据
            Data.AddPatrolPos(sprite);

            //开始创建数据
            sprite.Startup(Data, pos);

            return sprite;
        }


        #endregion

        #region 数据绘制

        #region GUI

        //点信息
        Rect pointRect = new Rect(900, 0, 250, 250);
        Vector2 spriteListScrollPosi = new Vector2();

        public void PatrolGUI()
        {
            if(Data != null && Data.patrol_type > 0)
            {
                pointRect = GUI.Window(200, pointRect, DrawPointWindow, " Point 属性编辑");

                //操作
                CheckMouseOperationPatrolInfo();
            }
        }

        //绘制 point 信息
        void DrawPointWindow(int id)
        {
            //显示多个小球的点数据信息

            if (Data!=null && Data.spritePatrolPointsList!=null && Data.spritePatrolPointsList.Count == 0)
                return;

            spriteListScrollPosi = GUILayout.BeginScrollView(spriteListScrollPosi);

            SpritePatrolPoint spp = null;
            for (int i = 0; i < Data.spritePatrolPointsList.Count; i++)
            {
                spp = Data.spritePatrolPointsList[i];
                if (spp != null)
                {
                    Transform tran = spp.transform;
                    if (GUILayout.Button(i + "_[" + tran.position.x + ", " + tran.position.y + ", " + tran.position.z + "]"))
                    {
                        //点击自动定位到相应的小球
                        CameraMove.GetInst().CameraLookAtTarget(spp.gameObject);
                        TransformGizmo.GetInst().SetTraget(tran);
                        currSelectPatrolId = i;
                    }

                }
            }

            GUILayout.EndScrollView();
        }

        //是否可以删除标识
        bool isCanDelete = true;

        /// <summary>
        /// 鼠标操作 巡逻数据
        /// </summary>
        void CheckMouseOperationPatrolInfo()
        {
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                if (isCanDelete)
                {
                    isCanDelete = false;
                    //移除 巡逻点数据
                    Data.RemovePatrolPos(currSelectPatrolId);
                }
            }

            if(Input.GetKeyUp(KeyCode.Delete))
            {
                if (!isCanDelete)
                    isCanDelete = true;
            }

            var e = Event.current;
            if (e == null || !e.isMouse)
                return;
            if (e.clickCount == 2
                && e.button == 0)
            {
                //鼠标左键，点击2下 创建一个新的点
                SpritePatrolPoint spp = CreatePatrolPoint(SceneManager.MousePos);
                if (spp != null)
                {
                    //设置当前选中数据
                    currSelectPatrolId = Data.spritePatrolPointsList.Count - 1;

                    TransformGizmo.GetInst().SetTraget(spp.transform);
                }
            }

        }

        #endregion



        //绘制线段使用的 line
        Material lineMat;
        string linePath = "Materials/Navmesh";

        /// <summary>
        /// 加载巡逻对象数据
        /// </summary>
        void LoadPatrolPointMat()
        {
            if (lineMat == null)
                lineMat = new Material(Shader.Find("Sprites/Default"));
        }

        //巡逻点数组
        Vector3[] patrolPointsArr;

        /// <summary>
        /// 绘制 巡逻点 连线数据
        /// </summary>
        public void OnRenderObject()
        {
            if (Data == null
                || Data.patrol_type <= 1)
                return;

            //没有 mat
            if (lineMat == null)
                return;

            patrolPointsArr = Data.GetPatrolPosArr();
            if (patrolPointsArr == null || patrolPointsArr.Length <= 1)
                return;

            //绘制 points 数据信息
            OnDrawPatrolPoints();
        }

        /// <summary>
        /// 绘制 巡逻点数据信息
        /// </summary>
        void OnDrawPatrolPoints()
        {
            lineMat.SetPass(0);
            //GL.PushMatrix();

            Vector3 prePos;
            //if (ShowPathInfo.isClosedLoop)
            //    prePos = patrolPointsArr[patrolPointsArr.Length - 1];
            //else
            prePos = patrolPointsArr[0];
            Vector3 currPos = patrolPointsArr[0];

            GL.Begin(GL.LINES);

            //设置线段颜色 默认为红色
            if (Data.patrol_type == 3)
                GL.Color(Color.yellow);
            else
                GL.Color(Color.red);

            for (int i = 0; i < patrolPointsArr.Length; i++)
            {
                currPos = patrolPointsArr[i];

                GL.Vertex(prePos);
                GL.Vertex(currPos);

                prePos = currPos;
            }

            GL.End();
        }

        #endregion
    }

}
