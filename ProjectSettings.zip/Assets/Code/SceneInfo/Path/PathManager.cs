﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using ZTool.Res;

namespace MapEditor
{

    public class PathManager
    {

        #region 单例

        static PathManager instance;
        public static PathManager GetInst()
        {
            if (instance == null)
                instance = new PathManager();

            return instance;
        }

        public PathManager()
        {
            LoadPointPrefab();

            pathEditor = new PathInfoEditor();
        }

        #endregion

        #region 属性控制

        //是否启用
        public bool Enable { get; set; }

        //path 编辑显示
        PathInfoEditor pathEditor;

        /// <summary>
        /// 设置显示的数据编辑
        /// </summary>
        /// <param name="info"></param>
        public void SetShowPathInfo(PathInfo info)
        {
            if (pathEditor != null)
                pathEditor.SetShowPathInfo(info);
        }

        #endregion

        #region 数据更新

        /// <summary>
        /// 显示操作信息
        /// </summary>
        public void Show()
        {
            if (Enable)
                return;

            Enable = true;

            //获取服务器轨迹数据信息
            LoadServerPathPoints();
        }

        /// <summary>
        /// 数据更新
        /// </summary>
        public void Update()
        {
            if (!Enable)
                return;

            //鼠标在UI 区域时不处理相应3D场景数据
            if (SceneManager.GetInst().IsInUIArea())
            {
                return;
            }

        }

        #region 获取服务器数据

        //存储服务器加载的轨迹数据
        List<PathInfo> pathList;

        //服务器资源数据是否已经加载解析完成
        bool serverPathLoadOver = false;

        /// <summary>
        /// 获取服务器轨迹信息数据
        /// </summary>
        public void LoadServerPathPoints()
        {
            serverPathLoadOver = false;

            string url = string.Format("{0}{1}", Config.CAMERA_PATH_LIST, SceneManager.GetInst().CurrScene.id);

            SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(url, LoadServerPathPointsOver));
        }

        /// <summary>
        /// 获取服务器轨迹信息数据
        /// </summary>
        /// <param name="www"></param>
        /// <param name="parameter"></param>
        void LoadServerPathPointsOver(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                GUINotice.Show("<color=red> 找不到Path信息数据 </color>");
                return;
            }

            //解析服务器列表数据
            string[] strs = text.Split('\n');
            if (strs == null || strs.Length == 0)
                return;

            //数据清理
            if (pathList == null)
                pathList = new List<PathInfo>();
            pathList.Clear();

            //存储场景资源数据信息
            for (int i = 0; i < strs.Length; i++)
            {
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                PathInfo info = JsonUtility.FromJson(strs[i], typeof(PathInfo)) as PathInfo;
                if (info == null)
                    continue;

                //path 转换顶点数据
                info.StringToPoints();

                //存储数据信息
                pathList.Add(info);
            }

            //设置存储服务器中的 path 信息
            SpriteManager.GetInst().SetServerPathInfo(pathList);

            //创建出服务器轨迹数据列表
            for (int i = 0; i < pathList.Count; i++)
            {
                if (pathList[i] != null)
                {
                    SpriteManager.GetInst().CreateServerPoint(pathList[i]);
                }
            }

            serverPathLoadOver = true;
        }

        #endregion

        #endregion


        #region 数据绘制

        //绘制点资源数据
        GameObject point;
        string pointPath = "Point";

        /// <summary>
        /// 加载显示点数据模型
        /// </summary>
        void LoadPointPrefab()
        {

            if(point == null)
            {
                //加载显示资源数据
                point = Resources.Load<GameObject>(pointPath);
            }
        }

        /// <summary>
        /// 数据绘制
        /// </summary>
        public void OnGUI()
        {
            if (!Enable)
                return;

            //显示数据编辑
            if (pathEditor != null)
                pathEditor.OnGUI();

            //显示GUI 操作
            ShowGUIOperation();

            //处理鼠标操作
            ProcessMouseEvent();
        }

        /// <summary>
        /// 对象绘制
        /// </summary>
        public void OnRenderObject()
        {
            if (!Enable)
                return;

            if (pathEditor != null)
                pathEditor.OnRenderObject();
        }

        #region GUI 数据操作

        //gui显示操作数据
        string[] guiOperationArr = new string[] { "关闭全部", "Path列表" };
        int subViewIdx = 0;

        //显示服务器路径列表数据
        bool showServerPathList = false;

        /// <summary>
        /// 显示GUI操作
        /// </summary>
        void ShowGUIOperation()
        {
            //服务器资源数据没有加载解析完成，不显示操作数据
            if (!serverPathLoadOver)
                return;

            subViewIdx = GUILayout.SelectionGrid(subViewIdx, guiOperationArr, 2, GUILayout.Width(300), GUILayout.Height(60));
            switch (subViewIdx)
            {
                case 0:
                    showServerPathList = false;
                    break;
                case 1:
                    showServerPathList = true;
                    break;
            }

            //显示服务器轨迹数据列表
            OnShowServerPathList();
        }

        #region 显示服务器 轨迹数据列表

        //位置控制
        Rect pathListRect = new Rect(0, 300, 300, Screen.height - 300 - 20);
        Vector2 pathListScrollPosi = new Vector2();

        /// <summary>
        /// 显示服务器轨迹数据列表
        /// </summary>
        void OnShowServerPathList()
        {
            if (pathList == null
                || !showServerPathList)
                return;

            SpriteManager.GetInst().PathOnGUI();

            //pathListRect = GUI.Window(2, pathListRect, DrawServerPathList, "Server Path列表");
        }

        ///// <summary>
        ///// 绘制怪物列表数据
        ///// </summary>
        ///// <param name="id"></param>
        //void DrawServerPathList(int id)
        //{
        //    if(GUILayout.Button(" Refresh Server Path "))
        //    {
        //        //刷新服务器数据
        //        LoadServerPathPoints();
        //    }


        //    GUILayout.Space(20);

        //    pathListScrollPosi = GUILayout.BeginScrollView(pathListScrollPosi);

        //    for (int i = 0; i < pathList.Count; i++)
        //    {
        //        if (pathList[i] != null)
        //        {
        //            if (GUILayout.Button(pathList[i].id + "_" + pathList[i].name))
        //            {
        //                //SpriteManager.GetInst().LoadModel(modelList[i].id, modelList[i].model_id, modelList[i].path, modelList[i].name);
        //                //相机应该照射到当前选中 Path 的第一个点
        //            }
        //        }
        //    }

        //    GUILayout.EndScrollView();
        //}

        #endregion

        #endregion

        /// <summary>
        /// 处理按键和鼠标操作
        /// </summary>
        void ProcessMouseEvent()
        {

            //检测是否为删除数据
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                //按下删除按钮， 移除数据
                if(pathEditor != null)
                {
                    pathEditor.RemovePointFromPath();
                }
                return;
            }

            //如果不是鼠标操作，那么返回
            Event e = Event.current;
            if (e == null || !e.isMouse)
                return;

            if(e.clickCount == 2)
            {
                if(e.button == 0)
                {
                    //鼠标左键点击2下，那么新加一个 point
                    if (pathEditor.ShowPathInfo == null)
                    {
                        pathEditor.SetShowPathInfo(SpriteManager.GetInst().CreateNewPathInfo());
                    }

                    SpriteManager.GetInst().CreateNewPoint(pathEditor.ShowPathInfo);
                }
                else if(e.button == 1)
                {
                    //鼠标右键点击2下， 那么就去除当前编辑 PathInfo
                    if(pathEditor != null)
                    {
                        pathEditor.SetShowPathInfo(null);
                    }
                }
            }
        }

        #endregion
    }
}
