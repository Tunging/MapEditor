﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using NavMesh.Camera;
using TransformGizmos;
using ZTool.ITween;

namespace MapEditor
{
    /// <summary>
    /// Path 数据编辑
    /// </summary>
    public class PathInfoEditor
    {

        /// <summary>
        /// 初始化
        /// </summary>
        public PathInfoEditor()
        {
            //加载材质球数据
            LoadRenderLineMat();
        }

        #region 属性数据

        //属性数据信息
        PathInfo info;
        public PathInfo ShowPathInfo { get { return info; } }

        //显示 Path point 属性数据
        int showPointId = -1;
        //point 切换的id
        int showChangeId = -1;

        //设置当前显示的path数据信息
        public void SetShowPathInfo(PathInfo info)
        {
            this.info = info;

            if (info != null)
            {
                //只要开始编辑就设置为和服务器数据不同步
                info.isSynchronizationServer = false;

                //检测当前选中的point 数据
                for (int i = 0; i < info.spritePointsList.Count; i++)
                {
                    if(info.spritePointsList[i] != null)
                    {
                        if (TransformGizmo.GetInst().IsTarget(info.spritePointsList[i].transform))
                        {
                            showPointId = i;
                            showChangeId = showPointId;
                            break;
                        }
                    }
                }
            }
            else
            {
                showPointId = -1;
            }

        }

        /// <summary>
        /// 在Path中移除 point
        /// </summary>
        public void RemovePointFromPath()
        {
            if (ShowPathInfo == null)
                return;

            //移除一个点的数据
            ShowPathInfo.RemovePoint(showPointId);

            //检测当前是否还有点数据
            if(!ShowPathInfo.HavePoints())
            {
                //如果没有点了，就把整条path都删了
                ConfirmDeletePath();
            }

            //设置选中目标为null
            SetShowPathInfo(null);
        }

        #endregion

        #region GUI

        //显示窗口位置
        Rect winRect = new Rect(300, 0, 600, 250);
        Rect pointRect = new Rect(900, 0, 200, 250);

        //点信息
        Vector2 spriteListScrollPosi = new Vector2();

        //子窗口要显示的东西
        int subViewIdx = 0;

        //子窗口显示数组名字
        string[] subViewArr = { "基础数据", "轨迹点", "轨迹预览" };

        /// <summary>
        /// 绘制GUI数据
        /// </summary>
        public void OnGUI()
        {
            winRect = GUI.Window(1, winRect, DrawWindow, " Path 属性编辑");

            if(showPointId >= 0)
                pointRect = GUI.Window(100, pointRect, DrawPointWindow, " Point 属性编辑");
        }

        ///npc属性窗口
        void DrawWindow(int id)
        {
            
            //如果当前没有选择 Path 数据
            if (ShowPathInfo == null)
            {
                GUILayout.Label("当前未选中 Path");
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("保存到服务器", GUILayout.Height(30)))
                {
                    SceneManager.GetInst().SendToServer();
                }
                GUILayout.EndHorizontal();
                return;
            }

            GUILayout.BeginHorizontal();

            //显示地图信息
            GUILayout.Label("当前地图：<color=red> " + ShowPathInfo.scene_id + " </color> Path 包含 <color=red>" + ShowPathInfo.spritePointsList.Count + " </color> 个点数据");

            if (GUILayout.Button("删除 Path"))
            {
                GUINotice.Confirm(" 是否确认删除 此Path 数据 ", ConfirmDeletePath);
            }

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("保存到服务器", GUILayout.Height(30)))
            {
                SceneManager.GetInst().SendToServer();
            }
            GUILayout.EndHorizontal();

            subViewIdx = GUILayout.SelectionGrid(subViewIdx, subViewArr, subViewArr.Length, GUILayout.Width(550), GUILayout.Height(30));
            switch(subViewIdx)
            {
                case 0:
                    //设置基础数据
                    GUILayout.BeginVertical();
                    if (info.isServer)
                        GUILayout.Label("Id: <color=red>" + ShowPathInfo.id + "</color>");
                    else
                        ShowPathInfo.id = GUIUtils.NumberField("Id: ", ShowPathInfo.id);

                    //设置名字
                    ShowPathInfo.name = GUIUtils.StrField("Name:", ShowPathInfo.name);

                    ShowPathInfo.isClosedLoop = GUILayout.Toggle(ShowPathInfo.isClosedLoop, "是否闭环Loop", GUILayout.Height(25));
                    ShowPathInfo.isSmoothAmount = GUILayout.Toggle(ShowPathInfo.isSmoothAmount, "是否平滑过渡", GUILayout.Height(25));

                    GUILayout.EndVertical();
                    break;
                case 1:
                    //显示多个小球的点数据信息

                    if (ShowPathInfo.spritePointsList.Count == 0)
                        return;

                    spriteListScrollPosi = GUILayout.BeginScrollView(spriteListScrollPosi);

                    PointInfo pi = null;
                    for (int i = 0; i < ShowPathInfo.spritePointsList.Count; i++)
                    {
                        pi = ShowPathInfo.spritePointsList[i].CurrInfo;
                        if (pi != null)
                        {
                            if (GUILayout.Button(i + "_[" + pi.pos.x + ", " + pi.pos.y + ", " + pi.pos.z + "]"))
                            {
                                //点击自动定位到相应的小球
                                CameraMove.GetInst().CameraLookAtTarget(ShowPathInfo.spritePointsList[i].gameObject);
                                TransformGizmo.GetInst().SetTraget(ShowPathInfo.spritePointsList[i].transform);
                                showPointId = i;
                                showChangeId = showPointId;
                            }

                        }
                    }

                    GUILayout.EndScrollView();

                    break;
                case 2:

                    //轨迹数据预览
                    if(GUILayout.Button(" 预览 "))
                    {
                        //预览 Path
                        ReviewPath();
                    }

                    break;
            }
        }

        //绘制 point 信息
        void DrawPointWindow(int id)
        {
            GUILayout.BeginVertical();


            showChangeId = GUIUtils.NumberField("Point Id: ", showChangeId);
            if(GUILayout.Button("交换 Point 位置"))
            {
                if (ShowPathInfo.ExchangePoint(showPointId, showChangeId))
                    showPointId = showChangeId;
            }

            if(GUILayout.Button("插入 Point 位置"))
            {
                if (ShowPathInfo.InsertPoint(showPointId, showChangeId))
                    showPointId = showChangeId;
            }

            GUILayout.EndVertical();
        }

        /// <summary>
        /// 确认删除当前Path
        /// </summary>
        void ConfirmDeletePath()
        {
            SpriteManager.GetInst().RemovePathInfo(ShowPathInfo);

            SetShowPathInfo(null);
        }

        #endregion

        #region 绘制Path 连线

        //绘制线的 mat
        Material lineMat;
        string linePath = "Materials/glLine";

        //points
        Vector3[] points;

        //绘制连线的材质
        void LoadRenderLineMat()
        {
            if(lineMat == null)
            {
                lineMat = Resources.Load<Material>(linePath);
            }
        }

        /// <summary>
        /// 获取顶点位置数据
        /// </summary>
        /// <returns></returns>
        Vector3[] GetPathPointsPos()
        {
            if (ShowPathInfo == null || ShowPathInfo.spritePointsList.Count == 0)
                return null;

            List<Vector3> list = new List<Vector3>();
            for (int i = 0; i < ShowPathInfo.spritePointsList.Count; i++)
            {
                if(ShowPathInfo.spritePointsList[i] != null
                    && ShowPathInfo.spritePointsList[i].CurrInfo != null)
                {
                    list.Add(ShowPathInfo.spritePointsList[i].CurrInfo.pos);
                }
            }

            return list.ToArray();
        }

        /// <summary>
        /// 绘制 Path 连线数据
        /// </summary>
        public void OnRenderObject()
        {
            if (ShowPathInfo == null
                || ShowPathInfo.spritePointsList.Count <= 1)
                return;

            //没有 mat
            if (lineMat == null)
                return;

            points = GetPathPointsPos();
            if (points == null || points.Length <= 1)
                return;

            //绘制 points 数据信息
            OnDrawPathPoints();
        }

        /// <summary>
        /// 绘制 points 数据信息
        /// </summary>
        void OnDrawPathPoints()
        {
            if(ShowPathInfo.isSmoothAmount)
            {
                //Path 平滑过渡
                Vector3[] vector3s = PathControlPointGenerator(points);

                Vector3 prePos;
                Vector3 currPos;

                //闭环绘制控制
                if (ShowPathInfo.isClosedLoop)
                    prePos = Interp(vector3s, 1);
                else
                    prePos = Interp(vector3s, 0);

                //细分数据
                int SmoothAmount = points.Length * 20;

                lineMat.SetPass(0);
                GL.PushMatrix();

                GL.Begin(GL.LINES);
                for (int i = 1; i <= SmoothAmount; i++)
                {
                    float pm = (float)i / SmoothAmount;
                    currPos = Interp(vector3s, pm);

                    //直线
                    GL.Vertex(currPos);
                    GL.Vertex(prePos);

                    prePos = currPos;
                }

                GL.End();
                GL.PopMatrix();
            }
            else
            {
                //Path 没有平滑过渡
                lineMat.SetPass(0);
                //GL.PushMatrix();

                Vector3 prePos;
                if (ShowPathInfo.isClosedLoop)
                    prePos = points[points.Length - 1];
                else
                    prePos = points[0];
                Vector3 currPos = points[0];

                GL.Begin(GL.LINES);
                for (int i = 0; i < points.Length; i++)
                {
                    currPos = points[i];

                    GL.Vertex(prePos);
                    GL.Vertex(currPos);

                    prePos = currPos;
                }

                GL.End();
                //GL.PopMatrix();
            }
        }

        #region Path 平滑过渡

        /// <summary>
        /// path 控制点生成
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        Vector3[] PathControlPointGenerator(Vector3[] path)
        {
            Vector3[] suppliedPath;
            Vector3[] vector3s;

            //create and store path points:
            suppliedPath = path;

            //populate calculate path;
            int offset = 2;
            vector3s = new Vector3[suppliedPath.Length + offset];
            Array.Copy(suppliedPath, 0, vector3s, 1, suppliedPath.Length);

            //populate start and end control points:
            //vector3s[0] = vector3s[1] - vector3s[2];
            vector3s[0] = vector3s[1] + (vector3s[1] - vector3s[2]);
            vector3s[vector3s.Length - 1] = vector3s[vector3s.Length - 2] + (vector3s[vector3s.Length - 2] - vector3s[vector3s.Length - 3]);

            //is this a closed, continuous loop? yes? well then so let's make a continuous Catmull-Rom spline!
            if (vector3s[1] == vector3s[vector3s.Length - 2])
            {
                Vector3[] tmpLoopSpline = new Vector3[vector3s.Length];
                Array.Copy(vector3s, tmpLoopSpline, vector3s.Length);
                tmpLoopSpline[0] = tmpLoopSpline[tmpLoopSpline.Length - 3];
                tmpLoopSpline[tmpLoopSpline.Length - 1] = tmpLoopSpline[2];
                vector3s = new Vector3[tmpLoopSpline.Length];
                Array.Copy(tmpLoopSpline, vector3s, tmpLoopSpline.Length);
            }

            return (vector3s);
        }

        //andeeee from the Unity forum's steller Catmull-Rom class ( http://forum.unity3d.com/viewtopic.php?p=218400#218400 ):
        Vector3 Interp(Vector3[] pts, float t)
        {
            int numSections = pts.Length - 3;
            int currPt = Mathf.Min(Mathf.FloorToInt(t * (float)numSections), numSections - 1);
            float u = t * (float)numSections - (float)currPt;

            Vector3 a = pts[currPt];
            Vector3 b = pts[currPt + 1];
            Vector3 c = pts[currPt + 2];
            Vector3 d = pts[currPt + 3];

            return .5f * (
                (-a + 3f * b - 3f * c + d) * (u * u * u)
                + (2f * a - 5f * b + 4f * c - d) * (u * u)
                + (-a + c) * u
                + 2f * b
            );
        }

        #endregion

        #endregion

        #region 预览轨迹点

        //当前是否正在预览 path
        bool review = false;

        /// <summary>
        /// 预览轨迹点
        /// </summary>
        void ReviewPath()
        {
            //检测数据
            if (ShowPathInfo == null || ShowPathInfo.spritePointsList == null
                || ShowPathInfo.spritePointsList.Count == 0)
                return;

            //设置 预览标识
            review = true;

            //存储所有点的
            List<Transform> points = new List<Transform>();
            for (int i = 0; i < ShowPathInfo.spritePointsList.Count; i++)
            {
                if(ShowPathInfo.spritePointsList[i] != null)
                {
                    points.Add(ShowPathInfo.spritePointsList[i].transform);
                }
            }

            if(points.Count > 0)
            {
                //iTween.MoveTo(Camera.main.gameObject, iTween.Hash(
                //"movetopath", true,
                //"path", points.ToArray(),
                //"looktarget", true,
                //"oncomplete", "OnReviewComplete",
                //"time", 10f,
                //"orienttopath", true,
                //"easetype", iTween.EaseType.linear,
                //"lookahead", 0.1f
                //));

                List<Vector3> l = new List<Vector3>();
                for (int i = 0; i < points.Count; i++)
                {
                    if(points[i] != null)
                    {
                        l.Add(points[i].position);
                    }
                }

                PathMove.GetInst().MoveTo(Camera.main.gameObject, l.ToArray());
            }
        }

        /// <summary>
        /// 预览结束
        /// </summary>
        void OnReviewComplete()
        {
            review = false;
            UnityEngine.Debug.Log("This is a Log!!!");
        }

        #endregion
    }

}
