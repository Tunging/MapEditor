﻿
using UnityEngine;

namespace NavMesh
{
    /// <summary>
    /// 由三角形表示的节点
    /// </summary>
    public class TriangleMeshNode
    {
        //public TriangleMeshNode(AstarPath astar) : base(astar) { }
        static int id = 0;
        public TriangleMeshNode(NavmeshTile tile)
        {
            this.tile = tile;
            //设置自增长的 indexId
            nodeIndex = id++;
        }

        //可行走位的位置
        const int FlagsWalkableOffset = 0;
        //可行走的 mask
        const uint FlagsWalkableMask = 1 << FlagsWalkableOffset;

        //area 开始 位
        const int FlagsAreaOffset = 1;
        //area mask
        const uint FlagsAreaMask = (131072 - 1) << FlagsAreaOffset;

        //graph 开始位
        const int FlagsGraphOffset = 24;
        //graph index mask
        const uint FlagsGraphMask = (256u - 1) << FlagsGraphOffset;

        //最大 AreaIndex
        public const uint MaxAreaIndex = FlagsAreaMask >> FlagsAreaOffset;
        //最大的 GraphIndex
        public const uint MaxGraphIndex = FlagsGraphMask >> FlagsGraphOffset;

        //tag 开始位
        const int FlagsTagOffset = 19;
        //tag mask
        const uint FlagsTagMask = (32 - 1) << FlagsTagOffset;


        /** Penalty cost for walking on this node.
		 * This can be used to make it harder/slower to walk over certain nodes.
		 *
		 * A penalty of 1000 (Int3.Precision) corresponds to the cost of walking one world unit.
		 */
        private uint penalty;

        /** Penalty cost for walking on this node. This can be used to make it harder/slower to walk over certain areas. */
        public uint Penalty
        {
#if !ASTAR_NO_PENALTY
            get
            {
                return penalty;
            }
            set
            {
                if (value > 0xFFFFFF)
                    Debug.LogWarning("Very high penalty applied. Are you sure negative values haven't underflowed?\n" +
                        "Penalty values this high could with long paths cause overflows and in some cases infinity loops because of that.\n" +
                        "Penalty value applied: " + value);
                penalty = value;
            }
#else
			get { return 0U; }
			set {}
#endif
        }

        //保存几个数据位
        protected uint flags;
        public uint Flags
        {
            get
            {
                return flags;
            }
            set
            {
                flags = value;
            }
        }

        //如果为 true 表示结点可以通过
        public bool Walkable
        {
            get
            {
                return (flags & FlagsWalkableMask) != 0;
            }
            set
            {
                flags = flags & ~FlagsWalkableMask | (value ? 1U : 0U) << FlagsWalkableOffset;
            }
        }

        public uint Area
        {
            get
            {
                return (flags & FlagsAreaMask) >> FlagsAreaOffset;
            }
            set
            {
                flags = (flags & ~FlagsAreaMask) | (value << FlagsAreaOffset);
            }
        }

        public uint GraphIndex
        {
            get
            {
                return (flags & FlagsGraphMask) >> FlagsGraphOffset;
            }
            set
            {
                flags = flags & ~FlagsGraphMask | value << FlagsGraphOffset;
            }
        }

        public uint Tag
        {
            get
            {
                return (flags & FlagsTagMask) >> FlagsTagOffset;
            }
            set
            {
                flags = flags & ~FlagsTagMask | value << FlagsTagOffset;
            }
        }

        //三角形中第一个顶点
        public int v0;
        //三角形中第二个顶点
        public int v1;
        //三角形中第三个顶点
        public int v2;

        //内部使用节点标识
        int nodeIndex;
        //每个节点拥有的索引编号
        public int NodeIndex { get { return nodeIndex; } set { nodeIndex = value; } }

        //存储服务器使用的结点编号id
        public int SaveDatabaseNodeIndex { get; set; }

        //在世界空间中节点的位置 存储为Int3类型 而不是 Vector3 类型
        // 可以代码动态转换 var v3 = (Vector3)node.position
        public Int3 position;

        //此 triangle 所属 tile
        public NavmeshTile tile;

        //protected static INavmeshHolder[] _navmeshHolders = new INavmeshHolder[0];
        ////获取 navmesh 拥有者
        //public static INavmeshHolder GetNavmeshHolder(uint graphindex)
        //{
        //    return _navmeshHolders[(int)graphindex];
        //}

        ///** Sets the internal navmesh holder for a given graph index.
        // * \warning Internal method
        // */
        ////设置给定图索引的内部导航器。
        //public static void SetNavmeshHolder(int graphIndex, INavmeshHolder graph)
        //{
        //    if (_navmeshHolders.Length <= graphIndex)
        //    {
        //        var gg = new INavmeshHolder[graphIndex + 1];
        //        for (int i = 0; i < _navmeshHolders.Length; i++) gg[i] = _navmeshHolders[i];
        //        _navmeshHolders = gg;
        //    }
        //    _navmeshHolders[graphIndex] = graph;
        //}

        //将此节点的位置设置为其3个顶点的平均值
        /** Set the position of this node to the average of its 3 vertices */
        public void UpdatePositionFromVertices()
        {
            //INavmeshHolder g = GetNavmeshHolder(GraphIndex);

            //position = (g.GetVertex(v0) + g.GetVertex(v1) + g.GetVertex(v2)) * 0.333333f;

            position = (GetVertex(0) + GetVertex(1) + GetVertex(2)) * 0.333333f;

        }

        /** Return a number identifying a vertex.
         * This number does not necessarily need to be a index in an array but two different vertices (in the same graph) should
         * not have the same vertex numbers.
         */
        //获取三角形的 顶点
        public int GetVertexIndex(int i)
        {
            return i == 0 ? v0 : (i == 1 ? v1 : v2);
        }

        /** Return a number specifying an index in the source vertex array.
         * The vertex array can for example be contained in a recast tile, or be a navmesh graph, that is graph dependant.
         * This is slower than GetVertexIndex, if you only need to compare vertices, use GetVertexIndex.
         */
        public int GetVertexArrayIndex(int i)
        {
            return tile.GetVertexArrayIndex(i == 0 ? v0 : (i == 1 ? v1 : v2));

            //return GetNavmeshHolder(GraphIndex).GetVertexArrayIndex(i == 0 ? v0 : (i == 1 ? v1 : v2));
            //return i == 0 ? v0 : (i == 1 ? v1 : v2);
        }

        //获取三角形的顶点
        public Int3 GetVertex(int i)
        {
            return tile.GetVertex(GetVertexIndex(i));
            //return GetNavmeshHolder(GraphIndex).GetVertex(GetVertexIndex(i));
        }

        /// <summary>
        /// 获取顶点位置
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public Vector3 GetVertexPos(int i)
        {
            return (Vector3)GetVertex(i);
        }

        public int GetVertexCount()
        {
            // A triangle has 3 vertices
            return 3;
        }

        public Vector3 ClosestPointOnNode(Vector3 p)
        {
            //INavmeshHolder g = GetNavmeshHolder(GraphIndex);

            return Vector3.zero;
            //return Pathfinding.Polygon.ClosestPointOnTriangle((Vector3)g.GetVertex(v0), (Vector3)g.GetVertex(v1), (Vector3)g.GetVertex(v2), p);
        }

        //        public Vector3 ClosestPointOnNodeXZ(Vector3 _p)
        //        {
        //            // Get the object holding the vertex data for this node
        //            // This is usually a graph or a recast graph tile
        //            INavmeshHolder g = GetNavmeshHolder(GraphIndex);

        //            // Get all 3 vertices for this node
        //            Int3 tp1 = g.GetVertex(v0);
        //            Int3 tp2 = g.GetVertex(v1);
        //            Int3 tp3 = g.GetVertex(v2);

        //            // We need the point as an Int3
        //            var p = (Int3)_p;

        //            // Save the original y coordinate, we will return a point with the same y coordinate
        //            int oy = p.y;

        //            // Assumes the triangle vertices are laid out in (counter?)clockwise order

        //            tp1.y = 0;
        //            tp2.y = 0;
        //            tp3.y = 0;
        //            p.y = 0;

        //            if ((long)(tp2.x - tp1.x) * (long)(p.z - tp1.z) - (long)(p.x - tp1.x) * (long)(tp2.z - tp1.z) > 0)
        //            {
        //                float f = Mathf.Clamp01(VectorMath.ClosestPointOnLineFactor(tp1, tp2, p));
        //                return new Vector3(tp1.x + (tp2.x - tp1.x) * f, oy, tp1.z + (tp2.z - tp1.z) * f) * Int3.PrecisionFactor;
        //            }
        //            else if ((long)(tp3.x - tp2.x) * (long)(p.z - tp2.z) - (long)(p.x - tp2.x) * (long)(tp3.z - tp2.z) > 0)
        //            {
        //                float f = Mathf.Clamp01(VectorMath.ClosestPointOnLineFactor(tp2, tp3, p));
        //                return new Vector3(tp2.x + (tp3.x - tp2.x) * f, oy, tp2.z + (tp3.z - tp2.z) * f) * Int3.PrecisionFactor;
        //            }
        //            else if ((long)(tp1.x - tp3.x) * (long)(p.z - tp3.z) - (long)(p.x - tp3.x) * (long)(tp1.z - tp3.z) > 0)
        //            {
        //                float f = Mathf.Clamp01(VectorMath.ClosestPointOnLineFactor(tp3, tp1, p));
        //                return new Vector3(tp3.x + (tp1.x - tp3.x) * f, oy, tp3.z + (tp1.z - tp3.z) * f) * Int3.PrecisionFactor;
        //            }
        //            else
        //            {
        //                return _p;
        //            }

        //            /*
        //             * Equivalent to the above, but the above uses manual inlining
        //             * if (!VectorMath.RightOrColinearXZ (tp1, tp2, p)) {
        //             *  float f = Mathf.Clamp01 (VectorMath.ClosestPointOnLineFactor (tp1, tp2, p));
        //             *  return new Vector3(tp1.x + (tp2.x-tp1.x)*f, oy, tp1.z + (tp2.z-tp1.z)*f)*Int3.PrecisionFactor;
        //             * } else if (!VectorMath.RightOrColinearXZ (tp2, tp3, p)) {
        //             *  float f = Mathf.Clamp01 (VectorMath.ClosestPointOnLineFactor (tp2, tp3, p));
        //             *  return new Vector3(tp2.x + (tp3.x-tp2.x)*f, oy, tp2.z + (tp3.z-tp2.z)*f)*Int3.PrecisionFactor;
        //             * } else if (!VectorMath.RightOrColinearXZ (tp3, tp1, p)) {
        //             *  float f = Mathf.Clamp01 (VectorMath.ClosestPointOnLineFactor (tp3, tp1, p));
        //             *  return new Vector3(tp3.x + (tp1.x-tp3.x)*f, oy, tp3.z + (tp1.z-tp3.z)*f)*Int3.PrecisionFactor;
        //             * } else {
        //             *  return _p;
        //             * }*/

        //            /* Almost equivalent to the above, but this is slower
        //             * Vector3 tp1 = (Vector3)g.GetVertex(v0);
        //             * Vector3 tp2 = (Vector3)g.GetVertex(v1);
        //             * Vector3 tp3 = (Vector3)g.GetVertex(v2);
        //             * tp1.y = 0;
        //             * tp2.y = 0;
        //             * tp3.y = 0;
        //             * _p.y = 0;
        //             * return Pathfinding.Polygon.ClosestPointOnTriangle (tp1,tp2,tp3,_p);*/
        //        }

        /// <summary>
        /// 检测三角形是否包含一个点
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public bool ContainsPoint(Int3 p)
        {
            // Get the object holding the vertex data for this node
            // This is usually a graph or a recast graph tile

            //INavmeshHolder navmeshHolder = GetNavmeshHolder(GraphIndex);

            //// Get all 3 vertices for this node
            //Int3 a = navmeshHolder.GetVertex(v0);
            //Int3 b = navmeshHolder.GetVertex(v1);
            //Int3 c = navmeshHolder.GetVertex(v2);

            Int3 a = tile.GetVertex(v0);
            Int3 b = tile.GetVertex(v1);
            Int3 c = tile.GetVertex(v2);

            if ((long)(b.x - a.x) * (long)(p.z - a.z) - (long)(p.x - a.x) * (long)(b.z - a.z) > 0) return false;

            if ((long)(c.x - b.x) * (long)(p.z - b.z) - (long)(p.x - b.x) * (long)(c.z - b.z) > 0) return false;

            if ((long)(a.x - c.x) * (long)(p.z - c.z) - (long)(p.x - c.x) * (long)(a.z - c.z) > 0) return false;

            return true;
            // Equivalent code, but the above code is faster
            //return Polygon.IsClockwiseMargin (a,b, p) && Polygon.IsClockwiseMargin (b,c, p) && Polygon.IsClockwiseMargin (c,a, p);

            //return Polygon.ContainsPoint(g.GetVertex(v0),g.GetVertex(v1),g.GetVertex(v2),p);
        }

        //        public void UpdateRecursiveG(Path path, PathNode pathNode, PathHandler handler)
        //        {
        //            UpdateG(path, pathNode);

        //            handler.PushNode(pathNode);

        //            if (connections == null) return;

        //            for (int i = 0; i < connections.Length; i++)
        //            {
        //                GraphNode other = connections[i];
        //                PathNode otherPN = handler.GetPathNode(other);
        //                if (otherPN.parent == pathNode && otherPN.pathID == handler.PathID) other.UpdateRecursiveG(path, otherPN, handler);
        //            }
        //        }

        //        public void Open(Path path, PathNode pathNode, PathHandler handler)
        //        {
        //            if (connections == null) return;

        //            // Flag2 indicates if this node needs special treatment
        //            // with regard to connection costs
        //            bool flag2 = pathNode.flag2;

        //            // Loop through all connections
        //            for (int i = connections.Length - 1; i >= 0; i--)
        //            {
        //                GraphNode other = connections[i];

        //                // Make sure we can traverse the neighbour
        //                if (path.CanTraverse(other))
        //                {
        //                    PathNode pathOther = handler.GetPathNode(other);

        //                    // Fast path out, worth it for triangle mesh nodes since they usually have degree 2 or 3
        //                    if (pathOther == pathNode.parent)
        //                    {
        //                        continue;
        //                    }

        //                    uint cost = connectionCosts[i];

        //                    if (flag2 || pathOther.flag2)
        //                    {
        //                        // Get special connection cost from the path
        //                        // This is used by the start and end nodes
        //                        cost = path.GetConnectionSpecialCost(this, other, cost);
        //                    }

        //                    // Test if we have seen the other node before
        //                    if (pathOther.pathID != handler.PathID)
        //                    {
        //                        // We have not seen the other node before
        //                        // So the path from the start through this node to the other node
        //                        // must be the shortest one so far

        //                        // Might not be assigned
        //                        pathOther.node = other;

        //                        pathOther.parent = pathNode;
        //                        pathOther.pathID = handler.PathID;

        //                        pathOther.cost = cost;

        //                        pathOther.H = path.CalculateHScore(other);
        //                        other.UpdateG(path, pathOther);

        //                        handler.PushNode(pathOther);
        //                    }
        //                    else
        //                    {
        //                        // If not we can test if the path from this node to the other one is a better one than the one already used
        //                        if (pathNode.G + cost + path.GetTraversalCost(other) < pathOther.G)
        //                        {
        //                            pathOther.cost = cost;
        //                            pathOther.parent = pathNode;

        //                            other.UpdateRecursiveG(path, pathOther, handler);
        //                        }
        //                        else if (pathOther.G + cost + path.GetTraversalCost(this) < pathNode.G && other.ContainsConnection(this))
        //                        {
        //                            // Or if the path from the other node to this one is better

        //                            pathNode.parent = pathOther;
        //                            pathNode.cost = cost;

        //                            UpdateRecursiveG(path, pathNode, handler);
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //        /** Returns the edge which is shared with \a other.
        //         * If no edge is shared, -1 is returned.
        //         * The edge is GetVertex(result) - GetVertex((result+1) % GetVertexCount()).
        //         * See GetPortal for the exact segment shared.
        //         * \note Might return that an edge is shared when the two nodes are in different tiles and adjacent on the XZ plane, but on the Y-axis.
        //         * Therefore it is recommended that you only test for neighbours of this node or do additional checking afterwards.
        //         */
        //        public int SharedEdge(GraphNode other)
        //        {
        //            int a, b;

        //            GetPortal(other, null, null, false, out a, out b);
        //            return a;
        //        }

        //        public override bool GetPortal(GraphNode _other, System.Collections.Generic.List<Vector3> left, System.Collections.Generic.List<Vector3> right, bool backwards)
        //        {
        //            int aIndex, bIndex;

        //            return GetPortal(_other, left, right, backwards, out aIndex, out bIndex);
        //        }

        //        public bool GetPortal(GraphNode _other, System.Collections.Generic.List<Vector3> left, System.Collections.Generic.List<Vector3> right, bool backwards, out int aIndex, out int bIndex)
        //        {
        //            aIndex = -1;
        //            bIndex = -1;

        //            //If the nodes are in different graphs, this function has no idea on how to find a shared edge.
        //            if (_other.GraphIndex != GraphIndex) return false;

        //            // Since the nodes are in the same graph, they are both TriangleMeshNodes
        //            // So we don't need to care about other types of nodes
        //            var other = _other as TriangleMeshNode;

        //            //Get tile indices
        //            int tileIndex = (GetVertexIndex(0) >> RecastGraph.TileIndexOffset) & RecastGraph.TileIndexMask;
        //            int tileIndex2 = (other.GetVertexIndex(0) >> RecastGraph.TileIndexOffset) & RecastGraph.TileIndexMask;

        //            //When the nodes are in different tiles, the edges might not be completely identical
        //            //so another technique is needed
        //            //Only do this on recast graphs
        //            if (tileIndex != tileIndex2 && (GetNavmeshHolder(GraphIndex) is RecastGraph))
        //            {
        //                for (int i = 0; i < connections.Length; i++)
        //                {
        //                    if (connections[i].GraphIndex != GraphIndex)
        //                    {
        //#if !ASTAR_NO_POINT_GRAPH
        //                        var mid = connections[i] as NodeLink3Node;
        //                        if (mid != null && mid.GetOther(this) == other)
        //                        {
        //                            // We have found a node which is connected through a NodeLink3Node

        //                            if (left != null)
        //                            {
        //                                mid.GetPortal(other, left, right, false);
        //                                return true;
        //                            }
        //                        }
        //#endif
        //                    }
        //                }

        //                //Get the tile coordinates, from them we can figure out which edge is going to be shared
        //                int x1, x2, z1, z2;
        //                int coord;
        //                INavmeshHolder nm = GetNavmeshHolder(GraphIndex);
        //                nm.GetTileCoordinates(tileIndex, out x1, out z1);
        //                nm.GetTileCoordinates(tileIndex2, out x2, out z2);

        //                if (System.Math.Abs(x1 - x2) == 1) coord = 0;
        //                else if (System.Math.Abs(z1 - z2) == 1) coord = 2;
        //                else throw new System.Exception("Tiles not adjacent (" + x1 + ", " + z1 + ") (" + x2 + ", " + z2 + ")");

        //                int av = GetVertexCount();
        //                int bv = other.GetVertexCount();

        //                //Try the X and Z coordinate. For one of them the coordinates should be equal for one of the two nodes' edges
        //                //The midpoint between the tiles is the only place where they will be equal

        //                int first = -1, second = -1;

        //                //Find the shared edge
        //                for (int a = 0; a < av; a++)
        //                {
        //                    int va = GetVertex(a)[coord];
        //                    for (int b = 0; b < bv; b++)
        //                    {
        //                        if (va == other.GetVertex((b + 1) % bv)[coord] && GetVertex((a + 1) % av)[coord] == other.GetVertex(b)[coord])
        //                        {
        //                            first = a;
        //                            second = b;
        //                            a = av;
        //                            break;
        //                        }
        //                    }
        //                }

        //                aIndex = first;
        //                bIndex = second;

        //                if (first != -1)
        //                {
        //                    Int3 a = GetVertex(first);
        //                    Int3 b = GetVertex((first + 1) % av);

        //                    //The coordinate which is not the same for the vertices
        //                    int ocoord = coord == 2 ? 0 : 2;

        //                    //When the nodes are in different tiles, they might not share exactly the same edge
        //                    //so we clamp the portal to the segment of the edges which they both have.
        //                    int mincoord = System.Math.Min(a[ocoord], b[ocoord]);
        //                    int maxcoord = System.Math.Max(a[ocoord], b[ocoord]);

        //                    mincoord = System.Math.Max(mincoord, System.Math.Min(other.GetVertex(second)[ocoord], other.GetVertex((second + 1) % bv)[ocoord]));
        //                    maxcoord = System.Math.Min(maxcoord, System.Math.Max(other.GetVertex(second)[ocoord], other.GetVertex((second + 1) % bv)[ocoord]));

        //                    if (a[ocoord] < b[ocoord])
        //                    {
        //                        a[ocoord] = mincoord;
        //                        b[ocoord] = maxcoord;
        //                    }
        //                    else
        //                    {
        //                        a[ocoord] = maxcoord;
        //                        b[ocoord] = mincoord;
        //                    }

        //                    if (left != null)
        //                    {
        //                        //All triangles should be clockwise so second is the rightmost vertex (seen from this node)
        //                        left.Add((Vector3)a);
        //                        right.Add((Vector3)b);
        //                    }
        //                    return true;
        //                }
        //            }
        //            else
        //            if (!backwards)
        //            {
        //                int first = -1;
        //                int second = -1;

        //                int av = GetVertexCount();
        //                int bv = other.GetVertexCount();

        //                /** \todo Maybe optimize with pa=av-1 instead of modulus... */
        //                for (int a = 0; a < av; a++)
        //                {
        //                    int va = GetVertexIndex(a);
        //                    for (int b = 0; b < bv; b++)
        //                    {
        //                        if (va == other.GetVertexIndex((b + 1) % bv) && GetVertexIndex((a + 1) % av) == other.GetVertexIndex(b))
        //                        {
        //                            first = a;
        //                            second = b;
        //                            a = av;
        //                            break;
        //                        }
        //                    }
        //                }

        //                aIndex = first;
        //                bIndex = second;

        //                if (first != -1)
        //                {
        //                    if (left != null)
        //                    {
        //                        //All triangles should be clockwise so second is the rightmost vertex (seen from this node)
        //                        left.Add((Vector3)GetVertex(first));
        //                        right.Add((Vector3)GetVertex((first + 1) % av));
        //                    }
        //                }
        //                else
        //                {
        //                    for (int i = 0; i < connections.Length; i++)
        //                    {
        //                        if (connections[i].GraphIndex != GraphIndex)
        //                        {
        //#if !ASTAR_NO_POINT_GRAPH
        //                            var mid = connections[i] as NodeLink3Node;
        //                            if (mid != null && mid.GetOther(this) == other)
        //                            {
        //                                // We have found a node which is connected through a NodeLink3Node

        //                                if (left != null)
        //                                {
        //                                    mid.GetPortal(other, left, right, false);
        //                                    return true;
        //                                }
        //                            }
        //#endif
        //                        }
        //                    }
        //                    return false;
        //                }
        //            }

        //            return true;
        //        }

        //        public void SerializeNode(GraphSerializationContext ctx)
        //        {
        //            base.SerializeNode(ctx);
        //            ctx.writer.Write(v0);
        //            ctx.writer.Write(v1);
        //            ctx.writer.Write(v2);
        //        }

        //        public void DeserializeNode(GraphSerializationContext ctx)
        //        {
        //            base.DeserializeNode(ctx);
        //            v0 = ctx.reader.ReadInt32();
        //            v1 = ctx.reader.ReadInt32();
        //            v2 = ctx.reader.ReadInt32();
        //        }

        #region node 之间的数据连接处理

        public TriangleMeshNode[] connections;
        public uint[] connectionCosts;

        /// <summary>
        /// 清理所有的连接数据
        /// </summary>
        /// <param name="alsoReverse"></param>
        public void ClearConnections(bool alsoReverse)
        {
            // Remove all connections to this node from our neighbours
            if (alsoReverse && connections != null)
            {
                for (int i = 0; i < connections.Length; i++)
                {
                    connections[i].RemoveConnection(this);
                }
            }

            connections = null;
            connectionCosts = null;
        }

        //public void GetConnections(GraphNodeDelegate del)
        //{
        //    if (connections == null) return;
        //    for (int i = 0; i < connections.Length; i++) del(connections[i]);
        //}


        /** Add a connection from this node to the specified node.
 * If the connection already exists, the cost will simply be updated and
 * no extra connection added.
 *
 * \note Only adds a one-way connection. Consider calling the same function on the other node
 * to get a two-way connection.
 */
        public void AddConnection(TriangleMeshNode node, uint cost)
        {
            // Check if we already have a connection to the node
            if (connections != null)
            {
                for (int i = 0; i < connections.Length; i++)
                {
                    if (connections[i] == node)
                    {
                        // Just update the cost for the existing connection
                        connectionCosts[i] = cost;
                        return;
                    }
                }
            }

            // Create new arrays which include the new connection
            int connLength = connections != null ? connections.Length : 0;

            var newconns = new TriangleMeshNode[connLength + 1];
            var newconncosts = new uint[connLength + 1];
            for (int i = 0; i < connLength; i++)
            {
                newconns[i] = connections[i];
                newconncosts[i] = connectionCosts[i];
            }

            newconns[connLength] = node;
            newconncosts[connLength] = cost;

            connections = newconns;
            connectionCosts = newconncosts;
        }

        /** Removes any connection from this node to the specified node.
		 * If no such connection exists, nothing will be done.
		 *
		 * \note This only removes the connection from this node to the other node.
		 * You may want to call the same function on the other node to remove its eventual connection
		 * to this node.
		 */
        public void RemoveConnection(TriangleMeshNode node)
        {
            if (connections == null) return;

            // Iterate through all connections and check if there are any to the node
            for (int i = 0; i < connections.Length; i++)
            {
                if (connections[i] == node)
                {
                    // Create new arrays which have the specified node removed
                    int connLength = connections.Length;

                    var newconns = new TriangleMeshNode[connLength - 1];
                    var newconncosts = new uint[connLength - 1];
                    for (int j = 0; j < i; j++)
                    {
                        newconns[j] = connections[j];
                        newconncosts[j] = connectionCosts[j];
                    }
                    for (int j = i + 1; j < connLength; j++)
                    {
                        newconns[j - 1] = connections[j];
                        newconncosts[j - 1] = connectionCosts[j];
                    }

                    connections = newconns;
                    connectionCosts = newconncosts;
                    return;
                }
            }
        }

        #endregion

    }
}