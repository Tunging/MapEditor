﻿using UnityEngine;
using System.Collections;

namespace NavMesh 
{

    /// <summary>
    /// 存储生成的 NavMesh tile 信息数据
    /// </summary>
    public class NavmeshTile
    {
        //三角形数据
        public int[] tris;

        //顶点数据
        public Int3[] verts;

        //x 坐标
        public int x;

        //z 坐标
        public int z;

        //tile 宽度
        public int w;

        //tile深度
        public int d;

        //X轴大小
        public int tileX;

        //Z轴大小
        public int tileZ;

        //tile 包含的所有的 node
        public TriangleMeshNode[] nodes;

        //用于结点查找的边界框树
        /** Bounding Box Tree for node lookups */
        //public BBTree bbTree;

        //用于批处理的临时标识
        public bool flag;

        /// <summary>
        /// 获取 tile 的坐标
        /// </summary>
        /// <param name="tileIndex"></param>
        /// <param name="x"></param>
        /// <param name="z"></param>
        public void GetTileCoordinates(int tileIndex, out int x, out int z)
        {
            x = this.x;
            z = this.z;
        }

        /// <summary>
        /// 获取 顶点数组中的 index
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public int GetVertexArrayIndex(int index)
        {
            //return index & RecastGraph.VertexIndexMask;
            return index & 0xFFFFF;
        }

        /// <summary>
        /// 获取tile中特定顶点数据
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Int3 GetVertex(int index)
        {
            //int idx = index & RecastGraph.VertexIndexMask;
            int idx = index & 0xFFFFF;

            return verts[idx];
        }

        /// <summary>
        /// 检测是否包含一个点数据
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        public bool IsContainPoint(float px, float pz)
        {
            //Int3 pos = new Int3(px, 0, px);
            //Vector3 pos = new Vector3(px, 0, pz);

            //if (x * tileX <= pos.x && z * tileZ <= pos.z && (x + 1) * tileX >= pos.x && (z + 1) * tileZ >= pos.z)
            if (x * tileX <= px && z * tileZ <= pz && (x + 1) * tileX >= px && (z + 1) * tileZ >= pz)
                return true;

            return false;
        }

        //public void GetNodes(GraphNodeDelegateCancelable del)
        //{
        //    if (nodes == null) return;
        //    for (int i = 0; i < nodes.Length && del(nodes[i]); i++) { }
        //}
    }

}
