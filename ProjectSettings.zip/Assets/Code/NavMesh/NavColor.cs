﻿using UnityEngine;
using System.Collections;

namespace NavMesh
{


    public class NavColor
    {

        //默认颜色显示数组
        public static Color[] _AreaColors = new Color[] { Color.green, Color.yellow, Color.white, Color.red };
        private static Color[] AreaColors
        {
            get { return _AreaColors; }
        }

        public static Color IntToColor(int i, float a)
        {
            int r = Bit(i, 1) + Bit(i, 3) * 2 + 1;
            int g = Bit(i, 2) + Bit(i, 4) * 2 + 1;
            int b = Bit(i, 0) + Bit(i, 5) * 2 + 1;

            return new Color(r * 0.25F, g * 0.25F, b * 0.25F, a);
        }

        static int Bit(int a, int b)
        {
            return (a >> b) & 1;
            //return (a & (1 << b)) >> b; //Original code, one extra shift operation required
        }

        //不同 Area 显示不同的颜色
        public static Color GetAreaColor(uint area)
        {
            if (AreaColors == null || area >= AreaColors.Length)
            {
                return IntToColor((int)area, 1F);
            }
            return AreaColors[(int)area];
        }

        //不可行走区域显示颜色
        public static Color UnWalkable = Color.red;
    }
}
