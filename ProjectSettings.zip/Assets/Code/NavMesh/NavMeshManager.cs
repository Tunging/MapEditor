﻿using UnityEngine;
using System.Collections;
using System;
using System.IO;
using message.mesh3;
using ProtoBuf;
using NavMesh;
using System.Collections.Generic;

namespace MapEditor
{

    public class NavMeshManager
    {

        #region 单例 

        static NavMeshManager instance;
        public static NavMeshManager GetInst()
        {
            if (instance == null)
            {
                instance = new NavMeshManager();
            }
            return instance;
        }

        public NavMeshManager()
        {
            //加载材质球数据
            LoadMaterial();

            //加载显示 NavMesh 组成的Mesh
            OnLoadShowNavMeshMaterial();
        }

        #endregion

        #region 请求从服务器获取 NavMesh

        //存储NavMesh 数据信息
        public NavmeshTile Tile { get; private set; }

        //服务器navMesh 数据
        ServerNavMesh mapNavMesh;

        /// <summary>
        /// 获取当前显示场景的 NavMesh 数据信息
        /// </summary>
        public void GetNavMeshFromMap()
        {
            //string url = string.Format("{0}{1}", Config.SERVER_NAVMESH, SceneManager.GetInst().CurrShowSceneId);
            string url = string.Format("{0}{1}", Config.SERVER_NAVMESH, SceneManager.GetInst().CurrShowMapId);

            //开始请求数据
            SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(url, OnNavMeshLoadOver));
        }

        /// <summary>
        /// NavMesh 资源数据加载完成
        /// </summary>
        /// <param name="www"></param>
        /// <param name="parameter"></param>
        void OnNavMeshLoadOver(string text)
        {
            if ( string.IsNullOrEmpty(text))
            {
                GUINotice.Show("<color=red> 找不到当前场景的NavMesh数据信息， 地图id为 <color=yellow>" + SceneManager.GetInst().CurrShowMapId + "</color></color>");
                return;
            }

            Debug.Log("  获取数据库资源成功，正在解析数据库数据 ");

            //因一个地图在服务器中只有一条数据，所以可以直接转换
            mapNavMesh = JsonUtility.FromJson(text, typeof(ServerNavMesh)) as ServerNavMesh;
            if (mapNavMesh != null && mapNavMesh.mesh!=null)
            {
                //进行二进制数据转换
                MapStruct3 map;
                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(mapNavMesh.mesh, 0, mapNavMesh.mesh.Length);
                    //设置为起始位置
                    stream.Seek(0, SeekOrigin.Begin);
                    //反序列化数据
                    map = Serializer.Deserialize<MapStruct3>(stream);

                    //销毁数据流
                    stream.Dispose();
                }

                Debug.Log("  正在解析数据库数据成功，正在转换成本地数据格式 ");

                //把服务器数据转换成本地数据
                NavMeshConvert(map);
            }
            else
            {
                Debug.LogError("解析navmesh数据库资源 失败");
            }
        }

        /// <summary>
        /// NavMesh 数据转换
        /// </summary>
        /// <param name="map"></param>
        void NavMeshConvert(MapStruct3 map)
        {
            //设置tile 数据
            Tile = new NavmeshTile();
            //初始化数据信息
            Tile.x = 0;
            Tile.z = 0;
            Tile.w = 1;
            Tile.d = 1;

            //顶点数据转换
            Int3[] verts = new Int3[map.point.Count];
            for (int i = 0; i < map.point.Count; i++)
            {
                verts[i] = new Int3(map.point[i].x, map.point[i].y, map.point[i].z);
            }

            //三角面数据类型转换
            TriangleMeshNode[] nodes = new TriangleMeshNode[map.mesh.Count];
            //三角形数据
            int[] tris = new int[map.mesh.Count * 3];

            for (int i = 0; i < map.mesh.Count; i++)
            {
                TriangleMeshNode node = new TriangleMeshNode(Tile);
                //默认只有一个
                node.GraphIndex = 0;
                node.NodeIndex = i;
                node.SaveDatabaseNodeIndex = i;
                node.v0 = (int)map.mesh[i].point[0];
                node.v1 = (int)map.mesh[i].point[1];
                node.v2 = (int)map.mesh[i].point[2];
                node.Area = map.mesh[i].layer;

                //目前数据没有控制，认为都可以行走
                node.Walkable = map.mesh[i].walkable;

                //赋值设置
                nodes[i] = node;

                //设置三角形顶点数据
                tris[i * 3] = node.v0;
                tris[i * 3 + 1] = node.v1;
                tris[i * 3 + 2] = node.v2;
            }

            //设置三角形结点之间的连接关系
            for (int i = 0; i < nodes.Length; i++)
            {
                if (nodes[i] != null)
                {
                    List<int> link = map.mesh[i].link;
                    if (link != null && link.Count > 0)
                    {
                        //添加相连结点数据
                        List<TriangleMeshNode> connectList = new List<TriangleMeshNode>();
                        List<uint> connectCostList = new List<uint>();

                        for (int j = 0; j < link.Count; j++)
                        {
                            if (link[j] >= 0)
                            {
                                connectList.Add(nodes[j]);

                                uint cost = (uint)(nodes[i].position - nodes[j].position).costMagnitude;
                                connectCostList.Add(cost);
                            }
                        }

                        //设置结点连接数据
                        nodes[i].connections = connectList.ToArray();
                        nodes[i].connectionCosts = connectCostList.ToArray();
                    }
                }
            }

            ////设置tile 数据
            //NavmeshTile tile = new NavmeshTile();
            ////初始化数据信息
            //tile.x = 0;
            //tile.z = 0;
            //tile.w = 1;
            //tile.d = 1;

            //设置tile的 顶点，三角形，以及位置数据
            Tile.tris = tris;
            Tile.verts = verts;
            Tile.nodes = nodes;

            //rg.Tiles = new NavmeshTile[] { tile };
            ////设置 tile holder
            //TriangleMeshNode.SetNavmeshHolder(0, tile);

            Debug.Log(" NavMesh 数据转换完成！ ");
        }

        #endregion

        #region GUI

        //是否显示NavMesh
        bool showNavMesh = true;

        //是否显示 不同结点之间的 连接线
        bool showNodeConnections = false;

        //是否显示 mesh 边缘线
        bool showMeshOutline = true;

        //是否显示 NavMesh 组成的Mesh
        bool showMeshSurface = true;

        //编辑器属性窗口设置
        Rect winRect = new Rect(300, 0, 600, 220);

        /// <summary>
        /// GUI 绘制
        /// </summary>
        public void OnGUI()
        {
            if (mapNavMesh == null)
                return;

            winRect = GUI.Window(102, winRect, DrawWindow, "地图数据信息展示");
        }

        //数组地面的数据标志
        void DrawWindow(int id)
        {
            GUI.color = Color.yellow;

            //地图基本信息
            if (mapNavMesh != null)
            {
                GUILayout.BeginVertical();
                GUILayout.Label("mapID:" + mapNavMesh.id + " Name:" + mapNavMesh.name + " X:" + mapNavMesh.max_x + " Y:" + mapNavMesh.max_y + " Z:" + mapNavMesh.max_z);
                GUILayout.Label("提示：在分别编辑阻挡点或者孤岛信息时，可以按 <color=#22ff22>Ctrl+Z</color> 撤销和 <color=#22ff22>Ctrl+Y</color> 重做");
                GUILayout.EndVertical();
            }

            //绘制鼠标位置
            GUILayout.Label("X:" + SceneManager.MousePos.x + " Y:" + SceneManager.MousePos.y + " Z:" + SceneManager.MousePos.z + " MousePosition:" + Input.mousePosition);

            //绘制显示操作
            GUILayout.BeginHorizontal();

            if(GUILayout.Button("显示 NavMesh 网格信息"))
            {
                showNavMesh = !showNavMesh;
            }

            if(GUILayout.Button("显示不同三角形之间的中点连线"))
            {
                showNodeConnections = !showNodeConnections;
            }

            if(GUILayout.Button("显示三角形组成的Mesh Surface"))
            {
                showMeshSurface = !showMeshSurface;
            }

            GUILayout.EndHorizontal();

        }

        #endregion

        #region 绘制NavMesh

        //绘制线段使用的材质球
        Material LineMat;

        /// <summary>
        /// 加载材质球
        /// </summary>
        void LoadMaterial()
        {
            if (LineMat == null)
            {
                ////加载绘制线段时，使用的材质球数据
                //string path = "Assets/Editor/EditorAssets/Materials/";

                //navmeshMaterial = AssetDatabase.LoadAssetAtPath(path + "LineMat.mat", typeof(Material)) as Material;
                LineMat = new Material(Shader.Find("Sprites/Default"));
            }
        }

        /// <summary>
        /// 在场景中的物件渲染完毕之后开始绘制
        /// </summary>
        public void OnRenderObject()
        {
            //没有数据, 或者不绘制的时候
            if (Tile == null || !showNavMesh)
                return;

            if (LineMat == null)
            {
                Debug.LogError("没有绘制需要的材质球数据");
                return;
            }

            //绘制NavMesh
            DrawNavMesh();

            //绘制选中三角形
            //DrawSelectTriangleMeshNode();
        }


        /// <summary>
        /// 绘制NavMesh
        /// </summary>
        void DrawNavMesh()
        {
            //设置绘制通道
            LineMat.SetPass(0);

            if (Tile == null || Tile.nodes == null)
                return;

            TriangleMeshNode[] nodes = Tile.nodes;

            //绘制线段
            GL.Begin(GL.LINES);

            for (int j = 0; j < Tile.nodes.Length; j++)
            {
                var node = nodes[j];
                if (node == null) continue;

                if (showNodeConnections)
                {
                    GL.Color(Color.red);
                    for (int q = 0; q < node.connections.Length; q++)
                    {
                        GL.Vertex((Vector3)node.position);
                        GL.Vertex(Vector3.Lerp((Vector3)node.connections[q].position, (Vector3)node.position, 0.4f));
                    }

                }

                if (showMeshOutline)
                {

                    //GL.Color(node.Walkable ? NavC rg.NodeColor(node) : NavColor.UnwalkableNode);

                    GL.Color(node.Walkable ? NavColor.GetAreaColor(node.Area) : NavColor.UnWalkable);

                    GL.Vertex((Vector3)node.GetVertex(0));
                    GL.Vertex((Vector3)node.GetVertex(1));

                    GL.Vertex((Vector3)node.GetVertex(1));
                    GL.Vertex((Vector3)node.GetVertex(2));

                    GL.Vertex((Vector3)node.GetVertex(2));
                    GL.Vertex((Vector3)node.GetVertex(0));
                }
            }


            GL.End();
        }

        ///// <summary>
        ///// 绘制选中的三角形数据
        ///// </summary>
        //void DrawSelectTriangleMeshNode()
        //{
        //    if (selectdNode == null)
        //        return;

        //    //设置绘制通道
        //    navmeshMaterial.SetPass(0);

        //    //绘制线段
        //    GL.Begin(GL.LINES);

        //    //GL.Color(selectdNode.Walkable ? rg.NodeColor(selectdNode) : AstarColor.UnwalkableNode);
        //    GL.Color(selectdNode.Walkable ? Color.blue : Color.red);

        //    GL.Vertex((Vector3)selectdNode.GetVertex(0));
        //    GL.Vertex((Vector3)selectdNode.GetVertex(1));

        //    GL.Vertex((Vector3)selectdNode.GetVertex(1));
        //    GL.Vertex((Vector3)selectdNode.GetVertex(2));

        //    GL.Vertex((Vector3)selectdNode.GetVertex(2));
        //    GL.Vertex((Vector3)selectdNode.GetVertex(0));

        //    GL.End();
        //}

        #endregion


        #region 区域绘制


#if !UNITY_5_1 && !UNITY_5_0

        //编辑器中使用的绘制NavMesh的 Material
        Material navmeshMaterial;

        //编辑器中使用的绘制NavMesh的 轮廓Material
        Material navmeshOutlineMaterial;

        //存储可视化的导航网格数据，在OnDrawGizmos中使用
        GizmoTile gizmoMeshes = new GizmoTile();

        //拥有一个可视化的表面和轮廓的 NavMesh导航tile
        struct GizmoTile
        {
            public NavmeshTile tile;
            public int hash;
            public Mesh surfaceMesh;
            public Mesh outlineMesh;
        }

        /// <summary>
        /// 加载NavMesh材质
        /// </summary>
        void OnLoadShowNavMeshMaterial()
        {
            //string path = "Assets/Editor/EditorAssets/Materials/";

            //navmeshMaterial = AssetDatabase.LoadAssetAtPath(path + "Navmesh.mat", typeof(Material)) as Material;
            //navmeshOutlineMaterial = AssetDatabase.LoadAssetAtPath(path + "NavmeshOutline.mat", typeof(Material)) as Material;

            if(navmeshMaterial == null)
                navmeshMaterial = Resources.Load("Materials/Navmesh", typeof(Material)) as Material;

            if(navmeshOutlineMaterial == null)
                navmeshOutlineMaterial = Resources.Load("Materials/NavmeshOutline", typeof(Material)) as Material;

            ////设置Gizmos回调
            //rg.SetDrawGizmosAction(OnDrawGizmos);
        }

        /// <summary>
        /// 清理 可视化的Mesh数据
        /// </summary>
        public void UnloadGizmoMeshes()
        {
            //for (int i = 0; i < gizmoMeshes.Count; i++)
            //{
            //    Mesh.DestroyImmediate(gizmoMeshes[i].surfaceMesh);
            //    Mesh.DestroyImmediate(gizmoMeshes[i].outlineMesh);
            //}
            //gizmoMeshes.Clear();

            Mesh.DestroyImmediate(gizmoMeshes.surfaceMesh);
            Mesh.DestroyImmediate(gizmoMeshes.outlineMesh);
        }

        /// <summary>
        /// 更新OnDrawGizmos中使用的可视化网格数据
        /// </summary>
        void UpdateDebugMeshes()
        {
            //获取所有的tile数据
            //var tiles = rg.Tiles;

            if (Tile == null)
            {
                //清理所有的数据信息
                UnloadGizmoMeshes();
            }

            if (Tile != null)
            {
                //如果 tiles已经更改了，那么就更新显示数据
                //for (int i = 0; i < tiles.Length; i++)
                //{
                //bool validTile = i < gizmoMeshes.Count && gizmoMeshes[i].tile == tiles[i];
                bool validTile = true;

                    // Calculate a hash of the tile
                    int hash = 0;
                    const int HashPrime = 31;
                    var nodes = Tile.nodes;
                    for (int j = 0; j < nodes.Length; j++)
                    {
                        hash = hash * HashPrime;
                        var node = nodes[j];
                        hash ^= node.position.GetHashCode();
                        hash ^= 17 * (node.connections != null ? node.connections.Length : -1);
                        hash ^= 19 * (int)node.Penalty;
                        hash ^= 41 * (int)node.Tag;
                        hash ^= 57 * (int)node.Area;
                    }

                    //hash ^= 67 * (int)AstarPath.active.debugMode;
                    //hash ^= 73 * AstarPath.active.debugFloor.GetHashCode();
                    //hash ^= 79 * AstarPath.active.debugRoof.GetHashCode();

                    //是否需要更新，为有效的数据
                    validTile = validTile && hash == gizmoMeshes.hash;

                    if (!validTile)
                    {
                        //如果需要更新
                        var newTile = new GizmoTile
                        {
                            tile = Tile,
                            hash = hash,
                            surfaceMesh = CreateNavmeshSurfaceVisualization(Tile),
                            outlineMesh = CreateNavmeshOutlineVisualization(Tile)
                        };


                    //删除，并且替换现有的网格数据
                    Mesh.DestroyImmediate(gizmoMeshes.surfaceMesh);
                    Mesh.DestroyImmediate(gizmoMeshes.outlineMesh);
                    gizmoMeshes = newTile;

                    //if (i < gizmoMeshes.Count)
                    //{
                    //    //删除，并且替换现有的网格数据
                    //    Mesh.DestroyImmediate(gizmoMeshes[i].surfaceMesh);
                    //    Mesh.DestroyImmediate(gizmoMeshes[i].outlineMesh);
                    //    gizmoMeshes[i] = newTile;
                    //}
                    //else
                    //{
                    //    gizmoMeshes.Add(newTile);
                    //}
                }
                //}
            }
        }

        /// <summary>
        /// 创建在编辑器的OnDrawGizmos中使用网状的导航网格表面
        /// </summary>
        /// <param name="tile"></param>
        /// <returns></returns>
        Mesh CreateNavmeshSurfaceVisualization(NavmeshTile tile)
        {
            var mesh = new Mesh();

            mesh.hideFlags = HideFlags.DontSave;

            List<Vector3> vertices = new List<Vector3>(tile.verts.Length);
            List<Color32> colors = new List<Color32>(tile.verts.Length);

            for (int j = 0; j < tile.verts.Length; j++)
            {
                vertices.Add((Vector3)tile.verts[j]);
                colors.Add(new Color32());
            }

            //设置颜色进行绘制
            for (int j = 0; j < tile.nodes.Length; j++)
            {
                var node = tile.nodes[j];
                for (int v = 0; v < 3; v++)
                {
                    //var color = rg.NodeColor(node);
                    var color = NavColor.GetAreaColor(node.Area);
                    //Debug.LogError(node.GetVertexArrayIndex(v) + "    " + tile.verts.Length + "    0000 " + colors.Count);
                    colors[node.GetVertexArrayIndex(v)] = (Color32)color;//(Color32)AstarColor.GetAreaColor(node.Area);
                }
            }

            //设置顶点，三角形和颜色
            mesh.SetVertices(vertices);
            mesh.SetTriangles(tile.tris, 0);
            mesh.SetColors(colors);

            // 上传的所有数据和标记网格不可读
            mesh.UploadMeshData(true);

            // 清理数据
            vertices.Clear();
            colors.Clear();

            return mesh;
        }

        /// <summary>
        ///  创建在编辑器的OnDrawGizmos中使用网状的导航区域
        /// </summary>
        /// <param name="tile"></param>
        /// <returns></returns>
        static Mesh CreateNavmeshOutlineVisualization(NavmeshTile tile)
        {
            var sharedEdges = new bool[3];

            var mesh = new Mesh();

            mesh.hideFlags = HideFlags.DontSave;

            List<Color32> colorList = new List<Color32>();
            List<Int3> edgeList = new List<Int3>();

            for (int j = 0; j < tile.nodes.Length; j++)
            {
                sharedEdges[0] = sharedEdges[1] = sharedEdges[2] = false;

                var node = tile.nodes[j];
                for (int c = 0; c < node.connections.Length; c++)
                {
                    var other = node.connections[c] as TriangleMeshNode;

                    //循环遍历，找到共享的边
                    if (other != null && other.GraphIndex == node.GraphIndex)
                    {
                        for (int v = 0; v < 3; v++)
                        {
                            for (int v2 = 0; v2 < 3; v2++)
                            {
                                if (node.GetVertexIndex(v) == other.GetVertexIndex((v2 + 1) % 3) && node.GetVertexIndex((v + 1) % 3) == other.GetVertexIndex(v2))
                                {
                                    // 找到一个和其他三角形共享的边
                                    sharedEdges[v] = true;
                                    v = 3;
                                    break;
                                }
                            }
                        }
                    }
                }

                for (int v = 0; v < 3; v++)
                {
                    if (!sharedEdges[v])
                    {
                        edgeList.Add(node.GetVertex(v));
                        edgeList.Add(node.GetVertex((v + 1) % 3));
                        var color = (Color32)NavColor.GetAreaColor(node.Area);
                        colorList.Add(color);
                        colorList.Add(color);
                    }
                }
            }


            List<Vector3> vertices = new List<Vector3>(edgeList.Count * 2);
            List<Color32> colors = new List<Color32>(edgeList.Count * 2);
            List<Vector3> normals = new List<Vector3>(edgeList.Count * 2);
            List<int> tris = new List<int>(edgeList.Count * 3);

            //循环每个边的端点，并且为每个边添加两个端点
            for (int j = 0; j < edgeList.Count; j++)
            {
                var vertex = (Vector3)edgeList[j];
                vertices.Add(vertex);
                vertices.Add(vertex);

                //设置颜色
                var color = colorList[j];
                colors.Add(new Color32(color.r, color.g, color.b, 0));
                colors.Add(new Color32(color.r, color.g, color.b, 255));
            }

            //通过循环每条边数据添加每个顶点的法线
            for (int j = 0; j < edgeList.Count; j += 2)
            {
                var lineDir = (Vector3)(edgeList[j + 1] - edgeList[j]);
                lineDir.Normalize();

                normals.Add(lineDir);
                normals.Add(lineDir);
                normals.Add(lineDir);
                normals.Add(lineDir);
            }

            // Setup triangle indices
            // A triangle consists of 3 indices
            // A line (4 vertices) consists of 2 triangles, so 6 triangle indices
            //设置三角形索引
            //一个三角形由三个索引构成
            //一个线（4个顶点）构成2个三角形，因此6个三角形索引
            for (int j = 0, v = 0; j < edgeList.Count * 3; j += 6, v += 4)
            {
                // 第一个三角形
                tris.Add(v + 0);
                tris.Add(v + 1);
                tris.Add(v + 2);

                // 第二个三角形
                tris.Add(v + 1);
                tris.Add(v + 3);
                tris.Add(v + 2);
            }

            // 设置mesh的数据
            mesh.SetVertices(vertices);
            mesh.SetTriangles(tris, 0);
            mesh.SetColors(colors);
            mesh.SetNormals(normals);

            // 上传所有数据并将网格标记为不可读
            mesh.UploadMeshData(true);

            // 释放数据
            colorList.Clear();
            edgeList.Clear();
            vertices.Clear();

            colors.Clear();
            normals.Clear();
            tris.Clear();

            return mesh;
        }

        /// <summary>
        /// 区域绘制
        /// </summary>
        public void OnShowNavMeshSurface()
        {
            if (Tile != null && showNavMesh && showMeshSurface)
            {
                UpdateDebugMeshes();

                if(gizmoMeshes.surfaceMesh != null)
                {
                    for (int pass = 0; pass <= 2; pass++)
                    {
                        navmeshMaterial.SetPass(pass);
                        Graphics.DrawMeshNow(gizmoMeshes.surfaceMesh, Matrix4x4.identity);
                    }
                }
                
                if(gizmoMeshes.outlineMesh != null)
                {
                    navmeshOutlineMaterial.SetPass(0);
                    Graphics.DrawMeshNow(gizmoMeshes.outlineMesh, Matrix4x4.identity);
                }
                
            }
        }

#endif

        #endregion
    }
}
