using MapEditor;
using NavMesh.Camera;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class AirWallEditor:BaseEditor
{
    public AirWallEditor(string moduleName) : base(moduleName)
    {
    }
    #region GUI

    /// <summary>
    /// 空气墙属性
    /// </summary>
    /// <param name="id"></param>
    protected override void DrawPropertyWindow(int id)
    {
        base.DrawPropertyWindow(id);
        if (AirWallManager.Instance.currentModel == null)
        {
            GUI.color = Color.red;
            GUILayout.Label("没有选中空气墙");
            GUI.color = Color.white;
            if (GUILayout.Button("保存到服务器"))
            {
                SceneManager.GetInst().SendToServer();
            }
            return;
        }
        var data = AirWallManager.Instance.currentModel.data;

        data.id = GUIUtils.NumberField("id", data.id);
        GUILayout.BeginHorizontal();
        data.wall_height = GUIUtils.NumberField("墙体高度", data.wall_height);
        data.wall_length = GUIUtils.NumberField("墙体长度", data.wall_length);
        data.wall_width = GUIUtils.NumberField("墙体宽度", data.wall_width);
        GUILayout.EndHorizontal();
        data.wall_height = data.Go.transform.localScale.y;
        data.wall_length = data.Go.transform.localScale.x;
        data.wall_width = data.Go.transform.localScale.z;


        GUILayout.Space(2);
        GUILayout.BeginHorizontal();
        data.x = GUIUtils.NumberField("位置坐标x", data.x);
        data.y = GUIUtils.NumberField("位置坐标y", data.y);
        data.z = GUIUtils.NumberField("位置坐标z", data.z);
        GUILayout.EndHorizontal();
        data.x = data.Go.transform.position.x;
        data.y = data.Go.transform.position.y;
        data.z = data.Go.transform.position.z;



        GUILayout.Space(2);
        data.angle = GUIUtils.NumberField("旋转", data.angle);
        GUILayout.Space(2);
        data.angle = AirWallManager.Instance.currentModel.transform.rotation.eulerAngles.y;



        if (GUILayout.Button("保存到服务器"))
        {
            if (data.id == 0)
            {
                Debug.LogError("保存失敗，id不能是默認值");

                return;
            }
            SceneManager.GetInst().SendToServer();
        }
    }


    /// <summary>
    /// 空气墙控制面板
    /// </summary>
    /// <param name="id"></param>
    protected override void DrawLeftControlPanelWIndow(int id)
    {
        base.DrawLeftControlPanelWIndow(id);
        GUILayout.Label("Here is the control panel of wall air model");

        if (GUILayout.Button("创建新的空气墙"))
        {
            CreateCursorAirWall();
        }

        GUI.DragWindow();
    }

    private void CreateCursorAirWall()
    {
        var swp = AirwallFactory.Instance.GetAirwall();
        if (swp != null)
        {
            AirWallManager.Instance.cursorObj = swp;
        }
    }

    /// <summary>
    /// 空气墙列表
    /// </summary>
    /// <param name="id"></param>
    protected override void DrawRightListWindow(int id)
    {
        base.DrawRightListWindow(id);
        var currentModel = AirWallManager.Instance.currentModel;
        var Server_Wall_List = AirWallManager.Instance.Server_Wall_List;
        var NEW_Wall_List = AirWallManager.Instance.NEW_Wall_List;
        if (Server_Wall_List != null)
        {
            for (int i = 0; i < Server_Wall_List.Count; i++)
            {
                var item = Server_Wall_List[i];
                currentModel = UpdateCurrentModel(currentModel, item);
            }
        }

        if (NEW_Wall_List != null)
        {
            for (int i = 0; i < NEW_Wall_List.Count; i++)
            {
                var item = NEW_Wall_List[i];

                currentModel = UpdateCurrentModel(currentModel, item);

            }
        }
    }

    private Airwallcom UpdateCurrentModel(Airwallcom currentModel, Airwallcom item)
    {
        if (item != null)
        {
            var data = item.data;
            GUI.color = data.isDirty ? Color.red : Color.white;
            if (GUILayout.Button(string.Format("{0} id:{1},scne_id:{2}", data.isSelected ? "--->  " : string.Empty, data.id, data.scene_id)))
            {
                if (currentModel != null)
                {
                    currentModel.data.isSelected = false;
                }
                currentModel = item;
                currentModel.data.isSelected = true;
                currentModel.data.isDirty = true;

                CreateAirWall(item.data);
            }
        }

        return currentModel;
    }

    private void CreateAirWall(AirWallModel item)
    {
        GameObject go;
        var wall =AirWallManager.Instance. FindAirWallFromPos(new Vector3(item.x, item.y, item.z));
        if (wall == null)
        {
            go = AirwallFactory.Instance.GetAirwall();
            if (go != null)
            {
                var t = go.transform;
                t.localScale = new Vector3(item.wall_length, item.wall_height, item.wall_width);
                t.position = new Vector3(item.x, item.y, item.z);
                t.rotation = Quaternion.Euler(0, item.angle, 0);

                go.AddComponent<Airwallcom>().data = item;
            }
        }
        else
        {
            go = wall.gameObject;
        }

        item.Go = go;
        CameraMove.GetInst().CameraLookAtTarget(go);
        TransformGizmos.TransformGizmo.GetInst().SetTraget(go.transform);

    }
    #endregion

}