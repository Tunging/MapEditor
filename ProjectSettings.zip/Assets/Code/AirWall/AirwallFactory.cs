using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class AirwallFactory
{
    #region singleton
    private static AirwallFactory instance;
    public static AirwallFactory Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new AirwallFactory();
            }
            return instance;
        }
    }

    private AirwallFactory()
    {

        if (!string.IsNullOrEmpty(airwallPrefabPath))
        {
            airwallPrefab = Resources.Load<GameObject>(airwallPrefabPath);
        }
    }

    #endregion


    //预设
    /// <summary>
    /// 预设路径
    /// </summary>
    private string airwallPrefabPath = "area_box";
    /// <summary>
    /// 预设体
    /// </summary>
    GameObject airwallPrefab;
    public GameObject GetAirwall()
    {
        return GameObject.Instantiate<GameObject>(airwallPrefab);
    }
}