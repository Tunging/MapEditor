﻿using System.Linq;
using LitJson;
using MapEditor;
using NavMesh.Camera;
using System;
using System.Collections.Generic;
using System.Text;
using Tgame.Game.Table;
using UnityEngine;
using ZLib;

/// <summary>
/// OfflineGatherManager
/// author @dongzhiwei
/// date   2018/5/30 16:34:18
/// </summary>
public class OfflineGatherManager : Singleton<OfflineGatherManager>
{
    private bool enable;
    public bool Enable
    {
        get
        {
            return enable;
        }
        set
        {
            if (value != enable)
            {
                enable = value;
                editor = new OfflineGatherEditor("Offline Gather");

            }
        }
    }

    private OGMono curSelect;
    public OGMono CurSelect
    {
        get
        {
            return curSelect;
        }
        internal set
        {
            if (curSelect && curSelect != value)
            {
                curSelect.Data.IsSelected = false;

            }

            curSelect = value;

            CurSelect.Data.IsDirty = true;
            TransformGizmos.TransformGizmo.GetInst().SetTraget(curSelect.transform);

            CameraMove.GetInst().CameraLookAtTarget(curSelect.gameObject);
            curSelect.Data.IsSelected = true;

        }
    }

    List<int> listWaitForremove = new List<int>();

    internal void TryMoveLocalData()
    {
        TryRemoveData(CursorObj.Data);
    }

    public List<OfflineGather> LocalOfflineGather = new List<OfflineGather>();
    public OGMono CursorObj { get; internal set; }

    internal void TryRemoveData(OfflineGather data)
    {
        if (LocalOfflineGather.Exists(o => o.id == data.id))
        {
            LocalOfflineGather.Remove(data);
            listWaitForremove.Add(data.id);

        }

        if (ServerOfflineGathers.Contains(data))
        {
            ServerOfflineGathers.Remove(data);
            listWaitForremove.Add(data.id);
        }
    }

    internal OGMono CreateOG(Table_Client_Model item)
    {
        OfflineGather og = new OfflineGather()
        {
            id = 0,
            model_id = item.id
            ,
            scene_id = SceneManager.GetInst().CurrScene.id,
            trigger_radius = 5,
            IsServerData = false
        };
        LocalOfflineGather.Add(og);

        return OfflineGatherData.instance.Create(og);
        //return OGFactory.instance.CreateOGMono(item);
    }

    List<OfflineGather> ServerOfflineGathers = new List<OfflineGather>();
    internal List<OfflineGather> ListOG()
    {
        return ServerOfflineGathers;
    }

    OfflineGatherEditor editor;
    #region Manager

    public void OnGUI()
    {
        if (Enable)
        {
            if (editor != null)
            {
                editor.OnGUI();
            }


            ProcessMouseEvent();
        }
    }

    private void ProcessMouseEvent()
    {
        var e = Event.current;
        if (e != null)
        {
            if (e.clickCount == 1)
            {
                if (e.button == 0)
                {
                    OGMono oGMono = OfflineGatherData.instance.GetOgFromPos();

                    if (oGMono != null)
                    {
                        CurSelect = oGMono;

                        //TransformGizmos.TransformGizmo.GetInst().SetTraget(CurSelect.transform);
                    }
                }
            }
            else if (e.clickCount == 2)
            {
                if (e.button == 0)
                {
                    if (CursorObj)
                    {
                        CursorObj.Position = CursorObj.transform.position;
                    }

                    CursorObj = null;


                }
                else if (e.button == 1)
                {
                    OfflineGatherData.instance.Destory(CursorObj);
                }
            }
        }

        if (Input.GetKey(KeyCode.Delete))
        {
            if (CurSelect != null)
            {

                OfflineGatherData.instance.Destory(CurSelect);
            }
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            if (CurSelect != null)
            {
                CurSelect = null;
            }
        }

    }

    internal void Reset()
    {
        Clear();
    }

    internal void OnUpdate()
    {
        if (Enable == false)
            return;

        if (CursorObj != null)
        {
            CursorObj.transform.position = SceneManager.MousePos;
        }
    }

    internal void OnShow()
    {
        if (!Enable)
        {
            Enable = true;
        }
        OfflineGatherData.instance.DestoryAll();

        GetServerOGList();
    }
    #endregion

    private void GetServerOGList()
    {
        // string path = string.Format("{0}{1}", Config.Offline_Gather_List, SceneManager.GetInst().CurrScene.id);
        CoroutineManager.instance.StartCoroutine(WWWLoad.GetInst().LoadServerData(Config.Offline_Gather_List, OnDataLoadOver));
    }

    private void OnDataLoadOver(string obj)
    {
        //ServerOfflineGathers = JsonUtility.FromJson<List<OfflineGather>>("["+obj+"]");
        //ServerOfflineGathers = JsonMapper.ToObject<List<OfflineGather>>(obj);
        var lines = obj.Split('\n');
        foreach (var item in lines)
        {
            if (string.IsNullOrEmpty(item))
                continue;

            var og = JsonUtility.FromJson<OfflineGather>(item);
            if (og.scene_id == SceneManager.GetInst().CurrScene.id)
            {
                ServerOfflineGathers.Add(og);
            }
        }

        foreach (var item in ServerOfflineGathers)
        {
            item.IsServerData = true;
            OfflineGatherData.instance.Create(item);
        }

    }

    public void SaveToServer()
    {
        var list = OfflineGatherData.instance.oGs;
        foreach (var item in list)
        {
            if (item.Data.IsDirty)
            {
                if (item.Data.IsServerData)
                {

                    CoroutineManager.instance.StartCoroutine(WWWSend.GetInst().SendInfo(Config.Offline_Gather_Update, item.Data.ToForm(), OnSendOver, item));
                }
                else
                {
                    CoroutineManager.instance.StartCoroutine(WWWSend.GetInst().SendInfo(Config.Offline_Gather_Insert, item.Data.ToForm(), OnSendOver, item));
                }
            }
        }

        foreach (var item in listWaitForremove)
        {
            WWWForm form = new WWWForm();
            form.AddField("id", item);
            form.AddField("scene_id", SceneManager.GetInst().CurrScene.id);
            CoroutineManager.instance.StartCoroutine(WWWSend.GetInst().SendInfo(Config.Offline_Gather_Delete, form, OnDeleteOver));
        }
    }

    private void OnDeleteOver(WWWMessage arg1, object arg2)
    {
        if (arg1.msg != null)
        {
            GUINotice.Show(arg1.msg[0]);
            return;
        }

        if (arg1.success)
        {
            GUINotice.Show("删除成功");
        }
    }

    private void OnSendOver(WWWMessage arg1, object arg2)
    {
        if (arg1.msg != null)
        {
            GUINotice.Show(arg1.msg[0]);
            return;
        }

        if (arg1.success)
        {
            var og = arg2 as OGMono;
            if (og)
                og.Data.IsDirty = false;
            GUINotice.Show("保存成功");
        }
    }

    public void Clear()
    {
        ServerOfflineGathers.Clear();
        OfflineGatherData.instance.DestoryAll();
    }
}