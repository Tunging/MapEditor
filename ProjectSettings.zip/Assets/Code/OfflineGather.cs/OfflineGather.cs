﻿using MapEditor;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

/// <summary>
/// OfflineGatherData
/// author @dongzhiwei
/// date   2018/5/30 15:41:38
/// </summary>
public class OfflineGather
{
    public bool IsDirty { get; set; }

    public bool IsSelected { get; set; }
    public bool IsServerData { get; set; }

    ///<summary>
    /// 主键：ID
    ///</summary>
    public int id;


    ///<summary>
    /// 场景id
    ///</summary>
    public int scene_id;


    ///<summary>
    /// 坐标x
    ///</summary>
    public float x;


    ///<summary>
    /// 坐标y
    ///</summary>
    public float y;


    ///<summary>
    /// 坐标z
    ///</summary>
    public float z;


    ///<summary>
    /// 场景完成度积分
    ///</summary>
    public int completion_socre;


    ///<summary>
    /// 模型id
    ///</summary>
    public int model_id;


    ///<summary>
    /// 特效id
    ///</summary>
    public int effect_id;


    ///<summary>
    /// 触发半径
    ///</summary>
    public float trigger_radius;


    ///<summary>
    /// 采集动作
    ///</summary>
    public int gather_action;


    ///<summary>
    /// 采集特效id
    ///</summary>
    public int gather_effect;


    ///<summary>
    /// 碰撞后的飞行到人身上的特效id
    ///</summary>
    public int fly_effect_id;


    ///<summary>
    /// 采集音效
    ///</summary>
    public int gather_sound;


    ///<summary>
    /// 采集提示
    ///</summary>
    public string gather_tips = string.Empty;


    ///<summary>
    /// 采集提示国际化
    ///</summary>
    public string gather_tips_i18n = string.Empty;


    ///<summary>
    /// 采集奖励
    ///</summary>
    public int reward;


    ///<summary>
    /// 显示距离
    ///</summary>
    public float show_distance;


    ///<summary>
    /// 名称国际化
    ///</summary>
    public string name_i18n = string.Empty;


    ///<summary>
    /// buff id
    ///</summary>
    public int buff_id;


    ///<summary>
    /// 能否重复采集(下次游戏)
    ///</summary>
    public bool can_gather_multi_times;

    public WWWForm ToForm()
    {
        WWWForm form = new WWWForm();
        form.AddField("id",id);
        form.AddField("scene_id", scene_id);
        form.AddField("x",x.ToString("F2"));
        form.AddField("y",y.ToString("F2"));
        form.AddField("z",z.ToString("F2"));
        form.AddField("completion_socre", completion_socre);
        form.AddField("model_id", model_id);
        form.AddField("effect_id", effect_id);
        form.AddField("trigger_radius", trigger_radius.ToString("F2"));
        form.AddField("gather_action", gather_action);
        form.AddField("gather_effect", gather_effect);
        form.AddField("fly_effect_id", fly_effect_id);
        form.AddField("gather_sound", gather_sound);
        form.AddField("gather_tips", gather_tips);
        form.AddField("gather_tips_i18n", gather_tips_i18n);
        form.AddField("reward", reward);
        form.AddField("show_distance", show_distance.ToString("F2"));
        form.AddField("name_i18n", name_i18n);
        form.AddField("buff_id", buff_id);
        form.AddField("can_gather_multi_times", GameUtils.BoolToString(this.can_gather_multi_times));
        return form;
    }
}