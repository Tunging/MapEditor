﻿using System;
using System.Collections.Generic;
using System.Text;
using Tgame.Game.Table;
using UnityEngine;
using ZTool.Res;

/// <summary>
/// OGMono
/// author @dongzhiwei
/// date   2018/5/31 15:29:00
/// </summary>
public class OGMono : MonoBehaviour
{
    public OfflineGather Data { get; set; }

    public Vector3 Position
    {
        get
        {
            return new Vector3(Data.x, Data.y, Data.z);
        }
        set
        {
            Data.x = value.x;
            Data.y = value.y;
            Data.z = value.z;   
        }
    }
    Transform tran;


    private void Awake()
    {
        tran = transform;
    }
    bool hasStart = false;
    internal void StartUp(OfflineGather og)
    {
        if (hasStart)
            return;
        hasStart = true;

        this.Data = og;

        tran.position = new Vector3(og.x, og.y, og.z);

        Table_Client_Model tableModel = Table_Client_Model.GetPrimary(og.model_id);
        if (tableModel != null)
        {
            ResourcesLoad.instance.LoadAssetBundle(tableModel.path, OnLoadOver, isClone: true);
        }
        else
        {
            Debug.LogError("No model data found , id = " + og.model_id + "  , from offline data id = " + og.id);
        }
    }

    private void OnLoadOver(string path, UnityEngine.Object obj, object parameter)
    {
        if (obj != null)
        {
            GameObject model = obj as GameObject;
            if (model != null)
            {
                model.transform.SetParent(this.tran, false);
                model.transform.localPosition = Vector3.zero;
                model.transform.localEulerAngles = Vector3.zero;

                //model.transform.SetPositionAndRotation(Vector3.zero,Quaternion.identity);
                model.transform.localScale = Vector3.one;


            }
        }
    }
}