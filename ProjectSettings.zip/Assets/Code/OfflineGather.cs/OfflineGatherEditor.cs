﻿using UnityEngine;
using System;
using Tgame.Game.Table;
using MapEditor;

internal class OfflineGatherEditor : BaseEditor
{
    public OfflineGatherEditor(string moduleName) : base(moduleName)
    {
    }

    protected override void DrawLeftControlPanelWIndow(int id)
    {


        var listModel = Table_Client_Model.GetAllPrimaryList();
        foreach (var item in listModel)
        {
            if (GUILayout.Button(string.Format("{0} >> {1}", item.id, item.name)))
            {
                if (OfflineGatherManager.instance.CursorObj != null)
                {
                    //OfflineGatherData.instance.Destory(OfflineGatherManager.instance.CursorObj);
                    OfflineGatherManager.instance.TryMoveLocalData();
                }
                OfflineGatherManager.instance.CursorObj = OfflineGatherManager.instance.CreateOG(item);
            }
        }
    }

    protected override void DrawPropertyWindow(int id)
    {
        if (GUILayout.Button("Save to Server "))
        {
            OfflineGatherManager.instance.SaveToServer();
        }
        if (OfflineGatherManager.instance.CurSelect)
        {
            var go = OfflineGatherManager.instance.CurSelect.transform;
            var data = OfflineGatherManager.instance.CurSelect.Data;
            GUILayout.BeginHorizontal();

            data.id = GUIUtils.NumberField("id", data.id, true);
            data.scene_id = GUIUtils.NumberField("scene id", data.scene_id, false);
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();

            data.x = GUIUtils.NumberField("pos x", data.x);
            data.y = GUIUtils.NumberField("pos y", data.y);
            data.z = GUIUtils.NumberField("pos z", data.z);
            GUILayout.EndHorizontal();
            data.x = go.transform.position.x;
            data.y = go.transform.position.y;
            data.z = go.transform.position.z;

            GUILayout.BeginHorizontal();

            data.completion_socre = GUIUtils.NumberField("score ", data.completion_socre);
            data.model_id = GUIUtils.NumberField("model_id", data.model_id);
            data.effect_id = GUIUtils.NumberField("effect _id", data.effect_id);
            data.trigger_radius = GUIUtils.NumberField("触发半径    ", data.trigger_radius);

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            data.reward = GUIUtils.NumberField("奖励id", data.reward);

            data.show_distance = GUIUtils.NumberField("显示距离", data.show_distance);

            data.can_gather_multi_times = GUIUtils.BoolField("是否可以重复采集", data.can_gather_multi_times);
            GUILayout.EndHorizontal();


            data.gather_tips_i18n = GUIUtils.StrField("采集提示国际化", data.gather_tips_i18n);

            data.name_i18n = GUIUtils.StrField("名称国际化", data.name_i18n);

        }
    }

    protected override void DrawRightListWindow(int id)
    {
        foreach (var item in OfflineGatherManager.instance.LocalOfflineGather)
        {
            if (GUILayout.Button(string.Format("<color={2}>{0}  << {1}</color>", item.id, item.name_i18n, item.IsDirty ? "#ff0000" : (item.IsSelected ? "#00ff00" : "#ffffff"))))
            {
                OfflineGatherManager.instance.CurSelect = OfflineGatherData.instance.GetOG(item.id);
            }
        }
        var list = OfflineGatherManager.instance.ListOG();
        if (list != null)
        {
            for (int i = 0; i < list.Count; i++)
            {
                var item = list[i];
                if (GUILayout.Button(string.Format("<color={2}>{0}  << {1}</color>", item.id, item.name_i18n, item.IsDirty ? "#ff0000" : (item.IsSelected ? "#00ff00" : "#ffffff"))))
                {
                    OfflineGatherManager.instance.CurSelect = OfflineGatherData.instance.GetOG(item.id);
                }
            }
        }

    }
}