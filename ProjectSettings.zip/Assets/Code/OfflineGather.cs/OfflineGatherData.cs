﻿using System.Linq;
using ZLib;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using MapEditor;

/// <summary>
/// OfflineGatherData
/// author @dongzhiwei
/// date   2018/5/31 15:09:08
/// </summary>
public class OfflineGatherData : Singleton<OfflineGatherData>
{

    public List<OGMono> oGs = new List<OGMono>();

    internal OGMono Create(OfflineGather item)
    {
        var og = OGFactory.instance.CreateOGMono(item);
        oGs.Add(og);

        return og;
    }

    internal void DestoryAll()
    {
        for (int i = oGs.Count - 1; i >= 0; i--)
        {
            var item = oGs[i];
            if (item != null)
                Destory(item);
        }
        oGs.Clear();
    }

    internal OGMono GetOgFromPos()
    {
        var pos = SceneManager.MousePos;
        float minpos = float.MaxValue;
        OGMono result = null;
        for (int i = 0; i < oGs.Count; i++)
        {
            var item = oGs[i];
            if (item != null)
            {
                var dis = Vector3.Distance(pos, item.Position);
                if (dis <= Config.MAX_FIND_SPRITE_DIS)
                {
                    if (dis < minpos)
                    {
                        minpos = dis;
                        result = item;
                    }
                }
            }
        }

        return result;
    }

    internal OGMono GetOG(int id)
    {
        return oGs.Where(m => m.Data.id == id).FirstOrDefault();
    }

    internal void Destory(OGMono cursorObj)
    {
        if (cursorObj != null)
        {
        OfflineGatherManager.instance.TryRemoveData(cursorObj.Data);
            oGs.Remove(cursorObj);
            GameObject.Destroy(cursorObj.gameObject);
        }
    }

}