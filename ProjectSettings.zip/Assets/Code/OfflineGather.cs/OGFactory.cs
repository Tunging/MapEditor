﻿using Tgame.Game.Table;
using System.Collections.Generic;
using UnityEngine;
using ZLib;
using MapEditor;

/// <summary>
/// OGFactory
/// author @dongzhiwei
/// date   2018/5/31 16:13:54
/// </summary>
public class OGFactory : Singleton<OGFactory>
{
    public OGMono CreateOGMono(OfflineGather item)
    {
        var tableModel = Table_Client_Model.GetPrimary(item.model_id);
        if (tableModel == null)
        {
            Debug.LogError("model data is null ,id = " + item.id);
        }
        else
        {

            GameObject go = new GameObject(string.Format("{0}/{1}", item.id,item.name_i18n));
            go.transform.SetParent(UGE.trmContainers.sprsContainer,true);
            var mono = go.AddComponent<OGMono>();
            mono.StartUp(item);

            return mono;
        }

        return null;
    }
}