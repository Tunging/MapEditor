﻿using System;
using System.Collections.Generic;
using ZFrame;
using ZLib;
using ZTool.Res;
using ZTool.Table;

/// <summary>
/// 加载策划静态配置信息
/// @author Ollydbg
/// @date 2018-2-28
/// </summary>
public class LoadResProcessor:Singleton<LoadResProcessor>
{

    Action LoadOverCallback = null;
    public void ReceivedLoadRes(Action onLoadOVer)
    {
        this.LoadOverCallback = onLoadOVer;
        OnLoadConfig(LocalResConfig.GetInst().Pre_Load_Tables);
    }

    //已经加载的配置资源
    private int m_iCount;
    //所有的资源配置数量
    private int m_iAllConfigCount;

    static public string ShowProgress = "0/0";
    static public double costTime;
    static public DateTime lastttt;

    private void OnLoadConfig(string[] config)
    {
        if (config == null || config.Length == 0)
            return;
        //GameData.instance.configReady = false;
        //lastttt = DateTime.Now;

        m_iCount = 0;
        m_iAllConfigCount = config.Length;
        for (int i = 0; i < config.Length; i++)
        {
            try
            {
                string name = config[i].TrimEnd(new char[] { '\r' });
                //string name = config[i];

                if (OnCheckConfig(name))
                    continue;

                string url = string.Format("Config/{0}", name);
                System.Text.Encoding enco = null;
                if (ResourcesLoad.instance.isHaveResForOther(url))
                {
                    enco = System.Text.Encoding.UTF8;
                }
                //Debug.LogError(url);
                //加载配置资源
                ResourcesLoad.instance.LoadBytes(url, OnLoadConfigOver, name, true, enco);
            }
            catch (Exception ex)
            {
                Debug.LogError("配置资源 " + config[i] + " 加载出问题\n " + ex.ToString() + "\n" + ex.StackTrace);

                //跳过此配置的加载
                m_iCount++;
                OnAllConfigLoadOver();
            }
        }
    }

    private void OnLoadConfigOver(string path, object obj, object parameter)
    {
        if (obj == null)
        {
            //Debug.LogError("sss: " + path + "_____null"); 
            m_iCount += 1;
            OnAllConfigLoadOver();
            return;
        }

        string name = (string)parameter;
        Type type = Type.GetType(string.Format("Tgame.Game.Table.Table_{0}", TableManager.ToTitleCase(name)));
        if (type != null)
        {
            //string str = GameUtils.BytesToString((byte[])obj);
            //TableManager.LoadTable(str, name, type);
            object[] objs = new object[]
            {
                obj,name,type
            };
            //HandlerDataInWorkItem(objs);
            //启动线程池 操作数据解析存储
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(HandlerDataInWorkItem), objs);
            //HandlerDataInWorkItem(objs);
        }
        else
        {
            OnAllConfigLoadOver();
            throw new Exception("table没有找到" + name);
        }

    }
    object lockOOO = new object();
    /// <summary>
    /// 非主线程解析数据
    /// </summary>
    /// <param name="parmsArr"></param>
    void HandlerDataInWorkItem(object parmsArr)
    {
        //注意，这里写法为了安全降低了执行效率，如需优化需关闭lock，代码需要进一步验证 ，
        //已发现问题 多线程会出现问题，问题暂未定位
        //lock (lockOOO)
        {

            lastttt = DateTime.Now;
            object[] parms = parmsArr as object[];
            byte[] obj = parms[0] as byte[];
            string name = parms[1] as String;
            Type type = parms[2] as Type;
            try
            {
                TableManager.LoadTable((byte[])obj, name, type);

            }
            catch (Exception e)
            {
                m_iCount += 1;
                Debug.LogError(e.Message + " " + name);
            }
            m_iCount += 1;
            costTime += ((TimeSpan)(DateTime.Now - lastttt)).TotalMilliseconds;
            OnAllConfigLoadOver();
        }
    }

    private bool can_update_info = false;
    private void OnAllConfigLoadOver()
    {
        //float pro = (float)m_iCount / m_iAllConfigCount * 0.95f + 0.05f;
        float pro = (float)m_iCount / m_iAllConfigCount * 0.95f;
        ShowProgress = string.Format("{0}/{1}", m_iCount, m_iAllConfigCount);
        if (m_iCount >= m_iAllConfigCount)
        {
            pro = 1.0f;
            can_update_info = true;

            //清理需要加载的table表数据
            //GamePreLoadData.GetInst().ClearPreLoadTables();

            //Debug.LogError("  config load done  ");
            //costTime = ((TimeSpan)(DateTime.Now - lastttt)).TotalMilliseconds;
            //costTime = UnityEngine.Time.realtimeSinceStartup - costTime;
            Debug.Log("load config and extuce Over!!!" + m_iCount + "/" + m_iAllConfigCount);
            //GameData.instance.configReady = true;
            if (LoadOverCallback!=null)
            {
                LoadOverCallback();
            }
        }

        ////更新配表数据加载进度
        //CodeBridgeTool.instance.UpdateTableConfigLoadAction(pro);

        //通知外部资源加载进度
        //lm.SetConfigProgress(pro);
        //TODO 通过消息派发
    }

    /// <summary>
    /// 检测配置数据
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    private bool OnCheckConfig(string path)
    {
        if (string.IsNullOrEmpty(path))
        {
            m_iAllConfigCount--;
            OnAllConfigLoadOver();
            return true;
        }
        return false;
    }
}
