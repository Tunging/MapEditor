﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

/// <summary>
/// BaseEditor
/// author @dongzhiwei
/// date   2018/5/30 16:06:27
/// </summary>
public class BaseEditor
{
    Rect leftwindowRect = new Rect(0, 300, 300, Screen.height - 300 - 20);
    Rect PropertyRect = new Rect(300, 0, 600, 330);
    Rect rightwindowRect = new Rect(Screen.width - 300, 300, 300, Screen.height - 300 - 20);
    Vector2 wallListScrollrect = new Vector2();
    Vector2 modelListScrollrect = new Vector2();


    string ModuleName { get; set; }
    public BaseEditor(string moduleName)
    {
        this.ModuleName = moduleName;
    }

    public void OnGUI()
    {
        GUI.Window(0, PropertyRect, DrawProperty, ModuleName + "属性");
        GUI.Window(1, leftwindowRect, DrawLeftControlPanel, ModuleName + "控制面板");
        GUI.Window(2, rightwindowRect, DrawRightList, ModuleName + "列表");
    }

    private void DrawRightList(int id)
    {
        wallListScrollrect = GUILayout.BeginScrollView(wallListScrollrect);
        DrawRightListWindow(id);
        GUILayout.EndScrollView();
    }

    private void DrawLeftControlPanel(int id)
    {
        modelListScrollrect = GUILayout.BeginScrollView(modelListScrollrect);
        DrawLeftControlPanelWIndow(id);
        GUILayout.EndScrollView();
    }

    private void DrawProperty(int id)
    {
        DrawPropertyWindow(id);
    }

    protected virtual void DrawPropertyWindow(int id) { }
    protected virtual void DrawLeftControlPanelWIndow(int id) { }
    protected virtual void DrawRightListWindow(int id) { }

}