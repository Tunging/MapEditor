using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class SoundEmitterFactory
{
    #region singleton
    private static SoundEmitterFactory instance;
    public static SoundEmitterFactory Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new SoundEmitterFactory();
            }
            return instance;
        }
    }

    private SoundEmitterFactory()
    {

        if (!string.IsNullOrEmpty(SoundEmitterPrefabPath))
        {
            SoundEmitterPrefab = Resources.Load<GameObject>(SoundEmitterPrefabPath);
        }
    }

    #endregion

    private string SoundEmitterPrefabMaterialPath = "Materials/soundMaterial";
    //预设
    /// <summary>
    /// 预设路径
    /// </summary>
    private string SoundEmitterPrefabPath = "area_box";
    /// <summary>
    /// 预设体
    /// </summary>
    GameObject SoundEmitterPrefab;
    public GameObject GetSoundEmitter(Shape type)
    {
        GameObject go = null;
        switch (type)
        {
            case Shape.Cube:
                go =  GameObject.CreatePrimitive(PrimitiveType.Cube);
                break;
            case Shape.Sphere:
                go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                break;
            default:
                go= GameObject.CreatePrimitive(PrimitiveType.Cube);
                break;  
        }

        var render = go.GetComponent<MeshRenderer>();
        if (render)
        {
            render.material = Resources.Load(SoundEmitterPrefabMaterialPath) as Material;
        }
        return go;
    }


}
public enum Shape
{
    Cube = 1,
    Sphere
}