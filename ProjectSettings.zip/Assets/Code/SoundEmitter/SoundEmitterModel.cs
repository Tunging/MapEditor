﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class SoundEmitterModel
{
    /// <summary>
    /// id
    /// </summary>
    public int id;
    /// <summary>
    /// map_id
    /// </summary>
    public int group_id;
    /// <summary>
    /// the shape of collider  (1,cube ; 2,sphere)
    /// </summary>
    public int shape;
    /// <summary>
    /// the radius of the sphere radius ,if the shape if sphere
    /// </summary>
    public float radius;
    /// <summary>
    /// wall's x
    /// </summary>
    public float wall_length;
    /// <summary>
    /// wall's height
    /// </summary>
    public float wall_height;
    /// <summary>
    /// wall's z
    /// </summary>
    public float wall_width;
    /// <summary>
    /// wall's pos_x
    /// </summary>
    public float x;
    /// <summary>
    /// wall's pos_y
    /// </summary>
    public float y;
    /// <summary>
    /// wall's pos_z
    /// </summary>
    public float z;
    /// <summary>
    /// wall's angle of rotation angle
    /// </summary>
    public float angle;
    /// <summary>
    /// sound event id 
    /// </summary>
    public int sound_id;
    /// <summary>
    /// 描述
    /// </summary>
    public string des_i18n;
    /// <summary>
    /// 触发器类型
    /// </summary>
    public int trigger_type;


    public GameObject Go { get; set; }
    public bool isDirty { get; set; }
    public bool isSelected { get; set; }


    public WWWForm SerializeToForm() {
        WWWForm form = new WWWForm();

        form.AddField("id", id);
        form.AddField("group_id", group_id);
        form.AddField("shape", shape);
        form.AddField("radius", radius.ToString("F2"));
        form.AddField("wall_length", wall_length.ToString("F2"));
        form.AddField("wall_height", wall_height.ToString("F2"));
        form.AddField("wall_width", wall_width.ToString("F2"));
        form.AddField("x", x.ToString("F2"));
        form.AddField("y", y.ToString("F2"));
        form.AddField("z", z.ToString("F2"));
        form.AddField("angle", angle.ToString("F2"));
        form.AddField("sound_id", sound_id);
        form.AddField("des_i18n", des_i18n);
        form.AddField("trigger_type", trigger_type);

        return form;
    }
}

public class SoundEmittercom:MonoBehaviour
{
    public SoundEmitterModel data;
}