using MapEditor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZLib;
using UnityEngine;
using NavMesh.Camera;

public class SoundEmitterManager
{

    #region singleton

    private static SoundEmitterManager instance;

    public static SoundEmitterManager Instance
    {
        get
        {
            if (instance == null)
                instance = new SoundEmitterManager();
            return instance;
        }
    }

    private bool _enable;
    public bool Enable
    {
        get
        {
            return _enable;
        }
        internal set
        {

            if (value && value != _enable)
            {
                TransformGizmos.TransformGizmo.GetInst().OnBeginMoveEvent += OnMoveSoundEmitter;
                TransformGizmos.TransformGizmo.GetInst().OnBeginRotateEvent += OnRotateSoundEmitter;
                TransformGizmos.TransformGizmo.GetInst().OnBeginScaleEvent += OnScaleSoundEmitter;
            }
            else if (!value && value != _enable)
            {
                TransformGizmos.TransformGizmo.GetInst().OnBeginMoveEvent -= OnMoveSoundEmitter;
                TransformGizmos.TransformGizmo.GetInst().OnBeginRotateEvent -= OnRotateSoundEmitter;
                TransformGizmos.TransformGizmo.GetInst().OnBeginScaleEvent -= OnScaleSoundEmitter;
            }
            _enable = value;
        }
    }

    private SoundEmitterManager()
    {
        LoadOutLineShader();

        editor = new SoundEmitterEditor();

        net = new SoundEmitterNet(ListLocalSoundCom, ListServerSoundCom, List_Wall_Remove);

        Tick.AddLateUpdate(Update);
    }

    #endregion
    #region 操作控件事件

    private void OnScaleSoundEmitter()
    {
        var t = currentModel.gameObject.transform.localScale;
        currentModel.data.wall_width = t.z;
        currentModel.data.wall_height = t.y;
        currentModel.data.wall_length = t.x;
        currentModel.data.isDirty = true;
    }

    private void OnRotateSoundEmitter()
    {
        var t = currentModel.transform.rotation.eulerAngles;
        currentModel.data.angle = t.y;
        currentModel.data.isDirty = true;
    }

    private void OnMoveSoundEmitter()
    {
        var t = currentModel.gameObject.transform.position;
        currentModel.data.x = t.x;
        currentModel.data.y = t.y;
        currentModel.data.z = t.z;
        currentModel.data.isDirty = true;
    }
    #endregion


    /// <summary>
    /// 当前鼠标的位置
    /// </summary>`
    Vector3 cursorPos;
    /// <summary>
    /// 当前鼠标上的物体
    /// </summary>
    public GameObject cursorObj = null;
    Transform tran = null;

    /// <summary>
    /// 新创建的list
    /// </summary>
    public List<SoundEmittercom> ListLocalSoundCom = new List<SoundEmittercom>();
    /// <summary>
    /// 服务器空气墙数据列表
    /// </summary>
    public List<SoundEmittercom> ListServerSoundCom = new List<SoundEmittercom>();



    public Dictionary<int, List<SoundEmitterModel>> DictServerSoundComGroup = new Dictionary<int, List<SoundEmitterModel>>();

    List<int> List_Wall_Remove = new List<int>();

    public SoundEmitterEditor editor;
    public SoundEmitterNet net;


    public bool hasGetData = false;

    public void Show()
    {
        if (Enable) return;


        Enable = true;
        Reset();
        if (!hasGetData)
        {

            SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(Config.Sound_Emitter_LIST, OnGetServerData));
        }
    }

    private void OnGetServerData(string text)
    {
        if ( string.IsNullOrEmpty(text))
        {
            GUINotice.Show("<color=red> 找不到 声音组件 信息数据 </color>");
            return;
        }

        AnalysisServerData(text);
    }


    private void AnalysisServerData(string text)
    {
        Debug.LogError(text);
        hasGetData = true;
        string[] parts = text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < parts.Length; i++)
        {
            var str = parts[i];
            if (string.IsNullOrEmpty(str))
            {
                continue;
            }

            var model = JsonUtility.FromJson<SoundEmitterModel>(str);
            if (model != null)
            {
                if (DictServerSoundComGroup.ContainsKey(model.group_id))
                {
                    List<SoundEmitterModel> list = DictServerSoundComGroup[model.group_id];
                    list.Add(model);
                }
                else
                {
                    List<SoundEmitterModel> list = new List<SoundEmitterModel>();
                    list.Add(model);
                    DictServerSoundComGroup.Add(model.group_id, list);

                }
                //if (model.map_id != SceneManager.GetInst().CurrScene.scene_soundgroup_id) continue;
                //GameObject go = SoundEmitterFactory.Instance.GetSoundEmitter((Shape)model.shape);
                //var com = go.AddComponent<SoundEmittercom>();
                //go.transform.position = new Vector3(model.x, model.y, model.z);
                //go.transform.localScale = new Vector3(model.wall_length, model.wall_height, model.wall_width);
                //go.transform.rotation = Quaternion.Euler(0, model.angle, 0);
                //go.name = string.Format("{0}--sound:{1}--{2}",model.id, model.sound_id,model.des_i18n);
                //model.Go = go;
                //com.data = model;

                //ListServerSoundCom.Add(com);
            }
        }
        OnSetCurrGroupData();
        Enable = true;
    }


    public void OnSetCurrGroupData()
    {
        int _mid = SceneManager.GetInst().CurrScene.scene_soundgroup_id;
        if (_mid != 0)
        {
            var list = DictServerSoundComGroup[_mid];
            ListServerSoundCom.Clear();
            for (int i = 0; i < list.Count; i++)
            {
                var model = list[i];
                GameObject go = SoundEmitterFactory.Instance.GetSoundEmitter((Shape)model.shape);
                var com = go.AddComponent<SoundEmittercom>();
                go.transform.position = new Vector3(model.x, model.y, model.z);
                go.transform.localScale = new Vector3(model.wall_length, model.wall_height, model.wall_width);
                go.transform.rotation = Quaternion.Euler(0, model.angle, 0);
                go.name = string.Format("{0}--sound:{1}--{2}", model.id, model.sound_id, model.des_i18n);
                model.Go = go;
                com.data = model;

                ListServerSoundCom.Add(com);
            }
        }
    }

    public void Reset()
    {
        for (int i = 0; i < ListServerSoundCom.Count; i++)
        {
            var item = ListServerSoundCom[i];
            if (item == null) continue;
            if (item.gameObject != null)
                GameObject.Destroy(item.gameObject);
        }

        ListServerSoundCom.Clear();

        for (int i = 0; i < ListLocalSoundCom.Count; i++)
        {
            var item = ListLocalSoundCom[i];
            if (item == null || item.gameObject == null) continue;
            GameObject.Destroy(item.gameObject);
        }

        ListLocalSoundCom.Clear();
    }


    #region Update
    private void Update()
    {
        cursorPos = SceneManager.MousePos;


        if (cursorObj == null)
            return;

        //更新位置坐标
        cursorObj.transform.position = cursorPos;
    }

    #endregion

    /// <summary>
    /// 当前选中的空气墙
    /// </summary>
    public SoundEmittercom currentModel = null;

    public void OnGUI()
    {
        if (Enable == false) return;

        editor.OnGUI();

        //处理鼠标操作
        ProcessMouseEvent();
    }

    #region 鼠标操作种怪，取消等操作

    /// <summary>
    /// 处理鼠标事件
    /// </summary>
    void ProcessMouseEvent()
    {
        //移除对象数据
        if (Input.GetKeyDown(KeyCode.Delete))
        {
            if (currentModel != null)
            {
                RemoveWallModel(currentModel.data);

                SetShowEditorSprite(null);
            }
        }

        //对焦当前选中的目标
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (currentModel != null && currentModel.gameObject)
            {
                CameraMove.GetInst().CameraLookAtTarget(currentModel.gameObject);
            }
        }

        //获取鼠标事件
        var e = Event.current;
        if (e == null || !e.isMouse)
            return;

        if (e.clickCount == 1)
        {
            if (e.button == 0)
            {
                SoundEmittercom sprite = FindSoundEmitterFromPos(SceneManager.MousePos);
                if (sprite != null)
                {
                    currentModel = sprite;
                    TransformGizmos.TransformGizmo.GetInst().SetTraget(sprite.transform);
                }
            }
        }
        else if (e.clickCount == 2)
        {
            if (e.button == 0)
            {
                //左键两下 种怪
                //当前已经有模型选中显示，并且不是正在加载新的 model
                if (cursorObj != null)
                {
                    SoundEmittercom m = CreateNewSoundEmitter();
                    //设置好被编辑的目标
                    SetShowEditorSprite(m);
                }

            }
            else if (e.button == 1)
            {
                //右键两下 取消当前鼠标怪物预览
                if (cursorObj != null)
                {
                    UnLoadShowSprite();
                    SetShowEditorSprite(null);
                }
            }
        }
    }

    public SoundEmittercom FindSoundEmitterFromPos(Vector3 pos)
    {
        for (int i = 0; i < ListLocalSoundCom.Count; i++)
        {
            var item = ListLocalSoundCom[i];
            Vector3 position = new Vector3(item.data.x, item.data.y, item.data.z);
            if (Vector3.Distance(pos, position) <= Config.MAX_FIND_SPRITE_DIS)
            {
                currentModel = item;
                return currentModel;
            }
        }

        for (int i = 0; i < ListServerSoundCom.Count; i++)
        {
            var item = ListServerSoundCom[i];
            Vector3 position = new Vector3(item.data.x, item.data.y, item.data.z);
            if (Vector3.Distance(pos, position) <= Config.MAX_FIND_SPRITE_DIS)
            {
                currentModel = item;
                return currentModel;
            }
        }
        return null;
    }

    private void RemoveWallModel(SoundEmitterModel model)
    {
        if (ListLocalSoundCom.Exists(w => w.data.id == model.id))
        {
            ListLocalSoundCom.RemoveAll(w => w.data.id == model.id);
            GameObject.Destroy(model.Go);
        }

        if (ListServerSoundCom.Exists(w => w.data.id == model.id))
        {
            List_Wall_Remove.Add(model.id);
            ListServerSoundCom.RemoveAll(w => w.data.id == model.id);
            GameObject.Destroy(model.Go);
        }
    }

    private SoundEmittercom CreateNewSoundEmitter()
    {
        SoundEmittercom awm = cursorObj.AddComponent<SoundEmittercom>();
        awm.data = new SoundEmitterModel();
        awm.data.id = GetMaxId() + 1;
        awm.data.group_id = SceneManager.GetInst().CurrScene.scene_soundgroup_id;
        awm.data.shape = int.Parse(awm.gameObject.name);
        ListLocalSoundCom.Add(awm);
        return awm;

    }

    private int GetMaxId()
    {
        var data = ListServerSoundCom.OrderByDescending(o => o.data.id).FirstOrDefault();
        if (data == null)
        {
            data = ListLocalSoundCom.OrderByDescending(o => o.data.id).FirstOrDefault();
            if (data == null)
                return 0;
        }
        return data.data.id;
    }


    public int GetGroupMaxId()
    {
        var data = DictServerSoundComGroup.OrderByDescending(o => o.Key).FirstOrDefault();
        return data.Key;
    }

    private void SetShowEditorSprite(SoundEmittercom com)
    {
        if (com == null)
        {
            if (currentModel != null)
            {
                HideOutLine(currentModel.gameObject);
            }
            currentModel = null;
        }

        else
        {
            currentModel = com;
            if (currentModel.data == null)
            {
                currentModel.data = new SoundEmitterModel();

            }

            var data = currentModel.data;

            data.Go = cursorObj;

            var tran = com.transform;
            data.wall_height = tran.localScale.y;
            data.wall_width = tran.localScale.z;
            data.wall_length = tran.localScale.x;

            data.x = tran.position.x;
            data.y = tran.position.y;
            data.z = tran.position.z;

            data.angle = tran.rotation.eulerAngles.y;

            data.isDirty = true;

            cursorObj = null;
            tran = null;

            //com_list.Add(currentModel);

            ShowOutLine(currentModel.gameObject);
            TransformGizmos.TransformGizmo.GetInst().SetTraget(currentModel.transform);
        }
    }


    #region 显示模型描边

    //模型描边shader
    Shader outLine;
    List<Shader> tempShader = new List<Shader>();


    //描边材质球，以及显示描边之前的材质球个数
    Material outLineMat;
    List<int> matCountList = new List<int>();

    /// <summary>
    /// 加载描边shader
    /// </summary>
    void LoadOutLineShader()
    {
        if (outLine == null)
            outLine = Resources.Load<Shader>("Shader/OutLine");

        if (outLineMat == null)
            outLineMat = Resources.Load<Material>("Materials/OutLine");
    }

    /// <summary>
    /// 显示模型描边效果
    /// </summary>
    void ShowOutLine(GameObject go)
    {
        if (go == null)
            return;

        Renderer[] renderer = go.GetComponentsInChildren<Renderer>();
        if (renderer != null && renderer.Length > 0)
        {
            for (int i = 0; i < renderer.Length; i++)
            {
                List<Material> mats = new List<Material>();
                mats.AddRange(renderer[i].materials);
                matCountList.Add(mats.Count);

                mats.Add(outLineMat);

                renderer[i].materials = mats.ToArray();
            }
        }


        ////遍历当前模型上所有的 renderer, 并且保存，替换当前正在使用的shader
        //SkinnedMeshRenderer[] tempskin = go.GetComponentsInChildren<SkinnedMeshRenderer>();
        //if (tempskin != null)
        //{

        //    for (int i = 0; i < tempskin.Length; i++)
        //    {
        //        tempShader.Add(tempskin[i].material.shader);
        //        tempskin[i].material.shader = outLine;
        //    }
        //}
    }

    /// <summary>
    /// 隐藏模型描边效果
    /// </summary>
    /// <param name="go"></param>
    void HideOutLine(GameObject go)
    {
        if (go == null)
            return;

        Renderer[] renderer = go.GetComponentsInChildren<Renderer>();
        if (renderer != null && renderer.Length > 0)
        {
            for (int i = 0; i < renderer.Length; i++)
            {
                if (matCountList.Count <= i)
                    continue;

                List<Material> mats = new List<Material>();
                for (int j = 0; j < matCountList[i]; j++)
                {
                    mats.Add(renderer[i].materials[j]);
                }
                renderer[i].materials = mats.ToArray();
            }
        }

        matCountList.Clear();

        ////遍历当前模型上所有的 renderer, 并且还原shader
        //SkinnedMeshRenderer[] tempskin = go.GetComponentsInChildren<SkinnedMeshRenderer>();
        //if (tempskin != null)
        //{
        //    for (int i = 0; i < tempskin.Length; i++)
        //    {
        //        tempskin[i].material.shader = tempShader[0];
        //        tempShader.RemoveAt(0);
        //    }
        //}
        //tempShader.Clear();
    }

    #endregion

    private void UnLoadShowSprite()
    {
        if (cursorObj != null)
            GameObject.Destroy(cursorObj);
        cursorObj = null;

    }

    #endregion

    public void SendNewCreateInfo() { net.SendNewCreateInfo(); }//改为删除完成之后，在发送删除消息
    public void SendUpdateInfo() { net.SendUpdateInfo(); }
    public void SendDeleteInfo() { net.SendDeleteInfo(); }

}