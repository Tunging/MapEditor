using MapEditor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class SoundEmitterNet
{
    List<SoundEmittercom> NEW_Wall_List;
    List<SoundEmittercom> Server_Wall_List;
    List<int> Remove_wall_list;
    public SoundEmitterNet(List<SoundEmittercom> newer, List<SoundEmittercom> server, List<int> remove)
    {
        NEW_Wall_List = newer;
        Server_Wall_List = server;
        Remove_wall_list = remove;
    }
    internal void SendNewCreateInfo()
    {

        Debug.Log("send create");
        if (NEW_Wall_List != null && NEW_Wall_List.Count > 0)
        {

            for (int i = 0; i < NEW_Wall_List.Count; i++)
            {
                var item = NEW_Wall_List[i];
                if (item != null)
                {
                    if (item.data.id == 0)
                    {
                        Debug.LogError("还是初始id，请重新指定");
                        GUINotice.Show("<color=red> id 已存在，清检查后重新指定 id </color>");

                        return;
                    }
                    if (Server_Wall_List.Exists(s => s.data.id == item.data.id && s.data.group_id == item.data.group_id))
                    {

                        Debug.LogError(" id 重复");

                        GUINotice.Show("<color=red> id 已存在，清检查后重新指定 id </color>");

                        return;
                    }


                    WWWForm form = item.data.SerializeToForm();

                    SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.Sound_Emitter_INSERT, form, OnSendInsertNewOver, item.data.id));
                }
            }
        }
    }

    private void OnSendInsertNewOver(WWWMessage error, object parameter)
    {

        Debug.Log("create complete");
        int id = (int)parameter;
        if (error.success)
        {
            for (int i = 0; i < NEW_Wall_List.Count; i++)
            {
                var item = NEW_Wall_List[i];
                if (item == null || item.data == null || item.data.isDirty == false)
                {
                    continue;
                }

                if (item.data.id == id)
                {
                    Server_Wall_List.Add(item);
                    item.data.isDirty = false;
                }
            }
            NEW_Wall_List.Clear();

        }
        else
        {
            Debug.LogErrorFormat("{0} 添加失败\n{1}", id, error);
            GUINotice.Show(error.msg[0]);
        }
    }

    internal void SendUpdateInfo()
    {

        Debug.Log("send update");
        if (Server_Wall_List == null)
        {
            return;
        }
        for (int i = 0; i < Server_Wall_List.Count; i++)
        {
            var item = Server_Wall_List[i];
            if (item.data.isDirty)
            {
                if (item.data.id == 0)
                {
                    Debug.LogError("还是初始id，请重新指定");
                    GUINotice.Show("<color=red> id 已存在，清检查后重新指定 id </color>");

                    return;
                }
                //if (Server_Wall_List.Exists(s => s.data.id == item.data.id && s.data.scene_id == item.data.scene_id))
                //{

                //    Debug.LogError(" id 重复");

                //    GUINotice.Show("<color=red> id 已存在，清检查后重新指定 id </color>");

                //    return;
                //}

                var form = item.data.SerializeToForm();
                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.Sound_Emitter_UPDATE, form, ONSendUpdateOver, item.data.id));
            }
        }
        //return;
        //for (int i = 0; i < NEW_Wall_List.Count; i++)
        //{
        //    var item = NEW_Wall_List[i];
        //    if (item.data.isDirty)
        //    {
        //        var form = item.data.SerializeToForm();
        //        SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.AIR_WALL_UPDATE, form, (s, arg2) =>
        //        {

        //            int id = (int)arg2;
        //            if (NEW_Wall_List == null) return;
        //            for (int f = 0; f < NEW_Wall_List.Count; f++)
        //            {
        //                var it = NEW_Wall_List[f];
        //                if (it == null) continue;
        //                if (it.data.id == id)
        //                {
        //                    it.data.isDirty = false;
        //                }
        //            }

        //        }, item.data.id));
        //    }
        //}
    }

    private void ONSendUpdateOver(WWWMessage arg1, object arg2)
    {

        Debug.Log("update over");
        int id = (int)arg2;
        if (arg1.success)
        {
            if (Server_Wall_List == null) return;
            for (int i = 0; i < Server_Wall_List.Count; i++)
            {
                var item = Server_Wall_List[i];
                if (item == null || item.data == null || !item.data.isDirty) continue;
                if (item.data.id == id)
                {
                    item.data.isDirty = false;
                }
            }

        }
        else
        {
            Debug.LogErrorFormat("数据id为{0}添加失败 !\n {1}", id, arg1);
            GUINotice.Show(arg1.msg[0]);
        }
    }


    internal void SendDeleteInfo()
    {

        Debug.Log("delete info ");
        if (Remove_wall_list == null || Remove_wall_list.Count == 0)
        {
            
            return;
        }
        for (int i = 0; i < Remove_wall_list.Count; i++)
        {
            var item = Remove_wall_list[i];

            WWWForm form = new WWWForm();
            form.AddField("id", item);
            form.AddField("group_id", SceneManager.GetInst().CurrScene.scene_soundgroup_id);
            Debug.Log("delete air wall data ,id = " + item + "  , map id  = " + SceneManager.GetInst().CurrScene.scene_soundgroup_id);

            SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.Sound_Emitter_DELETE, form, OnSendDeleteOver, item));

        }
    }

    private void OnSendDeleteOver(WWWMessage message, object parameter)
    {

        Debug.Log("delete over");
        SendNewCreateInfo();
        int id = (int)parameter;
        if (!message.success)
        {
            Debug.LogErrorFormat("刪除數據失敗， id= {0}", id);
            GUINotice.Show(message.msg[0]);
            return;
        }
        if (Remove_wall_list != null)
        {
            for (int i = 0; i < Remove_wall_list.Count; i++)
            {
                var item = Remove_wall_list[i];
                if (item == id)
                {
                    Remove_wall_list.RemoveAt(i);
                    return;
                }
            }
        }

    }
}