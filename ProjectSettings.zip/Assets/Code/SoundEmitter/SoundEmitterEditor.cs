using MapEditor;
using NavMesh.Camera;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class SoundEmitterEditor
{
    Rect controlwindowRect = new Rect(0, 300, 300, Screen.height - 300 - 20);
    Rect wallPropertyRect = new Rect(300, 0, 600, 330);
    Rect listwindowRect = new Rect(Screen.width - 300, 300, 300, Screen.height - 300 - 20);
    Vector2 wallListScrollrect = new Vector2();
    


    public SoundEmitterEditor()
    {

    }
    #region GUI
    public void OnGUI()
    {
        if (SceneManager.GetInst().CurrScene.scene_soundgroup_id != 0)
        {
            GUI.Window(0, wallPropertyRect, DrawWallPropertyWindow, "SoundEmitter属性");
            GUI.Window(1, controlwindowRect, DrawControlPanelWIndow, "SoundEmitter控制面板");
            GUI.Window(2, listwindowRect, DrawWallListWindow, "SoundEmitter列表");

        }
        else
        {
            GUI.Window(2, listwindowRect, DrawGroupListWindow, "SoundEmitter——Group");
        }

    }

    

    /// <summary>
    /// 空气墙属性
    /// </summary>
    /// <param name="id"></param>
    private void DrawWallPropertyWindow(int id)
    {
        if (SoundEmitterManager.Instance.currentModel == null)
        {
            GUI.color = Color.red;
            GUILayout.Label("没有选中SoundEmitter");
            GUI.color = Color.white;
            if (GUILayout.Button("保存到服务器"))
            {
                SceneManager.GetInst().SendToServer();
            }
            return;
        }
        var data = SoundEmitterManager.Instance.currentModel.data;

        data.id = GUIUtils.NumberField("id", data.id,false);
        data.group_id = GUIUtils.NumberField("GroupId", data.group_id,false);

        //collider type
        GUILayout.BeginHorizontal();
        data.shape = GUIUtils.NumberField("触发器形状", data.shape);
        if (data.shape == (int)Shape.Sphere)
        {
            data.radius = GUIUtils.NumberField("球形触发器半径", data.radius);
            data.radius = data.Go.transform.localScale.x / 2;

            data.Go.transform.localScale = new Vector3(data.Go.transform.localScale.x, data.Go.transform.localScale.x, data.Go.transform.localScale.x);
            data.Go.transform.localScale = new Vector3(data.Go.transform.localScale.y, data.Go.transform.localScale.y, data.Go.transform.localScale.y);
            data.Go.transform.localScale = new Vector3(data.Go.transform.localScale.z, data.Go.transform.localScale.z, data.Go.transform.localScale.z);
        }
        GUILayout.EndHorizontal();

        //transform
        if (data.shape == (int)Shape.Cube)
        {
            GUILayout.BeginHorizontal();
            data.wall_height = GUIUtils.NumberField("墙体高度", data.wall_height);
            data.wall_length = GUIUtils.NumberField("墙体长度", data.wall_length);
            data.wall_width = GUIUtils.NumberField("墙体宽度", data.wall_width);
            GUILayout.EndHorizontal();
            data.wall_height = data.Go.transform.localScale.y;
            data.wall_length = data.Go.transform.localScale.x;
            data.wall_width = data.Go.transform.localScale.z;
        }


        GUILayout.Space(2);
        GUILayout.BeginHorizontal();
        data.x = GUIUtils.NumberField("位置坐标x", data.x);
        data.y = GUIUtils.NumberField("位置坐标y", data.y);
        data.z = GUIUtils.NumberField("位置坐标z", data.z);
        GUILayout.EndHorizontal();
        data.x = data.Go.transform.position.x;
        data.y = data.Go.transform.position.y;
        data.z = data.Go.transform.position.z;



        GUILayout.Space(2);
        data.angle = GUIUtils.NumberField("旋转", data.angle);
        GUILayout.Space(2);
        data.angle = SoundEmitterManager.Instance.currentModel.transform.rotation.eulerAngles.y;

        data.sound_id = GUIUtils.NumberField("sound id", data.sound_id);
        data.des_i18n = GUIUtils.StrField("描述", data.des_i18n);
        data.trigger_type = GUIUtils.NumberField("trigger_type", data.trigger_type);

        SoundEmitterManager.Instance.currentModel.name = string.Format("{0}--sound:{1}--{2}", data.id, data.sound_id, data.des_i18n);
        GUILayout.Space(2);
        //data.soundId = SoundEmitterManager.Instance.currentModel.transform.rotation.eulerAngles.y;


        if (GUILayout.Button("保存到服务器"))
        {
            if (data.id == 0)
            {
                Debug.LogError("保存失敗，id不能是默認值");

                return;
            }
            SceneManager.GetInst().SendToServer();
        }

    }
    /// <summary>
    /// 空气墙控制面板
    /// </summary>
    /// <param name="id"></param>
    private void DrawControlPanelWIndow(int id)
    {
        GUILayout.Label("Here is the control panel of SoundEmitter model");

        if (GUILayout.Button("创建新的cube  SoundEmitter"))
        {
            CreateCursorSoundEmitter(Shape.Cube);
        }
        if (GUILayout.Button("创建新的sphere SoundEmitter"))
        {
            CreateCursorSoundEmitter(Shape.Sphere);
        }

        GUI.DragWindow();
    }

    /// <summary>
    /// type : 1:cube, 2:sphere
    /// </summary>
    /// <param name="type"></param>
    private void CreateCursorSoundEmitter(Shape type)
    {
        var swp = SoundEmitterFactory.Instance.GetSoundEmitter(type);
        if (swp != null)
        {
            switch (type)
            {
                case Shape.Cube:
                    break;
                case Shape.Sphere:
                    break;
                default:
                    break;
            }
            //不可注释掉,用于创建组件的时候判断类型
            swp.name = ((int)type).ToString();
            SoundEmitterManager.Instance.cursorObj = swp;
        }
    }

    /// <summary>
    /// 空气墙列表
    /// </summary>
    /// <param name="id"></param>
    private void DrawWallListWindow(int id)
    {
        wallListScrollrect = GUILayout.BeginScrollView(wallListScrollrect);
        var currentModel = SoundEmitterManager.Instance.currentModel;
        var Server_Wall_List = SoundEmitterManager.Instance.ListServerSoundCom;
        var NEW_Wall_List = SoundEmitterManager.Instance.ListLocalSoundCom;
        GUI.color = Color.red;

        int groupId = SceneManager.GetInst().CurrScene.scene_soundgroup_id;
        List<SoundEmitterModel> list = null;
        SoundEmitterManager.Instance.DictServerSoundComGroup.TryGetValue(groupId, out list);
        if (GUILayout.Button("删除此地图对应的组信息"))
        {
            string tips = string.Format("是否删除此地图id=【{0}】的地图音效组信息", SceneManager.GetInst().CurrScene.id);
            GUINotice.Confirm(tips, ConfirmToRemove);
            
        }

        GUI.color = Color.white;

        if (Server_Wall_List != null)
        {
            for (int i = 0; i < Server_Wall_List.Count; i++)
            {
                var item = Server_Wall_List[i];
                currentModel = UpdateCurrentModel(currentModel, item);
            }
        }

        if (NEW_Wall_List != null)
        {
            for (int i = 0; i < NEW_Wall_List.Count; i++)
            {
                var item = NEW_Wall_List[i];

                currentModel = UpdateCurrentModel(currentModel, item);

            }
        }
        GUILayout.EndScrollView();
    }

    private void ConfirmToRemove()
    {
        SceneManager.GetInst().CurrScene.scene_soundgroup_id = 0;
        SceneManager.GetInst().CurrScene.isDirty = true;
        SoundEmitterManager.Instance.Reset();
        SceneManager.GetInst().SendToServerNoNotify();
    }
    private void DrawGroupListWindow(int id)
    {
        wallListScrollrect = GUILayout.BeginScrollView(wallListScrollrect);
        var allGroupDict = SoundEmitterManager.Instance.DictServerSoundComGroup;
        GUI.color = Color.red ;
        GUILayout.Label("使用新的分组或者选择已有分组");

        if (GUILayout.Button("我要使用新的分组"))
        {
            //get a new GroupId max One Add 1
            int maxId = SoundEmitterManager.Instance.GetGroupMaxId();
            maxId++;
            Debug.LogError("Create new Group id=[" + maxId + "]");
            SceneManager.GetInst().CurrScene.scene_soundgroup_id = maxId;
            SceneManager.GetInst().CurrScene.isDirty = true;
        }
        GUI.color = Color.white;
        foreach (var item in allGroupDict)
        {
            var data = item.Value[0];
            if (GUILayout.Button(string.Format("Group_{0}  点击选择分组", data.group_id)))
            {
                SceneManager.GetInst().CurrScene.scene_soundgroup_id = data.group_id;
                SceneManager.GetInst().CurrScene.isDirty = true;
                SoundEmitterManager.Instance.OnSetCurrGroupData();
            }
        }
        GUILayout.EndScrollView();
    }
    private SoundEmittercom UpdateCurrentModel(SoundEmittercom currentModel, SoundEmittercom item)
    {
        if (item != null)
        {
            var data = item.data;
            GUI.color = data.isDirty ? Color.red : Color.white;
            if (GUILayout.Button(string.Format("{0} id:{1},Group_id:{2};{3}", data.isSelected ? "--->  " : string.Empty, data.id, data.group_id,data.des_i18n)))
            {
                if (currentModel != null)
                {
                    currentModel.data.isSelected = false;
                }
                currentModel = item;
                currentModel.data.isSelected = true;
                currentModel.data.isDirty = true;

                CreateSoundEmitter(item.data);
            }
        }

        return currentModel;
    }

    private void CreateSoundEmitter(SoundEmitterModel item)
    {
        GameObject go;
        var wall = SoundEmitterManager.Instance.FindSoundEmitterFromPos(new Vector3(item.x, item.y, item.z));
        if (wall == null)
        {
            go = SoundEmitterFactory.Instance.GetSoundEmitter((Shape)wall.data.shape);
            if (go != null)
            {
                var t = go.transform;
                t.localScale = new Vector3(item.wall_length, item.wall_height, item.wall_width);
                t.position = new Vector3(item.x, item.y, item.z);
                t.rotation = Quaternion.Euler(0, item.angle, 0);

                go.AddComponent<SoundEmittercom>().data = item;
            }
        }
        else
        {
            go = wall.gameObject;
        }

        item.Go = go;
        CameraMove.GetInst().CameraLookAtTarget(go);
        TransformGizmos.TransformGizmo.GetInst().SetTraget(go.transform);

    }
    #endregion

}