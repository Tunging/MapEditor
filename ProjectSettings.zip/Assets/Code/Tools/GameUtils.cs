﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

namespace MapEditor
{
    /// <summary>
    /// 工具类
    /// </summary>
    public class GameUtils
    {

        /// <summary>
        /// 舍弃后续几位，调整精度
        /// </summary>
        /// <param name="value"></param>
        /// <param name="digits"></param>
        /// <returns></returns>
        public static float Round(float value, int digits = 4)
        {
            return Convert.ToSingle(Math.Round(value, digits));
        }
        /// <summary>
        /// 用于把  "x,y,z"  格式的字符串格式化为Vector3
        /// </summary>
        /// <param name="vector_string">向量字符串</param>
        /// <returns></returns>
        public static Vector3 StringToVector3(string vector_string)
        {
            Vector3 v = Vector3.zero;
            if (!string.IsNullOrEmpty(vector_string))
            {
                string[] str = vector_string.Split(',');
                if (str.Length >= 2)
                {
                    v = new Vector3(float.Parse(str[0]), float.Parse(str[1]), float.Parse(str[2]));
                }
            }
            return v;
        }

        /// <summary>
        /// string 转换成 Vector3 数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static Vector3[] StringToVector3Array(string str)
        {
            if (string.IsNullOrEmpty(str))
                return new Vector3[] { };

            string[] vs = str.Split(';');
            List<Vector3> list = new List<Vector3>();
            for (int i = 0; i < vs.Length; i++)
            {
                if (string.IsNullOrEmpty(vs[i]))
                    continue;
                list.Add(StringToVector3(vs[i]));
            }

            return list.ToArray();
        }

        public static string BoolToString(bool boolValue)
        {
            return boolValue ? "TRUE" : "FALSE";
        }
    }
}
