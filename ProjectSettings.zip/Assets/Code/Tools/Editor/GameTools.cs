﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.IO;

public class GameTools : Editor
{

    /// <summary>
    /// 清理缓存数据信息
    /// </summary>
    [MenuItem("Tools/Clear Cache")]
    public static void OnClearCache()
    {
        string path = string.Format("{0}/{1}", Application.persistentDataPath, "vercache");

        if (Directory.Exists(path))
            Directory.Delete(path, true);

        path = string.Format("{0}/{1}", Application.temporaryCachePath, "vercache");
        if (Directory.Exists(path))
            Directory.Delete(path, true);

        path = string.Format("{0}/{1}", Application.dataPath, "../update");
        if (Directory.Exists(path))
            Directory.Delete(path, true);


        path = string.Format("{0}/{1}", Application.dataPath, "../setup");
        if (Directory.Exists(path))
            Directory.Delete(path, true);

        PlayerPrefs.DeleteAll();

        Debug.Log("Cache cleared!!");
    }
}
