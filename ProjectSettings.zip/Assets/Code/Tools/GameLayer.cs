﻿using UnityEngine;

namespace MapEditor
{

	/// <summary>
	/// Sprite 图层枚举数据
	/// </summary>
	public enum SpriteLayerEnum
	{
		Default = 0,                                                                            //默认
		TransParentFX = 1,                                                                      //透明
		Ignore_Raycast = 2,                                                                     //忽略射线
		Warter = 4,                                                                             //水
		UI = 5,                                                                                 //UI
		Sprite = 8,                                                                             //Sprite
		Effect = 9,                                                                             //Effect
		UI3D = 10,                                                                              //3D ui比如模型
		CollisionNoProjector,                                                                   //地面碰撞，但是不投射
		Terrain = 12,                                                                           //Terrain
		Ground = 13,                                                                            //地面
		AreaTrigger = 14,                                                                       //区域环境光
		Collision = 15,                                                                         //碰撞层
		Standable = 16,                                                                         //可站立层
		CameraCollision,                                                                        //相机碰撞层
		STORY = 20,                                                                             //剧情资源数据
		Hero =  28,                                                                             //Hero
		Boss = 29,                                                                              //Boss
		OutLine = 31                                                                            //描边
	}


    /// <summary>
    /// 游戏图层设置
    /// </summary>
    public class GameLayer
    {

        static GameLayer instance;

        public static GameLayer GetInst()
        {
            if (instance == null)
                instance = new GameLayer();
            return instance;
        }

        /// <summary>
        /// 点击发射射线检测的层级
        /// </summary>
        int layerMask = 0;
        public int LayerMask
        {
            get
            {
                if (layerMask == 0)
                    layerMask = (1 << (int)SpriteLayerEnum.Terrain | 1 << (int)SpriteLayerEnum.Ground/* | 1<<(int)SpriteLayerEnum.Default*/);
                return layerMask;
            }
        }

        /// <summary>
        /// sprite 遮罩图层（鼠标点击选中设置）
        /// </summary>
        int spriteMaskLayer = 0;
        public int SpriteMaskLayer
        {
            get
            {
                if (spriteMaskLayer == 0)
                    spriteMaskLayer = (1 << (int)SpriteLayerEnum.Sprite);
                return spriteMaskLayer;
            }
        }

        /// <summary>
        /// 设置一个对象的图层
        /// </summary>
        /// <param name="tran"></param>
        /// <param name="layer"></param>
        /// <param name="children"></param>
        public void SetLayer(Transform tran, SpriteLayerEnum layer, bool children = false)
        {
            if (tran != null)
            {
                tran.gameObject.layer = (int)layer;
                if (children)
                {
                    for (int i = 0; i < tran.childCount; i++)
                    {
                        SetLayer(tran.GetChild(i), layer, children);
                    }
                }
            }
        }


    }

}