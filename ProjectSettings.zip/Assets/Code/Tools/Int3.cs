﻿using UnityEngine;

namespace NavMesh
{

    //处理整数坐标
    public struct Int3
    {
        //坐标值
        public int x;
        public int y;
        public int z;

        //整数坐标的精度 1000代表毫米的精度，1代表米的精度（假设一个世界单位 代表 1米）
        public const int Precision = 1000;

        // float 精度
        public const float FloatPrecision = 1000F;

        //1 除以精度
        public const float PrecisionFactor = 0.001F;

        //0，0，0
        private static Int3 _zero = new Int3(0, 0, 0);
        public static Int3 zero { get { return _zero; } }

        public Int3(Vector3 position)
        {
            x = (int)System.Math.Round(position.x * FloatPrecision);
            y = (int)System.Math.Round(position.y * FloatPrecision);
            z = (int)System.Math.Round(position.z * FloatPrecision);
        }

        public Int3(float _x, float _y, float _z)
        {
            x = (int)System.Math.Round(_x * FloatPrecision);
            y = (int)System.Math.Round(_y * FloatPrecision);
            z = (int)System.Math.Round(_z * FloatPrecision);
        }

        public Int3(int _x, int _y, int _z)
        {
            x = _x;
            y = _y;
            z = _z;
        }

        public static bool operator ==(Int3 lhs, Int3 rhs)
        {
            return lhs.x == rhs.x &&
                   lhs.y == rhs.y &&
                   lhs.z == rhs.z;
        }

        public static bool operator !=(Int3 lhs, Int3 rhs)
        {
            return lhs.x != rhs.x ||
                   lhs.y != rhs.y ||
                   lhs.z != rhs.z;
        }

        public static explicit operator Int3(Vector3 ob)
        {
            return new Int3(
                (int)System.Math.Round(ob.x * FloatPrecision),
                (int)System.Math.Round(ob.y * FloatPrecision),
                (int)System.Math.Round(ob.z * FloatPrecision)
                );
        }

        public static explicit operator Vector3(Int3 ob)
        {
            return new Vector3(ob.x * PrecisionFactor, ob.y * PrecisionFactor, ob.z * PrecisionFactor);
        }

        public static Int3 operator -(Int3 lhs, Int3 rhs)
        {
            lhs.x -= rhs.x;
            lhs.y -= rhs.y;
            lhs.z -= rhs.z;
            return lhs;
        }

        public static Int3 operator -(Int3 lhs)
        {
            lhs.x = -lhs.x;
            lhs.y = -lhs.y;
            lhs.z = -lhs.z;
            return lhs;
        }

        // REMOVE!
        public static Int3 operator +(Int3 lhs, Int3 rhs)
        {
            lhs.x += rhs.x;
            lhs.y += rhs.y;
            lhs.z += rhs.z;
            return lhs;
        }

        public static Int3 operator *(Int3 lhs, int rhs)
        {
            lhs.x *= rhs;
            lhs.y *= rhs;
            lhs.z *= rhs;

            return lhs;
        }

        public static Int3 operator *(Int3 lhs, float rhs)
        {
            lhs.x = (int)System.Math.Round(lhs.x * rhs);
            lhs.y = (int)System.Math.Round(lhs.y * rhs);
            lhs.z = (int)System.Math.Round(lhs.z * rhs);

            return lhs;
        }

        public static Int3 operator *(Int3 lhs, double rhs)
        {
            lhs.x = (int)System.Math.Round(lhs.x * rhs);
            lhs.y = (int)System.Math.Round(lhs.y * rhs);
            lhs.z = (int)System.Math.Round(lhs.z * rhs);

            return lhs;
        }

        public static Int3 operator *(Int3 lhs, Vector3 rhs)
        {
            lhs.x = (int)System.Math.Round(lhs.x * rhs.x);
            lhs.y = (int)System.Math.Round(lhs.y * rhs.y);
            lhs.z = (int)System.Math.Round(lhs.z * rhs.z);

            return lhs;
        }

        public static Int3 operator /(Int3 lhs, float rhs)
        {
            lhs.x = (int)System.Math.Round(lhs.x / rhs);
            lhs.y = (int)System.Math.Round(lhs.y / rhs);
            lhs.z = (int)System.Math.Round(lhs.z / rhs);
            return lhs;
        }

        public int this[int i]
        {
            get
            {
                return i == 0 ? x : (i == 1 ? y : z);
            }
            set
            {
                if (i == 0) x = value;
                else if (i == 1) y = value;
                else z = value;
            }
        }

        //两个向量之间的角度（弧度）
        public static float Angle(Int3 lhs, Int3 rhs)
        {
            double cos = Dot(lhs, rhs) / ((double)lhs.magnitude * (double)rhs.magnitude);

            cos = cos < -1 ? -1 : (cos > 1 ? 1 : cos);
            return (float)System.Math.Acos(cos);
        }

        public static int Dot(Int3 lhs, Int3 rhs)
        {
            return
                lhs.x * rhs.x +
                lhs.y * rhs.y +
                lhs.z * rhs.z;
        }

        public static long DotLong(Int3 lhs, Int3 rhs)
        {
            return
                (long)lhs.x * (long)rhs.x +
                (long)lhs.y * (long)rhs.y +
                (long)lhs.z * (long)rhs.z;
        }

        //在二维空间中的数据， Y轴保持不变
        public Int3 Normal2D()
        {
            return new Int3(z, y, -x);
        }

        // 返回向量的长度 原点为（0，0，0）
        public float magnitude
        {
            get
            {
                //It turns out that using doubles is just as fast as using ints with Mathf.Sqrt. And this can also handle larger numbers (possibly with small errors when using huge numbers)!

                double _x = x;
                double _y = y;
                double _z = z;

                return (float)System.Math.Sqrt(_x * _x + _y * _y + _z * _z);
            }
        }

        //获得相对于 原点（0，0，0）之间的长度 四舍五入到最近的整数
        public int costMagnitude
        {
            get
            {
                return (int)System.Math.Round(magnitude);
            }
        }

        //世界单位 的大小 （此方法不推荐 可以使用 Vector3 代替）
        [System.Obsolete("This property is deprecated. Use magnitude or cast to a Vector3")]
        public float worldMagnitude
        {
            get
            {
                double _x = x;
                double _y = y;
                double _z = z;

                return (float)System.Math.Sqrt(_x * _x + _y * _y + _z * _z) * PrecisionFactor;
            }
        }

        //向量的平方
        public float sqrMagnitude
        {
            get
            {
                double _x = x;
                double _y = y;
                double _z = z;
                return (float)(_x * _x + _y * _y + _z * _z);
            }
        }

        //向量的平方
        public long sqrMagnitudeLong
        {
            get
            {
                long _x = x;
                long _y = y;
                long _z = z;
                return (_x * _x + _y * _y + _z * _z);
            }
        }

        public static implicit operator string (Int3 ob)
        {
            return ob.ToString();
        }

        //返回一个向量的字符串输出
        public override string ToString()
        {
            return "( " + x + ", " + y + ", " + z + ")";
        }

        public override bool Equals(System.Object o)
        {
            if (o == null) return false;

            var rhs = (Int3)o;

            return x == rhs.x &&
                   y == rhs.y &&
                   z == rhs.z;
        }

        public override int GetHashCode()
        {
            return x * 73856093 ^ y * 19349663 ^ z * 83492791;
        }
    }
}
