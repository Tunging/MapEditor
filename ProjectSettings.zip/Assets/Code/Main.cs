using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using ZLib;
using ZTool.Res;
using ZTool.Table;

namespace MapEditor
{

    /// <summary>
    /// 编辑器入口
    /// </summary>
    public class Main : MonoBehaviour
    {

        // Use this for initialization
        void Start()
        {
            Debug.Log(Config.GetInst().ToString());
            List<string> listLocalRes = new List<string>();

            listLocalRes.AddRange(LocalResConfig.GetInst().GetLocalResPaths());
            listLocalRes.AddRange(new List<string>() { Config.PATH_SHOW_PREFAB, "Config/client_model", "Config/npc", "Config/npc_templete" });

            //设置本地加载资源数据
            ResourcesLoad.instance.SetLocalResConfig(listLocalRes, null);

            CoroutineManager.Init(this.gameObject);
            CoroutineManager.instance.StartCoroutine(OnGameStart());

        }

        private IEnumerator OnGameStart()
        {
            ResVerManager.instance.OnResVerInit(null);
            yield return new WaitUntil(() => ResVerManager.instance.IsDone == true);


            //加载编辑器配置文件;
            Config.GetInst().LoadConfig(this, null);

            RenderSettings.fog = false;

            OnSetTableInfo();
        }

        string[] needLoadTable = { "client_model", "scene_npc" };
        /// <summary>
        /// 设置Table管理信息数据资源
        /// </summary>
        void OnSetTableInfo()
        {
            //string tableNameSpace = "Tgame.Game.Table";
            //TableManager.SetTableAssemblyAndNameSpace(Assembly.GetExecutingAssembly(), tableNameSpace);

            //for (int i = 0; i < needLoadTable.Length; i++)
            //{
            //    string path = needLoadTable[i];
            //    if (string.IsNullOrEmpty(path) != true)
            //    {
            //        string url = string.Format("{0}{1}", "Config/", path);

            //        //StartCoroutine(LoadTable(url, ONLoadConfigOver, path));
            //        ResourcesLoad.instance.LoadBytes(url, ONLoadConfigOver, path);
            //    }
            //}
            LoadResProcessor.instance.ReceivedLoadRes(OnConfigLoadOver);
        }

        //private IEnumerator LoadTable(string url, System.Action<string, object, object> oNLoadConfigOver, object p)
        //{
        //    WWW www = new WWW(url);
        //    yield return www;
        //    if (string.IsNullOrEmpty(www.error) && oNLoadConfigOver != null)
        //    {
        //        oNLoadConfigOver(url, www.text, p);
        //    }
        //}

        //private void ONLoadConfigOver(string path, object obj, object parameter)
        //{
        //    string name = (string)parameter;
        //    Type type = System.Type.GetType(string.Format("Tgame.Game.Table.Table_{0}", TableManager.ToTitleCase(name)));
        //    if (type != null)
        //    {
        //        byte[] str = (byte[])obj;
        //        TableManager.LoadTable(str, name, type);
        //    }
        //}

        /// <summary>
        /// 配置资源数据已经加载完成
        /// </summary>
        void OnConfigLoadOver()
        {
            ResConfig.instance.OnSetResLoadMaxCount(Config.MAX_LOAD_RES_COUNT);

            //设置url地址
            //ResConfig.instance.OnSetResUrlInfo(Config.RES_SERVER_URL, Config.LOCAL_URL, Config.CACHE_URL, Config.CACHE_PATH);
            ResConfig.instance.OnSetResUrlInfo(Config.RES_SERVER_URL, string.Format("file://{0}", Config.LOCAL_EDITOR_PATH), Config.CACHE_URL, Config.CACHE_PATH);

            //设置缓存池数据
            //ExtHatchItem item = GetComponent<ExtHatchItem>();
            //if (item == null)
            //    item = gameObject.AddComponent<ExtHatchItem>();
            //ResCacheManager.instance.BuildInActiveTrans = item;

            //开始加载配置资源版本数据
            ResVerManager.instance.OnResVerInit(OnResVerLoadOver);

        }

        /// <summary>
        /// 版本资源配置数据加载完成
        /// </summary>
        void OnResVerLoadOver()
        {

            //扫描本地位置数据
            LocalResConfig.GetInst().StartScanLocalRes();

            //设置本地数据加载
            if (LocalResConfig.GetInst().Local_Res_Url.Count > 0)
                ResVerManager.instance.SetUseLocalRes(ResConfig.instance.GROUP_UPDATE, LocalResConfig.GetInst().Local_Res_Url);

            //请求加载资源引用关系管理
            ResManifest.instance.Init();

            //初始化UGE
            InitUGE();

            //加载服务器列表资源数据
            StartLoadServerSceneList();
        }

        #region UGE 加载地图资源设置

        /// <summary>
        /// 初始化UGE
        /// </summary>
        void InitUGE()
        {
            ////只是用本地资源数据，不检测服务器数据
            //LoadManager.UseNet = false;

            //UGEConfig.cacheDir = Config.LOCAL_EDITOR_PATH;

            //地图启动 默认加载地图最大块 （初始化地图数据慢，操作流畅）
            //           UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleNum = 32;
            //           UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleBigNum = 32;
            ////           UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleMidNum = 32;
            //           UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSuperNum = 32;
            //           UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSmallNum = 32;
            //帧率显示控制
            //UGE.debug.showFPS = false;

            //01 -- 开启map load过程中的所有 加载内容
            TResConfig.isSaveMapLoadInfo = false;

            //缓存池存储时间
            UGE.poolMgr.life_sec = 30f;
            //销毁的时候，判断玩家距离，判断时间间隔
            UGE.poolMgr.distance_sec = 30f;
            //距离目标多少距离之后销毁
            UGE.poolMgr.target_distance = 50f;
            //UGE.mapMgr.bigMapContentLoader.bigMapConfig.isFixFrameLoadSurf = false;
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.isFadeInOut = false;
            //取消队列加载排序
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.isQueueLoadMap = false;
            //同一帧同一地块同时加载的草的数量
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.frame = 0;
            //队列加载个数
            UGE.mapMgr.loadQueueMgr.loadMaxCount = 1;

            ////摄像机			//4.19			+uge中，已经不包含camera了
            //var camGO=Instantiate(Resources.Load<GameObD:\Tgame\Client\Client\Client_DEV\Assets\Code\Common\Event\NetEvent\ject>("UGE/MainCamera")) as GameObject;
            //UGEUtils.SetParent(camGO.transform, GameObject.Find("Engine").transform);
            //mainCam=Camera.main;

            //设置资源使用的时候在加载
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.isDownLoadMapData = false;
            //地形
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleNum = 32;
            //物件
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSuperNum = 32;
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleBigNum = 32;
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleMidNum = 32;
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSmallNum = 32;
            //特效
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleBigEffNum = 32;
            UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSmallEffNum = 32;

            UGE.mapMgr.bigMapContentLoader.bigMapConfig.isNeedSurfaceLoadOver = false;

            //设置资源最大下载数量
            //UGEConfig.MAX_DOWNLOAD_COUNT = 1000;

            //启用日志输出
            TTrace.Enable = true;

            UGE.runtimePlatform = RuntimePlatform.WindowsPlayer;
            //remote
            TResConfig._remoteUrl = Config.RES_SERVER_URL;
            //streaming assets
            TResConfig._buildinWwwUrl = Config.LOCAL_URL;
            TResConfig._buildinUrl = Application.streamingAssetsPath;
            //disk
            TResConfig._diskDir = string.Empty;// Config.LOCAL_EDITOR_PATH;//每次都会缓存地图资源，但是有了缓存就进不去了，为啥？？？

            //快速加载模式
            //TResConfig.UseFastLoader = true;

            //设置ver中介
            UGE.loadMgr.SetRevealAction(ResLoadManager.instance.GetResStateType1, SaveVer);
            //设置依赖关系中介
            UGE.loadMgr.SetRevealDependentAction(ResManifest.instance.GetAllDependencies);
            //设置 加载卸载 中介
            UGE.loadMgr.SetLoaderAction(RequestLoaderEquals);

            //设置 UGE 启动的各种启动提示
            UGE.loadMgr.SetStartupCallbackAction(OnChangeLoadingContent, OnDownProgress, OnLocalProgress);
            //加载错误 提示
            UGE.loadMgr.SetFailCallbackAction(OnLoaderFailCallback);

            //UGE 初始化
            UGE.Startup(
                OnStartupComplete,
                new List<string>() { string.Format("game/map/map_allshader{0}", ".p") }
            );

            //设置场景资源加载完成的回调数据
            UGE.mapMgr.eventListener += GetSceneManager().OnSceneLoadOver;

            ResConfig.instance.OnSetUGEResExtension(Config.UGE_CONFIG_TXT, Config.UGE_CONFIG_BIN, Config.fileSuff);

        }

        #endregion
        #region UGE Loader 回调事件

        void SaveVer(FileVer fileVer)
        {
            //???  只传path就行  ???

            //Debug.LogError(" update file info " + fileVer.name + "       " + fileVer.state);

            ResVerManager.instance.UpdateFileInfo(fileVer.name);
        }/// <summary>
         /// </summary>
         /// <param name="tLoaderRequest"></param>
         /// <param name="obj">tgame中间的回调方法</param>
         /// <returns></returns>
        bool RequestLoaderEquals(TLoaderRequest tLoaderRequest, object obj)
        {
            ResourcesLoad.RequestLoadData data = tLoaderRequest.param as ResourcesLoad.RequestLoadData;
            if (data == null)
            {
                //Debug.Log("UGE====Main.RequestLoaderEquals, data为null，说明是grouploader，此时就直接判断obj是否为方法即可  path=" + tLoaderRequest.path);
                //data为null，说明是grouploader，此时就直接判断obj是否为方法即可
                if (tLoaderRequest.onLoad.Equals(obj))
                {
                    return true;
                }
                return false;
            }
            object callback = null;
            if (data.callbackOne != null)
            {
                callback = data.callbackOne;
            }
            else if (data.callbackAll != null)
            {
                callback = data.callbackAll;
            }
            if (callback == null)
            {
                Debug.Log("UGE====Main.RequestLoaderEquals, callback为null, path=" + tLoaderRequest.path);
                return false;
            }
            if (callback.Equals(obj))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// UGE初始化完成
        /// </summary>
        void OnStartupComplete()
        {
            //TTrace.p("Main.Step2.OnStartupComplete");
            //TTrace.Enable = false;
            //mapListMgr.enabled = true;
            //mapListMgr.Init();
            Debug.LogError("   UGE init OK   ");
        }

        private void OnChangeLoadingContent(TLoaderStartupEnum startupEnum)
        {
            string title = "", tip = "不会参数任何流量";
            switch (startupEnum)
            {
                case TLoaderStartupEnum.VER_START:
                    title = "验证资源...";
                    break;
                case TLoaderStartupEnum.VER_END:
                    title = "验证资源完成";
                    break;
                case TLoaderStartupEnum.LOCAL_VERIFY_START:
                    title = "修正本地资源错误...";
                    break;
                case TLoaderStartupEnum.LOCAL_VERIFY_END:
                    title = "修正本地资源错误完成";
                    break;
                case TLoaderStartupEnum.DOWNLOAD_START:
                    title = "下载资源中...";
                    break;
                case TLoaderStartupEnum.DOWNLOAD_END:
                    title = "下载资源完成";
                    break;
                case TLoaderStartupEnum.DEPENDENT_START:
                    title = "加载依赖文件...";
                    break;
                case TLoaderStartupEnum.DEPENDENT_END:
                    title = "加载依赖文件完成";
                    break;
                case TLoaderStartupEnum.PREHEAD_SHADER_START:
                    title = "预热shader...";
                    break;
                case TLoaderStartupEnum.PREHEAD_SHADER_END:
                    title = "预热shader完成";
                    break;
            }
            //			LoadingManager.GetInstance().UpdateTextProgress(title);	//"正在加载资源......"
            //			LoadingManager.GetInstance().UpdateTextTip(tip);	//"Tip===============..."
            Debug.Log("title=" + title);
        }
        /// <summary>
        /// 资源加载进度的回调
        /// </summary>
        private void OnDownProgress(int curSize, int needSize, int current, int total)
        {
            //		switch(startupEnum){
            //		case TLoaderStartupEnum.DOWNLOAD_PROGRESS:
            //			break;
            //		}
            //			LoadingManager.GetInstance().UpdateProgress((float)current / total);
            var tip = string.Format("{0}/{1}", curSize, needSize);
            //			LoadingManager.GetInstance().UpdateTextTip(tip);
            Debug.Log("tip=" + tip);
        }
        private void OnLocalProgress(TLoaderStartupEnum startupEnum, int current, int total)
        {
            //		switch(startupEnum){
            //		case TLoaderStartupEnum.DEPENDENT_PROGRESS:
            //		case TLoaderStartupEnum.PREHEAD_SHADER_PROGRESS:
            //			break;
            //		}
            //			LoadingManager.GetInstance().UpdateProgress((float)current / total);
            var tip = string.Format("{0}/{1}", current, total);
            Debug.Log("tip=" + tip);
        }

        /// <summary>
        /// 加载模块 报错 回调
        /// </summary>
        void OnLoaderFailCallback(TLoaderFailInfo failInfo)
        {
            Debug.Log("UGE====Main.OnLoaderFailCallback, loadMgr.isStartupComplete=" + UGE.loadMgr.isStartupComplete);
            if (UGE.loadMgr.isStartupComplete == false)
            {
                //uge没有启动完成
                //UGE.Restartup();
            }
            else
            {
                //uge启动完成了
                //这里可以采用  单个回调用的判断      //TLoaderContent.failInfo != null; 说明 加载失败
            }
            //下面的，只是一个使用例子，具体的 根据项目组需求 修改。              //
            //是否联网，如果根本没有联网，那就直接报网络
            if (Application.internetReachability == NetworkReachability.NotReachable)
            {
                //无法连接到网络	-	Network unreachable
                Debug.LogError("---------- Loader Error. 无法连接到网络    Network unreachable");
                return;
            }
            //没有找到对应的ver文件          //Add Wade 7.29+
            if (failInfo.type == -1)
            {
                Debug.Log("---------- Loader Error.  filever=null, path=" + failInfo.path);
                return;
            }
            //联网了，获取不到服务器 -》如果停服了，应该是从服务器获取路径都出问题了，从那里就知道停服了
            if (failInfo.responseHeadersCount == 0)
            {
                //无法连接到服务器	-	Connection refused
                Debug.LogError("---------- Loader Error. 无法连接到服务器    Connection refused");
                return;
            }
            //下面就是判断程序返回的了
            switch (failInfo.type)
            {
                case 1:         //1 下载404	- source				-	基本不会出现 - 服务器ver和file没对上	-	让用户重新登录
                    break;
                case 2:         //2 hash错误	- source			-	基本不会出现 - 解决方案，删除本地ver，让其重新登录游戏
                    break;
                case 3:         //3 本地无此文件 -> 只是用于ver		-	基本不可能	 - 客户端streamingAssets中ver丢失了!这个不可能!
                    break;
                case 4:         //4 buildin无此文件	-> local	//需要重新整理本地ver	//运行时	//提示重新登录，修复bug

                    break;
            }
            //		Debug.Log("GameSavePrefs.GetLocalVerify()=" + GameSavePrefs.GetLocalVerify());
            Debug.LogError("---------- Loader Error. failInfo=" + failInfo.path + "|" + failInfo.type + "|" + failInfo.info + "|" + failInfo.responseHeadersCount);
        }
        #endregion

        #region 数据更新

        //是否 res manifest 加载完成
        bool isResManifestDone = false;

        /// <summary>
        /// 数据更新刷新
        /// </summary>
        void Update()
        {
            //数据更新
            Tick.Update();

            //设置资源是否加载完成
            if (!isResManifestDone)
            {
                if (ResManifest.instance.IsDone)
                    isResManifestDone = true;
            }
        }

        //数据更新
        void LateUpdate()
        {
            Tick.LateUpdate();
        }

        #endregion

        #region 地图列表数据

        //标识场景资源数据是否加载完成
        bool scene_list_load_over = false;

        //场景数据资源列表
        List<Scene> sceneList = null;

        /// <summary>
        /// 开始加载服务器列表资源数据
        /// </summary>
        void StartLoadServerSceneList()
        {
            StartCoroutine(LoadServerData(Config.SERVER_LIST_URL, LoadServerSceneInfo));
        }

        private IEnumerator LoadServerData(string url, System.Action<string> action)
        {
            if (string.IsNullOrEmpty(url))
                yield return null;

            //using (WWW www = new WWW(url))
            WWW www = new WWW(url);
            {
                yield return www;

                if (action != null)
                {
                    if (!string.IsNullOrEmpty(www.error))
                        Debug.LogError(" www is error " + www.error + "      " + url);
                    string json = www.text.Replace("\"true\"", "true").Replace("\"false\"", "false");
                    action(json);
                }
                www.Dispose();
            }
        }

        /// <summary>
        /// 加载服务器场景资源信息
        /// </summary>
        /// <param name="www"></param>
        /// <param name="parameter"></param>
        void LoadServerSceneInfo(string text)
        {


            //资源加载失败，返回
            if (string.IsNullOrEmpty(text))
            {
                Debug.LogError("返回了场景列表数据为空");
                return;
            }


            //解析服务器列表数据
            string[] strs = text.Split('\n');
            if (strs == null || strs.Length == 0)
                return;

            //数据清理
            if (sceneList == null)
                sceneList = new List<Scene>();
            sceneList.Clear();

            //存储场景资源数据信息
            for (int i = 0; i < strs.Length; i++)
            {
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                Scene info = JsonUtility.FromJson(strs[i], typeof(Scene)) as Scene;
                if (info == null)
                    continue;

                //存储数据信息
                sceneList.Add(info);
            }

            //设置场景资源数据加载完成
            scene_list_load_over = true;
        }


        #endregion


        #region GUI

        //是否可以显示GUI
        bool canShowGUI = true;
        public GameObject go;
        /// <summary>
        /// 数据资源显示
        /// </summary>
        void OnGUI()
        {
            //if (GUILayout.Button(" TTTTTTTTTTTTTTT "))
            //{
            //    string url = @"D:\U3dWorkSpace\Mobile\Tgame\Share\Tools\TGameArtEditor\data\windows\engine";

            //    url = url.Replace('\\', '/');
            //    Debug.LogError(url);
            //    //CameraMove.GetInst().CameraLookAtTarget(go);
            //}
            if (GUILayout.Button(" TTTTTTTTTTTTTTT "))
            {
                Debug.Log(Sprite.count);
                //CameraMove.GetInst().CameraLookAtTarget(go);
            }

            if (GUI.Button(new Rect(Screen.width - 200, 0, 200, 50), "返回地图列表"))
            {
                OnUnloadScene();
            }

            if (!canShowGUI)
                return;

            if (!scene_list_load_over)
            {
                //正在加载服务器资源
                winRect = GUI.Window(1, winRect, DrawWindow, "加载服务器资源");

            }
            else
            {
                if (sceneList == null || sceneList.Count == 0)
                {
                    //场景资源加载失败
                    winRect = GUI.Window(2, winRect, DrawWindow, "加载服务器资源");
                }
                else
                {
                    //资源配置加载完成 在显示GUI数据
                    if (isResManifestDone)
                        winRect = GUI.Window(3, winRect, DrawServerList, "服务器场景资源数据列表");
                }
            }


        }


        #region 显示场景列表资源加载，和失败

        const int WinWidth = 800;
        const int WinHeight = 600;
        //编辑器属性窗口设置
        Rect winRect = new Rect(Screen.width / 2 - WinWidth / 2, Screen.height / 2 - WinHeight / 2, WinWidth, WinHeight);

        /// <summary>
        /// 绘制数据窗口
        /// </summary>
        /// <param name="id"></param>
        void DrawWindow(int id)
        {
            if (id == 1)
            {
                GUILayout.BeginHorizontal();

                GUIDrawLabel("场景资源数据正在加载中", -1);

                GUILayout.EndHorizontal();
            }
            else if (id == 2)
            {
                GUILayout.BeginHorizontal();

                GUIDrawLabel("场景资源数据加载失败", -1);

                GUILayout.EndHorizontal();
            }

        }

        /// <summary>
        /// GUI 绘制 Label
        /// </summary>
        /// <param name="show"></param>
        /// <param name="fontSize"></param>
        void GUIDrawLabel(string show, int fontSize = -1)
        {
            if (fontSize > 0)
                GUI.skin.label.fontSize = fontSize;

            GUI.Label(new Rect(160, WinHeight * 0.5f - 20, WinWidth, WinHeight), show);
        }


        #endregion

        #region 显示服务器场景资源数据列表

        //存储滚动条位置变量
        Vector2 scrollPosi = Vector2.zero;

        //场景资源数据信息
        SceneManager sceneManager;
        SceneManager GetSceneManager()
        {
            if (sceneManager == null)
                sceneManager = gameObject.AddComponent<SceneManager>();

            return sceneManager;
        }

        /// <summary>
        /// 加载场景资源数据
        /// </summary>
        /// <param name="id"></param>
        void OnLoadScene(Scene scene)
        {
            if (scene == null || scene.map_id < 0)
                return;

            //加载场景资源数据
            if (GetSceneManager().LoadScene(scene))
                canShowGUI = false;
        }

        void OnUnloadScene()
        {
            GetSceneManager().UnloadScene();
            canShowGUI = true;
        }

        /// <summary>
        /// 绘制服务器列表数据
        /// </summary>
        /// <param name="id"></param>
        void DrawServerList(int id)
        {
            scrollPosi = GUILayout.BeginScrollView(scrollPosi);

            for (int i = 0; i < sceneList.Count; i++)
            {
                if (sceneList[i] != null)
                {
                    if (GUILayout.Button(" [ " + sceneList[i].id + " ]  " + sceneList[i].name_i18n))
                    {
                        OnLoadScene(sceneList[i]);
                    }
                }

            }

            GUILayout.EndScrollView();
        }

        #endregion

        #endregion

    }
}
