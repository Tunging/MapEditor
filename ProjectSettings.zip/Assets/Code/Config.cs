using MapEditor;
using UnityEngine;
using System.Collections;
using System;

/// <summary>
/// 配置数据
/// </summary>
public class Config
{

    #region 属性数据

    //本地编辑器使用的资源路径
    public static string LOCAL_EDITOR_PATH = "";

    //服务器列表资源数据
    public static string SERVER_LIST_URL = "http://192.168.17.156/dataeditor/ceditor/scene_list.do";

    //资源服地址
    public static string RES_SERVER_URL = "http://188.188.0.52/Tgame3D/M5B_DEV/PC/CN_Pro";

    //获取服务器 当前场景 NavMesh 地址
    public static string SERVER_NAVMESH = "http://192.168.17.156/dataeditor/mesh/mesh_info.do?id=";

    //服务器怪物数据
    public static string SERVER_NPC = "";

    //最大的同时下载资源数量
    public static int MAX_LOAD_RES_COUNT = 100;

    #region NPC数据
    //服务器npc 列表数据
    public static string NPC_LIST = "http://192.168.17.156/dataeditor/ceditor/npc_scene_list.do?scene_id=";

    //服务器npc 列表数据插入
    public static string NPC_INSERT = "http://192.168.17.156/dataeditor/ceditor/npc_scene_insert.do";

    //服务器npc 列表数据更新
    public static string NPC_UPDATE = "http://192.168.17.156/dataeditor/ceditor/npc_scene_update.do";

    //服务器npc 列表数据删除
    public static string NPC_DELETE = "http://192.168.17.156/dataeditor/ceditor/npc_scene_delete.do";

    #endregion

    #region 摄像机路径

    //path 数据
    public static string CAMERA_PATH_LIST = "http://192.168.17.156/dataeditor/camera/list.do?scene_id=";

    //path 数据插入
    public static string CAMERA_PATH_INSERT = "http://192.168.17.156/dataeditor/camera/insert.do";

    //path 数据更新
    public static string CAMERA_PATH_UPDATE = "http://192.168.17.156/dataeditor/camera/update.do";

    //path 数据删除
    public static string CAMERA_PATH_DELETE = "http://192.168.17.156/dataeditor/camera/delete.do";

    #endregion

    #region 任务区域数据
    //服务 区域数据
    public static string SERVER_AREA_LIST = "http://192.168.17.63:8090/dataeditor/sceneregion/list.do";

    //任务区域 数据插入
    public static string QUEST_AREA_INSERT = "http://192.168.17.63:8090/dataeditor/sceneregion/insert.do";

    //任务区域 数据更新
    public static string QUEST_AREA_UPDATE = "http://192.168.17.63:8090/dataeditor/sceneregion/update.do";

    //任务区域 数据删除
    public static string QUEST_AREA_DELETE = "http://192.168.17.63:8090/dataeditor/sceneregion/delete.do";
    #endregion

    #region 空气墙
    //空气墙
    public static string AIR_WALL_LIST = "http://192.168.18.102:8080/airwall/scene_air_wall_list.do";

    //空气墙 数据插入   
    public static string AIR_WALL_INSERT = "http://192.168.18.102:8080/airwall/scene_air_wall_insert.do";

    //空气墙 数据更新   
    public static string AIR_WALL_UPDATE = "http://192.168.18.102:8080/airwall/scene_air_wall_update.do";

    //空气墙 数据删除   
    public static string AIR_WALL_DELETE = "http://192.168.18.102:8080/airwall/scene_air_wall_delete.do";
    #endregion
    #region 声音触发器
    //空气墙
    public static string Sound_Emitter_LIST = "http://localhost:20000/ceditor/sound_emitter/list";

    //空气墙 数据插入   
    public static string Sound_Emitter_INSERT = "http://localhost:20000/ceditor/sound_emitter/insert";

    public static string Sound_Emitter_UPDATE = "http://localhost:20000/ceditor/sound_emitter/update";

    public static string Sound_Emitter_DELETE = "http://localhost:20000/ceditor/sound_emitter/delete";
    #endregion

    #region 碰撞采集物  Offline_Gather_List
    //碰撞采集物
    public static string Offline_Gather_List = "http://localhost:20000/ceditor/sound_emitter/list";

    //碰撞采集物 数据插入   
    public static string Offline_Gather_Insert = "http://localhost:20000/ceditor/sound_emitter/insert";

    public static string Offline_Gather_Update = "http://localhost:20000/ceditor/sound_emitter/update";

    public static string Offline_Gather_Delete = "http://localhost:20000/ceditor/sound_emitter/delete";

    #endregion


    #region Scene数据更改。。。慎重使用，仅仅为了添加 音效组ID而存在的接口，只保留了update接口 ZYJ
    //空气墙
    //public static string Sound_Emitter_LIST = "http://localhost:20000/ceditor/scene/list";

    //空气墙 数据插入   
    //public static string Sound_Emitter_INSERT = "http://localhost:20000/ceditor/scene/insert";

    public static string Scene_UPDATE = "http://localhost:20000/ceditor/scene/update";

    //public static string Sound_Emitter_DELETE = "http://localhost:20000/ceditor/scene/delete";
    #endregion


    #region 巡逻数据
    //巡逻数据
    public static string PATROL_LIST = "http://192.168.18.102:8080/patrol/patrol_list.do";

    //巡逻数据 数据插入   
    public static string PATROL_INSERT = "http://192.168.18.102:8080/patrol/patrol_insert.do";

    //巡逻数据 数据更新   
    public static string PATROL_UPDATE = "http://192.168.18.102:8080/patrol/patrol_update.do";

    //巡逻数据 数据删除   
    public static string PATROL_DELETE = "http://192.168.18.102:8080/patrol/patrol_delete.do";
    #endregion

    #region 副本配置
    public static string Instance_list;
    public static string Instance_Insert;
    public static string Instance_Update;
    public static string Instance_Delete;
    #endregion

    //最大查找 sprite范围
    public static float MAX_FIND_SPRITE_DIS = 1.5f;

    //本地路径（url WWW使用）
    public static string LOCAL_URL = string.Format("file://{0}", Application.streamingAssetsPath);
    //缓存路径（url WWW使用）  此url 在 windows 及 WP IOS  可以使用
    //IOS 下这个路径用cache，避免备份到Icloud
    public static string CACHE_URL = string.Format("file://{0}/vercache", Application.temporaryCachePath);

    //缓存路径（缓存使用 IO 使用）
    public static string CACHE_PATH = System.IO.Path.Combine(Application.persistentDataPath, "vercache");


    //资源manifest 后缀名
    public static string MANIFEST_EXTENSION = "";
    //配表配置后缀名
    public static string CONFIG_EXTENSION = ".bytes";
    //UGE 配置后缀
    public static string UGE_CONFIG_TXT = ".txt";
    //UGE 地图二进制后缀
    public static string UGE_CONFIG_BIN = ".bin";
    //加载的文件后缀名
    public static string fileSuff = ".p";

    //显示路径点时的资源数据
    public static string PATH_SHOW_PREFAB = "Point";

    #endregion



    #region 单例

    static Config instance;
    public static Config GetInst()
    {
        if (instance == null)
            instance = new Config();
        return instance;
    }

    #endregion

    #region 读取配置

    //加载配置资源数据 Action
    Action loadConfigAction;

    /// <summary>
    /// 解析配置信息
    /// </summary>
    public void LoadConfig(MonoBehaviour mb, Action action)
    {
        loadConfigAction = action;
#if UNITY_EDITOR
        string url = string.Format("file://{0}/Config.txt", Application.streamingAssetsPath);
#else

            string url = string.Format("{0}/StreamingAssets/Config.txt", Application.dataPath);
#endif

        mb.StartCoroutine(LoadServerData(url, LoadConfigOver));

    }


    private IEnumerator LoadServerData(string url, System.Action<string> action)
    {
        if (string.IsNullOrEmpty(url))
            yield return null;

        //using (WWW www = new WWW(url))
        WWW www = new WWW(url);
        {
            yield return www;

            if (action != null)
            {
                if (!string.IsNullOrEmpty(www.error))
                    Debug.LogError(" www is error " + www.error + "      " + url);
                string json = www.text.Replace("\"true\"", "true").Replace("\"false\"", "false");
                action(json);
            }
            www.Dispose();
        }
    }
    /// <summary>
    /// 配置文件加载完成
    /// </summary>
    /// <param name="www"></param>
    /// <param name="parameter"></param>
    void LoadConfigOver(string json)
    {
        if (string.IsNullOrEmpty(json))
        {
            GUINotice.Show("<color=red> 配置资源数据文件 Config.txt 加载失败 </color> \n" + json);
            return;
        }

        //字符串剪切
        string[] strs = json.Split('\n');
        for (int i = 0; i < strs.Length; i++)
        {
            if (string.IsNullOrEmpty(strs[i]))
                continue;

            SetConfig(i, strs[i].Trim());
        }

        //配置文件资源加载完成回调
        if (loadConfigAction != null)
            loadConfigAction();
    }

    /// <summary>
    /// 设置配置数据
    /// </summary>
    /// <param name="indexId"></param>
    /// <param name="str"></param>
    void SetConfig(int indexId, string str)
    {
        switch (indexId)
        {
            case 0:
                LOCAL_EDITOR_PATH = str.Replace('\\', '/');
                break;
            case 1:
                SERVER_LIST_URL = str;
                break;
            case 2:
                RES_SERVER_URL = str;
                break;
            case 3:
                SERVER_NAVMESH = str;
                break;
            case 4:
                SERVER_NPC = str;
                break;
            case 5:
                MAX_LOAD_RES_COUNT = int.Parse(str);
                break;
            case 6:
                NPC_LIST = str;
                break;
            case 7:
                NPC_INSERT = str;
                break;
            case 8:
                NPC_UPDATE = str;
                break;
            case 9:
                NPC_DELETE = str;
                break;
            case 10:
                CAMERA_PATH_LIST = str;
                break;
            case 11:
                CAMERA_PATH_INSERT = str;
                break;
            case 12:
                CAMERA_PATH_UPDATE = str;
                break;
            case 13:
                CAMERA_PATH_DELETE = str;
                break;
            case 14:
                SERVER_AREA_LIST = str;
                break;
            case 15:
                QUEST_AREA_INSERT = str;
                break;
            case 16:
                QUEST_AREA_UPDATE = str;
                break;
            case 17:
                QUEST_AREA_DELETE = str;
                break;
            case 18:
                AIR_WALL_LIST = str;
                break;
            case 19:
                AIR_WALL_INSERT = str;
                break;
            case 20:
                AIR_WALL_UPDATE = str;
                break;
            case 21:
                AIR_WALL_DELETE = str;
                break;
            case 22:
                PATROL_LIST = str;
                break;
            case 23:
                PATROL_INSERT = str;
                break;
            case 24:
                PATROL_UPDATE = str;
                break;
            case 25:
                PATROL_DELETE = str;
                break;
            case 26:
                Instance_list = str;
                break;
            case 27:
                Instance_Insert = str;
                break;
            case 28:
                Instance_Update = str;
                break;
            case 29:
                Instance_Delete = str;
                break;
            case 30:
                Sound_Emitter_LIST = str;
                break;
            case 31:
                Sound_Emitter_INSERT = str;
                break;
            case 32:
                Sound_Emitter_UPDATE = str;
                break;
            case 33:
                Sound_Emitter_DELETE = str;
                break;
            case 34:
                Offline_Gather_List = str;
                break;
            case 35:
                Offline_Gather_Insert = str;
                break;
            case 36:
                Offline_Gather_Update = str;
                break;
            case 37:
                Offline_Gather_Delete = str;
                break;
        }
    }

    #endregion
}