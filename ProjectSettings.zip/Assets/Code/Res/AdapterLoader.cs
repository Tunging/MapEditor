﻿//using System.Collections.Generic;
//using System.IO;
//using UnityEngine;
//using ZTool.Res;


////关于path
////路径是从update子目录开始，不包含update,这里需要在前面添加上update
////添加资源后缀 pc的是.p 安卓是.a iphone是.i
////例如 game/map/mt0041/eff_4_2.prefab，需要在此处理为 update/game/map/mt0041/eff_4_2.prefab.p

//public class AdapterLoader : LoadManager
//{
//    //4.19
//    //    public override void Startup(string ResServerUrl, List<string> checkVerGroupNameList, List<string> p_forceUpdateGroupNameList, int MaxTaskCount = 2, int CacheTime = 3)
//    public override void Startup(List<string> checkVerGroupNameList, List<string> p_forceUpdateGroupNameList,
//                                List<string> dependList,
//                                List<string> allShaderList)
//    {
//        Debug.Log("loader startup...");
//        //加载引擎依赖项		//2016.3.24 Wade+
//        var path = "game/map/map_manifest";     //"StreamingAssets";
//        DoLoadBundle(path, OnLoadEngineDependenciesOK);

//        //		//版本比对，或者已经比对完成就 直接调用
//        //		this.dispatchEvent(EVENTTYPE_COMPLETE, null);
//    }

//    //加载引擎依赖项		//2016.3.24 Wade+
//    void OnLoadEngineDependenciesOK(string path, UnityEngine.Object obj, System.Object parameter)
//    {
//        Debug.Log("===引擎加载依赖项完成===");

//        AssetBundle bundle = (AssetBundle)obj;
//        AssetBundleManifest fest = (AssetBundleManifest)bundle.LoadAsset("AssetBundleManifest");

//        //缓存当前所有的资源引用配置
//        string[] str = fest.GetAllAssetBundles();
//        if (str == null || str.Length == 0)
//        {
//            Debug.LogError("当前Manifest里不包含AssetBundle的资源引用");
//            return;
//        }

//        int count = str.Length;
//        for (int i = 0; i < count; i++)
//        {
//            string[] allDependencies = fest.GetAllDependencies(str[i]);
//            if (allDependencies != null && allDependencies.Length > 0)
//            {
//                //获得数据，然后存储
//                List<string> list = new List<string>();
//                list.AddRange(allDependencies);
//                if (string.IsNullOrEmpty(list[0]))
//                    list.RemoveAt(0);
//                //添加到 - jh的依赖项中
//                ResManifest.instance.AddAllDependencies(str[i], list);
//            }
//        }
//        Debug.Log("===引擎加载依赖项 - 添加完成===");

//        //版本比对，或者已经比对完成就 直接调用
//        this.dispatchEvent(EVENTTYPE_COMPLETE, null);
//    }

//    public override void tUpdate()
//    {
//        //空着就好
//    }


//    Dictionary<string, System.Action<string, object>> m_lDownLoad = new Dictionary<string, System.Action<string, object>>();

//    //下载方法			//4.19  //override  uge没有此方法
//    //目前在大地图中，要确保在进入前，地图相关资源都下载完成
//    public void Download(string path, System.Action<string, object> onLoadOver, object parameter = null)
//    {

//        if (string.IsNullOrEmpty(path))
//            return;

//        //        path = string.Format("{0}{1}", path, ResConst.fileSuff);

//        ResStateEnum rs = ResLoadManager.instance.GetFileResState(path);
//        Debug.LogError("download  rs=" + rs + "  " + path);
//        switch (rs)
//        {
//            case ResStateEnum.ResState_UseDownloaded:
//            case ResStateEnum.ResState_UseLocal:
//                //存在缓存或者本地
//                onLoadOver(path, parameter);
//                break;
//            case ResStateEnum.ResState_UseRemote:
//                //存在服务器，那么开始下载下来
//                if (!m_lDownLoad.ContainsKey(path))
//                    ResCacheManager.instance.LoadAssetBundle(path, OnDownLoadOver, parameter, null, false, false);
//                m_lDownLoad[path] = onLoadOver;
//                break;
//            case ResStateEnum.ResState_Error:
//            default:
//                Debug.LogError("  请求下载资源错误： " + path);
//                break;
//        }

//        //		if(path 在本地)
//        //			onLoadOver(path,parameter);
//        //		else
//        //		{
//        //			取服务器下载；
//        //			完成后回调 onloaderOver；
//        //		}
//    }

//    /// <summary>
//    /// Down 资源加载完成， 主要为地图切块
//    /// </summary>
//    /// <param name="path"></param>
//    /// <param name="obj"></param>
//    /// <param name="parameter"></param>
//    void OnDownLoadOver(string path, UnityEngine.Object obj, object parameter)
//    {
//        if (m_lDownLoad.ContainsKey(path))
//        {
//            m_lDownLoad[path](path, parameter);
//            m_lDownLoad.Remove(path);

//            //ResCacheManager.instance.UnLoadAssetBundle(path, OnDownLoadOver);
//        }

//    }

//    Dictionary<string, AssetNode.OnLoadOver> m_lLoadBundle = new Dictionary<string, AssetNode.OnLoadOver>();
//    public override void LoadBundle(string path, AssetNode.OnLoadOver onLoadOver, object parameter = null)
//    {
//        //加载完成后
//        //回调 onLoaderOver(path,bundle,parameter)
//        //		path = string.Format("{0}{1}", path, ResConst.fileSuff);
//        //
//        DoLoadBundle(path, onLoadOver, parameter);
//    }

//    /// <summary>
//    /// 路径传什么 就是什么，直接加载。  //2016.3.24 Wade + 
//    /// </summary>
//    /// <param name="path">Path.</param>
//    /// <param name="onLoadOver">On load over.</param>
//    /// <param name="parameter">Parameter.</param>
//    void DoLoadBundle(string path, AssetNode.OnLoadOver onLoadOver, object parameter = null)
//    {
//        if (m_lLoadBundle.ContainsKey(path))
//        {
//            m_lLoadBundle[path] = onLoadOver;
//        }
//        else
//        {
//            if (onLoadOver != null)
//            {
//                m_lLoadBundle[path] = onLoadOver;
//                ResCacheManager.instance.LoadAssetBundle(path, OnLoadBundleOver, parameter, null, false, true);
//            }
//        }
//    }

//    /// <summary>
//    /// Bundle 资源数据加载完成
//    /// </summary>
//    /// <param name="path"></param>
//    /// <param name="obj"></param>
//    /// <param name="parameter"></param>
//    void OnLoadBundleOver(string path, UnityEngine.Object obj, object parameter)
//    {
//        if (m_lLoadBundle.ContainsKey(path))
//        {
//            m_lLoadBundle[path](path, obj, parameter);
//            m_lLoadBundle.Remove(path);
//        }
//    }

//    Dictionary<string, List<AssetNode.OnLoadOver>> m_lLoadObj = new Dictionary<string, List<AssetNode.OnLoadOver>>();

//    public override void LoadObj(string path, AssetNode.OnLoadOver onLoadOver, object parameter = null)
//    {
//        //加载完成后
//        //从bundle中load出相应的obj（一般都是prefab），资源的名字为path的文件名字（例如path为“game/map/mt0041/eff_4_2.prefab.p”, 则 obj=bundle.loadAsset("eff_4_2.prefab") ）
//        //回调 onLoaderOver(path,obj,parameter)
//        //        path = string.Format("{0}{1}", path, ResConst.fileSuff);
//        //Debug.LogError("  start load asset   " + path);
//        if (m_lLoadObj.ContainsKey(path))
//        {
//            if (onLoadOver != null)
//                m_lLoadObj[path].Add(onLoadOver);
//        }
//        else
//        {
//            if (onLoadOver != null)
//            {
//                List<AssetNode.OnLoadOver> list = new List<AssetNode.OnLoadOver>();
//                list.Add(onLoadOver);
//                m_lLoadObj[path] = list;
//                ResCacheManager.instance.LoadAssetBundle(path, OnLoadObjOver, parameter, Path.GetFileNameWithoutExtension(path), false);
//            }
//        }
//    }

//    /// <summary>
//    /// obj 加载完成
//    /// </summary>
//    /// <param name="path"></param>
//    /// <param name="obj"></param>
//    /// <param name="parameter"></param>
//    void OnLoadObjOver(string path, UnityEngine.Object obj, object parameter)
//    {
//        //Debug.LogError("   load asset over  " + path);

//        if (m_lLoadObj.ContainsKey(path))
//        {
//            List<AssetNode.OnLoadOver> list = m_lLoadObj[path];
//            m_lLoadObj.Remove(path);
//            for (int i = 0; i < list.Count; i++)
//            {
//                list[i](path, obj, parameter);
//            }
//        }
//    }

//    Dictionary<string, List<System.Action<string, object>>> m_lLoadTxt = new Dictionary<string, List<System.Action<string, object>>>();

//    //加载文本主要是配表
//    public override void LoadTxt(string strPath, System.Action<string, object> onLoadOver, object paramater)
//    {
//        //        strPath = string.Format("{0}{1}", strPath, GameConfig.UGE_CONFIG_TXT);
//        Debug.LogError(strPath);
//        //编码是 Encoding.UTF8
//        if (m_lLoadTxt.ContainsKey(strPath))
//        {
//            if (onLoadOver != null)
//                m_lLoadTxt[strPath].Add(onLoadOver);
//        }
//        else
//        {
//            if (onLoadOver != null)
//            {
//                List<System.Action<string, object>> list = new List<System.Action<string, object>>();
//                list.Add(onLoadOver);
//                m_lLoadTxt[strPath] = list;
//                ResCacheManager.instance.LoadString(strPath, OnLoadTxtOver, paramater);
//            }
//        }
//    }

//    /// <summary>
//    /// Txt 加载完成
//    /// </summary>
//    /// <param name="path"></param>
//    /// <param name="obj"></param>
//    /// <param name="parameter"></param>
//    void OnLoadTxtOver(string path, object obj, object parameter)
//    {
//        Debug.LogError(path);

//        if (m_lLoadTxt.ContainsKey(path))
//        {
//            string str = (string)obj;
//            List<System.Action<string, object>> list = m_lLoadTxt[path];
//            m_lLoadTxt.Remove(path);
//            for (int i = 0; i < list.Count; i++)
//            {
//                list[i](str, parameter);
//            }
//        }
//    }


//    Dictionary<string, List<System.Action<byte[]>>> m_lLoadBin = new Dictionary<string, List<System.Action<byte[]>>>();
//    //加载二进制
//    public override void LoadBin(string strPath, System.Action<byte[]> onLoadOver)
//    {
//        //        strPath = string.Format("{0}{1}", strPath, GameConfig.UGE_CONFIG_BIN);
//        if (m_lLoadBin.ContainsKey(strPath))
//        {
//            if (onLoadOver != null)
//                m_lLoadBin[strPath].Add(onLoadOver);
//        }
//        else
//        {
//            if (onLoadOver != null)
//            {
//                List<System.Action<byte[]>> list = new List<System.Action<byte[]>>();
//                list.Add(onLoadOver);
//                m_lLoadBin[strPath] = list;
//                ResCacheManager.instance.LoadBytes(strPath, OnLoadBinOver, null, false);
//            }
//        }
//    }

//    /// <summary>
//    /// Bin资源加载完成
//    /// </summary>
//    /// <param name="path"></param>
//    /// <param name="obj"></param>
//    /// <param name="parameter"></param>
//    void OnLoadBinOver(string path, object obj, object parameter)
//    {
//        if (m_lLoadBin.ContainsKey(path))
//        {
//            Debug.LogError(path + "    " + obj);

//            byte[] b = (byte[])obj;
//            List<System.Action<byte[]>> list = m_lLoadBin[path];
//            m_lLoadBin.Remove(path);
//            for (int i = 0; i < list.Count; i++)
//            {
//                list[i](b);
//            }
//        }
//    }

//    void UnLoadRes(string path)
//    {
//        //path = string.Format("{0}{1}", path, ResConst.fileSuff);

//        //目前没有存储，是通过什么方式加载的资源，暂时所有的都卸载
//        if (m_lLoadBundle.ContainsKey(path))
//        {
//            m_lLoadBundle.Remove(path);
//        }
//        ResCacheManager.instance.UnLoadAssetBundle(path, (ResHelper.OnResNodeLoadOver)OnLoadBundleOver, true);

//        if (m_lLoadObj.ContainsKey(path))
//        {
//            m_lLoadObj[path].RemoveAt(0);
//            if (m_lLoadObj[path] == null || m_lLoadObj[path].Count == 0)
//                m_lLoadObj.Remove(path);
//        }
//        ResCacheManager.instance.UnLoadAssetBundle(path, (ResHelper.OnResNodeLoadOver)OnLoadObjOver, true);

//        if (m_lLoadTxt.ContainsKey(path))
//        {
//            m_lLoadTxt[path].RemoveAt(0);
//            if (m_lLoadTxt[path] == null || m_lLoadTxt[path].Count == 0)
//                m_lLoadTxt.Remove(path);
//        }
//        ResCacheManager.instance.UnLoadString(path, OnLoadTxtOver);

//        if (m_lLoadBin.ContainsKey(path))
//        {
//            m_lLoadBin[path].RemoveAt(0);
//            if (m_lLoadBin[path] == null || m_lLoadBin[path].Count == 0)
//                m_lLoadBin.Remove(path);
//        }
//        ResCacheManager.instance.UnLoadBytes(path, OnLoadBinOver);

//    }

//    //卸载资源，如果你们那边不需要就直接重写后空着就好
//    public override void Unload(string path, bool deleteImmediately = false)
//    {
//        UnLoadRes(path);
//    }

//    //取消下载资源
//    //例如在大地图中 在某块地图边缘，向前走了一点儿，又立马回头，会导致需要取消加载前面的那块
//    public override void Cancel(string url, AssetNode.OnLoadOver callback)
//    {
//        //取消加载bundle,真取消和假取消都可以
//        //删除之前load时候的回调
//        UnLoadRes(url);
//    }
//}

