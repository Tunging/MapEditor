﻿using UnityEngine;
using System.Collections;

namespace MapEditor
{
    /// <summary>
    /// 巡逻 数据
    /// </summary>
    public class PatrolPos
    {
        //坐标点数组
        public Vector3[] pos;
    }
}
