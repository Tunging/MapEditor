﻿using UnityEngine;
using System.Collections;

namespace MapEditor
{

    /// <summary>
    /// Path 顶点信息
    /// </summary>
    public class PointInfo
    {
        //point pos 信息
        public Vector3 pos;

        //point 朝向信息
        public Quaternion rot;
    }

}
