﻿namespace MapEditor
{

    /// <summary>
    /// 数据库中 存储一个场景中的信息数据
    /// </summary>
    public class ServerNavMesh
    {
        //地图id
        public int id;

        //地图名字
        public string name;

        //地图路径
        public string path;

        //最大坐标
        public float max_x;

        public float max_y;

        public float max_z;

        //mesh 数据 二进制数组
        public byte[] mesh;
    }
}