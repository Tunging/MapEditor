﻿using UnityEngine;
using System.Collections;

namespace MapEditor
{
    /// <summary>
    /// 怪物数据
    /// </summary>
    public class NpcModel
    {

        //怪物id
        public int id;

        //怪物名字
        public string name_i18n;

        //等级
        //public int level;

        //模型id
        public int resources_id;

        //资源路径
        public string path;

        //移动类型
        public int move_type;

        //模型缩放
        public float model_scale;
    }

}
