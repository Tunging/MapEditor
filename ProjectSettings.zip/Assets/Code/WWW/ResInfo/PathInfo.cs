﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System;

namespace MapEditor
{

    //路径信息数据
    public class PathInfo
    {
        //path id
        public int id;

        //path name
        public string name = "名字";

        //path scene_id
        public int scene_id;

        //轨迹点集合
        public string data;

        //看向的目标点
        public string watch_point = "";

        //存储 Path Point 信息数据
        public List<SpritePoint> spritePointsList = new List<SpritePoint>();

        // points 顶点数据
        public List<PointInfo> pointsList = new List<PointInfo>();

        //是否是服务器资源数据
        public bool isServer = false;

        //Path 是否平滑过渡
        public bool isSmoothAmount = false;

        //是否为闭环
        public bool isClosedLoop = false;

        //是否和服务器数据相同
        public bool isSynchronizationServer = false;

        #region points 数据操作

        /// <summary>
        /// 添加 point 数据
        /// </summary>
        /// <param name="point"></param>
        public void AddPoint(SpritePoint point)
        {
            if (point == null)
                return;

            spritePointsList.Add(point);
        }

        /// <summary>
        /// 两个 point 位置 交换
        /// </summary>
        /// <param name="srcId"></param>
        /// <param name="targetId"></param>
        /// <returns></returns>
        public bool ExchangePoint(int srcId, int targetId)
        {
            if (srcId == targetId || targetId >= spritePointsList.Count
                || targetId < 0)
                return false;

            SpritePoint temp = spritePointsList[srcId];
            spritePointsList[srcId] = spritePointsList[targetId];
            spritePointsList[targetId] = temp;

            return true;
        }

        /// <summary>
        /// 插入到固定位置， 后续的顺次排列
        /// </summary>
        /// <param name="srcId"></param>
        /// <param name="targetId"></param>
        /// <returns></returns>
        public bool InsertPoint(int srcId, int targetId)
        {
            if (srcId == targetId || targetId >= spritePointsList.Count
                || targetId < 0)
                return false;

            SpritePoint sp = spritePointsList[srcId];

            spritePointsList.RemoveAt(srcId);
            spritePointsList.Insert(targetId, sp);
            return true;
        }

        /// <summary>
        /// 移除 point 数据
        /// </summary>
        /// <param name="index"></param>
        public void RemovePoint(int index)
        {
            //超出范围
            if (index < 0 || index >= spritePointsList.Count)
            {
                Debug.LogError(" point 超出范围 index " + index + " points count " + spritePointsList.Count);
                return;
            }

            //移除数据
            SpritePoint sp = spritePointsList[index];
            GameObject.Destroy(sp.gameObject);
            spritePointsList.RemoveAt(index);
        }

        /// <summary>
        /// 移除 point 数据
        /// </summary>
        /// <param name="index"></param>
        public void RemovePoint(SpritePoint point)
        {
            //超出范围
            if (point == null || spritePointsList.Count == 0)
            {
                return;
            }

            //移除数据
            for (int i = 0; i < spritePointsList.Count; i++)
            {
                if(spritePointsList[i] != null && spritePointsList[i] == point)
                {
                    GameObject.Destroy(point.gameObject);
                    spritePointsList.Remove(point);
                    return;
                }
            }
        }

        /// <summary>
        /// 清除 point 数据
        /// </summary>
        public void ClearPoints()
        {
            if (spritePointsList.Count == 0)
                return;

            for (int i = 0; i < spritePointsList.Count; i++)
            {
                if (spritePointsList[i] != null)
                {
                    GameObject.Destroy(spritePointsList[i].gameObject);
                }
            }

            spritePointsList.Clear();
        }

        /// <summary>
        /// 当前 Path 是否含有 points
        /// </summary>
        /// <returns></returns>
        public bool HavePoints()
        {
            return spritePointsList.Count > 0;
        }

        #endregion

        #region point数据和string 数据转换

        /// <summary>
        /// 顶点数据转换成 string 数据
        /// </summary>
        public void PointsToString()
        {
            if (spritePointsList == null || spritePointsList.Count == 0)
                return;

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < spritePointsList.Count; i++)
            {
                if(spritePointsList[i] != null && spritePointsList[i].CurrInfo != null)
                {
                    string str = JsonUtility.ToJson(spritePointsList[i].CurrInfo);
                    sb.Append(str);
                    //各个数据之间通过 “；”分割
                    if (i < spritePointsList.Count - 1)
                        sb.Append(";");
                }
            }

            //设置顶点数据
            data = sb.ToString();
        }

        /// <summary>
        /// string 转换成 points 数据
        /// </summary>
        public void StringToPoints()
        {
            if (string.IsNullOrEmpty(data))
                return;

            //清理数据信息
            pointsList.Clear();

            string[] strs = data.Split(';');
            if (strs == null || strs.Length == 0)
                return;

            for (int i = 0; i < strs.Length; i++)
            {
                //剔除不符合要求的数据
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                PointInfo info = JsonUtility.FromJson<PointInfo>(strs[i]);
                if (info == null)
                    continue;

                //存储所有的顶点数据信息
                pointsList.Add(info);
            }

        }

        internal WWWForm Serialize()
        {

            WWWForm form = new WWWForm();
            form.AddField("id", this.id);
            form.AddField("name", this.name);
            form.AddField("scene_id", this.scene_id);
            form.AddField("data", this.data);
            form.AddField("watch_point", this.watch_point);
            return form;
        }

        #endregion
    }
}
