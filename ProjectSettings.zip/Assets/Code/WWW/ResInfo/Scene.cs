﻿using UnityEngine;
using System.Collections;

namespace MapEditor
{

    /// <summary>
    /// 场景数据信息
    /// </summary>
    public class Scene
    {

        ///<summary>
        /// 主键：场景ID
        ///</summary>
        public int id;
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        ///<summary>
        /// 场景类型
        ///</summary>
        public int type;
        ///<summary>
        /// 引用的地图ID
        ///</summary>
        public int map_id;
        ///<summary>
        /// 小地图路径
        ///</summary>
        public string small_map_path;
        ///<summary>
        /// 场景物件加载配置ID
        ///</summary>
        public int object_loading_id;
        ///<summary>
        /// 相机屏幕后期文件名
        ///</summary>
        public string processing_profile_path;
        ///<summary>
        /// 场景lod设置组ID
        ///</summary>
        public int scene_lod_setting_id;
        ///<summary>
        /// 是否禁止跟随
        ///</summary>
        public bool forbidden_tam_follow;
        ///<summary>
        /// 救援总进度(单位m，速度单位为m/ms)
        ///</summary>
        public int rescue_progress;
        ///<summary>
        /// 场景BGM sound id
        ///</summary>
        public int scene_bgm_sound_id;
        ///<summary>
        /// 场景背景音效 sound id
        ///</summary>
        public int ambient_sound_id;
        ///<summary>
        /// 场景区域音效组id
        ///</summary>
        public int scene_soundgroup_id;


        public bool isDirty { get; set; }

        public WWWForm SerializeToForm()
        {
            WWWForm form = new WWWForm();
            form.AddField("id", this.id);
            form.AddField("name_i18n", this.name_i18n);
            form.AddField("name", this.name_i18n);
            form.AddField("type",this.type);
            form.AddField("map_id",this.map_id);
            form.AddField("small_map_path",this.small_map_path);
            form.AddField("object_loading_id",this.object_loading_id);
            form.AddField("processing_profile_path",this.processing_profile_path);
            form.AddField("scene_lod_setting_id",this.scene_lod_setting_id);
            form.AddField("forbidden_tam_follow",this.forbidden_tam_follow.ToString());
            form.AddField("rescue_progress",this.rescue_progress);
            form.AddField("scene_bgm_sound_id",this.scene_bgm_sound_id);
            form.AddField("ambient_sound_id",this.ambient_sound_id);
            form.AddField("scene_soundgroup_id",this.scene_soundgroup_id);
            return form;
        }
    }
}


