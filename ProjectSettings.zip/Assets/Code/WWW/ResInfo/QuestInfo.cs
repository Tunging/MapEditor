﻿using UnityEngine;
using System.Collections;
using TransformGizmos;

namespace MapEditor
{
    //区域事件信息
    public class QuestInfo : MonoBehaviour
    {
        //id
        public int id;

        public int type = 1;

        //名字
        public string name = "名字";

        //场景id
        public int scene_id;

        //场景坐标
        public float x;

        public float y;

        public float z;

        //半径:transform.scale.x=2*r  transform.scale.z=2*r
        public float r = 1;

        //高度:transform.scale.y=h;
        public float h = 1;

        //是否和服务器数据同步
        public bool isSynchronizationServer = false;

        /// <summary>
        /// 设置位置
        /// </summary>
        /// <param name="pos"></param>
        internal void SetPosition(Vector3 pos)
        {
            x = pos.x;
            y = pos.y;
            z = pos.z;
        }



        /// <summary>
        /// 数据刷新
        /// </summary>
        void Update()
        {
            if (TransformGizmo.GetInst().IsTarget(this.transform)
                && TransformGizmo.GetInst().IsChangeTarget())
            {
                if (x != this.transform.position.x ||
                    y != this.transform.position.y ||
                    z != this.transform.position.z ||
                    r != transform.localScale.x / 2 ||
                    h != transform.localScale.y)
                {
                    isSynchronizationServer = false;
                }


                x = this.transform.position.x;
                y = this.transform.position.y;
                z = this.transform.position.z;

                transform.localScale = new Vector3(transform.localScale.x, transform.localScale.y, transform.localScale.x);

                r = transform.localScale.x / 2;

                h = transform.localScale.y;

            }

            
        }

        internal void LocalScale()
        {
            transform.localScale = new Vector3(r * 2, h, r * 2);
        }
    }
}