﻿using UnityEngine;
using System.Collections;

public class JsonQuestInfo
{
    //id
    public int id;

    //name
    public string name;

    //场景 id
    public int scene_id;

    //场景坐标
    public string x;
    public string y;
    public string z;

    //半径
    public string radius;

    //高度
    public string height;
	
}
