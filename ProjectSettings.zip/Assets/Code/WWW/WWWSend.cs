﻿using UnityEngine;
using System.Collections;
using System;

namespace MapEditor
{

    /// <summary>
    /// 向服务器发送数据
    /// </summary>
    public class WWWSend
    {
        #region 单例

        static WWWSend instance;
        public static WWWSend GetInst()
        {
            if (instance == null)
                instance = new WWWSend();
            return instance;
        }

        #endregion

        /// <summary>
        /// 向服务器发送数据信息
        /// </summary>
        /// <param name="url"></param>
        /// <param name="action"></param>
        /// <param name="parameter"></param>
        public IEnumerator SendInfo(string url, WWWForm form, Action<WWWMessage, object> action = null, object parameter = null)
        {
            WWW www = new WWW(url, form);

            yield return www;
            if (www.isDone)
            {
                
                if (action != null)
                {
                    string json = www.text.ToLower().Replace("\"true\"", "true").Replace("\"false\"", "false");
                    action(JsonUtility.FromJson<WWWMessage>(www.text), parameter);
                }

                www.Dispose();
            }
        }
    }

    public class WWWMessage
    {
        public string[] msg;
        public bool success;
    }
}