﻿using UnityEngine;
using System.Collections;
using System;

namespace MapEditor
{

    /// <summary>
    /// 通过 www 加载的资源数据
    /// </summary>
    public class WWWLoad
    {

        static WWWLoad instance;
        public static WWWLoad GetInst()
        {
            if (instance == null)
                instance = new WWWLoad();
            return instance;
        }


        /// <summary>
        /// www 加载数据
        /// </summary>
        /// <param name="url"></param>
        /// <param name="action"></param>
        /// <param name="parameter"></param>
        public IEnumerator LoadServerData(string url, Action<string> action)
        {
            if (string.IsNullOrEmpty(url))
                yield return null;

            //using (WWW www = new WWW(url))
            WWW www = new WWW(url);
            {
                yield return www;

                if (action != null)
                {
                    if (!string.IsNullOrEmpty(www.error))
                        Debug.LogError(" www is error " + www.error + "      " + url);
                    string json = www.text.ToLower().Replace("\"true\"", "true").Replace("\"false\"", "false");
                    action(json);
                }
                www.Dispose();
            }
        }

    }
}


