using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace PatrolPath
{

    public class PatrolPathEditor
    {
        private string patrolPathListTitle = "已存在的巡逻路径";
        private Rect patrolPathListRect = new Rect(2, Screen.height - 400, 300, 440);
        private string patrolPathPropertyTitle = "当前选中的巡逻路径";
        private Rect patrolPathPropertyListRect  = new Rect(Screen.width/2-200,2,400,300);

        public void OnGUI()
        {
            patrolPathListRect = GUI.Window(0, patrolPathListRect, DrawPatrolPathListWindow, patrolPathListTitle);
            patrolPathPropertyListRect = GUI.Window(1, patrolPathPropertyListRect, DrawPatrolPathPropertyWindow, patrolPathPropertyTitle);

        }

        private void DrawPatrolPathPropertyWindow(int id)
        {


            GUI.DragWindow();
        }

        private void DrawPatrolPathListWindow(int id)
        {


            GUI.DragWindow();
        }
    }


}