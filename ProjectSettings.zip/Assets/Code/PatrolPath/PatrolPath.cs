using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PatrolPath
{
    public class PatrolPath
    {
        public PatrolPathInfo data;

        public PathPoint[] points;
    }

    public class PatrolPathInfo
    {
        public int id;

        public int scene_id;
        /// <summary>
        /// 巡逻方式
        /// </summary>
        public int patrol_type;
        /// <summary>
        /// 巡逻路径点数据，json数组
        /// </summary>
        public string patrol_data;
        /// <summary>
        /// 巡逻时间
        /// </summary>
        public int patrol_rest_time;
    }
}
