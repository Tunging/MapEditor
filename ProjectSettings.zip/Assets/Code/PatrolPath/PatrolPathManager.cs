using MapEditor;
using PatrolPath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class PatrolPathManager
{
    private static PatrolPathManager instance;
    public static PatrolPathManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new PatrolPathManager();
            }
            return instance;
        }
    }

    private PatrolPathManager()
    {
        editor = new PatrolPathEditor();
    }

    private PatrolPathEditor editor;
    private bool enable;
    public bool Enable
    {
        get;set;
    }
    public void OnGUI()
    {
        if (!Enable) return;

        editor.OnGUI();
    }

    internal void Show()
    {
        Enable = true;

        RequestPatrolServerData();
    }

    private void RequestPatrolServerData()
    {
        SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(Config.PATROL_LIST,OnGetPatrolListData));
    }

    private void OnGetPatrolListData(string text)
    {
        if (string.IsNullOrEmpty(text))
        {

            Debug.Log(text);
        }
    }
}
