using NavMesh.Camera;
using System.Collections.Generic;
using Tgame.Game.Table;
using TransformGizmos;
using UnityEngine;
using ZLib;
using ZTool.Res;
using ZTool.Table;

namespace MapEditor
{

    /// <summary>
    /// Sprite 管理
    /// </summary>
    public class SpriteManager
    {

        #region 单例

        static SpriteManager instance;
        public static SpriteManager GetInst()
        {
            if (instance == null)
            {
                instance = new SpriteManager();
                Tick.AddLateUpdate(instance.Update);
            }

            return instance;
        }

        #endregion

        #region Scene Npc

        #region 资源加载

        //当前鼠标操作的 Sprite
        Sprite currSprite = null;
        GameObject currSpriteObj = null;
        Transform tran = null;

        //存储sprite 数据
        SpriteInfo data = null;

        //是否正在加载模型数据
        public bool IsLoadModel { get; private set; }

        /// <summary>
        /// 当前是否正在显示 Sprite
        /// </summary>
        /// <returns></returns>
        public bool ShowSprite()
        {
            return currSpriteObj != null || IsLoadModel;
        }

        /// <summary>
        /// 卸载正在显示的Sprite数据
        /// </summary>
        public void UnLoadShowSprite()
        {
            Clear();
        }

        /// <summary>
        /// 加载 Model
        /// </summary>
        /// <param name="url"></param>
        public void LoadModel(int npcId, int modelId, string url, string name)
        {
            //url is null
            if (string.IsNullOrEmpty(url))
                return;

            if (IsLoadModel)
            {
                GUINotice.Show("<color=red> 当前正在加载模型资源数据 </color> \n" + data.name_i18n+ " : " + data.url);
                return;
            }

            IsLoadModel = true;

            //清理当前存储的数据信息
            Clear();

            data = new SpriteInfo();
            data.SetInfo(npcId, modelId, url, name);

            //开始加载资源数据
            ResourcesLoad.instance.LoadAssetBundle(url, LoadModelOver);
        }

        /// <summary>
        /// 模型加载完成
        /// </summary>
        /// <param name="url"></param>
        /// <param name="obj"></param>
        /// <param name="parameter"></param>
        void LoadModelOver(string url, UnityEngine.Object obj, object parameter)
        {

            IsLoadModel = false;
            if (string.IsNullOrEmpty(url) || obj == null)
            {
                Debug.LogError("找不到模型资源数据");
                GUINotice.Show("<color=red> 找不到模型资源数据 </color>");
                return;
            }

            GameObject go = obj as GameObject;
            if (go != null)
            {
                Sprite sprite = go.AddComponent<Sprite>();
                sprite.SetInitInfo(data);

                //设置当前的资源数据信息
                currSprite = sprite;
                currSpriteObj = go;
                tran = go.transform;

                GameLayer.GetInst().SetLayer(go.transform, SpriteLayerEnum.Sprite, true);

                //放在 sprite 视图下面
                //UGEUtils.SetParent(go.transform, tran);
            }
        }

        /// <summary>
        /// 清理数据信息
        /// </summary>
        void Clear()
        {
            if (currSpriteObj != null)
            {
                GameObject.Destroy(currSpriteObj);
                currSpriteObj = null;
                tran = null;
            }

            if (data != null)
                data = null;

            IsLoadModel = false;
        }

        #endregion

        #region 数据更新

        //位置坐标
        Vector3 pos;

        //数据更新
        public void Update()
        {
            pos = SceneManager.MousePos;

            if (tran == null)
                return;

            //更新位置坐标
            tran.position = pos;

        }

        #endregion

        #region 创建新的模型,用于显示不同的数据编辑

        //资源存储位置类型
        enum SpriteStorageEnum
        {
            NEW_CREATE,                                         //本地新建
            SERVER,                                             //服务器已经存在
        }

        //存储 新创建的 sprite数据列表
        List<Sprite> newSpriteList = new List<Sprite>();

        //存储在服务器上的 资源数据列表
        List<Sprite> serverSpriteList = new List<Sprite>();

        //删除的资源数据id
        List<int> removeSpriteIdList = new List<int>();

        /// <summary>
        /// 创建新的 数据
        /// </summary>
        public Sprite CreateNewSprite()
        {
            var go = new GameObject();
            var sprite = go.AddComponent<Sprite>();
            sprite.transform.parent = UGE.trmContainers.sprsContainer;

            SpriteInfo d = new SpriteInfo();
            //d.id = newSpriteList.Count;//手动写入id 创建新的模型时 加入 防止冲突数据库内容
            d.npc_id = data.npc_id;
            d.cached_npc_id = data.npc_id;
            d.name = data.name;
            d.name_i18n = data.name_i18n;
            d.url = data.url;
            d.pos = pos;
            //设置默认朝向
            //d.dx = 0;
            //d.dy = 1;
            d.angle = 0;

            d.sprite = sprite;
            d.scene_id = SceneManager.GetInst().CurrScene.id;
            sprite.Startup(d);

            newSpriteList.Add(sprite);

            return sprite;
        }

        /// <summary>
        /// 创建服务器 上存储的数据
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public Sprite CreateServerSprite(SpriteInfo info)
        {
            if (info == null)
                return null;

            var go = new GameObject();
            var sprite = go.AddComponent<Sprite>();
            sprite.transform.parent = UGE.trmContainers.sprsContainer;

            //设置位置
            info.pos = new Vector3(info.x, info.y, info.z);

            //获取模型数据
            NpcModel model = null;

            Table_Npc tableSceneNpc = Table_Npc.GetPrimary(info.npc_id);
            if (tableSceneNpc == null)
            {
                Debug.LogError("table npc is null ,id = " + info.npc_id);
                return null;
            }
            model = NpcManager.Instance.GetNpcModel(tableSceneNpc.id);

            if (model == null)
                return null;

            //设置模型数据
            info.url = model.path;
            info.resources_id = model.resources_id;
            info.sprite = sprite;

            //设置和服务器数据相同
            info.isSynchronizationServer = true;
            //设置为服务器数据标识
            info.isServer = true;

            sprite.Startup(info);

            serverSpriteList.Add(sprite);

            return sprite;
        }

        public Sprite UpdateSpriteShow(SpriteInfo info)
        {
            if (info.sprite != null && info.sprite.gameObject != null)
            {
                GameObject.Destroy(info.sprite.gameObject);
            }

            if (info == null)
                return null;

            var go = new GameObject();
            var sprite = go.AddComponent<Sprite>();
            sprite.transform.parent = UGE.trmContainers.sprsContainer;

            //设置位置
            info.pos = new Vector3(info.x, info.y, info.z);

            //获取模型数据
            NpcModel model = null;

            model = NpcManager.Instance.GetNpcModel(info.npc_id);

            if (model == null)
            {
                GUINotice.Show(string.Format("不存在 id 为 {0} 的npc模板", info.npc_id));
                return null;
            }

            //设置模型数据
            info.url = model.path;
            info.resources_id = model.resources_id;
            info.sprite = sprite;

            //设置和服务器数据相同
            info.isSynchronizationServer = true;
            //设置为服务器数据标识
            info.isServer = true;

            sprite.Startup(info);

            if (serverSpriteList.Exists(s => s.data.guid == sprite.data.guid))
            {
                serverSpriteList.RemoveAll(s => s.data.guid == sprite.data.guid);
            }
            serverSpriteList.Add(sprite);
            return sprite;
        }

        #region 向服务器发送数据更新

        /// <summary>
        /// 发送新建数据
        /// </summary>
        public void SendNewCreateInfo()
        {
            //没有数据，那么直接返回
            if (newSpriteList == null || newSpriteList.Count == 0)
                return;

            for (int i = 0; i < newSpriteList.Count; i++)
            {
                //如果已经和服务器数据同步一样，那么就不处理
                if (newSpriteList[i] == null
                        || newSpriteList[i].data == null
                        || newSpriteList[i].data.isSynchronizationServer)
                    continue;

                SpriteInfo info = newSpriteList[i].data;

                if (info.guid == 0)
                {
                    //还是初始数据，需要进行手动设置
                    Debug.LogError(" sprite id is 0");

                    GUINotice.Show("<color=red> sprite id 为初始数据, 请修改后设置 </color>");

                    NpcManager.Instance.SetShowEditorSprite(info);
                    return;
                }

                if (serverSpriteList.Exists(s => s.data.guid == info.guid))
                {
                    Debug.LogError(" sprite id 重复");

                    GUINotice.Show("<color=red> sprite id 已存在，清检查后重新指定 id </color>");

                    NpcManager.Instance.SetShowEditorSprite(info);
                    return;
                }

                

                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.NPC_INSERT, info.Serialize(), SendNewCreateInfoOver, info.guid));
            }
        }

        /// <summary>
        /// 发送新建数据完成
        /// </summary>
        /// <param name="parameter"></param>
        void SendNewCreateInfoOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {
                //数据上传成功
                for (int i = 0; i < newSpriteList.Count; i++)
                {
                    if (newSpriteList[i] == null
                        || newSpriteList[i].data == null
                        || newSpriteList[i].data.isSynchronizationServer)
                        continue;

                    if (newSpriteList[i].data.guid == id)
                    {
                        //设置数据已经和服务器同步
                        newSpriteList[i].data.isSynchronizationServer = true;
                    }
                }
            }
            else
            {
                //数据上传失败
                //数据删除失败
                Debug.LogError("数据id 为 " + id + " 添加失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        /// <summary>
        /// 发送修改数据
        /// </summary>
        public void SendModifyInfo()
        {
            //没有数据，那么直接返回
            if (serverSpriteList == null || serverSpriteList.Count == 0)
                return;

            for (int i = 0; i < serverSpriteList.Count; i++)
            {
                //如果已经和服务器数据同步一样，那么就不处理
                if (serverSpriteList[i] == null
                        || serverSpriteList[i].data == null
                        || serverSpriteList[i].data.isSynchronizationServer)
                    continue;

                SpriteInfo info = serverSpriteList[i].data;

                
                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.NPC_UPDATE, info.Serialize(), SendModifyInfoOver, info.guid));

            }
        }

        /// <summary>
        /// 发送修改数据完成
        /// </summary>
        /// <param name="parameter"></param>
        void SendModifyInfoOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {
                //数据上传成功
                for (int i = 0; i < serverSpriteList.Count; i++)
                {
                    if (serverSpriteList[i] == null
                        || serverSpriteList[i].data == null
                        || serverSpriteList[i].data.isSynchronizationServer)
                        continue;

                    if (serverSpriteList[i].data.guid == id)
                    {
                        //设置数据已经和服务器同步
                        serverSpriteList[i].data.isSynchronizationServer = true;
                    }
                }
            }
            else
            {
                //数据上传失败
                //数据删除失败
                Debug.LogError("数据id 为 " + id + " 添加失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        /// <summary>
        /// 发送移除数据
        /// </summary>
        public void SendRemoveSpriteInfo()
        {
            //没有数据，那么直接返回
            if (removeSpriteIdList == null || removeSpriteIdList.Count == 0)
                return;

            for (int i = 0; i < removeSpriteIdList.Count; i++)
            {
                WWWForm form = new WWWForm();
                form.AddField("guid", removeSpriteIdList[i]);

                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.NPC_DELETE, form, SendRemoveSpriteInfoOver, removeSpriteIdList[i]));
            }
        }

        /// <summary>
        /// 发送移除数据信息完成
        /// </summary>
        /// <param name="parameter"></param>
        void SendRemoveSpriteInfoOver(WWWMessage error, object parameter)
        {
            if (parameter == null
                || removeSpriteIdList == null
                || removeSpriteIdList.Count == 0)
                return;

            int id = (int)parameter;

            if (error.success)
            {
                //数据删除成功
                for (int i = 0; i < removeSpriteIdList.Count; i++)
                {
                    if (removeSpriteIdList[i] == id)
                    {
                        removeSpriteIdList.RemoveAt(i);
                        return;
                    }
                }
            }
            else
            {
                //数据删除失败
                Debug.LogError("数据id 为 " + id + " 数据删除失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        #endregion


        #endregion

        #region 绘制当前场景中创建的 npc

        //位置控制
        Rect spriteListRect = new Rect(Screen.width - 300, 300, 300, Screen.height - 300 - 20);
        Vector2 spriteListScrollPosi = new Vector2();


        /// <summary>
        /// 绘制当前场景中已经存在的 npc
        /// </summary>
        public void SpriteOnGUI()
        {
            spriteListRect = GUI.Window(5, spriteListRect, DrawSpriteList, " NPC 列表 ");
        }

        /// <summary>
        /// 绘制 sprite id
        /// </summary>
        /// <param name="id"></param>
        void DrawSpriteList(int id)
        {
            if (newSpriteList.Count == 0 && serverSpriteList.Count == 0)
                return;

            spriteListScrollPosi = GUILayout.BeginScrollView(spriteListScrollPosi);

            int count = newSpriteList.Count + serverSpriteList.Count;
            Sprite sprite = null;
            for (int i = 0; i < count; i++)
            {
                if (i < newSpriteList.Count)
                    sprite = newSpriteList[i];
                else
                    sprite = serverSpriteList[i - newSpriteList.Count];

                if (sprite == null || sprite.data == null)
                    continue;

                //设置文字颜色
                string color = "<color=green>";
                if (!sprite.data.isSynchronizationServer)
                    color = "<color=red>";

                //点击某一个sprite时就自动选中相应的 sprite
                if (GUILayout.Button(color + sprite.data.guid + "_" + sprite.data.name_i18n + "</color>" + "  组：" + sprite.data.group_id))
                {
                    CameraMove.GetInst().CameraLookAtTarget(sprite.gameObject);

                    NpcManager.Instance.SetShowEditorSprite(sprite.data);

                    TransformGizmo.GetInst().SetTraget(sprite.transform);
                }
            }

            GUILayout.EndScrollView();
        }

        #endregion

        #endregion



        #region Path Info

        //本地创建 path 列表数据
        List<PathInfo> newCreatePathList = new List<PathInfo>();

        //服务器存储 path 列表数据
        List<PathInfo> serverPathList = new List<PathInfo>();

        //存储显示服务器 path 数据 id
        List<int> deleteServerPathList = new List<int>();

        /// <summary>
        /// 创建新的 path信息
        /// </summary>
        public PathInfo CreateNewPathInfo()
        {
            PathInfo pi = new PathInfo();
            pi.scene_id = SceneManager.GetInst().CurrScene.id;

            newCreatePathList.Add(pi);

            return pi;
        }

        /// <summary>
        /// 设置服务器存储的数据列表信息
        /// </summary>
        /// <param name="list"></param>
        public void SetServerPathInfo(List<PathInfo> list)
        {
            serverPathList = list;
        }

        /// <summary>
        /// 创建 new point
        /// </summary>
        /// <returns></returns>
        public SpritePoint CreateNewPoint(PathInfo info)
        {
            var go = new GameObject();
            var sprite = go.AddComponent<SpritePoint>();
            sprite.transform.parent = UGE.trmContainers.sprsContainer;

            //创建点信息数据
            PointInfo pi = new PointInfo();
            pi.pos = pos;

            //添加点数据
            info.AddPoint(sprite);

            //开始创建数据
            sprite.Startup(info, pi);

            return sprite;
        }

        /// <summary>
        /// 创建 server point 数据
        /// 服务器数据就是创建一整条
        /// </summary>
        /// <param name="info"></param>
        public void CreateServerPoint(PathInfo info)
        {
            if (info == null || info.pointsList.Count == 0)
                return;

            //设置和服务器数据相同
            info.isSynchronizationServer = true;
            info.isServer = true;
            for (int i = 0; i < info.pointsList.Count; i++)
            {
                if (info.pointsList[i] != null)
                {
                    var go = new GameObject();
                    var sprite = go.AddComponent<SpritePoint>();
                    sprite.transform.parent = UGE.trmContainers.sprsContainer;

                    //创建点信息数据
                    PointInfo pi = info.pointsList[i];

                    //添加点数据
                    info.AddPoint(sprite);

                    //开始创建数据
                    sprite.Startup(info, pi);
                }
            }
        }


        /// <summary>
        /// 移除 Path 数据
        /// </summary>
        /// <param name="path"></param>
        public void RemovePathInfo(PathInfo path)
        {
            if (path == null)
                return;

            for (int i = 0; i < newCreatePathList.Count; i++)
            {
                if (newCreatePathList[i] != null && newCreatePathList[i] == path)
                {
                    path.ClearPoints();
                    newCreatePathList.Remove(path);
                    return;
                }
            }

            for (int i = 0; i < serverPathList.Count; i++)
            {
                if (serverPathList[i] != null && serverPathList[i] == path)
                {
                    if (!deleteServerPathList.Contains(path.id))
                        deleteServerPathList.Add(path.id);

                    path.ClearPoints();
                    serverPathList.Remove(path);
                    return;
                }
            }
        }

        #region 上传服务器

        /// <summary>
        /// 向服务器中插入新的 Path数据信息
        /// </summary>
        public void SendInsertNewPathInfo()
        {
            if (newCreatePathList == null || newCreatePathList.Count == 0)
                return;

            for (int i = 0; i < newCreatePathList.Count; i++)
            {
                PathInfo info = newCreatePathList[i];
                if (info != null)
                {
                    if (info.id == 0)
                    {
                        //还是初始数据，需要进行手动设置
                        Debug.LogError(" Path id is 0");

                        GUINotice.Show("<color=red> path id 为初始数据, 请修改后设置 </color>");
                        PathManager.GetInst().SetShowPathInfo(info);
                        return;
                    }

                    //位置坐标数据转换
                    info.PointsToString();


                    SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.CAMERA_PATH_INSERT, info.Serialize(), OnSendInsertNewPathOver, info.id));
                }
            }
        }

        /// <summary>
        /// 发送插入新点数据完成
        /// </summary>
        /// <param name="error"></param>
        /// <param name="parameter"></param>
        void OnSendInsertNewPathOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {
                //数据上传成功
                for (int i = 0; i < newCreatePathList.Count; i++)
                {
                    if (newCreatePathList[i] == null
                        || newCreatePathList[i].isSynchronizationServer)
                        continue;

                    if (newCreatePathList[i].id == id)
                    {
                        //设置数据已经和服务器同步
                        newCreatePathList[i].isSynchronizationServer = true;

                    }
                }
            }
            else
            {
                //数据上传失败
                Debug.LogError("数据id 为 " + id + " 添加失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        /// <summary>
        /// 向服务器中插入新的 Path数据信息
        /// </summary>
        public void SendUpdatePathInfo()
        {
            if (serverPathList == null || serverPathList.Count == 0)
                return;

            for (int i = 0; i < serverPathList.Count; i++)
            {
                PathInfo info = serverPathList[i];
                if (info != null && !info.isSynchronizationServer)
                {

                    //位置坐标数据转换
                    info.PointsToString();

                    SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.CAMERA_PATH_UPDATE, info.Serialize(), OnSendUpdatePathOver, info.id));
                }
            }
        }

        /// <summary>
        /// 发送插入新点数据完成
        /// </summary>
        /// <param name="error"></param>
        /// <param name="parameter"></param>
        void OnSendUpdatePathOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {
                //数据上传成功
                for (int i = 0; i < serverPathList.Count; i++)
                {
                    if (serverPathList[i] == null
                        || serverPathList[i].isSynchronizationServer)
                        continue;

                    if (serverPathList[i].id == id)
                    {
                        //设置数据已经和服务器同步
                        serverPathList[i].isSynchronizationServer = true;
                    }
                }
            }
            else
            {
                //数据上传失败
                Debug.LogError("数据id 为 " + id + " 添加失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        /// <summary>
        /// 发送移除数据
        /// </summary>
        public void SendRemovePathInfo()
        {
            //没有数据，那么直接返回
            if (deleteServerPathList == null || deleteServerPathList.Count == 0)
                return;

            for (int i = 0; i < deleteServerPathList.Count; i++)
            {
                WWWForm form = new WWWForm();
                form.AddField("id", deleteServerPathList[i]);

                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.CAMERA_PATH_DELETE, form, SendRemovePathInfoOver, deleteServerPathList[i]));
            }
        }

        /// <summary>
        /// 发送移除数据信息完成
        /// </summary>
        /// <param name="parameter"></param>
        void SendRemovePathInfoOver(WWWMessage error, object parameter)
        {
            if (parameter == null
                || deleteServerPathList == null
                || deleteServerPathList.Count == 0)
                return;

            int id = (int)parameter;

            if (error.success)
            {
                //数据删除成功
                for (int i = 0; i < deleteServerPathList.Count; i++)
                {
                    if (deleteServerPathList[i] == id)
                    {
                        deleteServerPathList.RemoveAt(i);
                        return;
                    }
                }
            }
            else
            {
                //数据删除失败
                Debug.LogError("数据id 为 " + id + " 数据删除失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        #endregion

        #region 绘制当前场景中创建的 npc

        //位置控制
        Rect pathListRect = new Rect(0, 300, 300, Screen.height - 300 - 20);
        Vector2 pathListScrollPosi = new Vector2();


        /// <summary>
        /// 绘制当前场景中已经存在的 npc
        /// </summary>
        public void PathOnGUI()
        {
            pathListRect = GUI.Window(5, pathListRect, DrawPathList, " Path 列表 ");
        }

        /// <summary>
        /// 绘制 sprite id
        /// </summary>
        /// <param name="id"></param>
        void DrawPathList(int id)
        {

            if (newCreatePathList.Count == 0 && serverPathList.Count == 0)
                return;

            pathListScrollPosi = GUILayout.BeginScrollView(pathListScrollPosi);

            int count = newCreatePathList.Count + serverPathList.Count;

            PathInfo info = null;
            for (int i = 0; i < count; i++)
            {
                if (i < newCreatePathList.Count)
                    info = newCreatePathList[i];
                else
                    info = serverPathList[i - newCreatePathList.Count];

                if (info == null)
                    continue;

                //设置文字颜色
                string color = "<color=green>";
                if (!info.isSynchronizationServer)
                    color = "<color=red>";

                //点击选中某一个 path 时就自动对应找到相应的点数据
                if (GUILayout.Button(color + info.id + "_" + info.name + "</color>"))
                {
                    //找到当前选中 path 数据信息，默认找到第一个点数据
                    SpritePoint sp = info.spritePointsList[0];
                    if (sp != null)
                    {
                        CameraMove.GetInst().CameraLookAtTarget(sp.gameObject);
                        PathManager.GetInst().SetShowPathInfo(sp.CurrPathInfo);
                        TransformGizmo.GetInst().SetTraget(sp.transform);
                    }
                }

            }

            GUILayout.EndScrollView();
        }

        #endregion

        #endregion


        #region 获取一个位置上的sprite

        /// <summary>
        /// 通过 tran 获取一个位置上的 sprite
        /// </summary>
        /// <param name="tran"></param>
        /// <returns></returns>
        public TActor GetSpriteFromTran(Transform tran)
        {
            if (tran == null)
                return null;

            TActor actor = tran.GetComponentInParent<TActor>();
            return actor;

            //Sprite s = tran.GetComponentInParent<Sprite>();
            //return s;
        }

        /// <summary>
        /// 查找某一个位置上的sprite
        /// </summary>
        /// <returns></returns>
        public Sprite GetSpriteFromPos()
        {
            if (newSpriteList.Count == 0 && serverSpriteList.Count == 0)
                return null;

            Sprite s = null;

            //如果鼠标选中了 sprite，那么优先处理 鼠标选中的 sprite
            if (SceneManager.MouseTran != null)
            {
                TActor actor = GetSpriteFromTran(SceneManager.MouseTran);
                if (actor != null && actor is Sprite)
                {
                    s = actor as Sprite;
                    return s;
                }
            }

            //检测本地新建数据
            for (int i = 0; i < newSpriteList.Count; i++)
            {
                s = newSpriteList[i];
                if (s != null)
                {
                    if (Vector3.Distance(s.data.pos, pos) <= Config.MAX_FIND_SPRITE_DIS)
                        return s;
                }
            }

            //检测服务器上已经存在的数据
            for (int i = 0; i < serverSpriteList.Count; i++)
            {
                s = serverSpriteList[i];
                if (s != null)
                {
                    if (Vector3.Distance(s.data.pos, pos) <= Config.MAX_FIND_SPRITE_DIS)
                        return s;
                }
            }

            return null;
        }

        ///// <summary>
        ///// 从一个位置移动 sprite
        ///// </summary>
        //public void RemoveSpriteFromPos()
        //{
        //    if (newSpriteList.Count == 0 && serverSpriteList.Count == 0)
        //        return;

        //    Sprite s = null;

        //    //检测本地创建数据
        //    for (int i = 0; i < newSpriteList.Count; i++)
        //    {
        //        s = newSpriteList[i];
        //        if (s != null)
        //        {
        //            if (Vector3.Distance(s.data.pos, pos) <= Config.MAX_FIND_SPRITE_DIS)
        //            {
        //                newSpriteList.RemoveAt(i);
        //                GameObject.Destroy(s.gameObject);
        //                return;
        //            }
        //        }
        //    }

        //    //检测服务器已经存在的数据
        //    for (int i = 0; i < serverSpriteList.Count; i++)
        //    {
        //        s = serverSpriteList[i];
        //        if (s != null)
        //        {
        //            if (Vector3.Distance(s.data.pos, pos) <= Config.MAX_FIND_SPRITE_DIS)
        //            {
        //                //添加到移除数据列表
        //                removeSpriteIdList.Add(s.data.id);

        //                //数据移除
        //                serverSpriteList.RemoveAt(i);
        //                GameObject.Destroy(s.gameObject);
        //                return;
        //            }
        //        }
        //    }
        //}

        /// <summary>
        /// 从一个列表中移除一个sprite
        /// </summary>
        /// <param name="s"></param>
        public void RemoveSpriteFromList(Sprite s)
        {
            if (s == null)
                return;

            Sprite ss;

            //检测本地创建数据
            for (int i = 0; i < newSpriteList.Count; i++)
            {
                ss = newSpriteList[i];
                if (ss != null && ss == s)
                {
                    newSpriteList.RemoveAt(i);
                    GameObject.Destroy(s.gameObject);
                    return;
                }
            }

            //检测服务器已经存在的数据
            for (int i = 0; i < serverSpriteList.Count; i++)
            {
                ss = serverSpriteList[i];
                if (ss != null && ss == s)
                {
                    //添加到移除数据列表
                    removeSpriteIdList.Add(s.data.guid);

                    //数据移除
                    serverSpriteList.RemoveAt(i);
                    GameObject.Destroy(s.gameObject);
                    return;
                }
            }
        }

        #endregion

        #region 设置 TActor 编辑

        /// <summary>
        /// 设置显示的 actor 数据编辑
        /// </summary>
        /// <param name="actor"></param>
        public void SetShowActorEditor(TActor actor)
        {
            if (actor == null)
                return;

            if (actor is Sprite)
            {
                Sprite s = actor as Sprite;

                NpcManager.Instance.SetShowEditorSprite(s.data);

            }
            else if (actor is SpritePoint)
            {
                SpritePoint sp = actor as SpritePoint;
                PathManager.GetInst().SetShowPathInfo(sp.CurrPathInfo);
            }
            else if (actor is SpritePatrolPoint)
            {
                SpritePatrolPoint spp = actor as SpritePatrolPoint;

            }
        }

        #endregion

        public void Reset()
        {
            for (int i = 0; i < serverSpriteList.Count; i++)
            {
                var item = serverSpriteList[i];
                if (item != null)
                {
                    GameObject.Destroy(item.gameObject);
                }
            }
            serverSpriteList.Clear();

            for (int i = 0; i < newSpriteList.Count; i++)
            {
                var item = newSpriteList[i];
                if (item != null)
                {
                    GameObject.Destroy(item.gameObject);
                }
            }
            newSpriteList.Clear();
        }
    }
}
