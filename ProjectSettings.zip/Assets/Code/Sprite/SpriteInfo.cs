using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace MapEditor
{
    /// <summary>
    /// 角色数据
    /// </summary>
    public class SpriteInfo
    {
        //id
        //新建数据时需要自己手动指定
        //在服务器上已经存在的数据 不能修改id 
        public int guid;

        //资源名字
        public string name;
        public string name_i18n;

        // scene id
        public int scene_id;
        public int npc_id;

        //模型id
        public int resources_id;
        /// <summary>
        /// 编组id
        /// </summary>
        public int group_id = 1;
        //是否隐藏，隐藏时只能通过AI刷新
        public bool is_hidden;
        //pos
        public Vector3 pos;
        public float x;
        public float y;
        public float z;
        //朝向角度(z偏x的度数)
        public float angle;
        //巡逻
        //巡逻方式
        public int patrol_type = 0;
        //巡逻数据
        public string patrol_data = "";
        public Vector3[] patrol_dataArr;
        //巡逻点数据列表
        public List<SpritePatrolPoint> spritePatrolPointsList = new List<SpritePatrolPoint>();
        public List<Vector3> patrolPosList = new List<Vector3>();
        //巡逻时休息时间（ms）
        public int patrol_rest_time;

        //野外：复活时间间隔（ms）
        public int relive_interval;

        //延时进入场景时间
        public int enter_scene_delay_time=0;

        public int cached_npc_id;


        //资源地址
        public string url;




        #region npc
        public int level;
        public int model_id;
        public int header_icon_id;
        public int function_id;
        public int camp_id;
        public float model_scale;
        public int effect_id;
        #endregion


        //朝向
        //public float dx;
        //public float dy;
        //public float dz;



        //副本：在第几波刷新
        public int refresh_sequence;
        //副本：刷新延迟时间
        public int refresh_delay_time;
        //副本：是否影响下一波刷新
        public bool is_join_refresh;


        //SpriteInfo 关联的 sprite
        public Sprite sprite;

        //是否和服务器数据同步
        public bool isSynchronizationServer = false;
        //是否为服务器数据（服务器上是否有此条数据）
        public bool isServer = false;
        //是否已经同步 巡逻点数据
        public bool isSyncPatrolPoints = false;

        /// <summary>
        /// 设置数据信息
        /// </summary>
        /// <param name="npcid"></param>
        /// <param name="modelId"></param>
        /// <param name="url"></param>
        public void SetInfo(int npcid, int modelId, string url, string name)
        {
            this.npc_id = npcid;
            this.cached_npc_id = npcid;
            this.resources_id = modelId;
            this.url = url;
            this.name = name;
            this.name_i18n = name;
        }



        #region 巡逻数据处理

        /// <summary>
        /// 添加巡逻点数据
        /// </summary>
        /// <param name="pos"></param>
        public void AddPatrolPos(SpritePatrolPoint sprite)
        {
            spritePatrolPointsList.Add(sprite);
        }

        /// <summary>
        /// 移除一个巡逻点数据
        /// </summary>
        /// <param name="id"></param>
        public void RemovePatrolPos(int id)
        {
            if (id >= 0 && spritePatrolPointsList.Count > id)
            {
                SpritePatrolPoint spp = spritePatrolPointsList[id];
                spritePatrolPointsList.RemoveAt(id);
                RemoveSpritePatrolPoint(spp);
            }
        }

        /// <summary>
        /// 移除一个巡逻点数据
        /// </summary>
        /// <param name="sprite"></param>
        public void RemovePatrolPos(SpritePatrolPoint sprite)
        {
            if (spritePatrolPointsList == null || spritePatrolPointsList.Count == 0)
                return;

            for (int i = 0; i < spritePatrolPointsList.Count; i++)
            {
                if (spritePatrolPointsList[i] != null && spritePatrolPointsList[i] == sprite)
                {
                    spritePatrolPointsList.Remove(sprite);
                    RemoveSpritePatrolPoint(sprite);
                    return;
                }
            }
        }

        /// <summary>
        /// 移除 SpritePatrolPoint 数据
        /// </summary>
        /// <param name="sprite"></param>
        void RemoveSpritePatrolPoint(SpritePatrolPoint sprite)
        {
            if (sprite != null)
            {
                GameObject.Destroy(sprite.gameObject);
                sprite = null;
            }
        }

        /// <summary>
        /// 显示或者隐藏所有的轨迹点数据
        /// </summary>
        public void ShowOrHideAllPatrolPos(bool show)
        {
            if (spritePatrolPointsList == null || spritePatrolPointsList.Count == 0)
                return;

            for (int i = 0; i < spritePatrolPointsList.Count; i++)
            {
                if (spritePatrolPointsList[i] != null && spritePatrolPointsList[i].gameObject.activeSelf != show)
                {
                    spritePatrolPointsList[i].gameObject.SetActive(show);
                }
            }
        }

        /// <summary>
        /// 获取当前巡逻点 数组
        /// </summary>
        /// <returns></returns>
        public Vector3[] GetPatrolPosArr()
        {
            if (spritePatrolPointsList == null || spritePatrolPointsList.Count == 0)
            {
                return null;
            }

            List<Vector3> list = new List<Vector3>();
            for (int i = 0; i < spritePatrolPointsList.Count; i++)
            {
                if (spritePatrolPointsList[i] != null)
                    list.Add(spritePatrolPointsList[i].transform.position);
            }

            return list.ToArray();
        }

        /// <summary>
        /// 巡逻点数据转换成 string数据
        /// </summary>
        public void PatrolPosToString()
        {
            if (spritePatrolPointsList == null || spritePatrolPointsList.Count == 0)
            {
                patrol_data = "";
                return;
            }

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < spritePatrolPointsList.Count; i++)
            {
                if (spritePatrolPointsList[i] != null)
                {
                    //坐标位置转换成 json数据
                    Vector3 pos = spritePatrolPointsList[i].transform.position;
                    pos.x = GameUtils.Round(pos.x, 2);
                    pos.y = GameUtils.Round(pos.y, 2);
                    pos.z = GameUtils.Round(pos.z, 2);

                    sb.Append(JsonUtility.ToJson(pos));
                    if (i < spritePatrolPointsList.Count - 1)
                        sb.Append('_');
                }
            }

            patrol_data = sb.ToString();
        }

        /// <summary>
        /// string 转换成 PatrolPos数据
        /// </summary>
        public void StringToPatrolPos()
        {
            if (string.IsNullOrEmpty(patrol_data))
                return;

            //通过 \n 对数据进行切割
            string[] strs = patrol_data.Split('_');
            patrolPosList.Clear();
            for (int i = 0; i < strs.Length; i++)
            {
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                Vector3 pos = JsonUtility.FromJson<Vector3>(strs[i]);

                patrolPosList.Add(pos);
            }

            isSyncPatrolPoints = true;
            for (int i = 0; i < spritePatrolPointsList.Count; i++)
            {
                if (spritePatrolPointsList[i] != null)
                {
                    RemoveSpritePatrolPoint(spritePatrolPointsList[i]);
                }
            }

            spritePatrolPointsList.Clear();
        }

        #endregion

        public WWWForm Serialize()
        {

            WWWForm form = new WWWForm();

            form.AddField("guid", this.guid);
            form.AddField("name", this.name);
            form.AddField("name_i18n", this.name_i18n);
            form.AddField("scene_id", this.scene_id);
            form.AddField("npc_id", this.npc_id);
            form.AddField("is_hidden", GameUtils.BoolToString(this.is_hidden));
            form.AddField("group_id", this.group_id);
            //位置
            form.AddField("x", this.pos.x.ToString("F2"));
            form.AddField("y", this.pos.y.ToString("F2"));
            form.AddField("z", this.pos.z.ToString("F2"));
            //方向
            // form.AddField("dx", this.dx.ToString());
            // form.AddField("dy", this.dy.ToString());
            // form.AddField("dz", this.dz.ToString());
            //旋转角度
            form.AddField("angle", this.angle.ToString("F2"));
            //巡逻
            this.PatrolPosToString();
            form.AddField("patrol_type", this.patrol_type);
            form.AddField("patrol_data", this.patrol_data);
            form.AddField("patrol_rest_time", this.patrol_rest_time);
            //复活
            form.AddField("relive_interval", this.relive_interval);
            form.AddField("is_join_refresh", GameUtils.BoolToString(this.is_join_refresh));

            //延时进入场景时间
            form.AddField("enter_scene_delay_time", this.enter_scene_delay_time);
            return form;
        }
    }
}


