﻿using UnityEngine;
using System.Collections;

namespace MapEditor
{

    /// <summary>
    /// actor 基类
    /// </summary>
    public class TActor : MonoBehaviour
    {

        
    }

}
