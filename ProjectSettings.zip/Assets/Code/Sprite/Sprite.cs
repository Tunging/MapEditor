﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TransformGizmos;
using UnityEngine;
using ZTool.Res;

namespace MapEditor
{

    /// <summary>
    /// Sprite 对象
    /// </summary>
    public class Sprite : TActor
    {
        //数据
        public SpriteInfo data;

        //Tran
        Transform tran;

        Transform spriteTran;

        /// <summary>
        /// 设置初始化数据信息
        /// </summary>
        /// <param name="data"></param>
        public void SetInitInfo(SpriteInfo data)
        {
            this.data = data;
        }

        /// <summary>
        /// 数据启用
        /// </summary>
        /// <param name="data"></param>
        public void Startup(SpriteInfo data)
        {
            gameObject.name = data.refresh_sequence + "_" + data.name_i18n; //"怪名字+xx";//TODO  这个要取成最终名字
            spriteTran = transform;

            this.data = data;
            
            string url = Path.Combine(Config.RES_SERVER_URL,"setup/"+ data.url.ToLower()) +ResConfig.instance.RES_EXTENSION;
            url = url.Replace('\\','/');
            //LoadModel(data.url, OnModelLoadOver, null);
            //StartCoroutine(BeginLoadTask(url, OnModelLoadOver));
            ResourcesLoad.instance.LoadAssetBundle(data.url, OnModelLoadOver);
        }

        //private void LoadModel(string url, System.Action<string, UnityEngine.Object, object> onModelLoadOver, object p)
        //{
        //    StartCoroutine(BeginLoadTask(url,onModelLoadOver));
        //}

        IEnumerator BeginLoadTask(string url,System.Action<string,UnityEngine.Object> callback)
        {
            WWW www = new WWW(url);
            yield return www;
            if (www.isDone && string.IsNullOrEmpty(www.error) && callback!=null)
            {
                var ab = www.assetBundle;
                if (ab!=null)
                {
                    var gos = ab.LoadAllAssets();
                    GameObject go = gos[0] as GameObject;
                    if (go != null)
                    {
                        go = GameObject.Instantiate(go);
                    }
                    callback(url, go);
                }
                ab.Unload(false);
            }
            else
            {
                Debug.Log(url +" load error , msg = " + www.error);
            }
            www.Dispose();
        }

        public static int count = 0;
        /// <summary>
        /// 模型资源数据加载完成
        /// </summary>
        /// <param name="url"></param>
        /// <param name="obj"></param>
        /// <param name="parameter"></param>
        void OnModelLoadOver(string url, UnityEngine.Object obj,object parameter)
        {
            Debug.Log(url);
            if (string.IsNullOrEmpty(url) || obj == null)
            {
                Debug.LogError("模型数据 为null " + url);
                return;
            }
            count++;
            GameObject go = obj as GameObject;
            if (go != null)
            {
                tran = go.transform;

                UGEUtils.SetParent(go.transform, transform);

                //更改图层设置
                GameLayer.GetInst().SetLayer(transform, SpriteLayerEnum.Sprite, true);

                tran.eulerAngles = Vector3.zero;
                float angleline = data.angle;// (float)(Math.Atan2(data.dx, data.dy) * 180 / Mathf.PI);

                Quaternion rotation = Quaternion.Euler(0, angleline, 0);
                transform.eulerAngles = rotation.eulerAngles;

                UpdatePos(data.pos);
            }
        }



        #region 数据更新

        /// <summary>
        /// 数据刷新
        /// </summary>
        void Update()
        {
            if (TransformGizmo.GetInst().IsTarget(spriteTran)
                && TransformGizmo.GetInst().IsChangeTarget())
            {
                //更新方向
                UpdateDir();

                //更新位置
                UpdatePos();
            }
        }

        /// <summary>
        /// 更新方向
        /// </summary>
        void UpdateDir()
        {
            if (data != null)
            {
                //Vector3 v = spriteTran.forward;
                //data.dx = GameUtils.Round(v.x);
                //data.dy = GameUtils.Round(v.y);
                //data.dz = GameUtils.Round(v.z);
                data.angle = spriteTran.rotation.eulerAngles.y;
            }

        }

        /// <summary>
        /// 更新位置
        /// </summary>
        void UpdatePos()
        {
            if (data != null)
            {
                if (data.pos != spriteTran.position)
                    data.pos = spriteTran.position;
            }
        }

        /// <summary>
        /// 更新位置信息
        /// </summary>
        void UpdatePos(Vector3 pos)
        {
            spriteTran.position = pos;
            data.pos = pos;
        }

        #endregion
    }
}
