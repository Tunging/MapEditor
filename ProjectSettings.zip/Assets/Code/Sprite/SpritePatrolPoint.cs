﻿using UnityEngine;
using System.Collections;
using ZTool.Res;
using TransformGizmos;

namespace MapEditor
{
    /// <summary>
    /// 巡逻点
    /// </summary>
    public class SpritePatrolPoint : TActor
    {

        //当前 point 所属的 Sprite 数据
        public SpriteInfo CurrSpriteInfo { get; private set; }

        //Tran
        Transform tran;

        Transform spriteTran;

        /// <summary>
        /// 启用开始加载数据
        /// </summary>
        /// <param name="indexId"></param>
        /// <param name="data"></param>
        public void Startup(SpriteInfo info, Vector3 pos)
        {
            gameObject.name = info.spritePatrolPointsList.Count.ToString();
            spriteTran = transform;

            //存储数据信息
            CurrSpriteInfo = info;

            //更新位置
            UpdatePos(pos);

            //加载资源数据
            ResourcesLoad.instance.LoadAssetBundle(Config.PATH_SHOW_PREFAB, OnModelLoadOver);
        }

        /// <summary>
        /// 资源数据加载完成
        /// </summary>
        /// <param name="path"></param>
        /// <param name="obj"></param>
        /// <param name="parameter"></param>
        void OnModelLoadOver(string url, UnityEngine.Object obj, object parameter)
        {
            if (string.IsNullOrEmpty(url) || obj == null)
            {
                Debug.LogError("模型数据 为null " + url);
                return;
            }

            GameObject go = obj as GameObject;
            if (go != null)
            {
                tran = go.transform;

                UGEUtils.SetParent(go.transform, transform);

                //更改图层设置
//                GameLayer.GetInst().SetLayer(transform, SpriteLayerEnum.Path_Point, true);

                Quaternion rotation = Quaternion.identity;
                tran.eulerAngles = rotation.eulerAngles;
            }
        }

        #region 数据更新
        /// <summary>
        /// 数据刷新
        /// </summary>
        void Update()
        {
            if (TransformGizmo.GetInst().IsTarget(spriteTran)
                && TransformGizmo.GetInst().IsChangeTarget())
            {
                //更新方向
                UpdateDir();

                //更新位置
                UpdatePos();
            }
        }

        /// <summary>
        /// 更新方向
        /// </summary>
        void UpdateDir()
        {
            //if (data != null)
            //{
            //    Vector3 v = spriteTran.forward;
            //    data.dx = GameUtils.Round(v.x);
            //    data.dy = GameUtils.Round(v.y);
            //    data.dz = GameUtils.Round(v.z);
            //}

        }

        /// <summary>
        /// 更新位置
        /// </summary>
        void UpdatePos()
        {
            if (spriteTran != null)
            {
                
            }
        }


        /// <summary>
        /// 更新位置信息
        /// </summary>
        void UpdatePos(Vector3 pos)
        {
            spriteTran.position = pos;
        }

        #endregion
    }

}
