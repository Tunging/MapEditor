﻿/**********************
/* Create by @dongzhiwei
/*
/*
**********************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using ZLib;

namespace InstanceBorder
{
    class InstanceBorderFactory
    {
        private static InstanceBorderFactory instance;
        public static InstanceBorderFactory Instance
        {
            get
            {
                if (instance == null)
                    instance = new InstanceBorderFactory();
                return instance;
            }
        }

        string prefabPath = "InstanceBorderPoint";
        GameObject prefab = null;
        private InstanceBorderFactory()
        {
            prefab = Resources.Load<GameObject>(prefabPath);
            if (prefab == null)
            {
                Debug.LogError("没有找到副本边界点的预设资源");
            }
        }

        List<GameObject> listGameObject = new List<GameObject>();

        private Transform _parent;
        public Transform Parent
        {
            get
            {
                if (_parent == null)
                    _parent = new GameObject("InstanceBorderParent").transform;
                return _parent;
            }
        }

        public GameObject GetPrefab(Vector3 postiion)
        {
            GameObject gameObject = GameObject.Instantiate<GameObject>(prefab);
            if (gameObject != null)
            {
                gameObject.transform.SetParent(Parent);
                gameObject.transform.SetPositionAndRotation(postiion,Quaternion.identity);
                listGameObject.Add(gameObject);
            }

            return gameObject;
        }
    }
}
