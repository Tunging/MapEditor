﻿/**********************
/* Create by @dongzhiwei
/*
/*
**********************/

using MapEditor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace InstanceBorder
{
    class InstanceBorderNet
    {

        public InstanceBorderNet()
        {
            List();
        }
        public void List()
        {
            SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(Config.Instance_list, OnGetListOver));
        }

        private void OnGetListOver(string json)
        {
            if (string.IsNullOrEmpty(json))
            {
                InstanceBorderManager.Instance.DisolveJson(json);
            }
        }


        public void Update() {

            WWWForm form = InstanceBorderManager.Instance.CurInstanceBorder.PackVector3();

            SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.Instance_Update,form,OnUpdateOver,null));
        }

        private void OnUpdateOver(WWWMessage msg, object arg2)
        {
            if (msg.success)
            {
                GUINotice.Show("Update complete");
                Debug.Log("success");
            }
            else
            {
                GUINotice.Show(msg.msg[0]);
            }
        }

        public void Insert()
        {

        }

        public void Delete() { }
    }
}
