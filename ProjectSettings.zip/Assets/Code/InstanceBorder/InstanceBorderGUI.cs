﻿/**********************
/* Create by @dongzhiwei
/*
/*
**********************/

using Assets.Code;
using MapEditor;
using NavMesh.Camera;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace InstanceBorder
{
    class InstanceBorderEditor:BaseEditor
    {
        Rect winRect = new Rect(300, 0, 600, 100);
        Rect controlwindowRect = new Rect(0, 300, 300, Screen.height - 300 - 20);

        Rect listwindowRect = new Rect(Screen.width - 300, 300, 300, Screen.height - 300 - 20);
        Vector2 wallListScrollrect = new Vector2();

        InstanceBorder BD = null;

        #region Control Panel Btn

        string btnstr11 = "内圈点";
        string btnstr12 = ">><color=#ff0000>内圈点</color><<";
        string btnstr1;

        string btnstr21 = "外圈点";
        string btnstr22 = ">><color=#ff0000>外圈点</color><<";
        string btnstr2;
        #endregion

        public InstanceBorderEditor(string moduleName) : base(moduleName)
        {
            btnstr1 = btnstr11;
            btnstr2 = btnstr21;
        }

        #region Control window
        /// <summary>
        /// 操作面板
        /// </summary>
        /// <param name="id"></param>
        protected override void DrawLeftControlPanelWIndow(int id)
        {
            base.DrawLeftControlPanelWIndow(id);
            if (GUILayout.Button(btnstr1))
            {
                btnstr1 = btnstr12;
                btnstr2 = btnstr21;

                CreateNew(BorderType.Inner);
            }

            if (GUILayout.Button(btnstr2))
            {
                btnstr2 = btnstr22;
                btnstr1 = btnstr11;
                CreateNew(BorderType.Outer);
            }
        }
      

        private void CreateNew(BorderType outer)
        {
            InstanceBorderManager.Instance.CreateCursorObj(outer,Vector3.zero);
            //cursorObj = InstanceBorderManager.Instance.CurInstanceBorder.CreateOnePoint(outer, Vector3.zero);
        }
        #endregion

        Vector2 scrollvector2 = new Vector2();
        protected override void DrawRightListWindow(int id)
        {
            base.DrawRightListWindow(id);
            BD = InstanceBorderManager.Instance.CurInstanceBorder;
            if (BD != null)
            {
                GameObject position = null;
                GUILayout.Label("inner");
                for (int i = 0; i < BD.listPoint1.Count; i++)
                {
                    position = BD.listPoint1[i];
                    if (GUILayout.Button(string.Format("Point {0},position : {1}", i, position)))
                    {
                        InstanceBorderManager.Instance.SetFocus(position);
                        CameraMove.GetInst().CameraLookAtTarget(position);
                    }
                }
                GUILayout.Space(20);
                GUILayout.Label("outer");
                for (int i = 0; i < BD.listPoint2.Count; i++)
                {
                    position = BD.listPoint2[i];
                    if (GUILayout.Button(string.Format("Point {0},position : {1}", i, position)))
                    {
                        InstanceBorderManager.Instance.SetFocus(position);
                        CameraMove.GetInst().CameraLookAtTarget(position);
                    }
                }
            }
        }

        protected override void DrawPropertyWindow(int id)
        {
            base.DrawPropertyWindow(id);
            GUIUtils.NumberField("副本id", SceneManager.GetInst().CurrScene.id, false);
            if (GUILayout.Button("提交数据"))
            {
                InstanceBorderManager.Instance.SendUpdateInfo();
            }
            if (InstanceBorderManager.Instance.CurInstanceBorder != null && !InstanceBorderManager.Instance.CurInstanceBorder.is_syncServer)
            {
                GUILayout.Label("<color=#ff0000>数据有变化，需要更新</color>");
            }
        }
      

    }
}
