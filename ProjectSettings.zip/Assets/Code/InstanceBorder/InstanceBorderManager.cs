﻿/**********************
/* Create by @dongzhiwei
/*
/*
**********************/
using TransformGizmos;
using MapEditor;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using NavMesh.Camera;

namespace InstanceBorder
{
    public class InstanceBorderManager
    {
        #region Instance


        private static InstanceBorderManager instance;
        public static InstanceBorderManager Instance
        {
            get
            {
                if (instance == null)
                    instance = new InstanceBorderManager();
                return instance;
            }
        }
        private InstanceBorderManager() { }
        #endregion

        public string prefabPath = "InstanceBorderPoint";

        InstanceBorderEditor GUICom = null;
        InstanceBorderNet NetCom = null;

        public void StartUp()
        {
            Reset();
            NetCom = new InstanceBorderNet();
            GUICom = new InstanceBorderEditor("副本边界");

        }


        Vector3 position;
        public void OnUpdate()
        {
            position = SceneManager.MousePos;
            if (cursorObj != null)
            {
                cursorObj.transform.position = position + Vector3.up;

            }
        }
        public void OnGUI()
        {
            if (!Enable) return;
            if (GUICom != null)
            {
                GUICom.OnGUI();
            }

            ProcessMouseEvent();
        }

        #region 处理鼠标事件

        public GameObject focus;

        /// <summary>
        /// 处理鼠标事件
        /// </summary>
        void ProcessMouseEvent()
        {
            //移除对象数据
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                if (focus != null)
                {
                    DeleteFocusObj();
                }
            }

            //对焦当前选中的目标
            if (Input.GetKeyDown(KeyCode.F))
            {
                if (focus != null)
                {
                    CameraMove.GetInst().CameraLookAtTarget(focus);
                }
            }

            //获取鼠标事件
            var e = Event.current;
            if (e == null || !e.isMouse)
                return;

            if (e.clickCount == 1)
            {
                if (e.button == 0)
                {
                    FindFocusObj(SceneManager.MousePos);
                }
            }
            else if (e.clickCount == 2)
            {
                if (e.button == 0)
                {
                    //左键两下 种怪
                    //当前已经有模型选中显示，并且不是正在加载新的 model
                    if (cursorObj)
                    {
                        focus = cursorObj;
                        cursorObj = null;
                    }

                }
                else if (e.button == 1)
                {
                    //右键两下 取消当前鼠标怪物预览
                    if (cursorObj != null)
                    {
                        UnLoadShowSprite();
                        // SetShowEditorSprite(null); 

                    }
                }
            }
        }


        public GameObject cursorObj = null;
        public void CreateCursorObj(BorderType type, Vector3 position)
        {
            cursorObj = CurInstanceBorder.CreateOnePoint(type, position);
        }

        private void DeleteFocusObj()
        {
            if (focus != null)
            {
                CurInstanceBorder.TryRemove(focus);
                GameObject.Destroy(focus);
            }
        }

        public void FindFocusObj(Vector3 mousePos)
        {
            GameObject sprite = FindGameObjectAtPosition(SceneManager.MousePos);
            if (sprite != null)
            {
                SetFocus(sprite);
            }
        }

        public void SetFocus(GameObject sprite)
        {
            focus = sprite;
            TransformGizmos.TransformGizmo.GetInst().SetTraget(sprite.transform);
        }

        private void UnLoadShowSprite()
        {
            if (cursorObj != null)
            {
                CurInstanceBorder.TryRemove(cursorObj);
                GameObject.Destroy(cursorObj);
            }
        }

        private GameObject FindGameObjectAtPosition(Vector3 mousePos)
        {
            return CurInstanceBorder.FindNearestPoint(mousePos);
        }
        #endregion

        internal void DisolveJson(string text)
        {
            if (!string.IsNullOrEmpty(text))
            {

                string[] lines = text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < lines.Length; i++)
                {
                    CurInstanceBorder = JsonUtility.FromJson<InstanceBorder>(lines[i]);
                    if (CurInstanceBorder.id == SceneManager.GetInst().CurrScene.id)
                    {
                        CurInstanceBorder.is_syncServer = true;
                        CurInstanceBorder.UnpackVector3();
                        CurInstanceBorder.CreatePoint();
                        break;
                    }
                }
            }
        }

        InstanceBorder m_objInstanceBorder;
        internal InstanceBorder CurInstanceBorder
        {
            get
            {
                return m_objInstanceBorder;
            }
            set
            {
                m_objInstanceBorder = value;
            }
        }

        public bool Enable { get; internal set; }

        public void Reset()
        {
            if (CurInstanceBorder != null)
            {
                CurInstanceBorder.Clear();
            }
            CurInstanceBorder = null;
        }

        internal void SendUpdateInfo()
        {
            NetCom.Update();
        }

        internal void SendNewCreateInfo()
        {
            NetCom.Insert();
        }

        internal void SendDeleteInfo()
        {
            NetCom.Delete();
        }

        internal void Show()
        {
            Enable = true;
            StartUp();
        }
    }


    class InstanceBorder
    {
        public int id;
        public int template_id;
        public long duration;
        public int standard_role_count;
        public float enter_x;
        public float enter_y;
        public float enter_z;
        public int dimension_scene_id;


        public string dimension_area1;
        public string dimension_area2;

        public bool is_roll;
        public bool is_jump;
        public bool is_no_fighting_state;
        public int buff_id;
        public int background_video;
        public int rotation_angle;
        public bool can_level;
        public bool can_return;
        public string remark;

        public bool is_syncServer = true;


        private List<Vector3> _listBorder1;
        public List<Vector3> ListBorder1
        {
            get
            {
                if (_listBorder1 == null)
                {
                    _listBorder1 = new List<Vector3>();
                }
                return _listBorder1;
            }
        }
        private List<Vector3> _listBorder2;
        public List<Vector3> ListBorder2
        {
            get
            {
                if (_listBorder2 == null)
                {
                    _listBorder2 = new List<Vector3>();
                }
                return _listBorder2;
            }
        }

        private Transform _parent;
        public Transform Parent
        {
            get
            {
                if (_parent == null)
                    _parent = new GameObject("InstanceBorderParent").transform;
                return _parent;
            }
        }

        public void UnpackVector3()
        {
            ListBorder1.AddRange(GameUtils.StringToVector3Array(dimension_area1));
            ListBorder2.AddRange(GameUtils.StringToVector3Array(dimension_area2));

        }

        public WWWForm PackVector3()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < listPoint1.Count; i++)
            {
                var vv = listPoint1[i];
                var v = vv.transform.position;
                sb.AppendFormat("{0},{1},{2};", v.x, v.y, v.z);
            }
            dimension_area1 = sb.ToString();

            sb.Remove(0, sb.Length);
            for (int i = 0; i < listPoint2.Count; i++)
            {
                var vv = listPoint2[i];
                var v = vv.transform.position;
                sb.AppendFormat("{0},{1},{2};", v.x, v.y, v.z);
            }
            dimension_area2 = sb.ToString();

            WWWForm form = new WWWForm();
            form.AddField("id", id);
            form.AddField("template_id", template_id);
            form.AddField("duration", duration.ToString("F2"));
            form.AddField("standard_role_count", standard_role_count);
            form.AddField("enter_x", enter_x.ToString("F2"));
            form.AddField("enter_y", enter_y.ToString("F2"));
            form.AddField("enter_z", enter_z.ToString("F2"));
            form.AddField("dimension_scene_id", dimension_scene_id);
            form.AddField("dimension_area1", dimension_area1);
            form.AddField("dimension_area2", dimension_area2);
            form.AddField("is_roll", is_roll.ToString().ToUpper());
            form.AddField("is_jump", is_jump.ToString().ToUpper());
            form.AddField("is_no_fighting_state", is_no_fighting_state.ToString().ToUpper());
            form.AddField("buff_id", buff_id.ToString());
            form.AddField("background_video", background_video.ToString());
            form.AddField("rotation_angle", rotation_angle.ToString());

            form.AddField("can_leave", can_level.ToString().ToUpper());
            form.AddField("can_return", can_return.ToString().ToUpper());
            form.AddField("remark", remark);
            return form;
        }
        public void Clear()
        {
            if (listPoint1 != null)
            {
                for (int i = 0; i < listPoint1.Count; i++)
                {
                    var p = listPoint1[i];
                    if (p != null)
                        GameObject.Destroy(p);
                }
            }
            if (listPoint2 != null)
            {
                for (int i = 0; i < listPoint2.Count; i++)
                {
                    var p = listPoint2[i];
                    if (p != null)
                        GameObject.Destroy(p);
                }
            }

            ListBorder1.Clear();
            ListBorder2.Clear();

            if (_parent)
            {
                GameObject.Destroy(_parent.gameObject);
            }
        }


        GameObject pointPrefab = null;
        public List<GameObject> listPoint1 = new List<GameObject>();
        public List<GameObject> listPoint2 = new List<GameObject>();
        internal void CreatePoint()
        {
            if (pointPrefab == null)
            {
                pointPrefab = Resources.Load(InstanceBorderManager.Instance.prefabPath) as GameObject;
            }

            if (pointPrefab != null)
            {
                for (int i = 0; i < ListBorder1.Count; i++)
                {
                    var v = ListBorder1[i];
                    CreateOnePoint(BorderType.Inner, v);
                }

                for (int i = 0; i < ListBorder2.Count; i++)
                {
                    var v = ListBorder2[i];
                    CreateOnePoint(BorderType.Outer, v);
                }
            }
            else
            {
                Debug.LogError("border Prefab is null");
            }
        }

        public GameObject CreateOnePoint(BorderType type, Vector3 position)
        {
            GameObject go = GameObject.Instantiate<GameObject>(pointPrefab, Parent);
            if (go != null)
            {
                go.transform.SetPositionAndRotation(position, Quaternion.identity);
                switch (type)
                {
                    case BorderType.Inner:
                        listPoint1.Add(go);
                        break;
                    case BorderType.Outer:
                        listPoint2.Add(go);
                        break;
                    default:
                        break;
                }
            }
            return go;
        }

        float distance = 2f;
        internal GameObject FindNearestPoint(Vector3 mousePos)
        {
            GameObject nearest = null;
            for (int i = 0; i < listPoint1.Count; i++)
            {
                float dst = Vector3.Distance(listPoint1[i].transform.position, mousePos);
                if (dst < distance)
                {
                    nearest = listPoint1[i];
                }
            }

            for (int i = 0; i < listPoint2.Count; i++)
            {
                float dst = Vector3.Distance(listPoint2[i].transform.position, mousePos);
                if (dst < distance)
                {
                    nearest = listPoint2[i];
                }
            }

            return nearest;
        }

        internal void TryRemove(GameObject cursorObj)
        {
            if (listPoint1.Contains(cursorObj))
            {
                listPoint1.Remove(cursorObj);
            }

            if (listPoint2.Contains(cursorObj))
            {
                listPoint2.Remove(cursorObj);
            }
        }
    }

    public enum BorderType
    {
        Inner,
        Outer
    }
}
