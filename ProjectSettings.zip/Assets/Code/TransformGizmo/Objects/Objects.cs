﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace TransformGizmos
{
    /// <summary>
    /// 轴实体
    /// </summary>
    public struct AxisInfo
    {
        public Vector3 xAxisEnd;
        public Vector3 yAxisEnd;
        public Vector3 zAxisEnd;
        public Vector3 xDirection;
        public Vector3 yDirection;
        public Vector3 zDirection;

        public void Set(Transform target, float handleLength, TransformSpace space)
        {
            if (space == TransformSpace.Global)
            {
                xDirection = Vector3.right;
                yDirection = Vector3.up;
                zDirection = Vector3.forward;
            }
            else if (space == TransformSpace.Local)
            {
                xDirection = target.right;
                yDirection = target.up;
                zDirection = target.forward;
            }

            xAxisEnd = target.position + (xDirection * handleLength);
            yAxisEnd = target.position + (yDirection * handleLength);
            zAxisEnd = target.position + (zDirection * handleLength);
        }
    }

    /// <summary>
    /// 轴向量
    /// </summary>
    public class AxisVectors
    {
        public List<Vector3> x = new List<Vector3>();
        public List<Vector3> y = new List<Vector3>();
        public List<Vector3> z = new List<Vector3>();
        public List<Vector3> all = new List<Vector3>();

        public void Add(AxisVectors axisVectors)
        {
            x.AddRange(axisVectors.x);
            y.AddRange(axisVectors.y);
            z.AddRange(axisVectors.z);
            all.AddRange(axisVectors.all);
        }

        public void Clear()
        {
            x.Clear();
            y.Clear();
            z.Clear();
            all.Clear();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public struct IntersectPoints
    {
        public Vector3 first;
        public Vector3 second;

        public IntersectPoints(Vector3 first, Vector3 second)
        {
            this.first = first;
            this.second = second;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public struct Square
    {
        public Vector3 bottomLeft;
        public Vector3 bottomRight;
        public Vector3 topLeft;
        public Vector3 topRight;

        public Vector3 this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0:
                        return this.bottomLeft;
                    case 1:
                        return this.bottomRight;
                    case 2:
                        return this.topLeft;
                    case 3:
                        return this.topRight;
                    case 4:
                        return this.bottomLeft; //so we wrap around back to start
                    default:
                        return Vector3.zero;
                }
            }
        }
    }

    /// <summary>
    /// 扩展方法
    /// </summary>
    public static class ExtMathf
    {
        public static float Squared(this float value)
        {
            return value * value;
        }
    }
    #region 枚举
    /// <summary>
    /// 空间坐标
    /// </summary>
    public enum TransformSpace { Global, Local }
    /// <summary>
    /// Transform 类型
    /// </summary>
    public enum TransformType { Move, Rotate, Scale }
    /// <summary>
    /// 轴向
    /// </summary>
    public enum Axis { None, X, Y, Z, Any }
    #endregion
}
