﻿using UnityEngine;

namespace MapEditor
{

    /// <summary>
    /// GUI 提示信息
    /// </summary>
    public class GUINotice : MonoBehaviour
    {
        static bool isShow = false;
        static int width = 400;
        static int height = 200;
        static string content = "这是一条测试消息";
        static Action ifTrueDoAction;
        static bool isConfriming = false;

        public static void Show(string contentIn)
        {
            isConfriming = false;
            isShow = true;
            content = contentIn;
        }

        public static void Confirm(string contentIn, Action ifTrueDo)
        {
            isConfriming = true;
            isShow = true;
            content = contentIn;
            ifTrueDoAction = ifTrueDo;
        }

        void OnGUI()
        {
            if (isShow)
            {
                Rect centerRect = new Rect(new Vector2(Screen.width / 2 - width / 2, Screen.height / 2 - height / 2), new Vector2(width, height));
                GUILayout.Window(-1, centerRect, DrawWindow, isConfriming ? "确认" : "消息");
            }
        }

        void DrawWindow(int windowID)
        {
            Rect textRect = new Rect(20, 20, width - 40, height - 50);
            Rect buttonRect = new Rect(20, height - 30, width - 40, 20);

            GUILayout.BeginArea(textRect);
            GUILayout.Label(content);
            GUILayout.EndArea();

            GUILayout.BeginArea(buttonRect);
            GUILayout.BeginHorizontal();
            if (isConfriming)
            {
                GUILayout.Space(width / 2 - 60 - 20);
                if (GUILayout.Button("<color=#22ff22>确定</color>"))
                {
                    isShow = false;
                    ifTrueDoAction.Invoke();
                }
                GUILayout.Space(20);
                if (GUILayout.Button("<color=#ff2222>取消</color>"))
                {
                    isShow = false;
                }
                GUILayout.Space(width / 2 - 60 - 20);
            }
            else
            {
                GUILayout.Space(width / 2 - 25 - 20);
                if (GUILayout.Button("确认"))
                {
                    isShow = false;
                }
                GUILayout.Space(width / 2 - 25 - 20);
            }
            GUILayout.EndHorizontal();
            GUILayout.EndArea();
        }
    }
}
