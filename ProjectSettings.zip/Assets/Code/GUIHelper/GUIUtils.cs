﻿using UnityEngine;

namespace MapEditor
{

    //为了方便gui的一些输入而做，目前只是显示数字输入
    public class GUIUtils
    {


        //public static List<mapdata> allMapList = new List<mapdata>();
        public static int NumberField(string label, int n,bool editable = true)
        {
            GUILayout.BeginHorizontal();

            int result = 0;

            GUILayout.Label(label + ":");
            GUI.enabled = editable;
            string temp = GUILayout.TextField(n.ToString());

            if (!string.IsNullOrEmpty(temp))
            {
                try
                {
                    result = int.Parse(temp);
                }
                catch
                {
                    GUILayout.Label("Editor: 输入非法");
                }
            }


            GUILayout.EndHorizontal();
            GUI.enabled = true;
            return result;
        }
        //TODO Lpy+重载参数为float类型的
        public static float NumberField(string label, float n,bool editable =true)
        {
            GUILayout.BeginHorizontal();

            float result = 0;

            GUILayout.Label(label + ":");

            GUI.enabled = editable;
            string temp = GUILayout.TextField(n.ToString());

            if (!string.IsNullOrEmpty(temp))
            {
                try
                {
                    result = float.Parse(temp);
                }
                catch
                {
                    GUILayout.Label("Editor: 输入非法");
                }
            }


            GUILayout.EndHorizontal();
            GUI.enabled = true;
            return result;
        }

        //TODO Lpy+重载参数为float类型的
        public static string StrField(string label, string n,bool editable=true)
        {
            GUILayout.BeginHorizontal();

            string result = "";

            GUILayout.Label(label + ":");
            GUI.enabled = editable;
            string temp = GUILayout.TextField(n, GUILayout.Width(200));

            if (!string.IsNullOrEmpty(temp))
            {
                try
                {
                    result = temp;
                }
                catch
                {
                    GUILayout.Label("Editor: 输入非法");
                }
            }


            GUILayout.EndHorizontal();
            GUI.enabled = true;
            return result;
        }

        public static bool BoolField(string label, bool n,bool editable = true)
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label(label + ":");
            GUI.enabled = editable;
            //string temp = GUILayout.TextField(n, GUILayout.Width(200));

            bool b = GUILayout.Toggle(n, "", GUILayout.Width(200));


            GUILayout.EndHorizontal();
            GUI.enabled = true;
            return b;
        }
    }
}
