/**********************
/* Create by @dongzhiwei
/*
/*
**********************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;

namespace Assets.Code
{
    class GameTool:Editor
    {
        /// <summary>
        /// 创建 本地加载数据的配置文件
        /// </summary>
        [MenuItem("Tools/Create Local Load Res Config", priority = 2)]
        public static void OnCreateLocalLoadResConfig()
        {
            //获得当前所有的资源数据信息
            string[] str = AssetDatabase.GetAllAssetPaths();
            //string[] str = AssetDatabase.FindAssets("t:scene t:Prefab t:Material t:font t:AudioClip", null);

            string configPath = "Assets/StreamingAssets/Resconfig.txt";
            if (File.Exists(configPath))//已经有的文件要删除
            {
                File.Delete(configPath);
            }

            StringBuilder sb = new StringBuilder("1.0.0\n");

            for (int i = 0; i < str.Length; i++)
            {

                if (!(str[i].Contains("Resources/Res") || str[i].Contains("Resources/Config")))
                    continue;

                string s = Path.GetExtension(str[i]);
                if (s.Equals(".cs") || s.Equals(".dll") || s.Equals(".asset") || s.Equals(".xml") || s.Equals(".prefs") || string.IsNullOrEmpty(s))
                    continue;

                sb.Append(str[i].Replace("Assets/Resources/", "").Replace("Assets/Built-in/Resources/", "").Replace('\\', '/'));
                sb.Append("\n");
            }
            byte[] b = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
            if (!Directory.Exists(Path.GetDirectoryName(configPath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(configPath));
            }
            using (var s = File.Create(configPath))
            {
                s.Write(b, 0, b.Length);
                s.Dispose();
            }
            Debug.LogError("本地配置文件生成完毕！！！");
        }
    }
}
