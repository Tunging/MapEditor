using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 邮件表
    ///</summary>
    [Serializable]
    [TableName("email")]
    public partial class Table_Email : TableContent
    {

        private static List<Table_Email> all_Table_Email_List = new List<Table_Email>();
        //primary | 主键
        public static Dictionary<int, Table_Email > pool_primary = new Dictionary<int, Table_Email > ();
        
        
        ///<summary>
        /// 主键：邮件ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 标题
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 国际化标题
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 内容
        ///</summary>
        public string content;
        
        
        ///<summary>
        /// 国际化内容
        ///</summary>
        public string content_i18n;
        
        
        ///<summary>
        /// 发送者名称
        ///</summary>
        public string sender_name;
        
        
        ///<summary>
        /// 国际化发送者名称
        ///</summary>
        public string sender_name_i18n;
        
        
        ///<summary>
        /// 保存天数
        ///</summary>
        public int keep_days;
        
        
        ///<summary>
        /// 删除日期
        ///</summary>
        public string delete_date;
        
        
        ///<summary>
        /// 读取后是否删除
        ///</summary>
        public bool read_delete;
        
        
        ///<summary>
        /// 附件(id*num;id*num)
        ///</summary>
        public string attachment;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：邮件ID</param>
        ///
        public static Table_Email GetPrimary ( int _id ){        
            Table_Email _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Email > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Email> GetAllPrimaryList()
        {
            return all_Table_Email_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("content", out _currValue))
            {
                this.content = _currValue;
            }
            if(_itemData.TryGetValue("content_i18n", out _currValue))
            {
                this.content_i18n = _currValue;
            }
            if(_itemData.TryGetValue("sender_name", out _currValue))
            {
                this.sender_name = _currValue;
            }
            if(_itemData.TryGetValue("sender_name_i18n", out _currValue))
            {
                this.sender_name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("keep_days", out _currValue))
            {
                this.keep_days = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("delete_date", out _currValue))
            {
                this.delete_date = _currValue;
            }
            if(_itemData.TryGetValue("read_delete", out _currValue))
            {
                this.read_delete = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("attachment", out _currValue))
            {
                this.attachment = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "email";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "content":
                    return this.content;
                case "content_i18n":
                    return this.content_i18n;
                case "sender_name":
                    return this.sender_name;
                case "sender_name_i18n":
                    return this.sender_name_i18n;
                case "keep_days":
                    return this.keep_days;
                case "delete_date":
                    return this.delete_date;
                case "read_delete":
                    return this.read_delete;
                case "attachment":
                    return this.attachment;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Email> rows = _rows as List<Table_Email>;
            pool_primary=TableContent.ListToPool < int, Table_Email > ( rows, "map", "id" );
            all_Table_Email_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Email_List.Clear();
        }
    }
}
