using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 词条
    ///</summary>
    [Serializable]
    [TableName("entry")]
    public partial class Table_Entry : TableContent
    {

        private static List<Table_Entry> all_Table_Entry_List = new List<Table_Entry>();
        //primary | 主键
        public static Dictionary<int, Table_Entry > pool_primary = new Dictionary<int, Table_Entry > ();
        
        
        ///<summary>
        /// ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 白色品质权重
        ///</summary>
        public int white_prop_weight;
        
        
        ///<summary>
        /// 蓝色色品质权重
        ///</summary>
        public int blue_prop_weight;
        
        
        ///<summary>
        /// 紫色色品质权重
        ///</summary>
        public int purple_prop_weight;
        
        
        ///<summary>
        /// 橙色色品质权重
        ///</summary>
        public int orange_prop_weight;
        
        
        ///<summary>
        /// 白色品质属性最小值
        ///</summary>
        public int white_prop_min_value;
        
        
        ///<summary>
        /// 白色品质属性最大值
        ///</summary>
        public int white_prop_max_value;
        
        
        ///<summary>
        /// 蓝色品质属性最小值
        ///</summary>
        public int blue_prop_min_value;
        
        
        ///<summary>
        /// 蓝色品质属性最大值
        ///</summary>
        public int blue_prop_max_value;
        
        
        ///<summary>
        /// 紫色品质属性最小值
        ///</summary>
        public int purple_prop_min_value;
        
        
        ///<summary>
        /// 紫色品质属性最大值
        ///</summary>
        public int purple_prop_max_value;
        
        
        ///<summary>
        /// 橙色品质属性最小值
        ///</summary>
        public int orange_prop_min_value;
        
        
        ///<summary>
        /// 橙色品质属性最大值
        ///</summary>
        public int orange_prop_max_value;
        
        
        ///<summary>
        /// 替换后的技能组ID
        ///</summary>
        public int replace_skill_grouop_id;
        
        
        ///<summary>
        /// 事件属性最大值
        ///</summary>
        public int event_max_value;
        
        
        ///<summary>
        /// 触发子技能最大几率
        ///</summary>
        public int trigger_skill_max_ratio;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> ID</param>
        ///
        public static Table_Entry GetPrimary ( int _id ){        
            Table_Entry _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Entry > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Entry> GetAllPrimaryList()
        {
            return all_Table_Entry_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("white_prop_weight", out _currValue))
            {
                this.white_prop_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("blue_prop_weight", out _currValue))
            {
                this.blue_prop_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("purple_prop_weight", out _currValue))
            {
                this.purple_prop_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("orange_prop_weight", out _currValue))
            {
                this.orange_prop_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("white_prop_min_value", out _currValue))
            {
                this.white_prop_min_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("white_prop_max_value", out _currValue))
            {
                this.white_prop_max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("blue_prop_min_value", out _currValue))
            {
                this.blue_prop_min_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("blue_prop_max_value", out _currValue))
            {
                this.blue_prop_max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("purple_prop_min_value", out _currValue))
            {
                this.purple_prop_min_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("purple_prop_max_value", out _currValue))
            {
                this.purple_prop_max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("orange_prop_min_value", out _currValue))
            {
                this.orange_prop_min_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("orange_prop_max_value", out _currValue))
            {
                this.orange_prop_max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("replace_skill_grouop_id", out _currValue))
            {
                this.replace_skill_grouop_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("event_max_value", out _currValue))
            {
                this.event_max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_skill_max_ratio", out _currValue))
            {
                this.trigger_skill_max_ratio = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "entry";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "white_prop_weight":
                    return this.white_prop_weight;
                case "blue_prop_weight":
                    return this.blue_prop_weight;
                case "purple_prop_weight":
                    return this.purple_prop_weight;
                case "orange_prop_weight":
                    return this.orange_prop_weight;
                case "white_prop_min_value":
                    return this.white_prop_min_value;
                case "white_prop_max_value":
                    return this.white_prop_max_value;
                case "blue_prop_min_value":
                    return this.blue_prop_min_value;
                case "blue_prop_max_value":
                    return this.blue_prop_max_value;
                case "purple_prop_min_value":
                    return this.purple_prop_min_value;
                case "purple_prop_max_value":
                    return this.purple_prop_max_value;
                case "orange_prop_min_value":
                    return this.orange_prop_min_value;
                case "orange_prop_max_value":
                    return this.orange_prop_max_value;
                case "replace_skill_grouop_id":
                    return this.replace_skill_grouop_id;
                case "event_max_value":
                    return this.event_max_value;
                case "trigger_skill_max_ratio":
                    return this.trigger_skill_max_ratio;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Entry> rows = _rows as List<Table_Entry>;
            pool_primary=TableContent.ListToPool < int, Table_Entry > ( rows, "map", "id" );
            all_Table_Entry_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Entry_List.Clear();
        }
    }
}
