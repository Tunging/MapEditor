using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 优悦反馈
    ///</summary>
    [Serializable]
    [TableName("client_feed_back")]
    public partial class Table_Client_Feed_Back : TableContent
    {

        private static List<Table_Client_Feed_Back> all_Table_Client_Feed_Back_List = new List<Table_Client_Feed_Back>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Feed_Back > pool_primary = new Dictionary<int, Table_Client_Feed_Back > ();
        
        
        ///<summary>
        /// 标签id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 反馈类型(体验，建议，两个都显示)
        ///</summary>
        public int feedtype;
        
        
        ///<summary>
        /// 标签内容
        ///</summary>
        public string content;
        
        
        ///<summary>
        /// icon类型（boom or flower）
        ///</summary>
        public int type;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 标签id</param>
        ///
        public static Table_Client_Feed_Back GetPrimary ( int _id ){        
            Table_Client_Feed_Back _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Feed_Back > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Feed_Back> GetAllPrimaryList()
        {
            return all_Table_Client_Feed_Back_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("feedtype", out _currValue))
            {
                this.feedtype = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("content", out _currValue))
            {
                this.content = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_feed_back";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "feedtype":
                    return this.feedtype;
                case "content":
                    return this.content;
                case "type":
                    return this.type;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Feed_Back> rows = _rows as List<Table_Client_Feed_Back>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Feed_Back > ( rows, "map", "id" );
            all_Table_Client_Feed_Back_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Feed_Back_List.Clear();
        }
    }
}
