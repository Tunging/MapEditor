using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 表演脚本组循环类型表
    ///</summary>
    [Serializable]
    [TableName("npc_script_group")]
    public partial class Table_Npc_Script_Group : TableContent
    {

        private static List<Table_Npc_Script_Group> all_Table_Npc_Script_Group_List = new List<Table_Npc_Script_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Script_Group > pool_primary = new Dictionary<int, Table_Npc_Script_Group > ();
        
        
        ///<summary>
        /// 主键:id
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 类型(1 触发后单次播放  2 循环播放)
        ///</summary>
        public int loop_type;
        
        
        ///<summary>
        /// 播放类型(1 头顶气泡 2 界面)
        ///</summary>
        public int play_type;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 主键:id</param>
        ///
        public static Table_Npc_Script_Group GetPrimary ( int _groupId ){        
            Table_Npc_Script_Group _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Script_Group > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Script_Group> GetAllPrimaryList()
        {
            return all_Table_Npc_Script_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("loop_type", out _currValue))
            {
                this.loop_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("play_type", out _currValue))
            {
                this.play_type = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_script_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "group_id":
                    return this.group_id;
                case "loop_type":
                    return this.loop_type;
                case "play_type":
                    return this.play_type;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Script_Group> rows = _rows as List<Table_Npc_Script_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Script_Group > ( rows, "map", "group_id" );
            all_Table_Npc_Script_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Script_Group_List.Clear();
        }
    }
}
