using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 专精等级表
    ///</summary>
    [Serializable]
    [TableName("mastery_level")]
    public partial class Table_Mastery_Level : TableContent
    {

        private static List<Table_Mastery_Level> all_Table_Mastery_Level_List = new List<Table_Mastery_Level>();
        //primary | 主键
        public static Dictionary<int, Table_Mastery_Level > pool_primary = new Dictionary<int, Table_Mastery_Level > ();
        
        
        ///<summary>
        /// 专精等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 升级所需的专精值
        ///</summary>
        public int up_value;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param level> 专精等级</param>
        ///
        public static Table_Mastery_Level GetPrimary ( int _level ){        
            Table_Mastery_Level _map0=null;        
            pool_primary. TryGetValue(_level,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mastery_Level > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mastery_Level> GetAllPrimaryList()
        {
            return all_Table_Mastery_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("up_value", out _currValue))
            {
                this.up_value = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mastery_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "level":
                    return this.level;
                case "up_value":
                    return this.up_value;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mastery_Level> rows = _rows as List<Table_Mastery_Level>;
            pool_primary=TableContent.ListToPool < int, Table_Mastery_Level > ( rows, "map", "level" );
            all_Table_Mastery_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mastery_Level_List.Clear();
        }
    }
}
