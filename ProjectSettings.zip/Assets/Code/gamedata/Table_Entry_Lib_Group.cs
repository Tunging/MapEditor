using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 词条随机库分组配置
    ///</summary>
    [Serializable]
    [TableName("entry_lib_group")]
    public partial class Table_Entry_Lib_Group : TableContent
    {

        private static List<Table_Entry_Lib_Group> all_Table_Entry_Lib_Group_List = new List<Table_Entry_Lib_Group>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Entry_Lib_Group > > pool_primary = new Dictionary<int, Dictionary<int, Table_Entry_Lib_Group > > ();
        
        
        ///<summary>
        /// 主键：随机库ID
        ///</summary>
        public int lib_id;
        
        
        ///<summary>
        /// 主键：分组ID
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param libId> 主键：随机库ID</param>
        ///
        public static Dictionary<int, Table_Entry_Lib_Group > GetPrimary ( int _libId ){        
            Dictionary<int, Table_Entry_Lib_Group > _map0=null;        
            pool_primary. TryGetValue(_libId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param libId> 主键：随机库ID</param>
        ///	<param groupId> 主键：分组ID</param>
        ///
        public static Table_Entry_Lib_Group GetPrimary ( int _libId , int _groupId ){        
            Dictionary<int, Table_Entry_Lib_Group > _map0=null;        
            pool_primary. TryGetValue(_libId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Entry_Lib_Group _map1=null;        
            _map0. TryGetValue(_groupId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Entry_Lib_Group > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Entry_Lib_Group> GetAllPrimaryList()
        {
            return all_Table_Entry_Lib_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("lib_id", out _currValue))
            {
                this.lib_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "entry_lib_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "lib_id":
                    return this.lib_id;
                case "group_id":
                    return this.group_id;
                case "weight":
                    return this.weight;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Entry_Lib_Group> rows = _rows as List<Table_Entry_Lib_Group>;
            pool_primary=TableContent.ListToPool < int, int, Table_Entry_Lib_Group > ( rows, "map", "lib_id", "group_id" );
            all_Table_Entry_Lib_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Entry_Lib_Group_List.Clear();
        }
    }
}
