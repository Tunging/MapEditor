using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 相机行为
    ///</summary>
    [Serializable]
    [TableName("camera_behavior")]
    public partial class Table_Camera_Behavior : TableContent
    {

        private static List<Table_Camera_Behavior> all_Table_Camera_Behavior_List = new List<Table_Camera_Behavior>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Camera_Behavior > > pool_primary = new Dictionary<int, Dictionary<int, Table_Camera_Behavior > > ();
        
        
        ///<summary>
        /// Id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 步骤
        ///</summary>
        public int step;
        
        
        ///<summary>
        /// 相机行为类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 开始时间（毫秒）
        ///</summary>
        public int start_time;
        
        
        ///<summary>
        /// 结束时间（毫秒）
        ///</summary>
        public int end_time;
        
        
        ///<summary>
        /// 参数(参数意义见camera_behavior_type)
        ///</summary>
        public string param;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> Id</param>
        ///
        public static Dictionary<int, Table_Camera_Behavior > GetPrimary ( int _id ){        
            Dictionary<int, Table_Camera_Behavior > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> Id</param>
        ///	<param step> 步骤</param>
        ///
        public static Table_Camera_Behavior GetPrimary ( int _id , int _step ){        
            Dictionary<int, Table_Camera_Behavior > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Camera_Behavior _map1=null;        
            _map0. TryGetValue(_step,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Camera_Behavior > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Camera_Behavior> GetAllPrimaryList()
        {
            return all_Table_Camera_Behavior_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("step", out _currValue))
            {
                this.step = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("start_time", out _currValue))
            {
                this.start_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("end_time", out _currValue))
            {
                this.end_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param", out _currValue))
            {
                this.param = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "camera_behavior";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "step":
                    return this.step;
                case "type":
                    return this.type;
                case "start_time":
                    return this.start_time;
                case "end_time":
                    return this.end_time;
                case "param":
                    return this.param;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Camera_Behavior> rows = _rows as List<Table_Camera_Behavior>;
            pool_primary=TableContent.ListToPool < int, int, Table_Camera_Behavior > ( rows, "map", "id", "step" );
            all_Table_Camera_Behavior_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Camera_Behavior_List.Clear();
        }
    }
}
