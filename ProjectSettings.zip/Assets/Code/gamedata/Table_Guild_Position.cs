using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 公会职位表
    ///</summary>
    [Serializable]
    [TableName("guild_position")]
    public partial class Table_Guild_Position : TableContent
    {

        private static List<Table_Guild_Position> all_Table_Guild_Position_List = new List<Table_Guild_Position>();
        //primary | 主键
        public static Dictionary<int, Table_Guild_Position > pool_primary = new Dictionary<int, Table_Guild_Position > ();
        
        
        ///<summary>
        /// 主键：职位ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 职位名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 修改公会名字
        ///</summary>
        public bool can_change_guild_name;
        
        
        ///<summary>
        /// 修改公会宣言
        ///</summary>
        public bool can_change_guild_declaration;
        
        
        ///<summary>
        /// 升级公会
        ///</summary>
        public bool can_upgrade_guild;
        
        
        ///<summary>
        /// 踢人
        ///</summary>
        public bool can_kick_member;
        
        
        ///<summary>
        /// 收人
        ///</summary>
        public bool can_accept_member;
        
        
        ///<summary>
        /// 任命副会长
        ///</summary>
        public bool can_appoint_vice_chairman;
        
        
        ///<summary>
        /// 任命长老
        ///</summary>
        public bool can_appoint_elder;
        
        
        ///<summary>
        /// 任命堂主
        ///</summary>
        public bool can_appoint_chief;
        
        
        ///<summary>
        /// 任命精英
        ///</summary>
        public bool can_appoint_elite;
        
        
        ///<summary>
        /// 任命普通成员
        ///</summary>
        public bool can_appoint_normal;
        
        
        ///<summary>
        /// 修改旗帜
        ///</summary>
        public bool can_change_banner;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：职位ID</param>
        ///
        public static Table_Guild_Position GetPrimary ( int _id ){        
            Table_Guild_Position _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Guild_Position > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Guild_Position> GetAllPrimaryList()
        {
            return all_Table_Guild_Position_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("can_change_guild_name", out _currValue))
            {
                this.can_change_guild_name = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_change_guild_declaration", out _currValue))
            {
                this.can_change_guild_declaration = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_upgrade_guild", out _currValue))
            {
                this.can_upgrade_guild = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_kick_member", out _currValue))
            {
                this.can_kick_member = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_accept_member", out _currValue))
            {
                this.can_accept_member = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_appoint_vice_chairman", out _currValue))
            {
                this.can_appoint_vice_chairman = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_appoint_elder", out _currValue))
            {
                this.can_appoint_elder = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_appoint_chief", out _currValue))
            {
                this.can_appoint_chief = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_appoint_elite", out _currValue))
            {
                this.can_appoint_elite = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_appoint_normal", out _currValue))
            {
                this.can_appoint_normal = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_change_banner", out _currValue))
            {
                this.can_change_banner = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "guild_position";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name_i18n":
                    return this.name_i18n;
                case "can_change_guild_name":
                    return this.can_change_guild_name;
                case "can_change_guild_declaration":
                    return this.can_change_guild_declaration;
                case "can_upgrade_guild":
                    return this.can_upgrade_guild;
                case "can_kick_member":
                    return this.can_kick_member;
                case "can_accept_member":
                    return this.can_accept_member;
                case "can_appoint_vice_chairman":
                    return this.can_appoint_vice_chairman;
                case "can_appoint_elder":
                    return this.can_appoint_elder;
                case "can_appoint_chief":
                    return this.can_appoint_chief;
                case "can_appoint_elite":
                    return this.can_appoint_elite;
                case "can_appoint_normal":
                    return this.can_appoint_normal;
                case "can_change_banner":
                    return this.can_change_banner;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Guild_Position> rows = _rows as List<Table_Guild_Position>;
            pool_primary=TableContent.ListToPool < int, Table_Guild_Position > ( rows, "map", "id" );
            all_Table_Guild_Position_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Guild_Position_List.Clear();
        }
    }
}
