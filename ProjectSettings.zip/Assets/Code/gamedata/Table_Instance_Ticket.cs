using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本门票
    ///</summary>
    [Serializable]
    [TableName("instance_ticket")]
    public partial class Table_Instance_Ticket : TableContent
    {

        private static List<Table_Instance_Ticket> all_Table_Instance_Ticket_List = new List<Table_Instance_Ticket>();
        //primary | 主键
        public static Dictionary<int, Table_Instance_Ticket > pool_primary = new Dictionary<int, Table_Instance_Ticket > ();
        
        
        ///<summary>
        /// 副本门票ID
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 对应的副本id
        ///</summary>
        public int instance_id;
        
        
        ///<summary>
        /// 对应的副本等级
        ///</summary>
        public int instance_level;
        
        
        ///<summary>
        /// 副本难度
        ///</summary>
        public int instance_difficulty;
        
        
        ///<summary>
        /// 展示图片
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 展示奖励道具id（用逗号隔开）
        ///</summary>
        public string show_reward_id;
        
        
        ///<summary>
        /// 特性数量以及对应权重(如2,10;4,20）
        ///</summary>
        public string feature_count_weight;
        
        
        ///<summary>
        /// 副本特性组
        ///</summary>
        public int feature_group_id;
        
        
        ///<summary>
        /// 固定的副本特性
        ///</summary>
        public string fixed_feature_ids;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param itemId> 副本门票ID</param>
        ///
        public static Table_Instance_Ticket GetPrimary ( int _itemId ){        
            Table_Instance_Ticket _map0=null;        
            pool_primary. TryGetValue(_itemId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Instance_Ticket > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance_Ticket> GetAllPrimaryList()
        {
            return all_Table_Instance_Ticket_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("instance_id", out _currValue))
            {
                this.instance_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("instance_level", out _currValue))
            {
                this.instance_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("instance_difficulty", out _currValue))
            {
                this.instance_difficulty = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_reward_id", out _currValue))
            {
                this.show_reward_id = _currValue;
            }
            if(_itemData.TryGetValue("feature_count_weight", out _currValue))
            {
                this.feature_count_weight = _currValue;
            }
            if(_itemData.TryGetValue("feature_group_id", out _currValue))
            {
                this.feature_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fixed_feature_ids", out _currValue))
            {
                this.fixed_feature_ids = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance_ticket";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "item_id":
                    return this.item_id;
                case "instance_id":
                    return this.instance_id;
                case "instance_level":
                    return this.instance_level;
                case "instance_difficulty":
                    return this.instance_difficulty;
                case "icon_id":
                    return this.icon_id;
                case "show_reward_id":
                    return this.show_reward_id;
                case "feature_count_weight":
                    return this.feature_count_weight;
                case "feature_group_id":
                    return this.feature_group_id;
                case "fixed_feature_ids":
                    return this.fixed_feature_ids;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance_Ticket> rows = _rows as List<Table_Instance_Ticket>;
            pool_primary=TableContent.ListToPool < int, Table_Instance_Ticket > ( rows, "map", "item_id" );
            all_Table_Instance_Ticket_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_Ticket_List.Clear();
        }
    }
}
