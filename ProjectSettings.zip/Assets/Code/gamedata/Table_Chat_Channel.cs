using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 聊天频道
    ///</summary>
    [Serializable]
    [TableName("chat_channel")]
    public partial class Table_Chat_Channel : TableContent
    {

        private static List<Table_Chat_Channel> all_Table_Chat_Channel_List = new List<Table_Chat_Channel>();
        //primary | 主键
        public static Dictionary<int, Table_Chat_Channel > pool_primary = new Dictionary<int, Table_Chat_Channel > ();
        
        
        ///<summary>
        /// 频道ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 频道名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 频道icon
        ///</summary>
        public int channel_icon;
        
        
        ///<summary>
        /// 频道名字颜色
        ///</summary>
        public string name_color;
        
        
        ///<summary>
        /// 频道顺序
        ///</summary>
        public int channel_order;
        
        
        ///<summary>
        /// 可发言
        ///</summary>
        public int interactive;
        
        
        ///<summary>
        /// 发言CD
        ///</summary>
        public int cd;
        
        
        ///<summary>
        /// 字数上限
        ///</summary>
        public int max_word;
        
        
        ///<summary>
        /// 最小语音时间
        ///</summary>
        public int min_voice_time;
        
        
        ///<summary>
        /// 最大语音时间
        ///</summary>
        public int max_voice_time;
        
        
        ///<summary>
        /// 缓存消息条数
        ///</summary>
        public int max_cache_message;
        
        
        ///<summary>
        /// 发言最小等级
        ///</summary>
        public int min_level;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 频道ID</param>
        ///
        public static Table_Chat_Channel GetPrimary ( int _id ){        
            Table_Chat_Channel _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Chat_Channel > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Chat_Channel> GetAllPrimaryList()
        {
            return all_Table_Chat_Channel_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("channel_icon", out _currValue))
            {
                this.channel_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_color", out _currValue))
            {
                this.name_color = _currValue;
            }
            if(_itemData.TryGetValue("channel_order", out _currValue))
            {
                this.channel_order = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("interactive", out _currValue))
            {
                this.interactive = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cd", out _currValue))
            {
                this.cd = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_word", out _currValue))
            {
                this.max_word = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("min_voice_time", out _currValue))
            {
                this.min_voice_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_voice_time", out _currValue))
            {
                this.max_voice_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_cache_message", out _currValue))
            {
                this.max_cache_message = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("min_level", out _currValue))
            {
                this.min_level = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "chat_channel";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "channel_icon":
                    return this.channel_icon;
                case "name_color":
                    return this.name_color;
                case "channel_order":
                    return this.channel_order;
                case "interactive":
                    return this.interactive;
                case "cd":
                    return this.cd;
                case "max_word":
                    return this.max_word;
                case "min_voice_time":
                    return this.min_voice_time;
                case "max_voice_time":
                    return this.max_voice_time;
                case "max_cache_message":
                    return this.max_cache_message;
                case "min_level":
                    return this.min_level;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Chat_Channel> rows = _rows as List<Table_Chat_Channel>;
            pool_primary=TableContent.ListToPool < int, Table_Chat_Channel > ( rows, "map", "id" );
            all_Table_Chat_Channel_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Chat_Channel_List.Clear();
        }
    }
}
