using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 词条事件：action模板
    ///</summary>
    [Serializable]
    [TableName("entry_event_template")]
    public partial class Table_Entry_Event_Template : TableContent
    {

        private static List<Table_Entry_Event_Template> all_Table_Entry_Event_Template_List = new List<Table_Entry_Event_Template>();
        //primary | 主键
        public static Dictionary<int, Table_Entry_Event_Template > pool_primary = new Dictionary<int, Table_Entry_Event_Template > ();
        
        
        ///<summary>
        /// 主键：模板ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 标签
        ///</summary>
        public string tag;
        
        
        ///<summary>
        /// 颜色
        ///</summary>
        public string color;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 类路径
        ///</summary>
        public string script;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：模板ID</param>
        ///
        public static Table_Entry_Event_Template GetPrimary ( int _id ){        
            Table_Entry_Event_Template _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Entry_Event_Template > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Entry_Event_Template> GetAllPrimaryList()
        {
            return all_Table_Entry_Event_Template_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("tag", out _currValue))
            {
                this.tag = _currValue;
            }
            if(_itemData.TryGetValue("color", out _currValue))
            {
                this.color = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("script", out _currValue))
            {
                this.script = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "entry_event_template";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "tag":
                    return this.tag;
                case "color":
                    return this.color;
                case "name":
                    return this.name;
                case "remark":
                    return this.remark;
                case "script":
                    return this.script;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Entry_Event_Template> rows = _rows as List<Table_Entry_Event_Template>;
            pool_primary=TableContent.ListToPool < int, Table_Entry_Event_Template > ( rows, "map", "id" );
            all_Table_Entry_Event_Template_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Entry_Event_Template_List.Clear();
        }
    }
}
