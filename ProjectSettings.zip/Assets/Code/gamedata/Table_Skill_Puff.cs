using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能puff配置
    ///</summary>
    [Serializable]
    [TableName("skill_puff")]
    public partial class Table_Skill_Puff : TableContent
    {

        private static List<Table_Skill_Puff> all_Table_Skill_Puff_List = new List<Table_Skill_Puff>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Skill_Puff > > pool_primary = new Dictionary<int, Dictionary<int, Table_Skill_Puff > > ();
        
        
        ///<summary>
        /// 主键：技能ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 主键：puff类型
        ///</summary>
        public int puff_type;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 图标
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 特效
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 动作
        ///</summary>
        public int action_id;
        
        
        ///<summary>
        /// 是否替换死亡效果
        ///</summary>
        public bool is_replace_die;
        
        
        ///<summary>
        /// 死亡特效
        ///</summary>
        public int die_effect_id;
        
        
        ///<summary>
        /// 死亡动作
        ///</summary>
        public int die_action_id;
        
        
        ///<summary>
        /// 材质球效果ID
        ///</summary>
        public int material_effect_id;
        
        
        ///<summary>
        /// 死亡材质球效果ID
        ///</summary>
        public int death_material_effect_id;
        
        
        ///<summary>
        /// 出现时是否飘字
        ///</summary>
        public bool is_floating_on_add;
        
        
        ///<summary>
        /// 出现时飘字模板ID
        ///</summary>
        public int floating_text_id_on_add;
        
        
        ///<summary>
        /// 出现时飘字文本国际化
        ///</summary>
        public string floating_text_on_add_i18n;
        
        
        ///<summary>
        /// 消失时是否飘字
        ///</summary>
        public bool is_floating_on_remove;
        
        
        ///<summary>
        /// 消失时飘字模板ID
        ///</summary>
        public int floating_template_id_on_remove;
        
        
        ///<summary>
        /// 消失时飘字文本国际化
        ///</summary>
        public string floating_text_on_remove_i18n;
        
        
        ///<summary>
        /// 是不是坏puff
        ///</summary>
        public bool is_bad_skill_effect;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///
        public static Dictionary<int, Table_Skill_Puff > GetPrimary ( int _skillId ){        
            Dictionary<int, Table_Skill_Puff > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///	<param puffType> 主键：puff类型</param>
        ///
        public static Table_Skill_Puff GetPrimary ( int _skillId , int _puffType ){        
            Dictionary<int, Table_Skill_Puff > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Skill_Puff _map1=null;        
            _map0. TryGetValue(_puffType,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Skill_Puff > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Puff> GetAllPrimaryList()
        {
            return all_Table_Skill_Puff_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("puff_type", out _currValue))
            {
                this.puff_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_replace_die", out _currValue))
            {
                this.is_replace_die = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("die_effect_id", out _currValue))
            {
                this.die_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("die_action_id", out _currValue))
            {
                this.die_action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("material_effect_id", out _currValue))
            {
                this.material_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("death_material_effect_id", out _currValue))
            {
                this.death_material_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_floating_on_add", out _currValue))
            {
                this.is_floating_on_add = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_text_id_on_add", out _currValue))
            {
                this.floating_text_id_on_add = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_text_on_add_i18n", out _currValue))
            {
                this.floating_text_on_add_i18n = _currValue;
            }
            if(_itemData.TryGetValue("is_floating_on_remove", out _currValue))
            {
                this.is_floating_on_remove = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_template_id_on_remove", out _currValue))
            {
                this.floating_template_id_on_remove = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_text_on_remove_i18n", out _currValue))
            {
                this.floating_text_on_remove_i18n = _currValue;
            }
            if(_itemData.TryGetValue("is_bad_skill_effect", out _currValue))
            {
                this.is_bad_skill_effect = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_puff";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_id":
                    return this.skill_id;
                case "puff_type":
                    return this.puff_type;
                case "name_i18n":
                    return this.name_i18n;
                case "description_i18n":
                    return this.description_i18n;
                case "icon_id":
                    return this.icon_id;
                case "effect_id":
                    return this.effect_id;
                case "action_id":
                    return this.action_id;
                case "is_replace_die":
                    return this.is_replace_die;
                case "die_effect_id":
                    return this.die_effect_id;
                case "die_action_id":
                    return this.die_action_id;
                case "material_effect_id":
                    return this.material_effect_id;
                case "death_material_effect_id":
                    return this.death_material_effect_id;
                case "is_floating_on_add":
                    return this.is_floating_on_add;
                case "floating_text_id_on_add":
                    return this.floating_text_id_on_add;
                case "floating_text_on_add_i18n":
                    return this.floating_text_on_add_i18n;
                case "is_floating_on_remove":
                    return this.is_floating_on_remove;
                case "floating_template_id_on_remove":
                    return this.floating_template_id_on_remove;
                case "floating_text_on_remove_i18n":
                    return this.floating_text_on_remove_i18n;
                case "is_bad_skill_effect":
                    return this.is_bad_skill_effect;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Puff> rows = _rows as List<Table_Skill_Puff>;
            pool_primary=TableContent.ListToPool < int, int, Table_Skill_Puff > ( rows, "map", "skill_id", "puff_type" );
            all_Table_Skill_Puff_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Puff_List.Clear();
        }
    }
}
