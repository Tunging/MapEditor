using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 属性类型
    ///</summary>
    [Serializable]
    [TableName("prop_type")]
    public partial class Table_Prop_Type : TableContent
    {

        private static List<Table_Prop_Type> all_Table_Prop_Type_List = new List<Table_Prop_Type>();
        //primary | 主键
        public static Dictionary<int, Table_Prop_Type > pool_primary = new Dictionary<int, Table_Prop_Type > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 属性面板显示名称国际化
        ///</summary>
        public string show_name_i18n;
        
        
        ///<summary>
        /// 所属职业（0为所有职业通用）
        ///</summary>
        public int profession_id;
        
        
        ///<summary>
        /// 是否在UI界面上显示
        ///</summary>
        public bool is_show_in_panel;
        
        
        ///<summary>
        /// 显示分页
        ///</summary>
        public int show_page;
        
        
        ///<summary>
        /// 显示顺序
        ///</summary>
        public int show_order;
        
        
        ///<summary>
        /// 是否为千分比
        ///</summary>
        public bool is_chime_ratio;
        
        
        ///<summary>
        /// 关联的最大值的属性ID
        ///</summary>
        public int max_value_prop_id;
        
        
        ///<summary>
        /// 是否现在  属性改变动画面板上（前提：发生变化时，是否推送给客户端。 ）
        ///</summary>
        public bool is_show_in_change_anima_panel;
        
        
        ///<summary>
        /// 属性tips描述的内容
        ///</summary>
        public string tips_content;
        
        
        ///<summary>
        /// 是否是显示在基础属性面板
        ///</summary>
        public bool is_show_in_base;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Prop_Type GetPrimary ( int _id ){        
            Table_Prop_Type _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Prop_Type > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Prop_Type> GetAllPrimaryList()
        {
            return all_Table_Prop_Type_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("show_name_i18n", out _currValue))
            {
                this.show_name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("profession_id", out _currValue))
            {
                this.profession_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_in_panel", out _currValue))
            {
                this.is_show_in_panel = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_page", out _currValue))
            {
                this.show_page = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_order", out _currValue))
            {
                this.show_order = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_chime_ratio", out _currValue))
            {
                this.is_chime_ratio = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_value_prop_id", out _currValue))
            {
                this.max_value_prop_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_in_change_anima_panel", out _currValue))
            {
                this.is_show_in_change_anima_panel = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("tips_content", out _currValue))
            {
                this.tips_content = _currValue;
            }
            if(_itemData.TryGetValue("is_show_in_base", out _currValue))
            {
                this.is_show_in_base = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "prop_type";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "show_name_i18n":
                    return this.show_name_i18n;
                case "profession_id":
                    return this.profession_id;
                case "is_show_in_panel":
                    return this.is_show_in_panel;
                case "show_page":
                    return this.show_page;
                case "show_order":
                    return this.show_order;
                case "is_chime_ratio":
                    return this.is_chime_ratio;
                case "max_value_prop_id":
                    return this.max_value_prop_id;
                case "is_show_in_change_anima_panel":
                    return this.is_show_in_change_anima_panel;
                case "tips_content":
                    return this.tips_content;
                case "is_show_in_base":
                    return this.is_show_in_base;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Prop_Type> rows = _rows as List<Table_Prop_Type>;
            pool_primary=TableContent.ListToPool < int, Table_Prop_Type > ( rows, "map", "id" );
            all_Table_Prop_Type_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Prop_Type_List.Clear();
        }
    }
}
