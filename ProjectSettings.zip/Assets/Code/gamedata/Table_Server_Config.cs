using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 服务器配置
    ///</summary>
    [Serializable]
    [TableName("server_config")]
    public partial class Table_Server_Config : TableContent
    {

        private static List<Table_Server_Config> all_Table_Server_Config_List = new List<Table_Server_Config>();
        //primary | 主键
        public static Dictionary<string, Table_Server_Config > pool_primary = new Dictionary<string, Table_Server_Config > ();
        
        
        ///<summary>
        /// 主键：配置key
        ///</summary>
        public string id;
        
        
        ///<summary>
        /// 数据
        ///</summary>
        public string data;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：配置key</param>
        ///
        public static Table_Server_Config GetPrimary ( string _id ){        
            Table_Server_Config _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<string, Table_Server_Config > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Server_Config> GetAllPrimaryList()
        {
            return all_Table_Server_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = _currValue;
            }
            if(_itemData.TryGetValue("data", out _currValue))
            {
                this.data = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "server_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "data":
                    return this.data;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Server_Config> rows = _rows as List<Table_Server_Config>;
            pool_primary=TableContent.ListToPool < string, Table_Server_Config > ( rows, "map", "id" );
            all_Table_Server_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Server_Config_List.Clear();
        }
    }
}
