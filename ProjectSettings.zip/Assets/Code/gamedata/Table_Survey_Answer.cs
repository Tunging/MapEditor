using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 问卷调查答案
    ///</summary>
    [Serializable]
    [TableName("survey_answer")]
    public partial class Table_Survey_Answer : TableContent
    {

        private static List<Table_Survey_Answer> all_Table_Survey_Answer_List = new List<Table_Survey_Answer>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Survey_Answer > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Survey_Answer > > > ();
        
        
        ///<summary>
        /// 主键：ID 问卷id
        ///</summary>
        public int survey_id;
        
        
        ///<summary>
        /// 主键：ID 问题id
        ///</summary>
        public int question_id;
        
        
        ///<summary>
        /// 主键:ID  答案id
        ///</summary>
        public int answer_id;
        
        
        ///<summary>
        /// 是否是选择题
        ///</summary>
        public bool select;
        
        
        ///<summary>
        /// 答案描述
        ///</summary>
        public string desc;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param surveyId> 主键：ID 问卷id</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Survey_Answer > > GetPrimary ( int _surveyId ){        
            Dictionary<int, Dictionary<int, Table_Survey_Answer > > _map0=null;        
            pool_primary. TryGetValue(_surveyId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param surveyId> 主键：ID 问卷id</param>
        ///	<param questionId> 主键：ID 问题id</param>
        ///
        public static Dictionary<int, Table_Survey_Answer > GetPrimary ( int _surveyId , int _questionId ){        
            Dictionary<int, Dictionary<int, Table_Survey_Answer > > _map0=null;        
            pool_primary. TryGetValue(_surveyId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Survey_Answer > _map1=null;        
            _map0. TryGetValue(_questionId,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param surveyId> 主键：ID 问卷id</param>
        ///	<param questionId> 主键：ID 问题id</param>
        ///	<param answerId> 主键:ID  答案id</param>
        ///
        public static Table_Survey_Answer GetPrimary ( int _surveyId , int _questionId , int _answerId ){        
            Dictionary<int, Dictionary<int, Table_Survey_Answer > > _map0=null;        
            pool_primary. TryGetValue(_surveyId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Survey_Answer > _map1=null;        
            _map0. TryGetValue(_questionId,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Survey_Answer _map2=null;        
            _map1. TryGetValue(_answerId,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Survey_Answer > > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Survey_Answer> GetAllPrimaryList()
        {
            return all_Table_Survey_Answer_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("survey_id", out _currValue))
            {
                this.survey_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("question_id", out _currValue))
            {
                this.question_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("answer_id", out _currValue))
            {
                this.answer_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("select", out _currValue))
            {
                this.select = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("desc", out _currValue))
            {
                this.desc = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "survey_answer";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "survey_id":
                    return this.survey_id;
                case "question_id":
                    return this.question_id;
                case "answer_id":
                    return this.answer_id;
                case "select":
                    return this.select;
                case "desc":
                    return this.desc;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Survey_Answer> rows = _rows as List<Table_Survey_Answer>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Survey_Answer > ( rows, "map", "survey_id", "question_id", "answer_id" );
            all_Table_Survey_Answer_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Survey_Answer_List.Clear();
        }
    }
}
