using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 道具
    ///</summary>
    [Serializable]
    [TableName("item")]
    public partial class Table_Item : TableContent
    {

        private static List<Table_Item> all_Table_Item_List = new List<Table_Item>();
        //primary | 主键
        public static Dictionary<int, Table_Item > pool_primary = new Dictionary<int, Table_Item > ();
        
        
        ///<summary>
        /// 主键：道具ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 道具类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 图标ID
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 品质
        ///</summary>
        public int quality;
        
        
        ///<summary>
        /// 物品等级（限制使用等级下限）
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 物品星级（限制使用星级下限）
        ///</summary>
        public int star;
        
        
        ///<summary>
        /// 绑定类型
        ///</summary>
        public int bind_type;
        
        
        ///<summary>
        /// 限制使用等级上限
        ///</summary>
        public int limit_level_max;
        
        
        ///<summary>
        /// 限制使用星级上限
        ///</summary>
        public int limit_star_max;
        
        
        ///<summary>
        /// 限制使用职业
        ///</summary>
        public int limit_profession;
        
        
        ///<summary>
        /// 重要物品
        ///</summary>
        public bool important;
        
        
        ///<summary>
        /// 掉落模型ID
        ///</summary>
        public int drop_model;
        
        
        ///<summary>
        /// 掉落模型大小
        ///</summary>
        public float drop_model_size;
        
        
        ///<summary>
        /// 掉落：是否显示名称
        ///</summary>
        public bool drop_show_name;
        
        
        ///<summary>
        /// 掉落特效ID
        ///</summary>
        public int drop_light_halo_effect;
        
        
        ///<summary>
        /// 掉落声音
        ///</summary>
        public int drop_video;
        
        
        ///<summary>
        /// 掉落物拾取声音
        ///</summary>
        public int drop_collect_video;
        
        
        ///<summary>
        /// 掉落：是否显示光束
        ///</summary>
        public bool drop_show_light_beam;
        
        
        ///<summary>
        /// 掉落物拾取特效
        ///</summary>
        public int drop_collect_effect;
        
        
        ///<summary>
        /// 掉落动画配置
        ///</summary>
        public int drop_animation_config;
        
        
        ///<summary>
        /// 掉落物的拾取半径
        ///</summary>
        public float drop_pick_up_radius;
        
        
        ///<summary>
        /// 使用奖励
        ///</summary>
        public int use_reward_id;
        
        
        ///<summary>
        /// 使用动作
        ///</summary>
        public int use_action;
        
        
        ///<summary>
        /// 使用特效
        ///</summary>
        public int use_effect;
        
        
        ///<summary>
        /// 使用时间(ms)
        ///</summary>
        public int use_time;
        
        
        ///<summary>
        /// 限制使用次数类型（0：不限制，1:天,2:周,3:月）
        ///</summary>
        public int limit_use_count_type;
        
        
        ///<summary>
        /// 限制使用次数
        ///</summary>
        public int limit_use_count;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 使用描述国际化
        ///</summary>
        public string use_description_i18n;
        
        
        ///<summary>
        /// 特殊描述国际化
        ///</summary>
        public string special_description_i18n;
        
        
        ///<summary>
        /// 小地图雷达显示图标
        ///</summary>
        public int radar_icon;
        
        
        ///<summary>
        /// 合成配方ID
        ///</summary>
        public int synthetize_formula_id;
        
        
        ///<summary>
        /// 丢弃获得道具ID
        ///</summary>
        public int discard_gain_item_id;
        
        
        ///<summary>
        /// 丢弃获得道具数量
        ///</summary>
        public int discard_gain_item_num;
        
        
        ///<summary>
        /// 回收消耗道具ID
        ///</summary>
        public int recycle_cost_item_id;
        
        
        ///<summary>
        /// 回收消耗道具数量
        ///</summary>
        public int recycle_cost_item_num;
        
        
        ///<summary>
        /// 获取途径（;分隔）
        ///</summary>
        public string gain_way;
        
        
        ///<summary>
        /// 获得后的有效时间（分钟，0：一直有效）
        ///</summary>
        public int effective_time;
        
        
        ///<summary>
        /// 生效开始时间
        ///</summary>
        public string effective_start_time;
        
        
        ///<summary>
        /// 生效结束时间
        ///</summary>
        public string effective_end_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：道具ID</param>
        ///
        public static Table_Item GetPrimary ( int _id ){        
            Table_Item _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Item > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Item> GetAllPrimaryList()
        {
            return all_Table_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("quality", out _currValue))
            {
                this.quality = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star", out _currValue))
            {
                this.star = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("bind_type", out _currValue))
            {
                this.bind_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_level_max", out _currValue))
            {
                this.limit_level_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_star_max", out _currValue))
            {
                this.limit_star_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_profession", out _currValue))
            {
                this.limit_profession = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("important", out _currValue))
            {
                this.important = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_model", out _currValue))
            {
                this.drop_model = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_model_size", out _currValue))
            {
                this.drop_model_size = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_show_name", out _currValue))
            {
                this.drop_show_name = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_light_halo_effect", out _currValue))
            {
                this.drop_light_halo_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_video", out _currValue))
            {
                this.drop_video = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_collect_video", out _currValue))
            {
                this.drop_collect_video = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_show_light_beam", out _currValue))
            {
                this.drop_show_light_beam = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_collect_effect", out _currValue))
            {
                this.drop_collect_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_animation_config", out _currValue))
            {
                this.drop_animation_config = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("drop_pick_up_radius", out _currValue))
            {
                this.drop_pick_up_radius = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_reward_id", out _currValue))
            {
                this.use_reward_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_action", out _currValue))
            {
                this.use_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_effect", out _currValue))
            {
                this.use_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_time", out _currValue))
            {
                this.use_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_use_count_type", out _currValue))
            {
                this.limit_use_count_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_use_count", out _currValue))
            {
                this.limit_use_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("use_description_i18n", out _currValue))
            {
                this.use_description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("special_description_i18n", out _currValue))
            {
                this.special_description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("radar_icon", out _currValue))
            {
                this.radar_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("synthetize_formula_id", out _currValue))
            {
                this.synthetize_formula_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("discard_gain_item_id", out _currValue))
            {
                this.discard_gain_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("discard_gain_item_num", out _currValue))
            {
                this.discard_gain_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("recycle_cost_item_id", out _currValue))
            {
                this.recycle_cost_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("recycle_cost_item_num", out _currValue))
            {
                this.recycle_cost_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gain_way", out _currValue))
            {
                this.gain_way = _currValue;
            }
            if(_itemData.TryGetValue("effective_time", out _currValue))
            {
                this.effective_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effective_start_time", out _currValue))
            {
                this.effective_start_time = _currValue;
            }
            if(_itemData.TryGetValue("effective_end_time", out _currValue))
            {
                this.effective_end_time = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "type":
                    return this.type;
                case "icon_id":
                    return this.icon_id;
                case "quality":
                    return this.quality;
                case "level":
                    return this.level;
                case "star":
                    return this.star;
                case "bind_type":
                    return this.bind_type;
                case "limit_level_max":
                    return this.limit_level_max;
                case "limit_star_max":
                    return this.limit_star_max;
                case "limit_profession":
                    return this.limit_profession;
                case "important":
                    return this.important;
                case "drop_model":
                    return this.drop_model;
                case "drop_model_size":
                    return this.drop_model_size;
                case "drop_show_name":
                    return this.drop_show_name;
                case "drop_light_halo_effect":
                    return this.drop_light_halo_effect;
                case "drop_video":
                    return this.drop_video;
                case "drop_collect_video":
                    return this.drop_collect_video;
                case "drop_show_light_beam":
                    return this.drop_show_light_beam;
                case "drop_collect_effect":
                    return this.drop_collect_effect;
                case "drop_animation_config":
                    return this.drop_animation_config;
                case "drop_pick_up_radius":
                    return this.drop_pick_up_radius;
                case "use_reward_id":
                    return this.use_reward_id;
                case "use_action":
                    return this.use_action;
                case "use_effect":
                    return this.use_effect;
                case "use_time":
                    return this.use_time;
                case "limit_use_count_type":
                    return this.limit_use_count_type;
                case "limit_use_count":
                    return this.limit_use_count;
                case "description_i18n":
                    return this.description_i18n;
                case "use_description_i18n":
                    return this.use_description_i18n;
                case "special_description_i18n":
                    return this.special_description_i18n;
                case "radar_icon":
                    return this.radar_icon;
                case "synthetize_formula_id":
                    return this.synthetize_formula_id;
                case "discard_gain_item_id":
                    return this.discard_gain_item_id;
                case "discard_gain_item_num":
                    return this.discard_gain_item_num;
                case "recycle_cost_item_id":
                    return this.recycle_cost_item_id;
                case "recycle_cost_item_num":
                    return this.recycle_cost_item_num;
                case "gain_way":
                    return this.gain_way;
                case "effective_time":
                    return this.effective_time;
                case "effective_start_time":
                    return this.effective_start_time;
                case "effective_end_time":
                    return this.effective_end_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Item> rows = _rows as List<Table_Item>;
            pool_primary=TableContent.ListToPool < int, Table_Item > ( rows, "map", "id" );
            all_Table_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Item_List.Clear();
        }
    }
}
