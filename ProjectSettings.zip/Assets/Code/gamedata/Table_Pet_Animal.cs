using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物表
    ///</summary>
    [Serializable]
    [TableName("pet_animal")]
    public partial class Table_Pet_Animal : TableContent
    {

        private static List<Table_Pet_Animal> all_Table_Pet_Animal_List = new List<Table_Pet_Animal>();
        //primary | 主键
        public static Dictionary<int, Table_Pet_Animal > pool_primary = new Dictionary<int, Table_Pet_Animal > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 星级
        ///</summary>
        public int star;
        
        
        ///<summary>
        /// 宠物名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 标签icon
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 头像icon
        ///</summary>
        public int head_icon;
        
        
        ///<summary>
        /// 模型id
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 缩放比例
        ///</summary>
        public int scale;
        
        
        ///<summary>
        /// 能量最大值
        ///</summary>
        public int energy;
        
        
        ///<summary>
        /// 技能组id
        ///</summary>
        public int skill_group_id;
        
        
        ///<summary>
        /// 宠物类型
        ///</summary>
        public int kind;
        
        
        ///<summary>
        /// 说话最小间隔
        ///</summary>
        public int talk_min;
        
        
        ///<summary>
        /// 说话最大间隔
        ///</summary>
        public int talk_max;
        
        
        ///<summary>
        /// 说话类型0顺序1随机
        ///</summary>
        public int talk_type;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Pet_Animal GetPrimary ( int _id ){        
            Table_Pet_Animal _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Pet_Animal > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Pet_Animal> GetAllPrimaryList()
        {
            return all_Table_Pet_Animal_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star", out _currValue))
            {
                this.star = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("head_icon", out _currValue))
            {
                this.head_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scale", out _currValue))
            {
                this.scale = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("energy", out _currValue))
            {
                this.energy = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group_id", out _currValue))
            {
                this.skill_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("kind", out _currValue))
            {
                this.kind = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talk_min", out _currValue))
            {
                this.talk_min = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talk_max", out _currValue))
            {
                this.talk_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talk_type", out _currValue))
            {
                this.talk_type = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet_animal";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "star":
                    return this.star;
                case "name_i18n":
                    return this.name_i18n;
                case "icon":
                    return this.icon;
                case "head_icon":
                    return this.head_icon;
                case "model_id":
                    return this.model_id;
                case "scale":
                    return this.scale;
                case "energy":
                    return this.energy;
                case "skill_group_id":
                    return this.skill_group_id;
                case "kind":
                    return this.kind;
                case "talk_min":
                    return this.talk_min;
                case "talk_max":
                    return this.talk_max;
                case "talk_type":
                    return this.talk_type;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet_Animal> rows = _rows as List<Table_Pet_Animal>;
            pool_primary=TableContent.ListToPool < int, Table_Pet_Animal > ( rows, "map", "id" );
            all_Table_Pet_Animal_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Pet_Animal_List.Clear();
        }
    }
}
