using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景lod精灵类型
    ///</summary>
    [Serializable]
    [TableName("scene_lod_sprite_type")]
    public partial class Table_Scene_Lod_Sprite_Type : TableContent
    {

        private static List<Table_Scene_Lod_Sprite_Type> all_Table_Scene_Lod_Sprite_Type_List = new List<Table_Scene_Lod_Sprite_Type>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Lod_Sprite_Type > pool_primary = new Dictionary<int, Table_Scene_Lod_Sprite_Type > ();
        
        
        ///<summary>
        /// 主键ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键ID</param>
        ///
        public static Table_Scene_Lod_Sprite_Type GetPrimary ( int _id ){        
            Table_Scene_Lod_Sprite_Type _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Lod_Sprite_Type > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Lod_Sprite_Type> GetAllPrimaryList()
        {
            return all_Table_Scene_Lod_Sprite_Type_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_lod_sprite_type";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Lod_Sprite_Type> rows = _rows as List<Table_Scene_Lod_Sprite_Type>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Lod_Sprite_Type > ( rows, "map", "id" );
            all_Table_Scene_Lod_Sprite_Type_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Lod_Sprite_Type_List.Clear();
        }
    }
}
