using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本触发器
    ///</summary>
    [Serializable]
    [TableName("trigger_config")]
    public partial class Table_Trigger_Config : TableContent
    {

        private static List<Table_Trigger_Config> all_Table_Trigger_Config_List = new List<Table_Trigger_Config>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Trigger_Config > > pool_primary = new Dictionary<int, Dictionary<int, Table_Trigger_Config > > ();
        
        
        ///<summary>
        /// 
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string marks;
        
        
        ///<summary>
        /// 触发条件
        ///</summary>
        public string trigger_condition;
        
        
        ///<summary>
        /// 触发行为
        ///</summary>
        public string trigger_action;
        
        
        ///<summary>
        /// 触发后自动移除
        ///</summary>
        public bool remove_after_triggered;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> </param>
        ///
        public static Dictionary<int, Table_Trigger_Config > GetPrimary ( int _groupId ){        
            Dictionary<int, Table_Trigger_Config > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> </param>
        ///	<param id> </param>
        ///
        public static Table_Trigger_Config GetPrimary ( int _groupId , int _id ){        
            Dictionary<int, Table_Trigger_Config > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Trigger_Config _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Trigger_Config > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Trigger_Config> GetAllPrimaryList()
        {
            return all_Table_Trigger_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("marks", out _currValue))
            {
                this.marks = _currValue;
            }
            if(_itemData.TryGetValue("trigger_condition", out _currValue))
            {
                this.trigger_condition = _currValue;
            }
            if(_itemData.TryGetValue("trigger_action", out _currValue))
            {
                this.trigger_action = _currValue;
            }
            if(_itemData.TryGetValue("remove_after_triggered", out _currValue))
            {
                this.remove_after_triggered = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "trigger_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "group_id":
                    return this.group_id;
                case "id":
                    return this.id;
                case "marks":
                    return this.marks;
                case "trigger_condition":
                    return this.trigger_condition;
                case "trigger_action":
                    return this.trigger_action;
                case "remove_after_triggered":
                    return this.remove_after_triggered;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Trigger_Config> rows = _rows as List<Table_Trigger_Config>;
            pool_primary=TableContent.ListToPool < int, int, Table_Trigger_Config > ( rows, "map", "group_id", "id" );
            all_Table_Trigger_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Trigger_Config_List.Clear();
        }
    }
}
