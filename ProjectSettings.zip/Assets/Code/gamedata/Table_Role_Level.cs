using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 角色等级经验
    ///</summary>
    [Serializable]
    [TableName("role_level")]
    public partial class Table_Role_Level : TableContent
    {

        private static List<Table_Role_Level> all_Table_Role_Level_List = new List<Table_Role_Level>();
        //primary | 主键
        public static Dictionary<int, Table_Role_Level > pool_primary = new Dictionary<int, Table_Role_Level > ();
        
        
        ///<summary>
        /// 主键：角色等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 升级所需的经验值，-1代表不可升级
        ///</summary>
        public long experience;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param level> 主键：角色等级</param>
        ///
        public static Table_Role_Level GetPrimary ( int _level ){        
            Table_Role_Level _map0=null;        
            pool_primary. TryGetValue(_level,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Role_Level > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Role_Level> GetAllPrimaryList()
        {
            return all_Table_Role_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("experience", out _currValue))
            {
                this.experience = Utils.GetLongFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "role_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "level":
                    return this.level;
                case "experience":
                    return this.experience;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Role_Level> rows = _rows as List<Table_Role_Level>;
            pool_primary=TableContent.ListToPool < int, Table_Role_Level > ( rows, "map", "level" );
            all_Table_Role_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Role_Level_List.Clear();
        }
    }
}
