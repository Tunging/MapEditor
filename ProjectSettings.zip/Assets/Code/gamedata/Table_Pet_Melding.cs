using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物融合
    ///</summary>
    [Serializable]
    [TableName("pet_melding")]
    public partial class Table_Pet_Melding : TableContent
    {

        private static List<Table_Pet_Melding> all_Table_Pet_Melding_List = new List<Table_Pet_Melding>();
        //primary | 主键
        public static Dictionary<int, Table_Pet_Melding > pool_primary = new Dictionary<int, Table_Pet_Melding > ();
        
        
        ///<summary>
        /// 主键：星级
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 成功概率(10000分制)
        ///</summary>
        public int pro;
        
        
        ///<summary>
        /// 保命符道具ID
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 保命符数量
        ///</summary>
        public int item_count;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：星级</param>
        ///
        public static Table_Pet_Melding GetPrimary ( int _id ){        
            Table_Pet_Melding _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Pet_Melding > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Pet_Melding> GetAllPrimaryList()
        {
            return all_Table_Pet_Melding_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pro", out _currValue))
            {
                this.pro = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_count", out _currValue))
            {
                this.item_count = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet_melding";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "pro":
                    return this.pro;
                case "item_id":
                    return this.item_id;
                case "item_count":
                    return this.item_count;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet_Melding> rows = _rows as List<Table_Pet_Melding>;
            pool_primary=TableContent.ListToPool < int, Table_Pet_Melding > ( rows, "map", "id" );
            all_Table_Pet_Melding_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Pet_Melding_List.Clear();
        }
    }
}
