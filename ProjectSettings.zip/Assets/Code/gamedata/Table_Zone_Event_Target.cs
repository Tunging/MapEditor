using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 区域事件目标
    ///</summary>
    [Serializable]
    [TableName("zone_event_target")]
    public partial class Table_Zone_Event_Target : TableContent
    {

        private static List<Table_Zone_Event_Target> all_Table_Zone_Event_Target_List = new List<Table_Zone_Event_Target>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Zone_Event_Target > > pool_primary = new Dictionary<int, Dictionary<int, Table_Zone_Event_Target > > ();
        
        
        ///<summary>
        /// 场景事件ID
        ///</summary>
        public int event_id;
        
        
        ///<summary>
        /// 目标编号
        ///</summary>
        public int target_no;
        
        
        ///<summary>
        /// 目标类型
        ///</summary>
        public int target_type;
        
        
        ///<summary>
        /// 目标描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 目标描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 目标总进度
        ///</summary>
        public int total_progress;
        
        
        ///<summary>
        /// 单次增加进度
        ///</summary>
        public int add_progress;
        
        
        ///<summary>
        /// 参数1
        ///</summary>
        public int param;
        
        
        ///<summary>
        /// 参数2
        ///</summary>
        public int param2;
        
        
        ///<summary>
        /// 参数3
        ///</summary>
        public int param3;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param eventId> 场景事件ID</param>
        ///
        public static Dictionary<int, Table_Zone_Event_Target > GetPrimary ( int _eventId ){        
            Dictionary<int, Table_Zone_Event_Target > _map0=null;        
            pool_primary. TryGetValue(_eventId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param eventId> 场景事件ID</param>
        ///	<param targetNo> 目标编号</param>
        ///
        public static Table_Zone_Event_Target GetPrimary ( int _eventId , int _targetNo ){        
            Dictionary<int, Table_Zone_Event_Target > _map0=null;        
            pool_primary. TryGetValue(_eventId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Zone_Event_Target _map1=null;        
            _map0. TryGetValue(_targetNo,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Zone_Event_Target > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Zone_Event_Target> GetAllPrimaryList()
        {
            return all_Table_Zone_Event_Target_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("event_id", out _currValue))
            {
                this.event_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_no", out _currValue))
            {
                this.target_no = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_type", out _currValue))
            {
                this.target_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("total_progress", out _currValue))
            {
                this.total_progress = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("add_progress", out _currValue))
            {
                this.add_progress = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param", out _currValue))
            {
                this.param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param2", out _currValue))
            {
                this.param2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param3", out _currValue))
            {
                this.param3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "zone_event_target";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "event_id":
                    return this.event_id;
                case "target_no":
                    return this.target_no;
                case "target_type":
                    return this.target_type;
                case "description":
                    return this.description;
                case "description_i18n":
                    return this.description_i18n;
                case "total_progress":
                    return this.total_progress;
                case "add_progress":
                    return this.add_progress;
                case "param":
                    return this.param;
                case "param2":
                    return this.param2;
                case "param3":
                    return this.param3;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Zone_Event_Target> rows = _rows as List<Table_Zone_Event_Target>;
            pool_primary=TableContent.ListToPool < int, int, Table_Zone_Event_Target > ( rows, "map", "event_id", "target_no" );
            all_Table_Zone_Event_Target_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Zone_Event_Target_List.Clear();
        }
    }
}
