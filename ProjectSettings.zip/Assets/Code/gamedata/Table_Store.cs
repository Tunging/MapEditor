using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 商店
    ///</summary>
    [Serializable]
    [TableName("store")]
    public partial class Table_Store : TableContent
    {

        private static List<Table_Store> all_Table_Store_List = new List<Table_Store>();
        //primary | 主键
        public static Dictionary<int, Table_Store > pool_primary = new Dictionary<int, Table_Store > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 商店icon
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 商店名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 刷新方式0、无刷新1、定时自动刷新2、间隔自动刷新3、定时手动刷新4、间隔手动刷新
        ///</summary>
        public int refresh;
        
        
        ///<summary>
        /// 是否可以消耗道具刷新
        ///</summary>
        public bool buy_refresh;
        
        
        ///<summary>
        /// 刷新参数定时刷新填写时间,井号分号分割，间隔刷新填写间隔多少毫秒
        ///</summary>
        public string params1;
        
        
        ///<summary>
        /// 累计刷新次数最大值
        ///</summary>
        public int manual_refresh_free_limit;
        
        
        ///<summary>
        /// 刷新消耗的道具
        ///</summary>
        public int refresh_item_id;
        
        
        ///<summary>
        /// 刷新消耗道具数量
        ///</summary>
        public int refresh_item_num;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Table_Store GetPrimary ( int _id ){        
            Table_Store _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Store > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Store> GetAllPrimaryList()
        {
            return all_Table_Store_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("refresh", out _currValue))
            {
                this.refresh = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("buy_refresh", out _currValue))
            {
                this.buy_refresh = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("params1", out _currValue))
            {
                this.params1 = _currValue;
            }
            if(_itemData.TryGetValue("manual_refresh_free_limit", out _currValue))
            {
                this.manual_refresh_free_limit = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refresh_item_id", out _currValue))
            {
                this.refresh_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refresh_item_num", out _currValue))
            {
                this.refresh_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "store";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "icon":
                    return this.icon;
                case "type":
                    return this.type;
                case "name_i18n":
                    return this.name_i18n;
                case "refresh":
                    return this.refresh;
                case "buy_refresh":
                    return this.buy_refresh;
                case "params1":
                    return this.params1;
                case "manual_refresh_free_limit":
                    return this.manual_refresh_free_limit;
                case "refresh_item_id":
                    return this.refresh_item_id;
                case "refresh_item_num":
                    return this.refresh_item_num;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Store> rows = _rows as List<Table_Store>;
            pool_primary=TableContent.ListToPool < int, Table_Store > ( rows, "map", "id" );
            all_Table_Store_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Store_List.Clear();
        }
    }
}
