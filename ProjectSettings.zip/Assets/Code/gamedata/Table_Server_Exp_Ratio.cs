using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 服务器经验加成倍率
    ///</summary>
    [Serializable]
    [TableName("server_exp_ratio")]
    public partial class Table_Server_Exp_Ratio : TableContent
    {

        private static List<Table_Server_Exp_Ratio> all_Table_Server_Exp_Ratio_List = new List<Table_Server_Exp_Ratio>();
        //primary | 主键
        public static Dictionary<int, Table_Server_Exp_Ratio > pool_primary = new Dictionary<int, Table_Server_Exp_Ratio > ();
        //diff | 
        public static Dictionary<int, Table_Server_Exp_Ratio > pool_diff = new Dictionary<int, Table_Server_Exp_Ratio > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 等级差(角色等级与服务器等级差)
        ///</summary>
        public int level_diff;
        
        
        ///<summary>
        /// 经验倍率(1000的倍数)
        ///</summary>
        public int exp_ratio;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Server_Exp_Ratio GetPrimary ( int _id ){        
            Table_Server_Exp_Ratio _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Server_Exp_Ratio > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param levelDiff> 等级差(角色等级与服务器等级差)</param>
        ///
        public static Table_Server_Exp_Ratio GetDiff ( int _levelDiff ){        
            Table_Server_Exp_Ratio _map0=null;        
            pool_diff. TryGetValue(_levelDiff,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Server_Exp_Ratio > GetAllDiff()
        {
            return pool_diff;
        }


        ///查询出所有的数据
        public static List<Table_Server_Exp_Ratio> GetAllPrimaryList()
        {
            return all_Table_Server_Exp_Ratio_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level_diff", out _currValue))
            {
                this.level_diff = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("exp_ratio", out _currValue))
            {
                this.exp_ratio = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "server_exp_ratio";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "level_diff":
                    return this.level_diff;
                case "exp_ratio":
                    return this.exp_ratio;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Server_Exp_Ratio> rows = _rows as List<Table_Server_Exp_Ratio>;
            pool_primary=TableContent.ListToPool < int, Table_Server_Exp_Ratio > ( rows, "map", "id" );
            pool_diff=TableContent.ListToPool < int, Table_Server_Exp_Ratio > ( rows, "map", "level_diff" );
            all_Table_Server_Exp_Ratio_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_diff.Clear();
            all_Table_Server_Exp_Ratio_List.Clear();
        }
    }
}
