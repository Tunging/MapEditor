using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 导师对话操作表
    ///</summary>
    [Serializable]
    [TableName("mentor_dialog_operation")]
    public partial class Table_Mentor_Dialog_Operation : TableContent
    {

        private static List<Table_Mentor_Dialog_Operation> all_Table_Mentor_Dialog_Operation_List = new List<Table_Mentor_Dialog_Operation>();
        //primary | 主键
        public static Dictionary<int, Table_Mentor_Dialog_Operation > pool_primary = new Dictionary<int, Table_Mentor_Dialog_Operation > ();
        
        
        ///<summary>
        /// 操作ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 是否开启导师界面
        ///</summary>
        public bool open_mentor_ui;
        
        
        ///<summary>
        /// 是否打开天赋界面
        ///</summary>
        public bool open_talent_ui;
        
        
        ///<summary>
        /// 否要进行导师每日副本
        ///</summary>
        public bool is_mentor_instance;
        
        
        ///<summary>
        /// 导师ID
        ///</summary>
        public int mentor_id;
        
        
        ///<summary>
        /// 解锁天赋ID
        ///</summary>
        public int talent_id;
        
        
        ///<summary>
        /// 显示天赋ID
        ///</summary>
        public int show_talent_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 操作ID</param>
        ///
        public static Table_Mentor_Dialog_Operation GetPrimary ( int _id ){        
            Table_Mentor_Dialog_Operation _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mentor_Dialog_Operation > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mentor_Dialog_Operation> GetAllPrimaryList()
        {
            return all_Table_Mentor_Dialog_Operation_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("open_mentor_ui", out _currValue))
            {
                this.open_mentor_ui = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("open_talent_ui", out _currValue))
            {
                this.open_talent_ui = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_mentor_instance", out _currValue))
            {
                this.is_mentor_instance = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("mentor_id", out _currValue))
            {
                this.mentor_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talent_id", out _currValue))
            {
                this.talent_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_talent_id", out _currValue))
            {
                this.show_talent_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mentor_dialog_operation";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "open_mentor_ui":
                    return this.open_mentor_ui;
                case "open_talent_ui":
                    return this.open_talent_ui;
                case "is_mentor_instance":
                    return this.is_mentor_instance;
                case "mentor_id":
                    return this.mentor_id;
                case "talent_id":
                    return this.talent_id;
                case "show_talent_id":
                    return this.show_talent_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mentor_Dialog_Operation> rows = _rows as List<Table_Mentor_Dialog_Operation>;
            pool_primary=TableContent.ListToPool < int, Table_Mentor_Dialog_Operation > ( rows, "map", "id" );
            all_Table_Mentor_Dialog_Operation_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mentor_Dialog_Operation_List.Clear();
        }
    }
}
