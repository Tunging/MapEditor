using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 导师等级表
    ///</summary>
    [Serializable]
    [TableName("mentor_preference_level")]
    public partial class Table_Mentor_Preference_Level : TableContent
    {

        private static List<Table_Mentor_Preference_Level> all_Table_Mentor_Preference_Level_List = new List<Table_Mentor_Preference_Level>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Mentor_Preference_Level > > pool_primary = new Dictionary<int, Dictionary<int, Table_Mentor_Preference_Level > > ();
        
        
        ///<summary>
        /// 导师ID
        ///</summary>
        public int mentor_id;
        
        
        ///<summary>
        /// 好感度等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 升级所需的好感度
        ///</summary>
        public int up_preference;
        
        
        ///<summary>
        /// 等级称谓国际化
        ///</summary>
        public string title_i18;
        
        
        ///<summary>
        /// 开启内容描述
        ///</summary>
        public string open_content;
        
        
        ///<summary>
        /// 开启内容描述国际化
        ///</summary>
        public string open_content_u18n;
        
        
        ///<summary>
        /// 升级奖励
        ///</summary>
        public int reward_id;
        
        
        ///<summary>
        /// 进阶副本
        ///</summary>
        public int jinjie_instance;
        
        
        ///<summary>
        /// 进阶开启内容
        ///</summary>
        public string jinjie_open_content;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param mentorId> 导师ID</param>
        ///
        public static Dictionary<int, Table_Mentor_Preference_Level > GetPrimary ( int _mentorId ){        
            Dictionary<int, Table_Mentor_Preference_Level > _map0=null;        
            pool_primary. TryGetValue(_mentorId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param mentorId> 导师ID</param>
        ///	<param level> 好感度等级</param>
        ///
        public static Table_Mentor_Preference_Level GetPrimary ( int _mentorId , int _level ){        
            Dictionary<int, Table_Mentor_Preference_Level > _map0=null;        
            pool_primary. TryGetValue(_mentorId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Mentor_Preference_Level _map1=null;        
            _map0. TryGetValue(_level,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Mentor_Preference_Level > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mentor_Preference_Level> GetAllPrimaryList()
        {
            return all_Table_Mentor_Preference_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("mentor_id", out _currValue))
            {
                this.mentor_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("up_preference", out _currValue))
            {
                this.up_preference = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("title_i18", out _currValue))
            {
                this.title_i18 = _currValue;
            }
            if(_itemData.TryGetValue("open_content", out _currValue))
            {
                this.open_content = _currValue;
            }
            if(_itemData.TryGetValue("open_content_u18n", out _currValue))
            {
                this.open_content_u18n = _currValue;
            }
            if(_itemData.TryGetValue("reward_id", out _currValue))
            {
                this.reward_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("jinjie_instance", out _currValue))
            {
                this.jinjie_instance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("jinjie_open_content", out _currValue))
            {
                this.jinjie_open_content = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mentor_preference_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "mentor_id":
                    return this.mentor_id;
                case "level":
                    return this.level;
                case "up_preference":
                    return this.up_preference;
                case "title_i18":
                    return this.title_i18;
                case "open_content":
                    return this.open_content;
                case "open_content_u18n":
                    return this.open_content_u18n;
                case "reward_id":
                    return this.reward_id;
                case "jinjie_instance":
                    return this.jinjie_instance;
                case "jinjie_open_content":
                    return this.jinjie_open_content;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mentor_Preference_Level> rows = _rows as List<Table_Mentor_Preference_Level>;
            pool_primary=TableContent.ListToPool < int, int, Table_Mentor_Preference_Level > ( rows, "map", "mentor_id", "level" );
            all_Table_Mentor_Preference_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mentor_Preference_Level_List.Clear();
        }
    }
}
