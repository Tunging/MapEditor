using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端触碰采集物
    ///</summary>
    [Serializable]
    [TableName("scene_gather_offline")]
    public partial class Table_Scene_Gather_Offline : TableContent
    {

        private static List<Table_Scene_Gather_Offline> all_Table_Scene_Gather_Offline_List = new List<Table_Scene_Gather_Offline>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Gather_Offline > pool_primary = new Dictionary<int, Table_Scene_Gather_Offline > ();
        //sceneId | 
        public static Dictionary<int, List<Table_Scene_Gather_Offline> > pool_sceneId = new Dictionary<int, List<Table_Scene_Gather_Offline> > ();
        //sceneGather | 
        public static Dictionary<int, Dictionary<int, Table_Scene_Gather_Offline > > pool_sceneGather = new Dictionary<int, Dictionary<int, Table_Scene_Gather_Offline > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 场景id
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 坐标x
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// 坐标y
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// 坐标z
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 场景完成度积分
        ///</summary>
        public int completion_socre;
        
        
        ///<summary>
        /// 模型id
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 特效id
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 触发半径
        ///</summary>
        public float trigger_radius;
        
        
        ///<summary>
        /// 采集动作
        ///</summary>
        public int gather_action;
        
        
        ///<summary>
        /// 采集特效id
        ///</summary>
        public int gather_effect;
        
        
        ///<summary>
        /// 碰撞后的飞行到人身上的特效id
        ///</summary>
        public int fly_effect_id;
        
        
        ///<summary>
        /// 采集音效
        ///</summary>
        public int gather_sound;
        
        
        ///<summary>
        /// 采集提示
        ///</summary>
        public string gather_tips;
        
        
        ///<summary>
        /// 采集提示国际化
        ///</summary>
        public string gather_tips_i18n;
        
        
        ///<summary>
        /// 采集奖励
        ///</summary>
        public int reward;
        
        
        ///<summary>
        /// 显示距离
        ///</summary>
        public float show_distance;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// buff id
        ///</summary>
        public int buff_id;
        
        
        ///<summary>
        /// 能否重复采集(下次游戏)
        ///</summary>
        public bool can_gather_multi_times;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Scene_Gather_Offline GetPrimary ( int _id ){        
            Table_Scene_Gather_Offline _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Gather_Offline > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景id</param>
        ///
        public static List<Table_Scene_Gather_Offline> GetSceneId ( int _sceneId ){        
            List<Table_Scene_Gather_Offline> _map0=null;        
            pool_sceneId. TryGetValue(_sceneId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Scene_Gather_Offline> > GetAllSceneId()
        {
            return pool_sceneId;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景id</param>
        ///
        public static Dictionary<int, Table_Scene_Gather_Offline > GetSceneGather ( int _sceneId ){        
            Dictionary<int, Table_Scene_Gather_Offline > _map0=null;        
            pool_sceneGather. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景id</param>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Scene_Gather_Offline GetSceneGather ( int _sceneId , int _id ){        
            Dictionary<int, Table_Scene_Gather_Offline > _map0=null;        
            pool_sceneGather. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Scene_Gather_Offline _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Scene_Gather_Offline > > GetAllSceneGather()
        {
            return pool_sceneGather;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Gather_Offline> GetAllPrimaryList()
        {
            return all_Table_Scene_Gather_Offline_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("completion_socre", out _currValue))
            {
                this.completion_socre = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_radius", out _currValue))
            {
                this.trigger_radius = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_action", out _currValue))
            {
                this.gather_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_effect", out _currValue))
            {
                this.gather_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fly_effect_id", out _currValue))
            {
                this.fly_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_sound", out _currValue))
            {
                this.gather_sound = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_tips", out _currValue))
            {
                this.gather_tips = _currValue;
            }
            if(_itemData.TryGetValue("gather_tips_i18n", out _currValue))
            {
                this.gather_tips_i18n = _currValue;
            }
            if(_itemData.TryGetValue("reward", out _currValue))
            {
                this.reward = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_distance", out _currValue))
            {
                this.show_distance = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("buff_id", out _currValue))
            {
                this.buff_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_gather_multi_times", out _currValue))
            {
                this.can_gather_multi_times = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_gather_offline";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "scene_id":
                    return this.scene_id;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "completion_socre":
                    return this.completion_socre;
                case "model_id":
                    return this.model_id;
                case "effect_id":
                    return this.effect_id;
                case "trigger_radius":
                    return this.trigger_radius;
                case "gather_action":
                    return this.gather_action;
                case "gather_effect":
                    return this.gather_effect;
                case "fly_effect_id":
                    return this.fly_effect_id;
                case "gather_sound":
                    return this.gather_sound;
                case "gather_tips":
                    return this.gather_tips;
                case "gather_tips_i18n":
                    return this.gather_tips_i18n;
                case "reward":
                    return this.reward;
                case "show_distance":
                    return this.show_distance;
                case "name_i18n":
                    return this.name_i18n;
                case "buff_id":
                    return this.buff_id;
                case "can_gather_multi_times":
                    return this.can_gather_multi_times;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Gather_Offline> rows = _rows as List<Table_Scene_Gather_Offline>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Gather_Offline > ( rows, "map", "id" );
            pool_sceneId=TableContent.ListToPoolList < int, Table_Scene_Gather_Offline > ( rows, "list", "scene_id" );
            pool_sceneGather=TableContent.ListToPool < int, int, Table_Scene_Gather_Offline > ( rows, "map", "scene_id", "id" );
            all_Table_Scene_Gather_Offline_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_sceneId.Clear();
            pool_sceneGather.Clear();
            all_Table_Scene_Gather_Offline_List.Clear();
        }
    }
}
