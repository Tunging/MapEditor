using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能组
    ///</summary>
    [Serializable]
    [TableName("skill_group")]
    public partial class Table_Skill_Group : TableContent
    {

        private static List<Table_Skill_Group> all_Table_Skill_Group_List = new List<Table_Skill_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Skill_Group > pool_primary = new Dictionary<int, Table_Skill_Group > ();
        //zoneId | 技能组所属于的区域id
        public static Dictionary<int, List<Table_Skill_Group> > pool_zoneId = new Dictionary<int, List<Table_Skill_Group> > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 技能组所属于的区域id
        ///</summary>
        public int zone_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Skill_Group GetPrimary ( int _id ){        
            Table_Skill_Group _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Skill_Group > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 技能组所属于的区域id
        /// 查询数据
        ///</summary>
        ///	<param zoneId> 技能组所属于的区域id</param>
        ///
        public static List<Table_Skill_Group> GetZoneId ( int _zoneId ){        
            List<Table_Skill_Group> _map0=null;        
            pool_zoneId. TryGetValue(_zoneId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///技能组所属于的区域id
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Skill_Group> > GetAllZoneId()
        {
            return pool_zoneId;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Group> GetAllPrimaryList()
        {
            return all_Table_Skill_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("zone_id", out _currValue))
            {
                this.zone_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "zone_id":
                    return this.zone_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Group> rows = _rows as List<Table_Skill_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Skill_Group > ( rows, "map", "id" );
            pool_zoneId=TableContent.ListToPoolList < int, Table_Skill_Group > ( rows, "list", "zone_id" );
            all_Table_Skill_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_zoneId.Clear();
            all_Table_Skill_Group_List.Clear();
        }
    }
}
