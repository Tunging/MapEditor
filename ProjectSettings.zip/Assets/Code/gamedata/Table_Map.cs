using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 地图基础数据
    ///</summary>
    [Serializable]
    [TableName("map")]
    public partial class Table_Map : TableContent
    {

        private static List<Table_Map> all_Table_Map_List = new List<Table_Map>();
        //primary | 主键
        public static Dictionary<int, Table_Map > pool_primary = new Dictionary<int, Table_Map > ();
        
        
        ///<summary>
        /// 主键：地图ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 资源文件路径
        ///</summary>
        public string path;
        
        
        ///<summary>
        /// X轴最大值
        ///</summary>
        public int max_x;
        
        
        ///<summary>
        /// Y轴最大值
        ///</summary>
        public int max_y;
        
        
        ///<summary>
        /// Z轴最大值
        ///</summary>
        public int max_z;
        
        
        ///<summary>
        /// 环境音id
        ///</summary>
        public int ambient_sound_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：地图ID</param>
        ///
        public static Table_Map GetPrimary ( int _id ){        
            Table_Map _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Map > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Map> GetAllPrimaryList()
        {
            return all_Table_Map_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
            if(_itemData.TryGetValue("max_x", out _currValue))
            {
                this.max_x = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_y", out _currValue))
            {
                this.max_y = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_z", out _currValue))
            {
                this.max_z = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ambient_sound_id", out _currValue))
            {
                this.ambient_sound_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "map";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "path":
                    return this.path;
                case "max_x":
                    return this.max_x;
                case "max_y":
                    return this.max_y;
                case "max_z":
                    return this.max_z;
                case "ambient_sound_id":
                    return this.ambient_sound_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Map> rows = _rows as List<Table_Map>;
            pool_primary=TableContent.ListToPool < int, Table_Map > ( rows, "map", "id" );
            all_Table_Map_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Map_List.Clear();
        }
    }
}
