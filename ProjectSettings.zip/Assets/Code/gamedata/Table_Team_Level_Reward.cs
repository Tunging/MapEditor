using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 队伍等级奖励
    ///</summary>
    [Serializable]
    [TableName("team_level_reward")]
    public partial class Table_Team_Level_Reward : TableContent
    {

        private static List<Table_Team_Level_Reward> all_Table_Team_Level_Reward_List = new List<Table_Team_Level_Reward>();
        //primary | 主键
        public static Dictionary<int, Table_Team_Level_Reward > pool_primary = new Dictionary<int, Table_Team_Level_Reward > ();
        
        
        ///<summary>
        /// 等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 当前等级的经验值
        ///</summary>
        public int max_exp;
        
        
        ///<summary>
        /// 当前等级奖励Id,多个用逗号分开
        ///</summary>
        public string reward;
        
        
        ///<summary>
        /// 队长奖励加成比率
        ///</summary>
        public float leader_rate;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param level> 等级</param>
        ///
        public static Table_Team_Level_Reward GetPrimary ( int _level ){        
            Table_Team_Level_Reward _map0=null;        
            pool_primary. TryGetValue(_level,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Team_Level_Reward > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Team_Level_Reward> GetAllPrimaryList()
        {
            return all_Table_Team_Level_Reward_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_exp", out _currValue))
            {
                this.max_exp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward", out _currValue))
            {
                this.reward = _currValue;
            }
            if(_itemData.TryGetValue("leader_rate", out _currValue))
            {
                this.leader_rate = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "team_level_reward";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "level":
                    return this.level;
                case "max_exp":
                    return this.max_exp;
                case "reward":
                    return this.reward;
                case "leader_rate":
                    return this.leader_rate;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Team_Level_Reward> rows = _rows as List<Table_Team_Level_Reward>;
            pool_primary=TableContent.ListToPool < int, Table_Team_Level_Reward > ( rows, "map", "level" );
            all_Table_Team_Level_Reward_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Team_Level_Reward_List.Clear();
        }
    }
}
