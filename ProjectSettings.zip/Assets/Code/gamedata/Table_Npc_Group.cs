using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc分组
    ///</summary>
    [Serializable]
    [TableName("npc_group")]
    public partial class Table_Npc_Group : TableContent
    {

        private static List<Table_Npc_Group> all_Table_Npc_Group_List = new List<Table_Npc_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Group > pool_primary = new Dictionary<int, Table_Npc_Group > ();
        
        
        ///<summary>
        /// 分组ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 分组名
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 第一次刷新数量
        ///</summary>
        public int first_num;
        
        
        ///<summary>
        /// 最小存在数量
        ///</summary>
        public int min_num;
        
        
        ///<summary>
        /// 每次补充数量
        ///</summary>
        public int each_num;
        
        
        ///<summary>
        /// 最大刷新数量
        ///</summary>
        public int max_count;
        
        
        ///<summary>
        /// 触发当前NPC组刷新的npc模板ID
        ///</summary>
        public int trigger_npc_id;
        
        
        ///<summary>
        /// 触发当前NPC组刷新的npc数量
        ///</summary>
        public int trigger_npc_num;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 分组ID</param>
        ///
        public static Table_Npc_Group GetPrimary ( int _id ){        
            Table_Npc_Group _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Group > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Group> GetAllPrimaryList()
        {
            return all_Table_Npc_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("first_num", out _currValue))
            {
                this.first_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("min_num", out _currValue))
            {
                this.min_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("each_num", out _currValue))
            {
                this.each_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_count", out _currValue))
            {
                this.max_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_npc_id", out _currValue))
            {
                this.trigger_npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_npc_num", out _currValue))
            {
                this.trigger_npc_num = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "scene_id":
                    return this.scene_id;
                case "first_num":
                    return this.first_num;
                case "min_num":
                    return this.min_num;
                case "each_num":
                    return this.each_num;
                case "max_count":
                    return this.max_count;
                case "trigger_npc_id":
                    return this.trigger_npc_id;
                case "trigger_npc_num":
                    return this.trigger_npc_num;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Group> rows = _rows as List<Table_Npc_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Group > ( rows, "map", "id" );
            all_Table_Npc_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Group_List.Clear();
        }
    }
}
