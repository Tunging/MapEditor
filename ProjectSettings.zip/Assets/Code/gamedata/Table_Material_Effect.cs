using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 材质球效果表
    ///</summary>
    [Serializable]
    [TableName("material_effect")]
    public partial class Table_Material_Effect : TableContent
    {

        private static List<Table_Material_Effect> all_Table_Material_Effect_List = new List<Table_Material_Effect>();
        //primary | 主键
        public static Dictionary<int, Table_Material_Effect > pool_primary = new Dictionary<int, Table_Material_Effect > ();
        
        
        ///<summary>
        /// 主键ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 添加材质球路径
        ///</summary>
        public string add_path;
        
        
        ///<summary>
        /// 替换材质球路径
        ///</summary>
        public string replace_path;
        
        
        ///<summary>
        /// 是否影响武器模型
        ///</summary>
        public bool effect_weapon_model;
        
        
        ///<summary>
        /// 是否影响角色模型
        ///</summary>
        public bool effect_role_model;
        
        
        ///<summary>
        /// 是否影响boss模型
        ///</summary>
        public bool effect_boss_model;
        
        
        ///<summary>
        /// 效果显示优先级，数字越大优先级越高；相同优先级时，新的会替换旧的
        ///</summary>
        public int priority;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键ID</param>
        ///
        public static Table_Material_Effect GetPrimary ( int _id ){        
            Table_Material_Effect _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Material_Effect > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Material_Effect> GetAllPrimaryList()
        {
            return all_Table_Material_Effect_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("add_path", out _currValue))
            {
                this.add_path = _currValue;
            }
            if(_itemData.TryGetValue("replace_path", out _currValue))
            {
                this.replace_path = _currValue;
            }
            if(_itemData.TryGetValue("effect_weapon_model", out _currValue))
            {
                this.effect_weapon_model = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_role_model", out _currValue))
            {
                this.effect_role_model = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_boss_model", out _currValue))
            {
                this.effect_boss_model = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("priority", out _currValue))
            {
                this.priority = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "material_effect";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "description_i18n":
                    return this.description_i18n;
                case "add_path":
                    return this.add_path;
                case "replace_path":
                    return this.replace_path;
                case "effect_weapon_model":
                    return this.effect_weapon_model;
                case "effect_role_model":
                    return this.effect_role_model;
                case "effect_boss_model":
                    return this.effect_boss_model;
                case "priority":
                    return this.priority;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Material_Effect> rows = _rows as List<Table_Material_Effect>;
            pool_primary=TableContent.ListToPool < int, Table_Material_Effect > ( rows, "map", "id" );
            all_Table_Material_Effect_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Material_Effect_List.Clear();
        }
    }
}
