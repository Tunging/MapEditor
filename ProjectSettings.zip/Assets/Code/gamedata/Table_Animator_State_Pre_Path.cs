using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 状态机职业动作路径与前缀表
    ///</summary>
    [Serializable]
    [TableName("animator_state_pre_path")]
    public partial class Table_Animator_State_Pre_Path : TableContent
    {

        private static List<Table_Animator_State_Pre_Path> all_Table_Animator_State_Pre_Path_List = new List<Table_Animator_State_Pre_Path>();
        //primary | 主键
        public static Dictionary<int, Table_Animator_State_Pre_Path > pool_primary = new Dictionary<int, Table_Animator_State_Pre_Path > ();
        
        
        ///<summary>
        /// 职业ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 动作文件前缀
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 职业名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 职业名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 文件夹路径
        ///</summary>
        public string path;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 职业ID</param>
        ///
        public static Table_Animator_State_Pre_Path GetPrimary ( int _id ){        
            Table_Animator_State_Pre_Path _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Animator_State_Pre_Path > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Animator_State_Pre_Path> GetAllPrimaryList()
        {
            return all_Table_Animator_State_Pre_Path_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "animator_state_pre_path";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "path":
                    return this.path;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Animator_State_Pre_Path> rows = _rows as List<Table_Animator_State_Pre_Path>;
            pool_primary=TableContent.ListToPool < int, Table_Animator_State_Pre_Path > ( rows, "map", "id" );
            all_Table_Animator_State_Pre_Path_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Animator_State_Pre_Path_List.Clear();
        }
    }
}
