using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 奖励表
    ///</summary>
    [Serializable]
    [TableName("reward")]
    public partial class Table_Reward : TableContent
    {

        private static List<Table_Reward> all_Table_Reward_List = new List<Table_Reward>();
        //primary | 主键
        public static Dictionary<int, Table_Reward > pool_primary = new Dictionary<int, Table_Reward > ();
        
        
        ///<summary>
        /// 主键：奖励ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 策划备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 显示图标（不显示不填）
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 标题
        ///</summary>
        public string title;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 描述2
        ///</summary>
        public string description2;
        
        
        ///<summary>
        /// 是否可以预览（可预览的包只能包含固定奖励）
        ///</summary>
        public bool can_preview;
        
        
        ///<summary>
        /// 固定奖励包ID
        ///</summary>
        public int fix_package_id;
        
        
        ///<summary>
        /// 随机奖励包1ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package1;
        
        
        ///<summary>
        /// 随机奖励包2ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package2;
        
        
        ///<summary>
        /// 随机奖励包3ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package3;
        
        
        ///<summary>
        /// 随机奖励包4ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package4;
        
        
        ///<summary>
        /// 随机奖励包5ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package5;
        
        
        ///<summary>
        /// 随机奖励包6ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package6;
        
        
        ///<summary>
        /// 随机奖励包7ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package7;
        
        
        ///<summary>
        /// 随机奖励包8ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package8;
        
        
        ///<summary>
        /// 随机奖励包9ID以及该包的奖励次数，配置格式为：ID;次数
        ///</summary>
        public string random_package9;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：奖励ID</param>
        ///
        public static Table_Reward GetPrimary ( int _id ){        
            Table_Reward _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Reward > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Reward> GetAllPrimaryList()
        {
            return all_Table_Reward_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("title", out _currValue))
            {
                this.title = _currValue;
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("description2", out _currValue))
            {
                this.description2 = _currValue;
            }
            if(_itemData.TryGetValue("can_preview", out _currValue))
            {
                this.can_preview = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("fix_package_id", out _currValue))
            {
                this.fix_package_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("random_package1", out _currValue))
            {
                this.random_package1 = _currValue;
            }
            if(_itemData.TryGetValue("random_package2", out _currValue))
            {
                this.random_package2 = _currValue;
            }
            if(_itemData.TryGetValue("random_package3", out _currValue))
            {
                this.random_package3 = _currValue;
            }
            if(_itemData.TryGetValue("random_package4", out _currValue))
            {
                this.random_package4 = _currValue;
            }
            if(_itemData.TryGetValue("random_package5", out _currValue))
            {
                this.random_package5 = _currValue;
            }
            if(_itemData.TryGetValue("random_package6", out _currValue))
            {
                this.random_package6 = _currValue;
            }
            if(_itemData.TryGetValue("random_package7", out _currValue))
            {
                this.random_package7 = _currValue;
            }
            if(_itemData.TryGetValue("random_package8", out _currValue))
            {
                this.random_package8 = _currValue;
            }
            if(_itemData.TryGetValue("random_package9", out _currValue))
            {
                this.random_package9 = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "reward";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "name":
                    return this.name;
                case "icon":
                    return this.icon;
                case "title":
                    return this.title;
                case "description":
                    return this.description;
                case "description2":
                    return this.description2;
                case "can_preview":
                    return this.can_preview;
                case "fix_package_id":
                    return this.fix_package_id;
                case "random_package1":
                    return this.random_package1;
                case "random_package2":
                    return this.random_package2;
                case "random_package3":
                    return this.random_package3;
                case "random_package4":
                    return this.random_package4;
                case "random_package5":
                    return this.random_package5;
                case "random_package6":
                    return this.random_package6;
                case "random_package7":
                    return this.random_package7;
                case "random_package8":
                    return this.random_package8;
                case "random_package9":
                    return this.random_package9;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Reward> rows = _rows as List<Table_Reward>;
            pool_primary=TableContent.ListToPool < int, Table_Reward > ( rows, "map", "id" );
            all_Table_Reward_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Reward_List.Clear();
        }
    }
}
