using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景完成度奖励
    ///</summary>
    [Serializable]
    [TableName("scene_completion_bonus")]
    public partial class Table_Scene_Completion_Bonus : TableContent
    {

        private static List<Table_Scene_Completion_Bonus> all_Table_Scene_Completion_Bonus_List = new List<Table_Scene_Completion_Bonus>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Completion_Bonus > pool_primary = new Dictionary<int, Table_Scene_Completion_Bonus > ();
        //sceneId | 
        public static Dictionary<int, List<Table_Scene_Completion_Bonus> > pool_sceneId = new Dictionary<int, List<Table_Scene_Completion_Bonus> > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 需要的积分
        ///</summary>
        public int score;
        
        
        ///<summary>
        /// 奖励ID
        ///</summary>
        public int reward_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Scene_Completion_Bonus GetPrimary ( int _id ){        
            Table_Scene_Completion_Bonus _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Completion_Bonus > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景ID</param>
        ///
        public static List<Table_Scene_Completion_Bonus> GetSceneId ( int _sceneId ){        
            List<Table_Scene_Completion_Bonus> _map0=null;        
            pool_sceneId. TryGetValue(_sceneId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Scene_Completion_Bonus> > GetAllSceneId()
        {
            return pool_sceneId;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Completion_Bonus> GetAllPrimaryList()
        {
            return all_Table_Scene_Completion_Bonus_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("score", out _currValue))
            {
                this.score = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward_id", out _currValue))
            {
                this.reward_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_completion_bonus";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "scene_id":
                    return this.scene_id;
                case "score":
                    return this.score;
                case "reward_id":
                    return this.reward_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Completion_Bonus> rows = _rows as List<Table_Scene_Completion_Bonus>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Completion_Bonus > ( rows, "map", "id" );
            pool_sceneId=TableContent.ListToPoolList < int, Table_Scene_Completion_Bonus > ( rows, "list", "scene_id" );
            all_Table_Scene_Completion_Bonus_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_sceneId.Clear();
            all_Table_Scene_Completion_Bonus_List.Clear();
        }
    }
}
