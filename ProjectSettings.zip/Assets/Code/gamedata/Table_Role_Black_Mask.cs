using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 角色黑幕遮罩
    ///</summary>
    [Serializable]
    [TableName("role_black_mask")]
    public partial class Table_Role_Black_Mask : TableContent
    {

        private static List<Table_Role_Black_Mask> all_Table_Role_Black_Mask_List = new List<Table_Role_Black_Mask>();
        //primary | 主键
        public static Dictionary<int, Table_Role_Black_Mask > pool_primary = new Dictionary<int, Table_Role_Black_Mask > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 步骤id
        ///</summary>
        public int step_id;
        
        
        ///<summary>
        /// 透明渐变时间(ms)
        ///</summary>
        public int alpha_time;
        
        
        ///<summary>
        /// 开始的alpha值
        ///</summary>
        public int start_alpha;
        
        
        ///<summary>
        /// 结束的alpha值
        ///</summary>
        public int end_alpha;
        
        
        ///<summary>
        /// 黑幕持续时间(ms)
        ///</summary>
        public int black_last_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Role_Black_Mask GetPrimary ( int _id ){        
            Table_Role_Black_Mask _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Role_Black_Mask > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Role_Black_Mask> GetAllPrimaryList()
        {
            return all_Table_Role_Black_Mask_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("step_id", out _currValue))
            {
                this.step_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("alpha_time", out _currValue))
            {
                this.alpha_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("start_alpha", out _currValue))
            {
                this.start_alpha = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("end_alpha", out _currValue))
            {
                this.end_alpha = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("black_last_time", out _currValue))
            {
                this.black_last_time = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "role_black_mask";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "step_id":
                    return this.step_id;
                case "alpha_time":
                    return this.alpha_time;
                case "start_alpha":
                    return this.start_alpha;
                case "end_alpha":
                    return this.end_alpha;
                case "black_last_time":
                    return this.black_last_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Role_Black_Mask> rows = _rows as List<Table_Role_Black_Mask>;
            pool_primary=TableContent.ListToPool < int, Table_Role_Black_Mask > ( rows, "map", "id" );
            all_Table_Role_Black_Mask_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Role_Black_Mask_List.Clear();
        }
    }
}
