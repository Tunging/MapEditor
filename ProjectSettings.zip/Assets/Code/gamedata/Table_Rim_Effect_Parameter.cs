using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 泛白参数表
    ///</summary>
    [Serializable]
    [TableName("rim_effect_parameter")]
    public partial class Table_Rim_Effect_Parameter : TableContent
    {

        private static List<Table_Rim_Effect_Parameter> all_Table_Rim_Effect_Parameter_List = new List<Table_Rim_Effect_Parameter>();
        //primary | 主键
        public static Dictionary<int, Table_Rim_Effect_Parameter > pool_primary = new Dictionary<int, Table_Rim_Effect_Parameter > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 持续时间
        ///</summary>
        public float fade_duration;
        
        
        ///<summary>
        /// 开始恢复时间
        ///</summary>
        public float fade_revertTime;
        
        
        ///<summary>
        /// rim power
        ///</summary>
        public float rim_power;
        
        
        ///<summary>
        /// rim level
        ///</summary>
        public float rim_level;
        
        
        ///<summary>
        /// rim color
        ///</summary>
        public string rim_color;
        
        
        ///<summary>
        /// rim_dircetion
        ///</summary>
        public string rim_direction;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Rim_Effect_Parameter GetPrimary ( int _id ){        
            Table_Rim_Effect_Parameter _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Rim_Effect_Parameter > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Rim_Effect_Parameter> GetAllPrimaryList()
        {
            return all_Table_Rim_Effect_Parameter_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("fade_duration", out _currValue))
            {
                this.fade_duration = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("fade_revertTime", out _currValue))
            {
                this.fade_revertTime = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("rim_power", out _currValue))
            {
                this.rim_power = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("rim_level", out _currValue))
            {
                this.rim_level = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("rim_color", out _currValue))
            {
                this.rim_color = _currValue;
            }
            if(_itemData.TryGetValue("rim_direction", out _currValue))
            {
                this.rim_direction = _currValue;
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "rim_effect_parameter";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "fade_duration":
                    return this.fade_duration;
                case "fade_revertTime":
                    return this.fade_revertTime;
                case "rim_power":
                    return this.rim_power;
                case "rim_level":
                    return this.rim_level;
                case "rim_color":
                    return this.rim_color;
                case "rim_direction":
                    return this.rim_direction;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Rim_Effect_Parameter> rows = _rows as List<Table_Rim_Effect_Parameter>;
            pool_primary=TableContent.ListToPool < int, Table_Rim_Effect_Parameter > ( rows, "map", "id" );
            all_Table_Rim_Effect_Parameter_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Rim_Effect_Parameter_List.Clear();
        }
    }
}
