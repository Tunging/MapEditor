using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc（弹簧）
    ///</summary>
    [Serializable]
    [TableName("npc_catapult")]
    public partial class Table_Npc_Catapult : TableContent
    {

        private static List<Table_Npc_Catapult> all_Table_Npc_Catapult_List = new List<Table_Npc_Catapult>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Catapult > pool_primary = new Dictionary<int, Table_Npc_Catapult > ();
        
        
        ///<summary>
        /// 主键：npc模板ID
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 弹簧半径（用于触发判断）
        ///</summary>
        public float catapult_radius;
        
        
        ///<summary>
        /// 目标重力加速度
        ///</summary>
        public float target_gravitational_acceleration;
        
        
        ///<summary>
        /// 目标上升最大高度
        ///</summary>
        public float target_max_rising_height;
        
        
        ///<summary>
        /// 目标坠落最大速度
        ///</summary>
        public float target_max_drop_speed;
        
        
        ///<summary>
        /// 目标移动速度
        ///</summary>
        public float target_move_speed;
        
        
        ///<summary>
        /// 正常高度
        ///</summary>
        public float catapult_normal_height;
        
        
        ///<summary>
        /// 压缩后的高度
        ///</summary>
        public float catapult_compressed_height;
        
        
        ///<summary>
        /// 动作ID
        ///</summary>
        public int action_id;
        
        
        ///<summary>
        /// 动作持续时间(ms)
        ///</summary>
        public int action_duration;
        
        
        ///<summary>
        /// 特效ID
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 下压加速度
        ///</summary>
        public float press_acceleration;
        
        
        ///<summary>
        /// 下压最大速度
        ///</summary>
        public float press_max_speed;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcId> 主键：npc模板ID</param>
        ///
        public static Table_Npc_Catapult GetPrimary ( int _npcId ){        
            Table_Npc_Catapult _map0=null;        
            pool_primary. TryGetValue(_npcId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Catapult > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Catapult> GetAllPrimaryList()
        {
            return all_Table_Npc_Catapult_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("catapult_radius", out _currValue))
            {
                this.catapult_radius = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_gravitational_acceleration", out _currValue))
            {
                this.target_gravitational_acceleration = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_max_rising_height", out _currValue))
            {
                this.target_max_rising_height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_max_drop_speed", out _currValue))
            {
                this.target_max_drop_speed = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_move_speed", out _currValue))
            {
                this.target_move_speed = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("catapult_normal_height", out _currValue))
            {
                this.catapult_normal_height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("catapult_compressed_height", out _currValue))
            {
                this.catapult_compressed_height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_duration", out _currValue))
            {
                this.action_duration = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("press_acceleration", out _currValue))
            {
                this.press_acceleration = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("press_max_speed", out _currValue))
            {
                this.press_max_speed = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_catapult";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_id":
                    return this.npc_id;
                case "catapult_radius":
                    return this.catapult_radius;
                case "target_gravitational_acceleration":
                    return this.target_gravitational_acceleration;
                case "target_max_rising_height":
                    return this.target_max_rising_height;
                case "target_max_drop_speed":
                    return this.target_max_drop_speed;
                case "target_move_speed":
                    return this.target_move_speed;
                case "catapult_normal_height":
                    return this.catapult_normal_height;
                case "catapult_compressed_height":
                    return this.catapult_compressed_height;
                case "action_id":
                    return this.action_id;
                case "action_duration":
                    return this.action_duration;
                case "effect_id":
                    return this.effect_id;
                case "press_acceleration":
                    return this.press_acceleration;
                case "press_max_speed":
                    return this.press_max_speed;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Catapult> rows = _rows as List<Table_Npc_Catapult>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Catapult > ( rows, "map", "npc_id" );
            all_Table_Npc_Catapult_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Catapult_List.Clear();
        }
    }
}
