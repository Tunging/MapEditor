using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 职业天赋
    ///</summary>
    [Serializable]
    [TableName("profession_talent")]
    public partial class Table_Profession_Talent : TableContent
    {

        private static List<Table_Profession_Talent> all_Table_Profession_Talent_List = new List<Table_Profession_Talent>();
        //primary | 主键
        public static Dictionary<int, Table_Profession_Talent > pool_primary = new Dictionary<int, Table_Profession_Talent > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 职业ID
        ///</summary>
        public int profession_id;
        
        
        ///<summary>
        /// 天赋类型
        ///</summary>
        public int talent_type;
        
        
        ///<summary>
        /// 天赋树ID
        ///</summary>
        public int talent_tree;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 天赋树描述国际化
        ///</summary>
        public string tree_desc_i18n;
        
        
        ///<summary>
        /// 简短描述
        ///</summary>
        public string short_desc;
        
        
        ///<summary>
        /// 被动词条ID
        ///</summary>
        public int passive_entry;
        
        
        ///<summary>
        /// 队伍界面图标
        ///</summary>
        public int team_icon;
        
        
        ///<summary>
        /// 主控图标
        ///</summary>
        public int main_icon;
        
        
        ///<summary>
        /// 多BD职业天赋图标
        ///</summary>
        public int multi_bd_icon;
        
        
        ///<summary>
        /// 展示天赋技能id(逗号分隔)
        ///</summary>
        public string show_talent_skill;
        
        
        ///<summary>
        /// 天赋名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 天赋名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// talent_icon
        ///</summary>
        public int talent_icon;
        
        
        ///<summary>
        /// 天赋定位
        ///</summary>
        public string talent_able;
        
        
        ///<summary>
        /// 天赋定位国际化
        ///</summary>
        public string talent_able_i18n;
        
        
        ///<summary>
        /// 天赋描述
        ///</summary>
        public string talent_desc;
        
        
        ///<summary>
        /// 天赋描述国际化
        ///</summary>
        public string talent_desc_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Profession_Talent GetPrimary ( int _id ){        
            Table_Profession_Talent _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Profession_Talent > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Profession_Talent> GetAllPrimaryList()
        {
            return all_Table_Profession_Talent_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("profession_id", out _currValue))
            {
                this.profession_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talent_type", out _currValue))
            {
                this.talent_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talent_tree", out _currValue))
            {
                this.talent_tree = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("tree_desc_i18n", out _currValue))
            {
                this.tree_desc_i18n = _currValue;
            }
            if(_itemData.TryGetValue("short_desc", out _currValue))
            {
                this.short_desc = _currValue;
            }
            if(_itemData.TryGetValue("passive_entry", out _currValue))
            {
                this.passive_entry = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("team_icon", out _currValue))
            {
                this.team_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("main_icon", out _currValue))
            {
                this.main_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("multi_bd_icon", out _currValue))
            {
                this.multi_bd_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_talent_skill", out _currValue))
            {
                this.show_talent_skill = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("talent_icon", out _currValue))
            {
                this.talent_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talent_able", out _currValue))
            {
                this.talent_able = _currValue;
            }
            if(_itemData.TryGetValue("talent_able_i18n", out _currValue))
            {
                this.talent_able_i18n = _currValue;
            }
            if(_itemData.TryGetValue("talent_desc", out _currValue))
            {
                this.talent_desc = _currValue;
            }
            if(_itemData.TryGetValue("talent_desc_i18n", out _currValue))
            {
                this.talent_desc_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "profession_talent";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "profession_id":
                    return this.profession_id;
                case "talent_type":
                    return this.talent_type;
                case "talent_tree":
                    return this.talent_tree;
                case "remark":
                    return this.remark;
                case "tree_desc_i18n":
                    return this.tree_desc_i18n;
                case "short_desc":
                    return this.short_desc;
                case "passive_entry":
                    return this.passive_entry;
                case "team_icon":
                    return this.team_icon;
                case "main_icon":
                    return this.main_icon;
                case "multi_bd_icon":
                    return this.multi_bd_icon;
                case "show_talent_skill":
                    return this.show_talent_skill;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "talent_icon":
                    return this.talent_icon;
                case "talent_able":
                    return this.talent_able;
                case "talent_able_i18n":
                    return this.talent_able_i18n;
                case "talent_desc":
                    return this.talent_desc;
                case "talent_desc_i18n":
                    return this.talent_desc_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Profession_Talent> rows = _rows as List<Table_Profession_Talent>;
            pool_primary=TableContent.ListToPool < int, Table_Profession_Talent > ( rows, "map", "id" );
            all_Table_Profession_Talent_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Profession_Talent_List.Clear();
        }
    }
}
