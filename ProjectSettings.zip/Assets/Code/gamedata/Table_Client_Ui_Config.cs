using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：UI配置
    ///</summary>
    [Serializable]
    [TableName("client_ui_config")]
    public partial class Table_Client_Ui_Config : TableContent
    {

        private static List<Table_Client_Ui_Config> all_Table_Client_Ui_Config_List = new List<Table_Client_Ui_Config>();
        //primary | 主键
        public static Dictionary<string, Table_Client_Ui_Config > pool_primary = new Dictionary<string, Table_Client_Ui_Config > ();
        
        
        ///<summary>
        /// 面板名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 0表示最底层(bottom)   1表示常在层(constant)   2表示最上层(top)   4目前表示名字血条层（有待修改）
        ///</summary>
        public int layer;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param name> 面板名称</param>
        ///
        public static Table_Client_Ui_Config GetPrimary ( string _name ){        
            Table_Client_Ui_Config _map0=null;        
            pool_primary. TryGetValue(_name,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<string, Table_Client_Ui_Config > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Ui_Config> GetAllPrimaryList()
        {
            return all_Table_Client_Ui_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("layer", out _currValue))
            {
                this.layer = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_ui_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "name":
                    return this.name;
                case "layer":
                    return this.layer;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Ui_Config> rows = _rows as List<Table_Client_Ui_Config>;
            pool_primary=TableContent.ListToPool < string, Table_Client_Ui_Config > ( rows, "map", "name" );
            all_Table_Client_Ui_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Ui_Config_List.Clear();
        }
    }
}
