using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能tips

    ///</summary>
    [Serializable]
    [TableName("skill_tips")]
    public partial class Table_Skill_Tips : TableContent
    {

        private static List<Table_Skill_Tips> all_Table_Skill_Tips_List = new List<Table_Skill_Tips>();
        //primary | 主键
        public static Dictionary<int, Table_Skill_Tips > pool_primary = new Dictionary<int, Table_Skill_Tips > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 显示描述
        ///</summary>
        public string show_desc;
        
        
        ///<summary>
        /// 属性类型1
        ///</summary>
        public int prop_type1;
        
        
        ///<summary>
        /// 属性类型2
        ///</summary>
        public int prop_type2;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Skill_Tips GetPrimary ( int _id ){        
            Table_Skill_Tips _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Skill_Tips > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Tips> GetAllPrimaryList()
        {
            return all_Table_Skill_Tips_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_desc", out _currValue))
            {
                this.show_desc = _currValue;
            }
            if(_itemData.TryGetValue("prop_type1", out _currValue))
            {
                this.prop_type1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prop_type2", out _currValue))
            {
                this.prop_type2 = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_tips";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "show_desc":
                    return this.show_desc;
                case "prop_type1":
                    return this.prop_type1;
                case "prop_type2":
                    return this.prop_type2;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Tips> rows = _rows as List<Table_Skill_Tips>;
            pool_primary=TableContent.ListToPool < int, Table_Skill_Tips > ( rows, "map", "id" );
            all_Table_Skill_Tips_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Tips_List.Clear();
        }
    }
}
