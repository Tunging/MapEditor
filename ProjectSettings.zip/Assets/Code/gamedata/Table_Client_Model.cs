using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：模型资源
    ///</summary>
    [Serializable]
    [TableName("client_model")]
    public partial class Table_Client_Model : TableContent
    {

        private static List<Table_Client_Model> all_Table_Client_Model_List = new List<Table_Client_Model>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Model > pool_primary = new Dictionary<int, Table_Client_Model > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 资源路径
        ///</summary>
        public string path;
        
        
        ///<summary>
        /// 材质球路径
        ///</summary>
        public string material_path;
        
        
        ///<summary>
        /// 体型半径(m)
        ///</summary>
        public float body_size;
        
        
        ///<summary>
        /// 脚底光圈缩放大小
        ///</summary>
        public float foot_aperture_size;
        
        
        ///<summary>
        /// 骨骼
        ///</summary>
        public string bones;
        
        
        ///<summary>
        /// 装备挂点
        ///</summary>
        public int equipment_position;
        
        
        ///<summary>
        /// 坐骑挂点
        ///</summary>
        public string mount_position;
        
        
        ///<summary>
        /// 界面对话缩放比例
        ///</summary>
        public float pannel_model_ratio;
        
        
        ///<summary>
        /// UI界面x偏移
        ///</summary>
        public float pannel_model_x;
        
        
        ///<summary>
        /// UI界面y偏移
        ///</summary>
        public float pannel_model_y;
        
        
        ///<summary>
        /// UI界面z偏移
        ///</summary>
        public float pannel_model_z;
        
        
        ///<summary>
        /// 剧情对话框模型缩放比例
        ///</summary>
        public float dialog_scale;
        
        
        ///<summary>
        /// 剧情对话模型位置偏移量
        ///</summary>
        public string dialog_offset;
        
        
        ///<summary>
        /// 碰撞区域：底部中心点
        ///</summary>
        public string collision_bottom;
        
        
        ///<summary>
        /// 碰撞区域：顶部中心点
        ///</summary>
        public string collision_top;
        
        
        ///<summary>
        /// 碰撞区域：半径
        ///</summary>
        public float collision_radius;
        
        
        ///<summary>
        /// 游泳碰撞盒：长度
        ///</summary>
        public float swim_collision_length;
        
        
        ///<summary>
        /// 游泳碰撞盒：高度
        ///</summary>
        public float swim_collision_hight;
        
        
        ///<summary>
        /// 游泳碰撞盒：宽度
        ///</summary>
        public float swim_collision_width;
        
        
        ///<summary>
        /// 游泳碰撞盒：偏移量
        ///</summary>
        public float swim_collision_offset;
        
        
        ///<summary>
        /// 水面角色偏移Y坐标
        ///</summary>
        public float water_surface_offset_y;
        
        
        ///<summary>
        /// 特效缩放比例
        ///</summary>
        public float effect_scale;
        
        
        ///<summary>
        /// 超近摄像头焦点高度
        ///</summary>
        public float near_camera_hight;
        
        
        ///<summary>
        /// MainCameraTarget默认高度
        ///</summary>
        public float camera_hight;
        
        
        ///<summary>
        /// 水下MainCameraTarget高度
        ///</summary>
        public float water_camera_hight;
        
        
        ///<summary>
        /// Npc是否需要调整到Hero层次，以取得更好的显示效果
        ///</summary>
        public bool npc_view_layer;
        
        
        ///<summary>
        /// 情景对话半身像展示偏移量字符串 (x|y|z)
        ///</summary>
        public string half_body_offset;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Client_Model GetPrimary ( int _id ){        
            Table_Client_Model _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Model > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Model> GetAllPrimaryList()
        {
            return all_Table_Client_Model_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
            if(_itemData.TryGetValue("material_path", out _currValue))
            {
                this.material_path = _currValue;
            }
            if(_itemData.TryGetValue("body_size", out _currValue))
            {
                this.body_size = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("foot_aperture_size", out _currValue))
            {
                this.foot_aperture_size = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("bones", out _currValue))
            {
                this.bones = _currValue;
            }
            if(_itemData.TryGetValue("equipment_position", out _currValue))
            {
                this.equipment_position = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("mount_position", out _currValue))
            {
                this.mount_position = _currValue;
            }
            if(_itemData.TryGetValue("pannel_model_ratio", out _currValue))
            {
                this.pannel_model_ratio = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("pannel_model_x", out _currValue))
            {
                this.pannel_model_x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("pannel_model_y", out _currValue))
            {
                this.pannel_model_y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("pannel_model_z", out _currValue))
            {
                this.pannel_model_z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_scale", out _currValue))
            {
                this.dialog_scale = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_offset", out _currValue))
            {
                this.dialog_offset = _currValue;
            }
            if(_itemData.TryGetValue("collision_bottom", out _currValue))
            {
                this.collision_bottom = _currValue;
            }
            if(_itemData.TryGetValue("collision_top", out _currValue))
            {
                this.collision_top = _currValue;
            }
            if(_itemData.TryGetValue("collision_radius", out _currValue))
            {
                this.collision_radius = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("swim_collision_length", out _currValue))
            {
                this.swim_collision_length = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("swim_collision_hight", out _currValue))
            {
                this.swim_collision_hight = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("swim_collision_width", out _currValue))
            {
                this.swim_collision_width = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("swim_collision_offset", out _currValue))
            {
                this.swim_collision_offset = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("water_surface_offset_y", out _currValue))
            {
                this.water_surface_offset_y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_scale", out _currValue))
            {
                this.effect_scale = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("near_camera_hight", out _currValue))
            {
                this.near_camera_hight = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_hight", out _currValue))
            {
                this.camera_hight = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("water_camera_hight", out _currValue))
            {
                this.water_camera_hight = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_view_layer", out _currValue))
            {
                this.npc_view_layer = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("half_body_offset", out _currValue))
            {
                this.half_body_offset = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_model";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "path":
                    return this.path;
                case "material_path":
                    return this.material_path;
                case "body_size":
                    return this.body_size;
                case "foot_aperture_size":
                    return this.foot_aperture_size;
                case "bones":
                    return this.bones;
                case "equipment_position":
                    return this.equipment_position;
                case "mount_position":
                    return this.mount_position;
                case "pannel_model_ratio":
                    return this.pannel_model_ratio;
                case "pannel_model_x":
                    return this.pannel_model_x;
                case "pannel_model_y":
                    return this.pannel_model_y;
                case "pannel_model_z":
                    return this.pannel_model_z;
                case "dialog_scale":
                    return this.dialog_scale;
                case "dialog_offset":
                    return this.dialog_offset;
                case "collision_bottom":
                    return this.collision_bottom;
                case "collision_top":
                    return this.collision_top;
                case "collision_radius":
                    return this.collision_radius;
                case "swim_collision_length":
                    return this.swim_collision_length;
                case "swim_collision_hight":
                    return this.swim_collision_hight;
                case "swim_collision_width":
                    return this.swim_collision_width;
                case "swim_collision_offset":
                    return this.swim_collision_offset;
                case "water_surface_offset_y":
                    return this.water_surface_offset_y;
                case "effect_scale":
                    return this.effect_scale;
                case "near_camera_hight":
                    return this.near_camera_hight;
                case "camera_hight":
                    return this.camera_hight;
                case "water_camera_hight":
                    return this.water_camera_hight;
                case "npc_view_layer":
                    return this.npc_view_layer;
                case "half_body_offset":
                    return this.half_body_offset;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Model> rows = _rows as List<Table_Client_Model>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Model > ( rows, "map", "id" );
            all_Table_Client_Model_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Model_List.Clear();
        }
    }
}
