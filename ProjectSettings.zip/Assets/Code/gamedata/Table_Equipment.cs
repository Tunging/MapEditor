using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 装备表
    ///</summary>
    [Serializable]
    [TableName("equipment")]
    public partial class Table_Equipment : TableContent
    {

        private static List<Table_Equipment> all_Table_Equipment_List = new List<Table_Equipment>();
        //primary | 主键
        public static Dictionary<int, Table_Equipment > pool_primary = new Dictionary<int, Table_Equipment > ();
        
        
        ///<summary>
        /// 装备ID=道具ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 装备部位
        ///</summary>
        public int position;
        
        
        ///<summary>
        /// 耐久度上限
        ///</summary>
        public int durability_max;
        
        
        ///<summary>
        /// 基础词条1
        ///</summary>
        public int base_entry1;
        
        
        ///<summary>
        /// 基础词条2
        ///</summary>
        public int base_entry2;
        
        
        ///<summary>
        /// 洗炼词条随机库
        ///</summary>
        public int wash_entry_lib;
        
        
        ///<summary>
        /// 分解返还道具ID
        ///</summary>
        public int decompose_return_item_id;
        
        
        ///<summary>
        /// 分解返还道具数量
        ///</summary>
        public int decompose_return_item_num;
        
        
        ///<summary>
        /// 是否可以开封
        ///</summary>
        public bool can_unseal;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 装备ID=道具ID</param>
        ///
        public static Table_Equipment GetPrimary ( int _id ){        
            Table_Equipment _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Equipment > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Equipment> GetAllPrimaryList()
        {
            return all_Table_Equipment_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("position", out _currValue))
            {
                this.position = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("durability_max", out _currValue))
            {
                this.durability_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("base_entry1", out _currValue))
            {
                this.base_entry1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("base_entry2", out _currValue))
            {
                this.base_entry2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_entry_lib", out _currValue))
            {
                this.wash_entry_lib = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("decompose_return_item_id", out _currValue))
            {
                this.decompose_return_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("decompose_return_item_num", out _currValue))
            {
                this.decompose_return_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_unseal", out _currValue))
            {
                this.can_unseal = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "equipment";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "position":
                    return this.position;
                case "durability_max":
                    return this.durability_max;
                case "base_entry1":
                    return this.base_entry1;
                case "base_entry2":
                    return this.base_entry2;
                case "wash_entry_lib":
                    return this.wash_entry_lib;
                case "decompose_return_item_id":
                    return this.decompose_return_item_id;
                case "decompose_return_item_num":
                    return this.decompose_return_item_num;
                case "can_unseal":
                    return this.can_unseal;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Equipment> rows = _rows as List<Table_Equipment>;
            pool_primary=TableContent.ListToPool < int, Table_Equipment > ( rows, "map", "id" );
            all_Table_Equipment_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Equipment_List.Clear();
        }
    }
}
