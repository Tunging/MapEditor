using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 商店商品
    ///</summary>
    [Serializable]
    [TableName("shop_item")]
    public partial class Table_Shop_Item : TableContent
    {

        private static List<Table_Shop_Item> all_Table_Shop_Item_List = new List<Table_Shop_Item>();
        //primary | 主键
        public static Dictionary<int, Table_Shop_Item > pool_primary = new Dictionary<int, Table_Shop_Item > ();
        
        
        ///<summary>
        /// 
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 商店id
        ///</summary>
        public int shop_id;
        
        
        ///<summary>
        /// 格子
        ///</summary>
        public int pos_id;
        
        
        ///<summary>
        /// 物品id
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 物品数量
        ///</summary>
        public int item_num;
        
        
        ///<summary>
        /// 消耗道具类型
        ///</summary>
        public int consume_item_id;
        
        
        ///<summary>
        /// 消耗道具数量
        ///</summary>
        public int consume_item_num;
        
        
        ///<summary>
        /// 是否稀有
        ///</summary>
        public bool is_rare;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> </param>
        ///
        public static Table_Shop_Item GetPrimary ( int _id ){        
            Table_Shop_Item _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Shop_Item > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Shop_Item> GetAllPrimaryList()
        {
            return all_Table_Shop_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("shop_id", out _currValue))
            {
                this.shop_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pos_id", out _currValue))
            {
                this.pos_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_num", out _currValue))
            {
                this.item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("consume_item_id", out _currValue))
            {
                this.consume_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("consume_item_num", out _currValue))
            {
                this.consume_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_rare", out _currValue))
            {
                this.is_rare = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "shop_item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "shop_id":
                    return this.shop_id;
                case "pos_id":
                    return this.pos_id;
                case "item_id":
                    return this.item_id;
                case "item_num":
                    return this.item_num;
                case "consume_item_id":
                    return this.consume_item_id;
                case "consume_item_num":
                    return this.consume_item_num;
                case "is_rare":
                    return this.is_rare;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Shop_Item> rows = _rows as List<Table_Shop_Item>;
            pool_primary=TableContent.ListToPool < int, Table_Shop_Item > ( rows, "map", "id" );
            all_Table_Shop_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Shop_Item_List.Clear();
        }
    }
}
