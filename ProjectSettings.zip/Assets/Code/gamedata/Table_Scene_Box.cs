using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景宝箱
    ///</summary>
	[Serializable]
	[TableName("scene_box")]
    public partial class Table_Scene_Box :TableContent
    {

                private static  List< Table_Scene_Box > all_Table_Scene_Box_List=new  List< Table_Scene_Box >();
                //primary | 主键
				public static 	Dictionary <int, Table_Scene_Box > pool_primary=new Dictionary <int, Table_Scene_Box > ();
                //sceneId | 
				public static 	Dictionary <int, List<Table_Scene_Box> > pool_sceneId=new Dictionary <int, List<Table_Scene_Box> > ();
        		///<summary>
        		/// 主键：ID
        		///</summary>
        		public int id;
        		///<summary>
        		/// 场景ID
        		///</summary>
        		public int scene_id;
        		///<summary>
        		/// 名称
        		///</summary>
        		public string name;
        		///<summary>
        		/// 名称国际化
        		///</summary>
        		public string name_i18n;
        		///<summary>
        		/// 场景完成度积分
        		///</summary>
        		public int completion_score;
        		///<summary>
        		/// X坐标
        		///</summary>
        		public float x;
        		///<summary>
        		/// Y坐标
        		///</summary>
        		public float y;
        		///<summary>
        		/// Z坐标
        		///</summary>
        		public float z;
        		///<summary>
        		/// 采集图标
        		///</summary>
        		public int gather_icon;
        		///<summary>
        		/// 采集前 按钮文本国际化
        		///</summary>
        		public int gather_before_button_text_i18n;
        		///<summary>
        		/// 采集按钮文本
        		///</summary>
        		public string gather_button_text;
        		///<summary>
        		/// 采集按钮文本国际化
        		///</summary>
        		public string gather_button_text_i18n;
        		///<summary>
        		/// 进度条长度(m)
        		///</summary>
        		public float progress_bar;
        		///<summary>
        		/// 采集速度(m/s)
        		///</summary>
        		public int speed;
        		///<summary>
        		/// 角色采集动作
        		///</summary>
        		public int role_action;
        		///<summary>
        		/// NPC采集开始动作
        		///</summary>
        		public int npc_start_action;
        		///<summary>
        		/// NPC采集开始特效
        		///</summary>
        		public int npc_start_effect;
        		///<summary>
        		/// NPC采集开始声音
        		///</summary>
        		public int npc_start_sound;
        		///<summary>
        		/// NPC采集完成动作
        		///</summary>
        		public int npc_finish_action;
        		///<summary>
        		/// NPC采集完成特效
        		///</summary>
        		public int npc_finish_effect;
        		///<summary>
        		/// 采集完成后的提示文字
        		///</summary>
        		public string finish_tips;
        		///<summary>
        		/// 采集完成后的提示文字国际化
        		///</summary>
        		public string finish_tips_i18n;
        		///<summary>
        		/// 采集完成后，给玩家的奖励包ID
        		///</summary>
        		public int finish_reward_id;
        		///<summary>
        		/// 旋转角度
        		///</summary>
        		public float angle;

				///<summary>
                /// 主键
                /// 查询数据
                ///</summary>
				///	<param id> 主键：ID</param>
          		///
				public static 	Table_Scene_Box GetPrimary ( int _id ){
                        Table_Scene_Box _map0=null;
						pool_primary. TryGetValue(_id,out _map0);
						return  _map0;
				}
        		 ///<summary>
                ///主键
                ///查询所有数据
                ///</summary>
				public static Dictionary <int, Table_Scene_Box > GetAllPrimary(){
						return pool_primary;
				}



				///<summary>
                /// 
                /// 查询数据
                ///</summary>
				///	<param sceneId> 场景ID</param>
          		///
				public static 	List<Table_Scene_Box> GetSceneId ( int _sceneId ){
                        List<Table_Scene_Box> _map0=null;
						pool_sceneId. TryGetValue(_sceneId,out _map0);
						return  _map0;
				}
        		 ///<summary>
                ///
                ///查询所有数据
                ///</summary>
				public static Dictionary <int, List<Table_Scene_Box> > GetAllSceneId(){
						return pool_sceneId;
				}


				///查询出所有的数据
				public static List<Table_Scene_Box> GetAllPrimaryList(){
						return all_Table_Scene_Box_List;
				}


    	        public override void ParseFrom(Dictionary<string, string> _itemData) {
					string _currValue = "";
					if(_itemData.TryGetValue("id", out _currValue)){
        		        this.id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("scene_id", out _currValue)){
        		        this.scene_id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("name", out _currValue)){
        		        this.name = _currValue;
					}

					if(_itemData.TryGetValue("name_i18n", out _currValue)){
        		        this.name_i18n = _currValue;
					}

					if(_itemData.TryGetValue("completion_score", out _currValue)){
        		        this.completion_score = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("x", out _currValue)){
        		        this.x = Utils.GetFloatFromString(_currValue);
					}

					if(_itemData.TryGetValue("y", out _currValue)){
        		        this.y = Utils.GetFloatFromString(_currValue);
					}

					if(_itemData.TryGetValue("z", out _currValue)){
        		        this.z = Utils.GetFloatFromString(_currValue);
					}

					if(_itemData.TryGetValue("gather_icon", out _currValue)){
        		        this.gather_icon = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("gather_before_button_text_i18n", out _currValue)){
        		        this.gather_before_button_text_i18n = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("gather_button_text", out _currValue)){
        		        this.gather_button_text = _currValue;
					}

					if(_itemData.TryGetValue("gather_button_text_i18n", out _currValue)){
        		        this.gather_button_text_i18n = _currValue;
					}

					if(_itemData.TryGetValue("progress_bar", out _currValue)){
        		        this.progress_bar = Utils.GetFloatFromString(_currValue);
					}

					if(_itemData.TryGetValue("speed", out _currValue)){
        		        this.speed = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("role_action", out _currValue)){
        		        this.role_action = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("npc_start_action", out _currValue)){
        		        this.npc_start_action = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("npc_start_effect", out _currValue)){
        		        this.npc_start_effect = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("npc_start_sound", out _currValue)){
        		        this.npc_start_sound = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("npc_finish_action", out _currValue)){
        		        this.npc_finish_action = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("npc_finish_effect", out _currValue)){
        		        this.npc_finish_effect = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("finish_tips", out _currValue)){
        		        this.finish_tips = _currValue;
					}

					if(_itemData.TryGetValue("finish_tips_i18n", out _currValue)){
        		        this.finish_tips_i18n = _currValue;
					}

					if(_itemData.TryGetValue("finish_reward_id", out _currValue)){
        		        this.finish_reward_id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("angle", out _currValue)){
        		        this.angle = Utils.GetFloatFromString(_currValue);
					}

				}

                 public override string Table()
                 {
                    return "scene_box";
                 }

                 public  override object GetValue(string column) {
        	            switch (column) {
        		            case "id":
            	            return this.id;
        		            case "scene_id":
            	            return this.scene_id;
        		            case "name":
            	            return this.name;
        		            case "name_i18n":
            	            return this.name_i18n;
        		            case "completion_score":
            	            return this.completion_score;
        		            case "x":
            	            return this.x;
        		            case "y":
            	            return this.y;
        		            case "z":
            	            return this.z;
        		            case "gather_icon":
            	            return this.gather_icon;
        		            case "gather_before_button_text_i18n":
            	            return this.gather_before_button_text_i18n;
        		            case "gather_button_text":
            	            return this.gather_button_text;
        		            case "gather_button_text_i18n":
            	            return this.gather_button_text_i18n;
        		            case "progress_bar":
            	            return this.progress_bar;
        		            case "speed":
            	            return this.speed;
        		            case "role_action":
            	            return this.role_action;
        		            case "npc_start_action":
            	            return this.npc_start_action;
        		            case "npc_start_effect":
            	            return this.npc_start_effect;
        		            case "npc_start_sound":
            	            return this.npc_start_sound;
        		            case "npc_finish_action":
            	            return this.npc_finish_action;
        		            case "npc_finish_effect":
            	            return this.npc_finish_effect;
        		            case "finish_tips":
            	            return this.finish_tips;
        		            case "finish_tips_i18n":
            	            return this.finish_tips_i18n;
        		            case "finish_reward_id":
            	            return this.finish_reward_id;
        		            case "angle":
            	            return this.angle;
        		            default:
                        return null;
			            }
		         }
                 public static void InitPool(IList _rows){
							List<Table_Scene_Box> rows = _rows as List<Table_Scene_Box>;
                      		pool_primary=TableContent.ListToPool < int, Table_Scene_Box > ( rows, "map", "id" );
                      		pool_sceneId=TableContent.ListToPoolList < int, Table_Scene_Box > ( rows, "list", "scene_id" );
							all_Table_Scene_Box_List=rows;
                 }

                public static void Clear()
                {
                       pool_primary.Clear();
                       pool_sceneId.Clear();
                       all_Table_Scene_Box_List.Clear();

                }
    }
}
