using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 服务器等级上限
    ///</summary>
    [Serializable]
    [TableName("server_level_cap")]
    public partial class Table_Server_Level_Cap : TableContent
    {

        private static List<Table_Server_Level_Cap> all_Table_Server_Level_Cap_List = new List<Table_Server_Level_Cap>();
        //primary | 主键
        public static Dictionary<int, Table_Server_Level_Cap > pool_primary = new Dictionary<int, Table_Server_Level_Cap > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 下一级ID
        ///</summary>
        public int next_id;
        
        
        ///<summary>
        /// 最高等级
        ///</summary>
        public int max_level;
        
        
        ///<summary>
        /// 是否开启盈福经验
        ///</summary>
        public int exp_reserve_enable;
        
        
        ///<summary>
        /// 开服时间(单位:天)
        ///</summary>
        public int server_open_time_diff;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Server_Level_Cap GetPrimary ( int _id ){        
            Table_Server_Level_Cap _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Server_Level_Cap > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Server_Level_Cap> GetAllPrimaryList()
        {
            return all_Table_Server_Level_Cap_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("next_id", out _currValue))
            {
                this.next_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_level", out _currValue))
            {
                this.max_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("exp_reserve_enable", out _currValue))
            {
                this.exp_reserve_enable = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("server_open_time_diff", out _currValue))
            {
                this.server_open_time_diff = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "server_level_cap";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "next_id":
                    return this.next_id;
                case "max_level":
                    return this.max_level;
                case "exp_reserve_enable":
                    return this.exp_reserve_enable;
                case "server_open_time_diff":
                    return this.server_open_time_diff;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Server_Level_Cap> rows = _rows as List<Table_Server_Level_Cap>;
            pool_primary=TableContent.ListToPool < int, Table_Server_Level_Cap > ( rows, "map", "id" );
            all_Table_Server_Level_Cap_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Server_Level_Cap_List.Clear();
        }
    }
}
