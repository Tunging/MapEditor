using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 主界面事件通知
    ///</summary>
    [Serializable]
    [TableName("main_event_notice")]
    public partial class Table_Main_Event_Notice : TableContent
    {

        private static List<Table_Main_Event_Notice> all_Table_Main_Event_Notice_List = new List<Table_Main_Event_Notice>();
        //primary | 主键
        public static Dictionary<int, Table_Main_Event_Notice > pool_primary = new Dictionary<int, Table_Main_Event_Notice > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 显示图标ID
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 主界面提示文本ID
        ///</summary>
        public int tip_text;
        
        
        ///<summary>
        /// 标题国际化
        ///</summary>
        public string title_i18n;
        
        
        ///<summary>
        /// 内容国际化
        ///</summary>
        public string content_i18n;
        
        
        ///<summary>
        /// 按钮处理类型（此处枚举2类（0-跳转查看，1确定和取消））
        ///</summary>
        public int handle_type;
        
        
        ///<summary>
        /// 否定意向的 按钮显示名字（language表中）
        ///</summary>
        public int button1name;
        
        
        ///<summary>
        /// 肯定意向的 按钮显示名字（language表中）
        ///</summary>
        public int button2name;
        
        
        ///<summary>
        /// 跳转类的， 需要跳转到的界面ID
        ///</summary>
        public int goto_panel_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Table_Main_Event_Notice GetPrimary ( int _id ){        
            Table_Main_Event_Notice _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Main_Event_Notice > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Main_Event_Notice> GetAllPrimaryList()
        {
            return all_Table_Main_Event_Notice_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("tip_text", out _currValue))
            {
                this.tip_text = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("title_i18n", out _currValue))
            {
                this.title_i18n = _currValue;
            }
            if(_itemData.TryGetValue("content_i18n", out _currValue))
            {
                this.content_i18n = _currValue;
            }
            if(_itemData.TryGetValue("handle_type", out _currValue))
            {
                this.handle_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("button1name", out _currValue))
            {
                this.button1name = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("button2name", out _currValue))
            {
                this.button2name = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("goto_panel_id", out _currValue))
            {
                this.goto_panel_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "main_event_notice";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name_i18n":
                    return this.name_i18n;
                case "icon_id":
                    return this.icon_id;
                case "tip_text":
                    return this.tip_text;
                case "title_i18n":
                    return this.title_i18n;
                case "content_i18n":
                    return this.content_i18n;
                case "handle_type":
                    return this.handle_type;
                case "button1name":
                    return this.button1name;
                case "button2name":
                    return this.button2name;
                case "goto_panel_id":
                    return this.goto_panel_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Main_Event_Notice> rows = _rows as List<Table_Main_Event_Notice>;
            pool_primary=TableContent.ListToPool < int, Table_Main_Event_Notice > ( rows, "map", "id" );
            all_Table_Main_Event_Notice_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Main_Event_Notice_List.Clear();
        }
    }
}
