using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 新手引导
    ///</summary>
    [Serializable]
    [TableName("novice_guide")]
    public partial class Table_Novice_Guide : TableContent
    {

        private static List<Table_Novice_Guide> all_Table_Novice_Guide_List = new List<Table_Novice_Guide>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Novice_Guide > > pool_primary = new Dictionary<int, Dictionary<int, Table_Novice_Guide > > ();
        //id | 
        public static Dictionary<int, List<Table_Novice_Guide> > pool_id = new Dictionary<int, List<Table_Novice_Guide> > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 步骤ID
        ///</summary>
        public int step;
        
        
        ///<summary>
        /// 类型(客户端定义)
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 等级限制
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 职业限制
        ///</summary>
        public int profession;
        
        
        ///<summary>
        /// 前置引导限制
        ///</summary>
        public int pre_guide_id;
        
        
        ///<summary>
        /// 提示文字
        ///</summary>
        public string prompt_text;
        
        
        ///<summary>
        /// 引导界面中需要播放的特效节点名称
        ///</summary>
        public string tip_obj_name;
        
        
        ///<summary>
        /// 特效节点的偏移位置(有指引控件时为相对坐标,否则不生效)
        ///</summary>
        public string effect_pos;
        
        
        ///<summary>
        /// 参数1
        ///</summary>
        public string param1;
        
        
        ///<summary>
        /// 参数2
        ///</summary>
        public string param2;
        
        
        ///<summary>
        /// 参数3
        ///</summary>
        public string param3;
        
        
        ///<summary>
        /// 关联区域ID
        ///</summary>
        public int region_id;
        
        
        ///<summary>
        /// 特效文本
        ///</summary>
        public string language;
        
        
        ///<summary>
        /// 提示文本位置(有指引控件时为相对坐标,否则为绝对坐标)
        ///</summary>
        public string language_pos;
        
        
        ///<summary>
        /// 提示文本半身像ID
        ///</summary>
        public int language_icon_id;
        
        
        ///<summary>
        /// 音效
        ///</summary>
        public int sound_effect;
        
        
        ///<summary>
        /// 箭头位置(有指引控件时为相对坐标,否则为绝对坐标)
        ///</summary>
        public string arrow_pos;
        
        
        ///<summary>
        /// 箭头朝向
        ///</summary>
        public float arrow_direction;
        
        
        ///<summary>
        /// 是否强制
        ///</summary>
        public bool is_force;
        
        
        ///<summary>
        /// 强制指引时隐藏黑色蒙版
        ///</summary>
        public bool is_hide_blackmask;
        
        
        ///<summary>
        /// 是否定帧
        ///</summary>
        public bool is_froze;
        
        
        ///<summary>
        /// 界面中需要指引的控件名
        ///</summary>
        public string force_click_obj_name;
        
        
        ///<summary>
        /// 是否回到主界面
        ///</summary>
        public bool return_to_main;
        
        
        ///<summary>
        /// 自动关闭时间
        ///</summary>
        public int close_time;
        
        
        ///<summary>
        /// 跳过时间
        ///</summary>
        public int skip_delay_time;
        
        
        ///<summary>
        /// 延迟时间
        ///</summary>
        public int show_delay_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Dictionary<int, Table_Novice_Guide > GetPrimary ( int _id ){        
            Dictionary<int, Table_Novice_Guide > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///	<param step> 步骤ID</param>
        ///
        public static Table_Novice_Guide GetPrimary ( int _id , int _step ){        
            Dictionary<int, Table_Novice_Guide > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Novice_Guide _map1=null;        
            _map0. TryGetValue(_step,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Novice_Guide > > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static List<Table_Novice_Guide> GetId ( int _id ){        
            List<Table_Novice_Guide> _map0=null;        
            pool_id. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Novice_Guide> > GetAllId()
        {
            return pool_id;
        }


        ///查询出所有的数据
        public static List<Table_Novice_Guide> GetAllPrimaryList()
        {
            return all_Table_Novice_Guide_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("step", out _currValue))
            {
                this.step = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("profession", out _currValue))
            {
                this.profession = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pre_guide_id", out _currValue))
            {
                this.pre_guide_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prompt_text", out _currValue))
            {
                this.prompt_text = _currValue;
            }
            if(_itemData.TryGetValue("tip_obj_name", out _currValue))
            {
                this.tip_obj_name = _currValue;
            }
            if(_itemData.TryGetValue("effect_pos", out _currValue))
            {
                this.effect_pos = _currValue;
            }
            if(_itemData.TryGetValue("param1", out _currValue))
            {
                this.param1 = _currValue;
            }
            if(_itemData.TryGetValue("param2", out _currValue))
            {
                this.param2 = _currValue;
            }
            if(_itemData.TryGetValue("param3", out _currValue))
            {
                this.param3 = _currValue;
            }
            if(_itemData.TryGetValue("region_id", out _currValue))
            {
                this.region_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("language", out _currValue))
            {
                this.language = _currValue;
            }
            if(_itemData.TryGetValue("language_pos", out _currValue))
            {
                this.language_pos = _currValue;
            }
            if(_itemData.TryGetValue("language_icon_id", out _currValue))
            {
                this.language_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_effect", out _currValue))
            {
                this.sound_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("arrow_pos", out _currValue))
            {
                this.arrow_pos = _currValue;
            }
            if(_itemData.TryGetValue("arrow_direction", out _currValue))
            {
                this.arrow_direction = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_force", out _currValue))
            {
                this.is_force = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_hide_blackmask", out _currValue))
            {
                this.is_hide_blackmask = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_froze", out _currValue))
            {
                this.is_froze = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("force_click_obj_name", out _currValue))
            {
                this.force_click_obj_name = _currValue;
            }
            if(_itemData.TryGetValue("return_to_main", out _currValue))
            {
                this.return_to_main = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("close_time", out _currValue))
            {
                this.close_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skip_delay_time", out _currValue))
            {
                this.skip_delay_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_delay_time", out _currValue))
            {
                this.show_delay_time = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "novice_guide";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "step":
                    return this.step;
                case "type":
                    return this.type;
                case "level":
                    return this.level;
                case "profession":
                    return this.profession;
                case "pre_guide_id":
                    return this.pre_guide_id;
                case "prompt_text":
                    return this.prompt_text;
                case "tip_obj_name":
                    return this.tip_obj_name;
                case "effect_pos":
                    return this.effect_pos;
                case "param1":
                    return this.param1;
                case "param2":
                    return this.param2;
                case "param3":
                    return this.param3;
                case "region_id":
                    return this.region_id;
                case "language":
                    return this.language;
                case "language_pos":
                    return this.language_pos;
                case "language_icon_id":
                    return this.language_icon_id;
                case "sound_effect":
                    return this.sound_effect;
                case "arrow_pos":
                    return this.arrow_pos;
                case "arrow_direction":
                    return this.arrow_direction;
                case "is_force":
                    return this.is_force;
                case "is_hide_blackmask":
                    return this.is_hide_blackmask;
                case "is_froze":
                    return this.is_froze;
                case "force_click_obj_name":
                    return this.force_click_obj_name;
                case "return_to_main":
                    return this.return_to_main;
                case "close_time":
                    return this.close_time;
                case "skip_delay_time":
                    return this.skip_delay_time;
                case "show_delay_time":
                    return this.show_delay_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Novice_Guide> rows = _rows as List<Table_Novice_Guide>;
            pool_primary=TableContent.ListToPool < int, int, Table_Novice_Guide > ( rows, "map", "id", "step" );
            pool_id=TableContent.ListToPoolList < int, Table_Novice_Guide > ( rows, "list", "id" );
            all_Table_Novice_Guide_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_id.Clear();
            all_Table_Novice_Guide_List.Clear();
        }
    }
}
