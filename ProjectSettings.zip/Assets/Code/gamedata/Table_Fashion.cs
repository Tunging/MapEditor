using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 时装
    ///</summary>
    [Serializable]
    [TableName("fashion")]
    public partial class Table_Fashion : TableContent
    {

        private static List<Table_Fashion> all_Table_Fashion_List = new List<Table_Fashion>();
        //primary | 主键
        public static Dictionary<int, Table_Fashion > pool_primary = new Dictionary<int, Table_Fashion > ();
        
        
        ///<summary>
        /// 时装ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 时装名字
        ///</summary>
        public string skin_name;
        
        
        ///<summary>
        /// 时装名字国际化
        ///</summary>
        public string skin_name_en;
        
        
        ///<summary>
        /// 时装碎片
        ///</summary>
        public int skin_piece_id;
        
        
        ///<summary>
        /// 时装碎片数量
        ///</summary>
        public int skin_piece_num;
        
        
        ///<summary>
        /// 时装icon
        ///</summary>
        public int skin_icon_id;
        
        
        ///<summary>
        /// 时装模型
        ///</summary>
        public int skin_model_id;
        
        
        ///<summary>
        /// 1是时装，2是武器
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 职业（0代表通用）
        ///</summary>
        public int profession;
        
        
        ///<summary>
        /// 武器位置
        ///</summary>
        public int weapon_pos;
        
        
        ///<summary>
        /// 武器类型
        ///</summary>
        public int weapon_type;
        
        
        ///<summary>
        /// 传送动作ID
        ///</summary>
        public int transfer_action_id;
        
        
        ///<summary>
        /// 传送特效ID
        ///</summary>
        public int transfer_effect_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 时装ID</param>
        ///
        public static Table_Fashion GetPrimary ( int _id ){        
            Table_Fashion _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Fashion > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Fashion> GetAllPrimaryList()
        {
            return all_Table_Fashion_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skin_name", out _currValue))
            {
                this.skin_name = _currValue;
            }
            if(_itemData.TryGetValue("skin_name_en", out _currValue))
            {
                this.skin_name_en = _currValue;
            }
            if(_itemData.TryGetValue("skin_piece_id", out _currValue))
            {
                this.skin_piece_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skin_piece_num", out _currValue))
            {
                this.skin_piece_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skin_icon_id", out _currValue))
            {
                this.skin_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skin_model_id", out _currValue))
            {
                this.skin_model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("profession", out _currValue))
            {
                this.profession = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weapon_pos", out _currValue))
            {
                this.weapon_pos = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weapon_type", out _currValue))
            {
                this.weapon_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("transfer_action_id", out _currValue))
            {
                this.transfer_action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("transfer_effect_id", out _currValue))
            {
                this.transfer_effect_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "fashion";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "skin_name":
                    return this.skin_name;
                case "skin_name_en":
                    return this.skin_name_en;
                case "skin_piece_id":
                    return this.skin_piece_id;
                case "skin_piece_num":
                    return this.skin_piece_num;
                case "skin_icon_id":
                    return this.skin_icon_id;
                case "skin_model_id":
                    return this.skin_model_id;
                case "type":
                    return this.type;
                case "profession":
                    return this.profession;
                case "weapon_pos":
                    return this.weapon_pos;
                case "weapon_type":
                    return this.weapon_type;
                case "transfer_action_id":
                    return this.transfer_action_id;
                case "transfer_effect_id":
                    return this.transfer_effect_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Fashion> rows = _rows as List<Table_Fashion>;
            pool_primary=TableContent.ListToPool < int, Table_Fashion > ( rows, "map", "id" );
            all_Table_Fashion_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Fashion_List.Clear();
        }
    }
}
