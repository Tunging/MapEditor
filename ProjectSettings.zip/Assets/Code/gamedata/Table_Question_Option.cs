using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 背景问题选项
    ///</summary>
    [Serializable]
    [TableName("question_option")]
    public partial class Table_Question_Option : TableContent
    {

        private static List<Table_Question_Option> all_Table_Question_Option_List = new List<Table_Question_Option>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Question_Option > > pool_primary = new Dictionary<int, Dictionary<int, Table_Question_Option > > ();
        
        
        ///<summary>
        /// 
        ///</summary>
        public int question_id;
        
        
        ///<summary>
        /// 
        ///</summary>
        public int option_id;
        
        
        ///<summary>
        /// 选项1国际化
        ///</summary>
        public string option1_i18n;
        
        
        ///<summary>
        /// 选项1解释国际化
        ///</summary>
        public string option1_des_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param questionId> </param>
        ///
        public static Dictionary<int, Table_Question_Option > GetPrimary ( int _questionId ){        
            Dictionary<int, Table_Question_Option > _map0=null;        
            pool_primary. TryGetValue(_questionId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param questionId> </param>
        ///	<param optionId> </param>
        ///
        public static Table_Question_Option GetPrimary ( int _questionId , int _optionId ){        
            Dictionary<int, Table_Question_Option > _map0=null;        
            pool_primary. TryGetValue(_questionId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Question_Option _map1=null;        
            _map0. TryGetValue(_optionId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Question_Option > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Question_Option> GetAllPrimaryList()
        {
            return all_Table_Question_Option_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("question_id", out _currValue))
            {
                this.question_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("option_id", out _currValue))
            {
                this.option_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("option1_i18n", out _currValue))
            {
                this.option1_i18n = _currValue;
            }
            if(_itemData.TryGetValue("option1_des_i18n", out _currValue))
            {
                this.option1_des_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "question_option";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "question_id":
                    return this.question_id;
                case "option_id":
                    return this.option_id;
                case "option1_i18n":
                    return this.option1_i18n;
                case "option1_des_i18n":
                    return this.option1_des_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Question_Option> rows = _rows as List<Table_Question_Option>;
            pool_primary=TableContent.ListToPool < int, int, Table_Question_Option > ( rows, "map", "question_id", "option_id" );
            all_Table_Question_Option_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Question_Option_List.Clear();
        }
    }
}
