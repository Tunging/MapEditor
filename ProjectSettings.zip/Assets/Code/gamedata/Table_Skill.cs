using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能
    ///</summary>
    [Serializable]
    [TableName("skill")]
    public partial class Table_Skill : TableContent
    {

        private static List<Table_Skill> all_Table_Skill_List = new List<Table_Skill>();
        //primary | 主键
        public static Dictionary<int, Table_Skill > pool_primary = new Dictionary<int, Table_Skill > ();
        
        
        ///<summary>
        /// 主键：技能ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 释放方式
        ///</summary>
        public int use_type;
        
        
        ///<summary>
        /// 施法距离
        ///</summary>
        public int use_distance;
        
        
        ///<summary>
        /// 一级消耗
        ///</summary>
        public int cost;
        
        
        ///<summary>
        /// 获得 一级消耗
        ///</summary>
        public int obtain_chakra;
        
        
        ///<summary>
        /// 是否使用全部一级消耗附加伤害
        ///</summary>
        public bool use_all_chakra;
        
        
        ///<summary>
        /// 消耗连击点数量
        ///</summary>
        public int cost_combo_point;
        
        
        ///<summary>
        /// 冷却时间
        ///</summary>
        public int cd_time;
        
        
        ///<summary>
        /// 是否可以移动施法
        ///</summary>
        public bool move_spell;
        
        
        ///<summary>
        /// 是否触发公共冷却时间
        ///</summary>
        public bool trigger_public_cd;
        
        
        ///<summary>
        /// 是否免疫控制
        ///</summary>
        public bool ignore_control;
        
        
        ///<summary>
        /// 位移速度：米/秒
        ///</summary>
        public int shift_speed;
        
        
        ///<summary>
        /// 追踪子弹飞行速度：米/秒
        ///</summary>
        public int track_bullet_speed;
        
        
        ///<summary>
        /// 定位子弹飞行时间：毫秒
        ///</summary>
        public int locate_bullet_time;
        
        
        ///<summary>
        /// 技能图标
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 效果描述
        ///</summary>
        public string effect_description;
        
        
        ///<summary>
        /// 飘字总次数
        ///</summary>
        public int floating_count;
        
        
        ///<summary>
        /// 飘字间隔时间(ms)
        ///</summary>
        public int floating_interval;
        
        
        ///<summary>
        /// 是否触发摄像机自动旋转
        ///</summary>
        public bool trigger_camera_auto_rotation;
        
        
        ///<summary>
        /// 是否使用连击点
        ///</summary>
        public bool use_combo_point;
        
        
        ///<summary>
        /// 不可移动时间
        ///</summary>
        public int no_move_duration;
        
        
        ///<summary>
        /// 收招点，基于后摇
        ///</summary>
        public int close_time;
        
        
        ///<summary>
        /// 前摇动作
        ///</summary>
        public int pre_action;
        
        
        ///<summary>
        /// 施法动作
        ///</summary>
        public int cast_action;
        
        
        ///<summary>
        /// 吟唱动作
        ///</summary>
        public int sing_action;
        
        
        ///<summary>
        /// 后摇动作
        ///</summary>
        public int post_action;
        
        
        ///<summary>
        /// 前摇特效
        ///</summary>
        public int pre_effect;
        
        
        ///<summary>
        /// 施法特效
        ///</summary>
        public int cast_effect;
        
        
        ///<summary>
        /// 吟唱特效
        ///</summary>
        public int sing_effect;
        
        
        ///<summary>
        /// 后摇特效
        ///</summary>
        public int post_effect;
        
        
        ///<summary>
        /// 子弹特效
        ///</summary>
        public int bullet_effect;
        
        
        ///<summary>
        /// 子物体特效
        ///</summary>
        public int subobject_effect;
        
        
        ///<summary>
        /// 受击高级动作
        ///</summary>
        public int target_high_action;
        
        
        ///<summary>
        /// 受击动作
        ///</summary>
        public int target_action;
        
        
        ///<summary>
        /// 受击特效
        ///</summary>
        public int target_effect;
        
        
        ///<summary>
        /// 受击音效
        ///</summary>
        public int target_sound;
        
        
        ///<summary>
        /// IK脚本权重
        ///</summary>
        public string ik_weight;
        
        
        ///<summary>
        /// 技能使用优先级，高级打断低级，同级缓存， 优先级为1，级别最低
        ///</summary>
        public int priority;
        
        
        ///<summary>
        /// 技能使用条件id
        ///</summary>
        public int use_condition;
        
        
        ///<summary>
        /// 技能使用条件数值
        ///</summary>
        public int use_condition_value;
        
        
        ///<summary>
        /// 技能的标签
        ///</summary>
        public string skil_label;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：技能ID</param>
        ///
        public static Table_Skill GetPrimary ( int _id ){        
            Table_Skill _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Skill > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill> GetAllPrimaryList()
        {
            return all_Table_Skill_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_type", out _currValue))
            {
                this.use_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_distance", out _currValue))
            {
                this.use_distance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cost", out _currValue))
            {
                this.cost = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("obtain_chakra", out _currValue))
            {
                this.obtain_chakra = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_all_chakra", out _currValue))
            {
                this.use_all_chakra = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("cost_combo_point", out _currValue))
            {
                this.cost_combo_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cd_time", out _currValue))
            {
                this.cd_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("move_spell", out _currValue))
            {
                this.move_spell = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_public_cd", out _currValue))
            {
                this.trigger_public_cd = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("ignore_control", out _currValue))
            {
                this.ignore_control = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("shift_speed", out _currValue))
            {
                this.shift_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("track_bullet_speed", out _currValue))
            {
                this.track_bullet_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("locate_bullet_time", out _currValue))
            {
                this.locate_bullet_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("effect_description", out _currValue))
            {
                this.effect_description = _currValue;
            }
            if(_itemData.TryGetValue("floating_count", out _currValue))
            {
                this.floating_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_interval", out _currValue))
            {
                this.floating_interval = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_camera_auto_rotation", out _currValue))
            {
                this.trigger_camera_auto_rotation = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_combo_point", out _currValue))
            {
                this.use_combo_point = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("no_move_duration", out _currValue))
            {
                this.no_move_duration = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("close_time", out _currValue))
            {
                this.close_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pre_action", out _currValue))
            {
                this.pre_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cast_action", out _currValue))
            {
                this.cast_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sing_action", out _currValue))
            {
                this.sing_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("post_action", out _currValue))
            {
                this.post_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pre_effect", out _currValue))
            {
                this.pre_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cast_effect", out _currValue))
            {
                this.cast_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sing_effect", out _currValue))
            {
                this.sing_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("post_effect", out _currValue))
            {
                this.post_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("bullet_effect", out _currValue))
            {
                this.bullet_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("subobject_effect", out _currValue))
            {
                this.subobject_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_high_action", out _currValue))
            {
                this.target_high_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_action", out _currValue))
            {
                this.target_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_effect", out _currValue))
            {
                this.target_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_sound", out _currValue))
            {
                this.target_sound = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ik_weight", out _currValue))
            {
                this.ik_weight = _currValue;
            }
            if(_itemData.TryGetValue("priority", out _currValue))
            {
                this.priority = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_condition", out _currValue))
            {
                this.use_condition = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_condition_value", out _currValue))
            {
                this.use_condition_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skil_label", out _currValue))
            {
                this.skil_label = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "type":
                    return this.type;
                case "use_type":
                    return this.use_type;
                case "use_distance":
                    return this.use_distance;
                case "cost":
                    return this.cost;
                case "obtain_chakra":
                    return this.obtain_chakra;
                case "use_all_chakra":
                    return this.use_all_chakra;
                case "cost_combo_point":
                    return this.cost_combo_point;
                case "cd_time":
                    return this.cd_time;
                case "move_spell":
                    return this.move_spell;
                case "trigger_public_cd":
                    return this.trigger_public_cd;
                case "ignore_control":
                    return this.ignore_control;
                case "shift_speed":
                    return this.shift_speed;
                case "track_bullet_speed":
                    return this.track_bullet_speed;
                case "locate_bullet_time":
                    return this.locate_bullet_time;
                case "icon_id":
                    return this.icon_id;
                case "description_i18n":
                    return this.description_i18n;
                case "effect_description":
                    return this.effect_description;
                case "floating_count":
                    return this.floating_count;
                case "floating_interval":
                    return this.floating_interval;
                case "trigger_camera_auto_rotation":
                    return this.trigger_camera_auto_rotation;
                case "use_combo_point":
                    return this.use_combo_point;
                case "no_move_duration":
                    return this.no_move_duration;
                case "close_time":
                    return this.close_time;
                case "pre_action":
                    return this.pre_action;
                case "cast_action":
                    return this.cast_action;
                case "sing_action":
                    return this.sing_action;
                case "post_action":
                    return this.post_action;
                case "pre_effect":
                    return this.pre_effect;
                case "cast_effect":
                    return this.cast_effect;
                case "sing_effect":
                    return this.sing_effect;
                case "post_effect":
                    return this.post_effect;
                case "bullet_effect":
                    return this.bullet_effect;
                case "subobject_effect":
                    return this.subobject_effect;
                case "target_high_action":
                    return this.target_high_action;
                case "target_action":
                    return this.target_action;
                case "target_effect":
                    return this.target_effect;
                case "target_sound":
                    return this.target_sound;
                case "ik_weight":
                    return this.ik_weight;
                case "priority":
                    return this.priority;
                case "use_condition":
                    return this.use_condition;
                case "use_condition_value":
                    return this.use_condition_value;
                case "skil_label":
                    return this.skil_label;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill> rows = _rows as List<Table_Skill>;
            pool_primary=TableContent.ListToPool < int, Table_Skill > ( rows, "map", "id" );
            all_Table_Skill_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_List.Clear();
        }
    }
}
