using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能组等级
    ///</summary>
    [Serializable]
    [TableName("skill_group_level")]
    public partial class Table_Skill_Group_Level : TableContent
    {

        private static List<Table_Skill_Group_Level> all_Table_Skill_Group_Level_List = new List<Table_Skill_Group_Level>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Skill_Group_Level > > pool_primary = new Dictionary<int, Dictionary<int, Table_Skill_Group_Level > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int skill_group_id;
        
        
        ///<summary>
        /// 技能组等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string desc;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public int desc_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillGroupId> 主键：ID</param>
        ///
        public static Dictionary<int, Table_Skill_Group_Level > GetPrimary ( int _skillGroupId ){        
            Dictionary<int, Table_Skill_Group_Level > _map0=null;        
            pool_primary. TryGetValue(_skillGroupId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillGroupId> 主键：ID</param>
        ///	<param level> 技能组等级</param>
        ///
        public static Table_Skill_Group_Level GetPrimary ( int _skillGroupId , int _level ){        
            Dictionary<int, Table_Skill_Group_Level > _map0=null;        
            pool_primary. TryGetValue(_skillGroupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Skill_Group_Level _map1=null;        
            _map0. TryGetValue(_level,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Skill_Group_Level > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Group_Level> GetAllPrimaryList()
        {
            return all_Table_Skill_Group_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_group_id", out _currValue))
            {
                this.skill_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("desc", out _currValue))
            {
                this.desc = _currValue;
            }
            if(_itemData.TryGetValue("desc_i18n", out _currValue))
            {
                this.desc_i18n = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_group_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_group_id":
                    return this.skill_group_id;
                case "level":
                    return this.level;
                case "desc":
                    return this.desc;
                case "desc_i18n":
                    return this.desc_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Group_Level> rows = _rows as List<Table_Skill_Group_Level>;
            pool_primary=TableContent.ListToPool < int, int, Table_Skill_Group_Level > ( rows, "map", "skill_group_id", "level" );
            all_Table_Skill_Group_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Group_Level_List.Clear();
        }
    }
}
