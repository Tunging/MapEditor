using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 道具合成配方
    ///</summary>
    [Serializable]
    [TableName("item_synthesize_formula")]
    public partial class Table_Item_Synthesize_Formula : TableContent
    {

        private static List<Table_Item_Synthesize_Formula> all_Table_Item_Synthesize_Formula_List = new List<Table_Item_Synthesize_Formula>();
        //primary | 主键
        public static Dictionary<int, Table_Item_Synthesize_Formula > pool_primary = new Dictionary<int, Table_Item_Synthesize_Formula > ();
        
        
        ///<summary>
        /// 主键：配方ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 原料道具数量
        ///</summary>
        public int material_item_num;
        
        
        ///<summary>
        /// 辅料道具ID1
        ///</summary>
        public int accessory_item1_id;
        
        
        ///<summary>
        /// 辅料道具1数量
        ///</summary>
        public int accessory_item1_num;
        
        
        ///<summary>
        /// 辅料道具2ID
        ///</summary>
        public int accessory_item2_id;
        
        
        ///<summary>
        /// 辅料道具2数量
        ///</summary>
        public int accessory_item2_num;
        
        
        ///<summary>
        /// 辅料道具3ID
        ///</summary>
        public int accessory_item3_id;
        
        
        ///<summary>
        /// 原料道具3数量
        ///</summary>
        public int accessory_item3_num;
        
        
        ///<summary>
        /// 产品道具ID
        ///</summary>
        public int product_item_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：配方ID</param>
        ///
        public static Table_Item_Synthesize_Formula GetPrimary ( int _id ){        
            Table_Item_Synthesize_Formula _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Item_Synthesize_Formula > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Item_Synthesize_Formula> GetAllPrimaryList()
        {
            return all_Table_Item_Synthesize_Formula_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("material_item_num", out _currValue))
            {
                this.material_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("accessory_item1_id", out _currValue))
            {
                this.accessory_item1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("accessory_item1_num", out _currValue))
            {
                this.accessory_item1_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("accessory_item2_id", out _currValue))
            {
                this.accessory_item2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("accessory_item2_num", out _currValue))
            {
                this.accessory_item2_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("accessory_item3_id", out _currValue))
            {
                this.accessory_item3_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("accessory_item3_num", out _currValue))
            {
                this.accessory_item3_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("product_item_id", out _currValue))
            {
                this.product_item_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "item_synthesize_formula";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "material_item_num":
                    return this.material_item_num;
                case "accessory_item1_id":
                    return this.accessory_item1_id;
                case "accessory_item1_num":
                    return this.accessory_item1_num;
                case "accessory_item2_id":
                    return this.accessory_item2_id;
                case "accessory_item2_num":
                    return this.accessory_item2_num;
                case "accessory_item3_id":
                    return this.accessory_item3_id;
                case "accessory_item3_num":
                    return this.accessory_item3_num;
                case "product_item_id":
                    return this.product_item_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Item_Synthesize_Formula> rows = _rows as List<Table_Item_Synthesize_Formula>;
            pool_primary=TableContent.ListToPool < int, Table_Item_Synthesize_Formula > ( rows, "map", "id" );
            all_Table_Item_Synthesize_Formula_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Item_Synthesize_Formula_List.Clear();
        }
    }
}
