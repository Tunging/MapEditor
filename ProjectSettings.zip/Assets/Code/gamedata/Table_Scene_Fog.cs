using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景迷雾
    ///</summary>
    [Serializable]
    [TableName("scene_fog")]
    public partial class Table_Scene_Fog : TableContent
    {

        private static List<Table_Scene_Fog> all_Table_Scene_Fog_List = new List<Table_Scene_Fog>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Fog > pool_primary = new Dictionary<int, Table_Scene_Fog > ();
        
        
        ///<summary>
        /// 主键ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 场景迷雾区域
        ///</summary>
        public string fog_area;
        
        
        ///<summary>
        /// 解锁区域ID
        ///</summary>
        public int unlock_id;
        
        
        ///<summary>
        /// 奖励id
        ///</summary>
        public int reward_id;
        
        
        ///<summary>
        /// 声音资源ID
        ///</summary>
        public int sound_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键ID</param>
        ///
        public static Table_Scene_Fog GetPrimary ( int _id ){        
            Table_Scene_Fog _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Fog > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Fog> GetAllPrimaryList()
        {
            return all_Table_Scene_Fog_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fog_area", out _currValue))
            {
                this.fog_area = _currValue;
            }
            if(_itemData.TryGetValue("unlock_id", out _currValue))
            {
                this.unlock_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward_id", out _currValue))
            {
                this.reward_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_fog";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "scene_id":
                    return this.scene_id;
                case "fog_area":
                    return this.fog_area;
                case "unlock_id":
                    return this.unlock_id;
                case "reward_id":
                    return this.reward_id;
                case "sound_id":
                    return this.sound_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Fog> rows = _rows as List<Table_Scene_Fog>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Fog > ( rows, "map", "id" );
            all_Table_Scene_Fog_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Fog_List.Clear();
        }
    }
}
