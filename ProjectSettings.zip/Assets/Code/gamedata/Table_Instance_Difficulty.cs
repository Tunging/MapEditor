using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本难度
    ///</summary>
    [Serializable]
    [TableName("instance_difficulty")]
    public partial class Table_Instance_Difficulty : TableContent
    {

        private static List<Table_Instance_Difficulty> all_Table_Instance_Difficulty_List = new List<Table_Instance_Difficulty>();
        //primary | 主键
        public static Dictionary<int, Table_Instance_Difficulty > pool_primary = new Dictionary<int, Table_Instance_Difficulty > ();
        
        
        ///<summary>
        /// 
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string des;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string des_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> </param>
        ///
        public static Table_Instance_Difficulty GetPrimary ( int _id ){        
            Table_Instance_Difficulty _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Instance_Difficulty > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance_Difficulty> GetAllPrimaryList()
        {
            return all_Table_Instance_Difficulty_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("des", out _currValue))
            {
                this.des = _currValue;
            }
            if(_itemData.TryGetValue("des_i18n", out _currValue))
            {
                this.des_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance_difficulty";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "des":
                    return this.des;
                case "des_i18n":
                    return this.des_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance_Difficulty> rows = _rows as List<Table_Instance_Difficulty>;
            pool_primary=TableContent.ListToPool < int, Table_Instance_Difficulty > ( rows, "map", "id" );
            all_Table_Instance_Difficulty_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_Difficulty_List.Clear();
        }
    }
}
