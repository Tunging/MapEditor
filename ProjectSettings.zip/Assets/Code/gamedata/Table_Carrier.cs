using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 载具表
    ///</summary>
    [Serializable]
    [TableName("carrier")]
    public partial class Table_Carrier : TableContent
    {

        private static List<Table_Carrier> all_Table_Carrier_List = new List<Table_Carrier>();
        //primary | 主键
        public static Dictionary<int, Table_Carrier > pool_primary = new Dictionary<int, Table_Carrier > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 退出类型
        ///</summary>
        public int exit_type;
        
        
        ///<summary>
        /// 种族限制
        ///</summary>
        public int race;
        
        
        ///<summary>
        /// 关联技能组1
        ///</summary>
        public int skill_group1;
        
        
        ///<summary>
        /// 关联技能组2
        ///</summary>
        public int skill_group2;
        
        
        ///<summary>
        /// 关联技能组3
        ///</summary>
        public int skill_group3;
        
        
        ///<summary>
        /// 关联技能组4
        ///</summary>
        public int skill_group4;
        
        
        ///<summary>
        /// 关联技能组5
        ///</summary>
        public int skill_group5;
        
        
        ///<summary>
        /// 骑乘动作ID
        ///</summary>
        public int riding_action;
        
        
        ///<summary>
        /// 背景音乐
        ///</summary>
        public int background_sound;
        
        
        ///<summary>
        /// 默认模型ID
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 职业对应模型ID列表
        ///</summary>
        public string profesion_model_ids;
        
        
        ///<summary>
        /// 退出音效
        ///</summary>
        public int leave_sound_id;
        
        
        ///<summary>
        /// 骨骼
        ///</summary>
        public string bone;
        
        
        ///<summary>
        /// 进入相机触发器ID
        ///</summary>
        public int enter_camera_id;
        
        
        ///<summary>
        /// 退出相机触发器
        ///</summary>
        public int leave_camera_id;
        
        
        ///<summary>
        /// 是否可以主动离开
        ///</summary>
        public bool is_initiative_leave;
        
        
        ///<summary>
        /// 是否可以跳跃
        ///</summary>
        public bool is_jump;
        
        
        ///<summary>
        /// 是否可以游泳
        ///</summary>
        public bool is_swim;
        
        
        ///<summary>
        /// 是否可以滑翔
        ///</summary>
        public bool is_glide;
        
        
        ///<summary>
        /// 是否隐藏武器
        ///</summary>
        public bool is_hide_weapon;
        
        
        ///<summary>
        /// 替换显示名字
        ///</summary>
        public bool replace_show_name;
        
        
        ///<summary>
        /// 身高
        ///</summary>
        public float height;
        
        
        ///<summary>
        /// 动作状态机ID
        ///</summary>
        public int client_model_animator_id;
        
        
        ///<summary>
        /// 能不能显示脚底指引
        ///</summary>
        public bool can_show_dir_tran;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Carrier GetPrimary ( int _id ){        
            Table_Carrier _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Carrier > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Carrier> GetAllPrimaryList()
        {
            return all_Table_Carrier_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("exit_type", out _currValue))
            {
                this.exit_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race", out _currValue))
            {
                this.race = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group1", out _currValue))
            {
                this.skill_group1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group2", out _currValue))
            {
                this.skill_group2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group3", out _currValue))
            {
                this.skill_group3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group4", out _currValue))
            {
                this.skill_group4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group5", out _currValue))
            {
                this.skill_group5 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("riding_action", out _currValue))
            {
                this.riding_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("background_sound", out _currValue))
            {
                this.background_sound = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("profesion_model_ids", out _currValue))
            {
                this.profesion_model_ids = _currValue;
            }
            if(_itemData.TryGetValue("leave_sound_id", out _currValue))
            {
                this.leave_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("bone", out _currValue))
            {
                this.bone = _currValue;
            }
            if(_itemData.TryGetValue("enter_camera_id", out _currValue))
            {
                this.enter_camera_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("leave_camera_id", out _currValue))
            {
                this.leave_camera_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_initiative_leave", out _currValue))
            {
                this.is_initiative_leave = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_jump", out _currValue))
            {
                this.is_jump = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_swim", out _currValue))
            {
                this.is_swim = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_glide", out _currValue))
            {
                this.is_glide = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_hide_weapon", out _currValue))
            {
                this.is_hide_weapon = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("replace_show_name", out _currValue))
            {
                this.replace_show_name = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("height", out _currValue))
            {
                this.height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("client_model_animator_id", out _currValue))
            {
                this.client_model_animator_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_show_dir_tran", out _currValue))
            {
                this.can_show_dir_tran = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "carrier";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "type":
                    return this.type;
                case "exit_type":
                    return this.exit_type;
                case "race":
                    return this.race;
                case "skill_group1":
                    return this.skill_group1;
                case "skill_group2":
                    return this.skill_group2;
                case "skill_group3":
                    return this.skill_group3;
                case "skill_group4":
                    return this.skill_group4;
                case "skill_group5":
                    return this.skill_group5;
                case "riding_action":
                    return this.riding_action;
                case "background_sound":
                    return this.background_sound;
                case "model_id":
                    return this.model_id;
                case "profesion_model_ids":
                    return this.profesion_model_ids;
                case "leave_sound_id":
                    return this.leave_sound_id;
                case "bone":
                    return this.bone;
                case "enter_camera_id":
                    return this.enter_camera_id;
                case "leave_camera_id":
                    return this.leave_camera_id;
                case "is_initiative_leave":
                    return this.is_initiative_leave;
                case "is_jump":
                    return this.is_jump;
                case "is_swim":
                    return this.is_swim;
                case "is_glide":
                    return this.is_glide;
                case "is_hide_weapon":
                    return this.is_hide_weapon;
                case "replace_show_name":
                    return this.replace_show_name;
                case "height":
                    return this.height;
                case "client_model_animator_id":
                    return this.client_model_animator_id;
                case "can_show_dir_tran":
                    return this.can_show_dir_tran;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Carrier> rows = _rows as List<Table_Carrier>;
            pool_primary=TableContent.ListToPool < int, Table_Carrier > ( rows, "map", "id" );
            all_Table_Carrier_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Carrier_List.Clear();
        }
    }
}
