using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 镜像npc
    ///</summary>
    [Serializable]
    [TableName("mirror_npc")]
    public partial class Table_Mirror_Npc : TableContent
    {

        private static List<Table_Mirror_Npc> all_Table_Mirror_Npc_List = new List<Table_Mirror_Npc>();
        //primary | 主键
        public static Dictionary<int, Table_Mirror_Npc > pool_primary = new Dictionary<int, Table_Mirror_Npc > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 模板:npc_id
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 坐标x
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// 坐标y
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// 坐标z
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 旋转角度
        ///</summary>
        public float angle;
        
        
        ///<summary>
        /// 是否跟随玩家
        ///</summary>
        public bool is_follow;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Mirror_Npc GetPrimary ( int _id ){        
            Table_Mirror_Npc _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mirror_Npc > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mirror_Npc> GetAllPrimaryList()
        {
            return all_Table_Mirror_Npc_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("angle", out _currValue))
            {
                this.angle = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_follow", out _currValue))
            {
                this.is_follow = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mirror_npc";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "npc_id":
                    return this.npc_id;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "angle":
                    return this.angle;
                case "is_follow":
                    return this.is_follow;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mirror_Npc> rows = _rows as List<Table_Mirror_Npc>;
            pool_primary=TableContent.ListToPool < int, Table_Mirror_Npc > ( rows, "map", "id" );
            all_Table_Mirror_Npc_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mirror_Npc_List.Clear();
        }
    }
}
