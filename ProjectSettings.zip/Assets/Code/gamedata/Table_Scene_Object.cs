using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景物件
    ///</summary>
    [Serializable]
    [TableName("scene_object")]
    public partial class Table_Scene_Object : TableContent
    {

        private static List<Table_Scene_Object> all_Table_Scene_Object_List = new List<Table_Scene_Object>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Object > pool_primary = new Dictionary<int, Table_Scene_Object > ();
        
        
        ///<summary>
        /// 主键：物件ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 所属的场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 单独模型ID
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 引用NPC模板ID
        ///</summary>
        public int npc_template_id;
        
        
        ///<summary>
        /// X坐标
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// Y坐标
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// Z坐标
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 旋转角度（从正北方向顺时针旋转）
        ///</summary>
        public float angle;
        
        
        ///<summary>
        /// 加载距离(m)
        ///</summary>
        public int show_distance;
        
        
        ///<summary>
        /// 触发间隔(毫秒)
        ///</summary>
        public int trigger_interval;
        
        
        ///<summary>
        /// 触发距离
        ///</summary>
        public int trigger_distance;
        
        
        ///<summary>
        /// 触发时给玩家的BUFF ID
        ///</summary>
        public int trigger_buff_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：物件ID</param>
        ///
        public static Table_Scene_Object GetPrimary ( int _id ){        
            Table_Scene_Object _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Object > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Object> GetAllPrimaryList()
        {
            return all_Table_Scene_Object_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_template_id", out _currValue))
            {
                this.npc_template_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("angle", out _currValue))
            {
                this.angle = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_distance", out _currValue))
            {
                this.show_distance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_interval", out _currValue))
            {
                this.trigger_interval = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_distance", out _currValue))
            {
                this.trigger_distance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_buff_id", out _currValue))
            {
                this.trigger_buff_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_object";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "scene_id":
                    return this.scene_id;
                case "name":
                    return this.name;
                case "type":
                    return this.type;
                case "model_id":
                    return this.model_id;
                case "npc_template_id":
                    return this.npc_template_id;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "angle":
                    return this.angle;
                case "show_distance":
                    return this.show_distance;
                case "trigger_interval":
                    return this.trigger_interval;
                case "trigger_distance":
                    return this.trigger_distance;
                case "trigger_buff_id":
                    return this.trigger_buff_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Object> rows = _rows as List<Table_Scene_Object>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Object > ( rows, "map", "id" );
            all_Table_Scene_Object_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Object_List.Clear();
        }
    }
}
