using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 蘑菇人收集物
    ///</summary>
    [Serializable]
    [TableName("mushroom_collection")]
    public partial class Table_Mushroom_Collection : TableContent
    {

        private static List<Table_Mushroom_Collection> all_Table_Mushroom_Collection_List = new List<Table_Mushroom_Collection>();
        //primary | 主键
        public static Dictionary<int, Table_Mushroom_Collection > pool_primary = new Dictionary<int, Table_Mushroom_Collection > ();
        
        
        ///<summary>
        /// npc模板ID
        ///</summary>
        public int npc_template_id;
        
        
        ///<summary>
        /// 增加经验
        ///</summary>
        public int add_experience;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcTemplateId> npc模板ID</param>
        ///
        public static Table_Mushroom_Collection GetPrimary ( int _npcTemplateId ){        
            Table_Mushroom_Collection _map0=null;        
            pool_primary. TryGetValue(_npcTemplateId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mushroom_Collection > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mushroom_Collection> GetAllPrimaryList()
        {
            return all_Table_Mushroom_Collection_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_template_id", out _currValue))
            {
                this.npc_template_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("add_experience", out _currValue))
            {
                this.add_experience = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mushroom_collection";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_template_id":
                    return this.npc_template_id;
                case "add_experience":
                    return this.add_experience;
                case "weight":
                    return this.weight;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mushroom_Collection> rows = _rows as List<Table_Mushroom_Collection>;
            pool_primary=TableContent.ListToPool < int, Table_Mushroom_Collection > ( rows, "map", "npc_template_id" );
            all_Table_Mushroom_Collection_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mushroom_Collection_List.Clear();
        }
    }
}
