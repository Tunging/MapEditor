using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 背景选择问题配置表
    ///</summary>
    [Serializable]
    [TableName("question")]
    public partial class Table_Question : TableContent
    {

        private static List<Table_Question> all_Table_Question_List = new List<Table_Question>();
        //primary | 主键
        public static Dictionary<int, Table_Question > pool_primary = new Dictionary<int, Table_Question > ();
        
        
        ///<summary>
        /// 背景选择问题配置表
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 问题描述国际化
        ///</summary>
        public string question_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 背景选择问题配置表</param>
        ///
        public static Table_Question GetPrimary ( int _id ){        
            Table_Question _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Question > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Question> GetAllPrimaryList()
        {
            return all_Table_Question_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("question_i18n", out _currValue))
            {
                this.question_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "question";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "question_i18n":
                    return this.question_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Question> rows = _rows as List<Table_Question>;
            pool_primary=TableContent.ListToPool < int, Table_Question > ( rows, "map", "id" );
            all_Table_Question_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Question_List.Clear();
        }
    }
}
