using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 装备重铸属性表
    ///</summary>
    [Serializable]
    [TableName("equip_recast_prop")]
    public partial class Table_Equip_Recast_Prop : TableContent
    {

        private static List<Table_Equip_Recast_Prop> all_Table_Equip_Recast_Prop_List = new List<Table_Equip_Recast_Prop>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > > ();
        
        
        ///<summary>
        /// 主键：属性ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 主键：部位
        ///</summary>
        public int postion;
        
        
        ///<summary>
        /// 主键：星级
        ///</summary>
        public int star;
        
        
        ///<summary>
        /// 增加属性千分比
        ///</summary>
        public int add_prop;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：属性ID</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > GetPrimary ( int _id ){        
            Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：属性ID</param>
        ///	<param postion> 主键：部位</param>
        ///
        public static Dictionary<int, Table_Equip_Recast_Prop > GetPrimary ( int _id , int _postion ){        
            Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Equip_Recast_Prop > _map1=null;        
            _map0. TryGetValue(_postion,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：属性ID</param>
        ///	<param postion> 主键：部位</param>
        ///	<param star> 主键：星级</param>
        ///
        public static Table_Equip_Recast_Prop GetPrimary ( int _id , int _postion , int _star ){        
            Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Equip_Recast_Prop > _map1=null;        
            _map0. TryGetValue(_postion,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Equip_Recast_Prop _map2=null;        
            _map1. TryGetValue(_star,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Equip_Recast_Prop > > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Equip_Recast_Prop> GetAllPrimaryList()
        {
            return all_Table_Equip_Recast_Prop_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("postion", out _currValue))
            {
                this.postion = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star", out _currValue))
            {
                this.star = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("add_prop", out _currValue))
            {
                this.add_prop = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "equip_recast_prop";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "postion":
                    return this.postion;
                case "star":
                    return this.star;
                case "add_prop":
                    return this.add_prop;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Equip_Recast_Prop> rows = _rows as List<Table_Equip_Recast_Prop>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Equip_Recast_Prop > ( rows, "map", "id", "postion", "star" );
            all_Table_Equip_Recast_Prop_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Equip_Recast_Prop_List.Clear();
        }
    }
}
