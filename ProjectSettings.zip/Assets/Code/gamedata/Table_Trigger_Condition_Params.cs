using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 触发器条件参数
    ///</summary>
    [Serializable]
    [TableName("trigger_condition_params")]
    public partial class Table_Trigger_Condition_Params : TableContent
    {

        private static List<Table_Trigger_Condition_Params> all_Table_Trigger_Condition_Params_List = new List<Table_Trigger_Condition_Params>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Trigger_Condition_Params > > pool_primary = new Dictionary<int, Dictionary<int, Table_Trigger_Condition_Params > > ();
        
        
        ///<summary>
        /// 主键：模板ID
        ///</summary>
        public int template_id;
        
        
        ///<summary>
        /// 主键：参数索引
        ///</summary>
        public int param_index;
        
        
        ///<summary>
        /// 主键：属性名
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 属性名注释
        ///</summary>
        public string label;
        
        
        ///<summary>
        /// 属性类型
        ///</summary>
        public string type;
        
        
        ///<summary>
        /// 属性精度
        ///</summary>
        public int value_precision;
        
        
        ///<summary>
        /// 属性最小值
        ///</summary>
        public int min_value;
        
        
        ///<summary>
        /// 属性最大值
        ///</summary>
        public int max_value;
        
        
        ///<summary>
        /// 下拉菜单使用的表
        ///</summary>
        public string combo_table;
        
        
        ///<summary>
        /// 下拉菜单ID字段
        ///</summary>
        public string combo_id;
        
        
        ///<summary>
        /// 下拉菜单Name字段
        ///</summary>
        public string combo_name;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param templateId> 主键：模板ID</param>
        ///
        public static Dictionary<int, Table_Trigger_Condition_Params > GetPrimary ( int _templateId ){        
            Dictionary<int, Table_Trigger_Condition_Params > _map0=null;        
            pool_primary. TryGetValue(_templateId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param templateId> 主键：模板ID</param>
        ///	<param paramIndex> 主键：参数索引</param>
        ///
        public static Table_Trigger_Condition_Params GetPrimary ( int _templateId , int _paramIndex ){        
            Dictionary<int, Table_Trigger_Condition_Params > _map0=null;        
            pool_primary. TryGetValue(_templateId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Trigger_Condition_Params _map1=null;        
            _map0. TryGetValue(_paramIndex,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Trigger_Condition_Params > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Trigger_Condition_Params> GetAllPrimaryList()
        {
            return all_Table_Trigger_Condition_Params_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("template_id", out _currValue))
            {
                this.template_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param_index", out _currValue))
            {
                this.param_index = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("label", out _currValue))
            {
                this.label = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = _currValue;
            }
            if(_itemData.TryGetValue("value_precision", out _currValue))
            {
                this.value_precision = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("min_value", out _currValue))
            {
                this.min_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_value", out _currValue))
            {
                this.max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("combo_table", out _currValue))
            {
                this.combo_table = _currValue;
            }
            if(_itemData.TryGetValue("combo_id", out _currValue))
            {
                this.combo_id = _currValue;
            }
            if(_itemData.TryGetValue("combo_name", out _currValue))
            {
                this.combo_name = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "trigger_condition_params";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "template_id":
                    return this.template_id;
                case "param_index":
                    return this.param_index;
                case "name":
                    return this.name;
                case "label":
                    return this.label;
                case "type":
                    return this.type;
                case "value_precision":
                    return this.value_precision;
                case "min_value":
                    return this.min_value;
                case "max_value":
                    return this.max_value;
                case "combo_table":
                    return this.combo_table;
                case "combo_id":
                    return this.combo_id;
                case "combo_name":
                    return this.combo_name;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Trigger_Condition_Params> rows = _rows as List<Table_Trigger_Condition_Params>;
            pool_primary=TableContent.ListToPool < int, int, Table_Trigger_Condition_Params > ( rows, "map", "template_id", "param_index" );
            all_Table_Trigger_Condition_Params_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Trigger_Condition_Params_List.Clear();
        }
    }
}
