using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物表
    ///</summary>
    [Serializable]
    [TableName("pet")]
    public partial class Table_Pet : TableContent
    {

        private static List<Table_Pet> all_Table_Pet_List = new List<Table_Pet>();
        //primary | 主键
        public static Dictionary<int, Table_Pet > pool_primary = new Dictionary<int, Table_Pet > ();
        
        
        ///<summary>
        /// 主键：宠物ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名字国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// npc模板id
        ///</summary>
        public int model;
        
        
        ///<summary>
        /// 一星分解货币
        ///</summary>
        public int coin1;
        
        
        ///<summary>
        /// 二星分解货币
        ///</summary>
        public int coin2;
        
        
        ///<summary>
        /// 三星分解货币
        ///</summary>
        public int coin3;
        
        
        ///<summary>
        /// 四星分解货币
        ///</summary>
        public int coin4;
        
        
        ///<summary>
        /// 宠物图标
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 宠物描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 喊话
        ///</summary>
        public string speak_id;
        
        
        ///<summary>
        /// 模型缩放比例
        ///</summary>
        public float model_scale;
        
        
        ///<summary>
        /// 模型旋转
        ///</summary>
        public float model_rotation;
        
        
        ///<summary>
        /// 模型高度
        ///</summary>
        public float model_high;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：宠物ID</param>
        ///
        public static Table_Pet GetPrimary ( int _id ){        
            Table_Pet _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Pet > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Pet> GetAllPrimaryList()
        {
            return all_Table_Pet_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("model", out _currValue))
            {
                this.model = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("coin1", out _currValue))
            {
                this.coin1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("coin2", out _currValue))
            {
                this.coin2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("coin3", out _currValue))
            {
                this.coin3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("coin4", out _currValue))
            {
                this.coin4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("speak_id", out _currValue))
            {
                this.speak_id = _currValue;
            }
            if(_itemData.TryGetValue("model_scale", out _currValue))
            {
                this.model_scale = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_rotation", out _currValue))
            {
                this.model_rotation = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_high", out _currValue))
            {
                this.model_high = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "model":
                    return this.model;
                case "coin1":
                    return this.coin1;
                case "coin2":
                    return this.coin2;
                case "coin3":
                    return this.coin3;
                case "coin4":
                    return this.coin4;
                case "icon":
                    return this.icon;
                case "description":
                    return this.description;
                case "speak_id":
                    return this.speak_id;
                case "model_scale":
                    return this.model_scale;
                case "model_rotation":
                    return this.model_rotation;
                case "model_high":
                    return this.model_high;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet> rows = _rows as List<Table_Pet>;
            pool_primary=TableContent.ListToPool < int, Table_Pet > ( rows, "map", "id" );
            all_Table_Pet_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Pet_List.Clear();
        }
    }
}
