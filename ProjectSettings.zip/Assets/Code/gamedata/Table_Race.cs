using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 种族
    ///</summary>
    [Serializable]
    [TableName("race")]
    public partial class Table_Race : TableContent
    {

        private static List<Table_Race> all_Table_Race_List = new List<Table_Race>();
        //primary | 主键
        public static Dictionary<int, Table_Race > pool_primary = new Dictionary<int, Table_Race > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 种族场景
        ///</summary>
        public int race_scene;
        
        
        ///<summary>
        /// 种族旗帜对应的图标ID
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 种族名字iconid
        ///</summary>
        public int name_icon_id;
        
        
        ///<summary>
        /// 种族小标志图标ID
        ///</summary>
        public int small_flag;
        
        
        ///<summary>
        /// 摄像机缩进的位置(x,y,z)
        ///</summary>
        public string zoomin_pos;
        
        
        ///<summary>
        /// 新手副本任务ID
        ///</summary>
        public int novice_task_id;
        
        
        ///<summary>
        /// 种族描述
        ///</summary>
        public string illustrate;
        
        
        ///<summary>
        /// 问题列表
        ///</summary>
        public string questions;
        
        
        ///<summary>
        /// 身高
        ///</summary>
        public float height;
        
        
        ///<summary>
        /// 翅膀id
        ///</summary>
        public int wing_id;
        
        
        ///<summary>
        ///  摄像机照射位置
        ///</summary>
        public string lookat_position;
        
        
        ///<summary>
        /// 摄像机位置
        ///</summary>
        public string camera_position;
        
        
        ///<summary>
        /// 摄像机照摄最远距离
        ///</summary>
        public float camera_max_dis;
        
        
        ///<summary>
        /// 摄像机照摄最近距离
        ///</summary>
        public float camera_min_dis;
        
        
        ///<summary>
        /// 播放的背景声音
        ///</summary>
        public int play_sound;
        
        
        ///<summary>
        /// 相机的fieldofview值
        ///</summary>
        public float camera_fieldofview;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Race GetPrimary ( int _id ){        
            Table_Race _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Race > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Race> GetAllPrimaryList()
        {
            return all_Table_Race_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("race_scene", out _currValue))
            {
                this.race_scene = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_icon_id", out _currValue))
            {
                this.name_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("small_flag", out _currValue))
            {
                this.small_flag = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("zoomin_pos", out _currValue))
            {
                this.zoomin_pos = _currValue;
            }
            if(_itemData.TryGetValue("novice_task_id", out _currValue))
            {
                this.novice_task_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("illustrate", out _currValue))
            {
                this.illustrate = _currValue;
            }
            if(_itemData.TryGetValue("questions", out _currValue))
            {
                this.questions = _currValue;
            }
            if(_itemData.TryGetValue("height", out _currValue))
            {
                this.height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("wing_id", out _currValue))
            {
                this.wing_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("lookat_position", out _currValue))
            {
                this.lookat_position = _currValue;
            }
            if(_itemData.TryGetValue("camera_position", out _currValue))
            {
                this.camera_position = _currValue;
            }
            if(_itemData.TryGetValue("camera_max_dis", out _currValue))
            {
                this.camera_max_dis = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_min_dis", out _currValue))
            {
                this.camera_min_dis = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("play_sound", out _currValue))
            {
                this.play_sound = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_fieldofview", out _currValue))
            {
                this.camera_fieldofview = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "race";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "race_scene":
                    return this.race_scene;
                case "icon":
                    return this.icon;
                case "name_icon_id":
                    return this.name_icon_id;
                case "small_flag":
                    return this.small_flag;
                case "zoomin_pos":
                    return this.zoomin_pos;
                case "novice_task_id":
                    return this.novice_task_id;
                case "illustrate":
                    return this.illustrate;
                case "questions":
                    return this.questions;
                case "height":
                    return this.height;
                case "wing_id":
                    return this.wing_id;
                case "lookat_position":
                    return this.lookat_position;
                case "camera_position":
                    return this.camera_position;
                case "camera_max_dis":
                    return this.camera_max_dis;
                case "camera_min_dis":
                    return this.camera_min_dis;
                case "play_sound":
                    return this.play_sound;
                case "camera_fieldofview":
                    return this.camera_fieldofview;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Race> rows = _rows as List<Table_Race>;
            pool_primary=TableContent.ListToPool < int, Table_Race > ( rows, "map", "id" );
            all_Table_Race_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Race_List.Clear();
        }
    }
}
