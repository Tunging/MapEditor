using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 战斗事件：action模板参数
    ///</summary>
    [Serializable]
    [TableName("skill_event_template_param")]
    public partial class Table_Skill_Event_Template_Param : TableContent
    {

        private static List<Table_Skill_Event_Template_Param> all_Table_Skill_Event_Template_Param_List = new List<Table_Skill_Event_Template_Param>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Skill_Event_Template_Param > > pool_primary = new Dictionary<int, Dictionary<int, Table_Skill_Event_Template_Param > > ();
        
        
        ///<summary>
        /// 主键：模板ID
        ///</summary>
        public int template_id;
        
        
        ///<summary>
        /// 主键：参数编号
        ///</summary>
        public int param_num;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 显示文本
        ///</summary>
        public string label;
        
        
        ///<summary>
        /// 类型：bool,int
        ///</summary>
        public string type;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 限制最小值
        ///</summary>
        public int min_value;
        
        
        ///<summary>
        /// 限制最大值
        ///</summary>
        public int max_value;
        
        
        ///<summary>
        /// 引用的表
        ///</summary>
        public string refer_table;
        
        
        ///<summary>
        /// 引用的值字段
        ///</summary>
        public string refer_value;
        
        
        ///<summary>
        /// 引用的显示字段
        ///</summary>
        public string refer_label;
        
        
        ///<summary>
        /// 引用过滤条件
        ///</summary>
        public string refer_where;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param templateId> 主键：模板ID</param>
        ///
        public static Dictionary<int, Table_Skill_Event_Template_Param > GetPrimary ( int _templateId ){        
            Dictionary<int, Table_Skill_Event_Template_Param > _map0=null;        
            pool_primary. TryGetValue(_templateId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param templateId> 主键：模板ID</param>
        ///	<param paramNum> 主键：参数编号</param>
        ///
        public static Table_Skill_Event_Template_Param GetPrimary ( int _templateId , int _paramNum ){        
            Dictionary<int, Table_Skill_Event_Template_Param > _map0=null;        
            pool_primary. TryGetValue(_templateId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Skill_Event_Template_Param _map1=null;        
            _map0. TryGetValue(_paramNum,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Skill_Event_Template_Param > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Event_Template_Param> GetAllPrimaryList()
        {
            return all_Table_Skill_Event_Template_Param_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("template_id", out _currValue))
            {
                this.template_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param_num", out _currValue))
            {
                this.param_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("label", out _currValue))
            {
                this.label = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = _currValue;
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("min_value", out _currValue))
            {
                this.min_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_value", out _currValue))
            {
                this.max_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refer_table", out _currValue))
            {
                this.refer_table = _currValue;
            }
            if(_itemData.TryGetValue("refer_value", out _currValue))
            {
                this.refer_value = _currValue;
            }
            if(_itemData.TryGetValue("refer_label", out _currValue))
            {
                this.refer_label = _currValue;
            }
            if(_itemData.TryGetValue("refer_where", out _currValue))
            {
                this.refer_where = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_event_template_param";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "template_id":
                    return this.template_id;
                case "param_num":
                    return this.param_num;
                case "name":
                    return this.name;
                case "label":
                    return this.label;
                case "type":
                    return this.type;
                case "remark":
                    return this.remark;
                case "min_value":
                    return this.min_value;
                case "max_value":
                    return this.max_value;
                case "refer_table":
                    return this.refer_table;
                case "refer_value":
                    return this.refer_value;
                case "refer_label":
                    return this.refer_label;
                case "refer_where":
                    return this.refer_where;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Event_Template_Param> rows = _rows as List<Table_Skill_Event_Template_Param>;
            pool_primary=TableContent.ListToPool < int, int, Table_Skill_Event_Template_Param > ( rows, "map", "template_id", "param_num" );
            all_Table_Skill_Event_Template_Param_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Event_Template_Param_List.Clear();
        }
    }
}
