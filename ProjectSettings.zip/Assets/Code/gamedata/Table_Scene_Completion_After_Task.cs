﻿using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景主线任务弹出完成度详情
    ///</summary>
    [Serializable]
    [TableName("scene_completion_after_task")]
    public partial class Table_Scene_Completion_After_Task : TableContent
    {

        private static List<Table_Scene_Completion_After_Task> all_Table_Scene_Completion_After_Task_List = new List<Table_Scene_Completion_After_Task>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Completion_After_Task > pool_primary = new Dictionary<int, Table_Scene_Completion_After_Task > ();
        //taskId | 
        public static Dictionary<int, Table_Scene_Completion_After_Task > pool_taskId = new Dictionary<int, Table_Scene_Completion_After_Task > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 任务ID（完成哪个任务后弹出面板）
        ///</summary>
        public int task_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Scene_Completion_After_Task GetPrimary ( int _id ){        
            Table_Scene_Completion_After_Task _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Completion_After_Task > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param taskId> 任务ID（完成哪个任务后弹出面板）</param>
        ///
        public static Table_Scene_Completion_After_Task GetTaskId ( int _taskId ){        
            Table_Scene_Completion_After_Task _map0=null;        
            pool_taskId. TryGetValue(_taskId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Completion_After_Task > GetAllTaskId()
        {
            return pool_taskId;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Completion_After_Task> GetAllPrimaryList()
        {
            return all_Table_Scene_Completion_After_Task_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task_id", out _currValue))
            {
                this.task_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_completion_after_task";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "scene_id":
                    return this.scene_id;
                case "task_id":
                    return this.task_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Completion_After_Task> rows = _rows as List<Table_Scene_Completion_After_Task>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Completion_After_Task > ( rows, "map", "id" );
            pool_taskId=TableContent.ListToPool < int, Table_Scene_Completion_After_Task > ( rows, "map", "task_id" );
            all_Table_Scene_Completion_After_Task_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_taskId.Clear();
            all_Table_Scene_Completion_After_Task_List.Clear();
        }
    }
}
