using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物蛋
    ///</summary>
    [Serializable]
    [TableName("pet_egg")]
    public partial class Table_Pet_Egg : TableContent
    {

        private static List<Table_Pet_Egg> all_Table_Pet_Egg_List = new List<Table_Pet_Egg>();
        //primary | 主键
        public static Dictionary<int, Table_Pet_Egg > pool_primary = new Dictionary<int, Table_Pet_Egg > ();
        
        
        ///<summary>
        /// 宠物蛋ID
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 名字
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 孵化时间
        ///</summary>
        public int incubation_time;
        
        
        ///<summary>
        /// 加速所需钻石
        ///</summary>
        public int diamond;
        
        
        ///<summary>
        /// 宠物蛋图标
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 置灰图标
        ///</summary>
        public int disable_icon;
        
        
        ///<summary>
        /// 孵化动作ID
        ///</summary>
        public int incubation_action;
        
        
        ///<summary>
        /// 模型ID
        ///</summary>
        public int model_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param itemId> 宠物蛋ID</param>
        ///
        public static Table_Pet_Egg GetPrimary ( int _itemId ){        
            Table_Pet_Egg _map0=null;        
            pool_primary. TryGetValue(_itemId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Pet_Egg > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Pet_Egg> GetAllPrimaryList()
        {
            return all_Table_Pet_Egg_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("incubation_time", out _currValue))
            {
                this.incubation_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("diamond", out _currValue))
            {
                this.diamond = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("disable_icon", out _currValue))
            {
                this.disable_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("incubation_action", out _currValue))
            {
                this.incubation_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet_egg";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "item_id":
                    return this.item_id;
                case "name":
                    return this.name;
                case "incubation_time":
                    return this.incubation_time;
                case "diamond":
                    return this.diamond;
                case "icon":
                    return this.icon;
                case "disable_icon":
                    return this.disable_icon;
                case "incubation_action":
                    return this.incubation_action;
                case "model_id":
                    return this.model_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet_Egg> rows = _rows as List<Table_Pet_Egg>;
            pool_primary=TableContent.ListToPool < int, Table_Pet_Egg > ( rows, "map", "item_id" );
            all_Table_Pet_Egg_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Pet_Egg_List.Clear();
        }
    }
}
