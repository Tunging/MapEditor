using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 触发器行为
    ///</summary>
    [Serializable]
    [TableName("trigger_action")]
    public partial class Table_Trigger_Action : TableContent
    {

        private static List<Table_Trigger_Action> all_Table_Trigger_Action_List = new List<Table_Trigger_Action>();
        //primary | 主键
        public static Dictionary<int, Table_Trigger_Action > pool_primary = new Dictionary<int, Table_Trigger_Action > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 
        ///</summary>
        public bool have_child;
        
        
        ///<summary>
        /// 
        ///</summary>
        public int show_order;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string format_name;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string condition_class;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Table_Trigger_Action GetPrimary ( int _id ){        
            Table_Trigger_Action _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Trigger_Action > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Trigger_Action> GetAllPrimaryList()
        {
            return all_Table_Trigger_Action_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("have_child", out _currValue))
            {
                this.have_child = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_order", out _currValue))
            {
                this.show_order = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("format_name", out _currValue))
            {
                this.format_name = _currValue;
            }
            if(_itemData.TryGetValue("condition_class", out _currValue))
            {
                this.condition_class = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "trigger_action";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "have_child":
                    return this.have_child;
                case "show_order":
                    return this.show_order;
                case "name":
                    return this.name;
                case "format_name":
                    return this.format_name;
                case "condition_class":
                    return this.condition_class;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Trigger_Action> rows = _rows as List<Table_Trigger_Action>;
            pool_primary=TableContent.ListToPool < int, Table_Trigger_Action > ( rows, "map", "id" );
            all_Table_Trigger_Action_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Trigger_Action_List.Clear();
        }
    }
}
