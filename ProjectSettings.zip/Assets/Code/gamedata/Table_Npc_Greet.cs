using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc打招呼
    ///</summary>
    [Serializable]
    [TableName("npc_greet")]
    public partial class Table_Npc_Greet : TableContent
    {

        private static List<Table_Npc_Greet> all_Table_Npc_Greet_List = new List<Table_Npc_Greet>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Greet > pool_primary = new Dictionary<int, Table_Npc_Greet > ();
        
        
        ///<summary>
        /// npc的guid
        ///</summary>
        public int npc_guid;
        
        
        ///<summary>
        /// 触发距离(m)
        ///</summary>
        public float trigger_distance;
        
        
        ///<summary>
        /// 触发时间间隔(ms)
        ///</summary>
        public int trigger_interval;
        
        
        ///<summary>
        /// 表演时间(ms)
        ///</summary>
        public int show_time;
        
        
        ///<summary>
        /// 动作ID
        ///</summary>
        public int action_id;
        
        
        ///<summary>
        /// 声音ID
        ///</summary>
        public int sound_id;
        
        
        ///<summary>
        /// 说话内容，国际化
        ///</summary>
        public string text_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcGuid> npc的guid</param>
        ///
        public static Table_Npc_Greet GetPrimary ( int _npcGuid ){        
            Table_Npc_Greet _map0=null;        
            pool_primary. TryGetValue(_npcGuid,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Greet > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Greet> GetAllPrimaryList()
        {
            return all_Table_Npc_Greet_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_guid", out _currValue))
            {
                this.npc_guid = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_distance", out _currValue))
            {
                this.trigger_distance = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_interval", out _currValue))
            {
                this.trigger_interval = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_time", out _currValue))
            {
                this.show_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text_i18n", out _currValue))
            {
                this.text_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_greet";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_guid":
                    return this.npc_guid;
                case "trigger_distance":
                    return this.trigger_distance;
                case "trigger_interval":
                    return this.trigger_interval;
                case "show_time":
                    return this.show_time;
                case "action_id":
                    return this.action_id;
                case "sound_id":
                    return this.sound_id;
                case "text_i18n":
                    return this.text_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Greet> rows = _rows as List<Table_Npc_Greet>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Greet > ( rows, "map", "npc_guid" );
            all_Table_Npc_Greet_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Greet_List.Clear();
        }
    }
}
