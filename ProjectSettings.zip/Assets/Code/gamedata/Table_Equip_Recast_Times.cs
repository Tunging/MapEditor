using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 装备重铸次数表
    ///</summary>
    [Serializable]
    [TableName("equip_recast_times")]
    public partial class Table_Equip_Recast_Times : TableContent
    {

        private static List<Table_Equip_Recast_Times> all_Table_Equip_Recast_Times_List = new List<Table_Equip_Recast_Times>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > > ();
        //positionStar | 
        public static Dictionary<int, Dictionary<int, List<Table_Equip_Recast_Times> > > pool_positionStar = new Dictionary<int, Dictionary<int, List<Table_Equip_Recast_Times> > > ();
        
        
        ///<summary>
        /// 主键：重铸次数
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 主键：部位
        ///</summary>
        public int postion;
        
        
        ///<summary>
        /// 主键：星级
        ///</summary>
        public int star;
        
        
        ///<summary>
        /// 重铸消耗道具（id*num;id*num）
        ///</summary>
        public string cost_items;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：重铸次数</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > GetPrimary ( int _id ){        
            Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：重铸次数</param>
        ///	<param postion> 主键：部位</param>
        ///
        public static Dictionary<int, Table_Equip_Recast_Times > GetPrimary ( int _id , int _postion ){        
            Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Equip_Recast_Times > _map1=null;        
            _map0. TryGetValue(_postion,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：重铸次数</param>
        ///	<param postion> 主键：部位</param>
        ///	<param star> 主键：星级</param>
        ///
        public static Table_Equip_Recast_Times GetPrimary ( int _id , int _postion , int _star ){        
            Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Equip_Recast_Times > _map1=null;        
            _map0. TryGetValue(_postion,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Equip_Recast_Times _map2=null;        
            _map1. TryGetValue(_star,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Equip_Recast_Times > > > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param postion> 主键：部位</param>
        ///
        public static Dictionary<int, List<Table_Equip_Recast_Times> > GetPositionStar ( int _postion ){        
            Dictionary<int, List<Table_Equip_Recast_Times> > _map0=null;        
            pool_positionStar. TryGetValue(_postion,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param postion> 主键：部位</param>
        ///	<param star> 主键：星级</param>
        ///
        public static List<Table_Equip_Recast_Times> GetPositionStar ( int _postion , int _star ){        
            Dictionary<int, List<Table_Equip_Recast_Times> > _map0=null;        
            pool_positionStar. TryGetValue(_postion,out _map0);        
            if(_map0==null){
                return null;
            }
        
            List<Table_Equip_Recast_Times> _map1=null;        
            _map0. TryGetValue(_star,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, List<Table_Equip_Recast_Times> > > GetAllPositionStar()
        {
            return pool_positionStar;
        }


        ///查询出所有的数据
        public static List<Table_Equip_Recast_Times> GetAllPrimaryList()
        {
            return all_Table_Equip_Recast_Times_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("postion", out _currValue))
            {
                this.postion = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star", out _currValue))
            {
                this.star = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cost_items", out _currValue))
            {
                this.cost_items = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "equip_recast_times";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "postion":
                    return this.postion;
                case "star":
                    return this.star;
                case "cost_items":
                    return this.cost_items;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Equip_Recast_Times> rows = _rows as List<Table_Equip_Recast_Times>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Equip_Recast_Times > ( rows, "map", "id", "postion", "star" );
            pool_positionStar=TableContent.ListToPoolList < int, int, Table_Equip_Recast_Times > ( rows, "list", "postion", "star" );
            all_Table_Equip_Recast_Times_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_positionStar.Clear();
            all_Table_Equip_Recast_Times_List.Clear();
        }
    }
}
