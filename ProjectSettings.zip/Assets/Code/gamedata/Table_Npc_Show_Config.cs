using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc显示配置
    ///</summary>
    [Serializable]
    [TableName("npc_show_config")]
    public partial class Table_Npc_Show_Config : TableContent
    {

        private static List<Table_Npc_Show_Config> all_Table_Npc_Show_Config_List = new List<Table_Npc_Show_Config>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Show_Config > pool_primary = new Dictionary<int, Table_Npc_Show_Config > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 是否永久显示icon
        ///</summary>
        public bool is_show_icon;
        
        
        ///<summary>
        /// 是否永久显示name
        ///</summary>
        public bool is_show_name;
        
        
        ///<summary>
        /// 头顶显示IconId
        ///</summary>
        public int head_icon_id;
        
        
        ///<summary>
        /// 地图显示IconId
        ///</summary>
        public int map_icon_id;
        
        
        ///<summary>
        /// 是否为怪物lod配置
        ///</summary>
        public bool is_lod_monster;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Npc_Show_Config GetPrimary ( int _id ){        
            Table_Npc_Show_Config _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Show_Config > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Show_Config> GetAllPrimaryList()
        {
            return all_Table_Npc_Show_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_icon", out _currValue))
            {
                this.is_show_icon = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_name", out _currValue))
            {
                this.is_show_name = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("head_icon_id", out _currValue))
            {
                this.head_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("map_icon_id", out _currValue))
            {
                this.map_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_lod_monster", out _currValue))
            {
                this.is_lod_monster = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_show_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "is_show_icon":
                    return this.is_show_icon;
                case "is_show_name":
                    return this.is_show_name;
                case "head_icon_id":
                    return this.head_icon_id;
                case "map_icon_id":
                    return this.map_icon_id;
                case "is_lod_monster":
                    return this.is_lod_monster;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Show_Config> rows = _rows as List<Table_Npc_Show_Config>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Show_Config > ( rows, "map", "id" );
            all_Table_Npc_Show_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Show_Config_List.Clear();
        }
    }
}
