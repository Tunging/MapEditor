using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 公会等级表
    ///</summary>
    [Serializable]
    [TableName("guild_grade")]
    public partial class Table_Guild_Grade : TableContent
    {

        private static List<Table_Guild_Grade> all_Table_Guild_Grade_List = new List<Table_Guild_Grade>();
        //primary | 主键
        public static Dictionary<int, Table_Guild_Grade > pool_primary = new Dictionary<int, Table_Guild_Grade > ();
        
        
        ///<summary>
        /// 主键：公会等级
        ///</summary>
        public int grade;
        
        
        ///<summary>
        /// 成员人数上限
        ///</summary>
        public int members_max;
        
        
        ///<summary>
        /// 副会长人数上限
        ///</summary>
        public int vice_chairmans_max;
        
        
        ///<summary>
        /// 长老人数上限
        ///</summary>
        public int elders_max;
        
        
        ///<summary>
        /// 团长人数上限
        ///</summary>
        public int heads_max;
        
        
        ///<summary>
        /// 公会活跃度上限
        ///</summary>
        public int liveness_max;
        
        
        ///<summary>
        /// 公会金库等级上限
        ///</summary>
        public int bursary_grade_max;
        
        
        ///<summary>
        /// 公会仓库等级上限
        ///</summary>
        public int repository_grade_max;
        
        
        ///<summary>
        /// 公会商店等级上限
        ///</summary>
        public int store_grade_max;
        
        
        ///<summary>
        /// 升级条件(分号分隔)
        ///</summary>
        public string upgrade_conditions;
        
        
        ///<summary>
        /// 公会升级时建筑替换npc模板
        ///</summary>
        public int npc_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param grade> 主键：公会等级</param>
        ///
        public static Table_Guild_Grade GetPrimary ( int _grade ){        
            Table_Guild_Grade _map0=null;        
            pool_primary. TryGetValue(_grade,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Guild_Grade > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Guild_Grade> GetAllPrimaryList()
        {
            return all_Table_Guild_Grade_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("grade", out _currValue))
            {
                this.grade = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("members_max", out _currValue))
            {
                this.members_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("vice_chairmans_max", out _currValue))
            {
                this.vice_chairmans_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("elders_max", out _currValue))
            {
                this.elders_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("heads_max", out _currValue))
            {
                this.heads_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("liveness_max", out _currValue))
            {
                this.liveness_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("bursary_grade_max", out _currValue))
            {
                this.bursary_grade_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("repository_grade_max", out _currValue))
            {
                this.repository_grade_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("store_grade_max", out _currValue))
            {
                this.store_grade_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("upgrade_conditions", out _currValue))
            {
                this.upgrade_conditions = _currValue;
            }
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "guild_grade";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "grade":
                    return this.grade;
                case "members_max":
                    return this.members_max;
                case "vice_chairmans_max":
                    return this.vice_chairmans_max;
                case "elders_max":
                    return this.elders_max;
                case "heads_max":
                    return this.heads_max;
                case "liveness_max":
                    return this.liveness_max;
                case "bursary_grade_max":
                    return this.bursary_grade_max;
                case "repository_grade_max":
                    return this.repository_grade_max;
                case "store_grade_max":
                    return this.store_grade_max;
                case "upgrade_conditions":
                    return this.upgrade_conditions;
                case "npc_id":
                    return this.npc_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Guild_Grade> rows = _rows as List<Table_Guild_Grade>;
            pool_primary=TableContent.ListToPool < int, Table_Guild_Grade > ( rows, "map", "grade" );
            all_Table_Guild_Grade_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Guild_Grade_List.Clear();
        }
    }
}
