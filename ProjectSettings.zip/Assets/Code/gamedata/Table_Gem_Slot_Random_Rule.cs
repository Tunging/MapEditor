using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宝石孔随机规则
    ///</summary>
    [Serializable]
    [TableName("gem_slot_random_rule")]
    public partial class Table_Gem_Slot_Random_Rule : TableContent
    {

        private static List<Table_Gem_Slot_Random_Rule> all_Table_Gem_Slot_Random_Rule_List = new List<Table_Gem_Slot_Random_Rule>();
        //primary | 主键
        public static Dictionary<int, Table_Gem_Slot_Random_Rule > pool_primary = new Dictionary<int, Table_Gem_Slot_Random_Rule > ();
        
        
        ///<summary>
        /// 宝石孔随机规则ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 出现0孔的权值
        ///</summary>
        public int weight0;
        
        
        ///<summary>
        /// 出现1孔的权值
        ///</summary>
        public int weight1;
        
        
        ///<summary>
        /// 出现2孔的权值
        ///</summary>
        public int weight2;
        
        
        ///<summary>
        /// 出现3孔的权值
        ///</summary>
        public int weight3;
        
        
        ///<summary>
        /// 出现4孔的权值
        ///</summary>
        public int weight4;
        
        
        ///<summary>
        /// 第1孔的随机库ID
        ///</summary>
        public int random_lib1;
        
        
        ///<summary>
        /// 第2孔的随机库ID
        ///</summary>
        public int random_lib2;
        
        
        ///<summary>
        /// 第3孔的随机库ID
        ///</summary>
        public int random_lib3;
        
        
        ///<summary>
        /// 第4孔的随机库ID
        ///</summary>
        public int random_lib4;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 宝石孔随机规则ID</param>
        ///
        public static Table_Gem_Slot_Random_Rule GetPrimary ( int _id ){        
            Table_Gem_Slot_Random_Rule _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Gem_Slot_Random_Rule > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Gem_Slot_Random_Rule> GetAllPrimaryList()
        {
            return all_Table_Gem_Slot_Random_Rule_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("weight0", out _currValue))
            {
                this.weight0 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight1", out _currValue))
            {
                this.weight1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight2", out _currValue))
            {
                this.weight2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight3", out _currValue))
            {
                this.weight3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight4", out _currValue))
            {
                this.weight4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("random_lib1", out _currValue))
            {
                this.random_lib1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("random_lib2", out _currValue))
            {
                this.random_lib2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("random_lib3", out _currValue))
            {
                this.random_lib3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("random_lib4", out _currValue))
            {
                this.random_lib4 = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "gem_slot_random_rule";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "weight0":
                    return this.weight0;
                case "weight1":
                    return this.weight1;
                case "weight2":
                    return this.weight2;
                case "weight3":
                    return this.weight3;
                case "weight4":
                    return this.weight4;
                case "random_lib1":
                    return this.random_lib1;
                case "random_lib2":
                    return this.random_lib2;
                case "random_lib3":
                    return this.random_lib3;
                case "random_lib4":
                    return this.random_lib4;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Gem_Slot_Random_Rule> rows = _rows as List<Table_Gem_Slot_Random_Rule>;
            pool_primary=TableContent.ListToPool < int, Table_Gem_Slot_Random_Rule > ( rows, "map", "id" );
            all_Table_Gem_Slot_Random_Rule_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Gem_Slot_Random_Rule_List.Clear();
        }
    }
}
