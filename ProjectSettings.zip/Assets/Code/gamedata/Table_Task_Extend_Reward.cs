using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 任务扩展奖励表
    ///</summary>
    [Serializable]
    [TableName("task_extend_reward")]
    public partial class Table_Task_Extend_Reward : TableContent
    {

        private static List<Table_Task_Extend_Reward> all_Table_Task_Extend_Reward_List = new List<Table_Task_Extend_Reward>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Task_Extend_Reward > > pool_primary = new Dictionary<int, Dictionary<int, Table_Task_Extend_Reward > > ();
        
        
        ///<summary>
        /// 主键：任务ID
        ///</summary>
        public int task_id;
        
        
        ///<summary>
        /// 主键：角色等级
        ///</summary>
        public int role_level;
        
        
        ///<summary>
        /// 奖励ID1
        ///</summary>
        public int reward1_id;
        
        
        ///<summary>
        /// 奖励ID2
        ///</summary>
        public int reward2_id;
        
        
        ///<summary>
        /// 队长奖励ID
        ///</summary>
        public int team_leader_reward_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param taskId> 主键：任务ID</param>
        ///
        public static Dictionary<int, Table_Task_Extend_Reward > GetPrimary ( int _taskId ){        
            Dictionary<int, Table_Task_Extend_Reward > _map0=null;        
            pool_primary. TryGetValue(_taskId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param taskId> 主键：任务ID</param>
        ///	<param roleLevel> 主键：角色等级</param>
        ///
        public static Table_Task_Extend_Reward GetPrimary ( int _taskId , int _roleLevel ){        
            Dictionary<int, Table_Task_Extend_Reward > _map0=null;        
            pool_primary. TryGetValue(_taskId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task_Extend_Reward _map1=null;        
            _map0. TryGetValue(_roleLevel,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task_Extend_Reward > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Task_Extend_Reward> GetAllPrimaryList()
        {
            return all_Table_Task_Extend_Reward_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("task_id", out _currValue))
            {
                this.task_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_level", out _currValue))
            {
                this.role_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward1_id", out _currValue))
            {
                this.reward1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward2_id", out _currValue))
            {
                this.reward2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("team_leader_reward_id", out _currValue))
            {
                this.team_leader_reward_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "task_extend_reward";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "task_id":
                    return this.task_id;
                case "role_level":
                    return this.role_level;
                case "reward1_id":
                    return this.reward1_id;
                case "reward2_id":
                    return this.reward2_id;
                case "team_leader_reward_id":
                    return this.team_leader_reward_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Task_Extend_Reward> rows = _rows as List<Table_Task_Extend_Reward>;
            pool_primary=TableContent.ListToPool < int, int, Table_Task_Extend_Reward > ( rows, "map", "task_id", "role_level" );
            all_Table_Task_Extend_Reward_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Task_Extend_Reward_List.Clear();
        }
    }
}
