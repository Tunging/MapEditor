using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 公会旗帜
    ///</summary>
    [Serializable]
    [TableName("guild_banner")]
    public partial class Table_Guild_Banner : TableContent
    {

        private static List<Table_Guild_Banner> all_Table_Guild_Banner_List = new List<Table_Guild_Banner>();
        //primary | 主键
        public static Dictionary<int, Table_Guild_Banner > pool_primary = new Dictionary<int, Table_Guild_Banner > ();
        //type | 
        public static Dictionary<int, Dictionary<int, Table_Guild_Banner > > pool_type = new Dictionary<int, Dictionary<int, Table_Guild_Banner > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 类型
        ///</summary>
        public int banner_combination;
        
        
        ///<summary>
        /// npc_resource_id
        ///</summary>
        public int model_combination;
        
        
        ///<summary>
        /// 公会标识图案
        ///</summary>
        public int logo;
        
        
        ///<summary>
        /// 选择时的图标
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 颜色
        ///</summary>
        public string colorid;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Guild_Banner GetPrimary ( int _id ){        
            Table_Guild_Banner _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Guild_Banner > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param bannerCombination> 类型</param>
        ///
        public static Dictionary<int, Table_Guild_Banner > GetType ( int _bannerCombination ){        
            Dictionary<int, Table_Guild_Banner > _map0=null;        
            pool_type. TryGetValue(_bannerCombination,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param bannerCombination> 类型</param>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Guild_Banner GetType ( int _bannerCombination , int _id ){        
            Dictionary<int, Table_Guild_Banner > _map0=null;        
            pool_type. TryGetValue(_bannerCombination,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Guild_Banner _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Guild_Banner > > GetAllType()
        {
            return pool_type;
        }


        ///查询出所有的数据
        public static List<Table_Guild_Banner> GetAllPrimaryList()
        {
            return all_Table_Guild_Banner_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("banner_combination", out _currValue))
            {
                this.banner_combination = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_combination", out _currValue))
            {
                this.model_combination = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("logo", out _currValue))
            {
                this.logo = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("colorid", out _currValue))
            {
                this.colorid = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "guild_banner";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "banner_combination":
                    return this.banner_combination;
                case "model_combination":
                    return this.model_combination;
                case "logo":
                    return this.logo;
                case "icon":
                    return this.icon;
                case "colorid":
                    return this.colorid;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Guild_Banner> rows = _rows as List<Table_Guild_Banner>;
            pool_primary=TableContent.ListToPool < int, Table_Guild_Banner > ( rows, "map", "id" );
            pool_type=TableContent.ListToPool < int, int, Table_Guild_Banner > ( rows, "map", "banner_combination", "id" );
            all_Table_Guild_Banner_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_type.Clear();
            all_Table_Guild_Banner_List.Clear();
        }
    }
}
