using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宝石孔随机库
    ///</summary>
    [Serializable]
    [TableName("gem_slot_random_library")]
    public partial class Table_Gem_Slot_Random_Library : TableContent
    {

        private static List<Table_Gem_Slot_Random_Library> all_Table_Gem_Slot_Random_Library_List = new List<Table_Gem_Slot_Random_Library>();
        //primary | 主键
        public static Dictionary<int, Table_Gem_Slot_Random_Library > pool_primary = new Dictionary<int, Table_Gem_Slot_Random_Library > ();
        
        
        ///<summary>
        /// 宝石孔随机库ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 孔类型ID1
        ///</summary>
        public int slot_type_id1;
        
        
        ///<summary>
        /// 孔类型权值1
        ///</summary>
        public int slot_type_weight1;
        
        
        ///<summary>
        /// 孔类型ID2
        ///</summary>
        public int slot_type_id2;
        
        
        ///<summary>
        /// 孔类型权值2
        ///</summary>
        public int slot_type_weight2;
        
        
        ///<summary>
        /// 孔类型ID3
        ///</summary>
        public int slot_type_id3;
        
        
        ///<summary>
        /// 孔类型权值3
        ///</summary>
        public int slot_type_weight3;
        
        
        ///<summary>
        /// 孔类型ID4
        ///</summary>
        public int slot_type_id4;
        
        
        ///<summary>
        /// 孔类型权值4
        ///</summary>
        public int slot_type_weight4;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 宝石孔随机库ID</param>
        ///
        public static Table_Gem_Slot_Random_Library GetPrimary ( int _id ){        
            Table_Gem_Slot_Random_Library _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Gem_Slot_Random_Library > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Gem_Slot_Random_Library> GetAllPrimaryList()
        {
            return all_Table_Gem_Slot_Random_Library_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("slot_type_id1", out _currValue))
            {
                this.slot_type_id1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_weight1", out _currValue))
            {
                this.slot_type_weight1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_id2", out _currValue))
            {
                this.slot_type_id2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_weight2", out _currValue))
            {
                this.slot_type_weight2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_id3", out _currValue))
            {
                this.slot_type_id3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_weight3", out _currValue))
            {
                this.slot_type_weight3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_id4", out _currValue))
            {
                this.slot_type_id4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("slot_type_weight4", out _currValue))
            {
                this.slot_type_weight4 = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "gem_slot_random_library";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "slot_type_id1":
                    return this.slot_type_id1;
                case "slot_type_weight1":
                    return this.slot_type_weight1;
                case "slot_type_id2":
                    return this.slot_type_id2;
                case "slot_type_weight2":
                    return this.slot_type_weight2;
                case "slot_type_id3":
                    return this.slot_type_id3;
                case "slot_type_weight3":
                    return this.slot_type_weight3;
                case "slot_type_id4":
                    return this.slot_type_id4;
                case "slot_type_weight4":
                    return this.slot_type_weight4;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Gem_Slot_Random_Library> rows = _rows as List<Table_Gem_Slot_Random_Library>;
            pool_primary=TableContent.ListToPool < int, Table_Gem_Slot_Random_Library > ( rows, "map", "id" );
            all_Table_Gem_Slot_Random_Library_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Gem_Slot_Random_Library_List.Clear();
        }
    }
}
