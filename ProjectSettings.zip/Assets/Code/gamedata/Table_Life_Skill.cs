using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 生活技能
    ///</summary>
    [Serializable]
    [TableName("life_skill")]
    public partial class Table_Life_Skill : TableContent
    {

        private static List<Table_Life_Skill> all_Table_Life_Skill_List = new List<Table_Life_Skill>();
        //primary | 主键
        public static Dictionary<int, Table_Life_Skill > pool_primary = new Dictionary<int, Table_Life_Skill > ();
        
        
        ///<summary>
        /// 技能ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 技能名称
        ///</summary>
        public string skill_name;
        
        
        ///<summary>
        /// 技能名称国际化
        ///</summary>
        public string skill_name_i18n;
        
        
        ///<summary>
        /// 技能分组ID
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 附属子技能ID
        ///</summary>
        public int sub_skill_id;
        
        
        ///<summary>
        /// 解锁任务ID
        ///</summary>
        public int unlock_task_id;
        
        
        ///<summary>
        /// 未激活是否显示
        ///</summary>
        public bool inactive_show;
        
        
        ///<summary>
        /// 未学习描述
        ///</summary>
        public string unlearn_description;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 技能ID</param>
        ///
        public static Table_Life_Skill GetPrimary ( int _skillId ){        
            Table_Life_Skill _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Life_Skill > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Life_Skill> GetAllPrimaryList()
        {
            return all_Table_Life_Skill_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_name", out _currValue))
            {
                this.skill_name = _currValue;
            }
            if(_itemData.TryGetValue("skill_name_i18n", out _currValue))
            {
                this.skill_name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sub_skill_id", out _currValue))
            {
                this.sub_skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_task_id", out _currValue))
            {
                this.unlock_task_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("inactive_show", out _currValue))
            {
                this.inactive_show = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlearn_description", out _currValue))
            {
                this.unlearn_description = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "life_skill";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_id":
                    return this.skill_id;
                case "skill_name":
                    return this.skill_name;
                case "skill_name_i18n":
                    return this.skill_name_i18n;
                case "group_id":
                    return this.group_id;
                case "sub_skill_id":
                    return this.sub_skill_id;
                case "unlock_task_id":
                    return this.unlock_task_id;
                case "inactive_show":
                    return this.inactive_show;
                case "unlearn_description":
                    return this.unlearn_description;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Life_Skill> rows = _rows as List<Table_Life_Skill>;
            pool_primary=TableContent.ListToPool < int, Table_Life_Skill > ( rows, "map", "skill_id" );
            all_Table_Life_Skill_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Life_Skill_List.Clear();
        }
    }
}
