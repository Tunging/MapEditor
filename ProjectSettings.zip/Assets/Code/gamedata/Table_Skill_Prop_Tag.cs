using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能属性组标签
    ///</summary>
    [Serializable]
    [TableName("skill_prop_tag")]
    public partial class Table_Skill_Prop_Tag : TableContent
    {

        private static List<Table_Skill_Prop_Tag> all_Table_Skill_Prop_Tag_List = new List<Table_Skill_Prop_Tag>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Skill_Prop_Tag > > pool_primary = new Dictionary<int, Dictionary<int, Table_Skill_Prop_Tag > > ();
        
        
        ///<summary>
        /// 主键：技能ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 主键：标签ID
        ///</summary>
        public int tag_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///
        public static Dictionary<int, Table_Skill_Prop_Tag > GetPrimary ( int _skillId ){        
            Dictionary<int, Table_Skill_Prop_Tag > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///	<param tagId> 主键：标签ID</param>
        ///
        public static Table_Skill_Prop_Tag GetPrimary ( int _skillId , int _tagId ){        
            Dictionary<int, Table_Skill_Prop_Tag > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Skill_Prop_Tag _map1=null;        
            _map0. TryGetValue(_tagId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Skill_Prop_Tag > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Prop_Tag> GetAllPrimaryList()
        {
            return all_Table_Skill_Prop_Tag_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("tag_id", out _currValue))
            {
                this.tag_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_prop_tag";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_id":
                    return this.skill_id;
                case "tag_id":
                    return this.tag_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Prop_Tag> rows = _rows as List<Table_Skill_Prop_Tag>;
            pool_primary=TableContent.ListToPool < int, int, Table_Skill_Prop_Tag > ( rows, "map", "skill_id", "tag_id" );
            all_Table_Skill_Prop_Tag_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Prop_Tag_List.Clear();
        }
    }
}
