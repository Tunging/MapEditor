using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 地图事件图标
    ///</summary>
    [Serializable]
    [TableName("map_event_icon")]
    public partial class Table_Map_Event_Icon : TableContent
    {

        private static List<Table_Map_Event_Icon> all_Table_Map_Event_Icon_List = new List<Table_Map_Event_Icon>();
        //primary | 主键
        public static Dictionary<int, Table_Map_Event_Icon > pool_primary = new Dictionary<int, Table_Map_Event_Icon > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 事件名称
        ///</summary>
        public string event_name;
        
        
        ///<summary>
        /// 关闭状态图标ID
        ///</summary>
        public int closed_icon_id;
        
        
        ///<summary>
        /// 开启状态图标id
        ///</summary>
        public int opend_icon_id;
        
        
        ///<summary>
        /// 缩小比（0：不显示，1：正常大小）
        ///</summary>
        public float narrow;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Map_Event_Icon GetPrimary ( int _id ){        
            Table_Map_Event_Icon _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Map_Event_Icon > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Map_Event_Icon> GetAllPrimaryList()
        {
            return all_Table_Map_Event_Icon_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("event_name", out _currValue))
            {
                this.event_name = _currValue;
            }
            if(_itemData.TryGetValue("closed_icon_id", out _currValue))
            {
                this.closed_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("opend_icon_id", out _currValue))
            {
                this.opend_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("narrow", out _currValue))
            {
                this.narrow = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "map_event_icon";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "event_name":
                    return this.event_name;
                case "closed_icon_id":
                    return this.closed_icon_id;
                case "opend_icon_id":
                    return this.opend_icon_id;
                case "narrow":
                    return this.narrow;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Map_Event_Icon> rows = _rows as List<Table_Map_Event_Icon>;
            pool_primary=TableContent.ListToPool < int, Table_Map_Event_Icon > ( rows, "map", "id" );
            all_Table_Map_Event_Icon_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Map_Event_Icon_List.Clear();
        }
    }
}
