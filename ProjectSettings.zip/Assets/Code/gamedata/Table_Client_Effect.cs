using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：特效资源
    ///</summary>
    [Serializable]
    [TableName("client_effect")]
    public partial class Table_Client_Effect : TableContent
    {

        private static List<Table_Client_Effect> all_Table_Client_Effect_List = new List<Table_Client_Effect>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Effect > pool_primary = new Dictionary<int, Table_Client_Effect > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 关联子特效：多个ID用逗号分割
        ///</summary>
        public string sub_effect;
        
        
        ///<summary>
        /// 资源路径
        ///</summary>
        public string path;
        
        
        ///<summary>
        /// 关联的声音ID
        ///</summary>
        public int refer_sound_id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Client_Effect GetPrimary ( int _id ){        
            Table_Client_Effect _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Effect > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Effect> GetAllPrimaryList()
        {
            return all_Table_Client_Effect_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("sub_effect", out _currValue))
            {
                this.sub_effect = _currValue;
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
            if(_itemData.TryGetValue("refer_sound_id", out _currValue))
            {
                this.refer_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_effect";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "sub_effect":
                    return this.sub_effect;
                case "path":
                    return this.path;
                case "refer_sound_id":
                    return this.refer_sound_id;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Effect> rows = _rows as List<Table_Client_Effect>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Effect > ( rows, "map", "id" );
            all_Table_Client_Effect_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Effect_List.Clear();
        }
    }
}
