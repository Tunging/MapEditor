using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 传记表
    ///</summary>
    [Serializable]
    [TableName("biography")]
    public partial class Table_Biography : TableContent
    {

        private static List<Table_Biography> all_Table_Biography_List = new List<Table_Biography>();
        //primary | 主键
        public static Dictionary<int, Table_Biography > pool_primary = new Dictionary<int, Table_Biography > ();
        
        
        ///<summary>
        /// 主键：精灵模板ID
        ///</summary>
        public int sprite_id;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 声音id
        ///</summary>
        public int voice_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param spriteId> 主键：精灵模板ID</param>
        ///
        public static Table_Biography GetPrimary ( int _spriteId ){        
            Table_Biography _map0=null;        
            pool_primary. TryGetValue(_spriteId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Biography > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Biography> GetAllPrimaryList()
        {
            return all_Table_Biography_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("sprite_id", out _currValue))
            {
                this.sprite_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("voice_id", out _currValue))
            {
                this.voice_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "biography";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "sprite_id":
                    return this.sprite_id;
                case "description":
                    return this.description;
                case "voice_id":
                    return this.voice_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Biography> rows = _rows as List<Table_Biography>;
            pool_primary=TableContent.ListToPool < int, Table_Biography > ( rows, "map", "sprite_id" );
            all_Table_Biography_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Biography_List.Clear();
        }
    }
}
