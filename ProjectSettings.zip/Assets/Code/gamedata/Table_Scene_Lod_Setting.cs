using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景lod设置
    ///</summary>
    [Serializable]
    [TableName("scene_lod_setting")]
    public partial class Table_Scene_Lod_Setting : TableContent
    {

        private static List<Table_Scene_Lod_Setting> all_Table_Scene_Lod_Setting_List = new List<Table_Scene_Lod_Setting>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > > ();
        
        
        ///<summary>
        /// 主键：场景lod设置组ID
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 主键：机型级别
        ///</summary>
        public int machine_grade;
        
        
        ///<summary>
        /// 主键：精灵类型
        ///</summary>
        public int sprite_type;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 最小同屏个数
        ///</summary>
        public int show_min_num;
        
        
        ///<summary>
        /// 最大同屏个数
        ///</summary>
        public int show_num;
        
        
        ///<summary>
        /// 最远显示距离
        ///</summary>
        public int show_distance;
        
        
        ///<summary>
        /// 显示权重
        ///</summary>
        public int show_weight;
        
        
        ///<summary>
        /// 显示优先级
        ///</summary>
        public int show_priority;
        
        
        ///<summary>
        /// 最大同时声音
        ///</summary>
        public int max_sound_num;
        
        
        ///<summary>
        /// 声音播放权重
        ///</summary>
        public int sound_play_weight;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 主键：场景lod设置组ID</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > GetPrimary ( int _groupId ){        
            Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 主键：场景lod设置组ID</param>
        ///	<param machineGrade> 主键：机型级别</param>
        ///
        public static Dictionary<int, Table_Scene_Lod_Setting > GetPrimary ( int _groupId , int _machineGrade ){        
            Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Scene_Lod_Setting > _map1=null;        
            _map0. TryGetValue(_machineGrade,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 主键：场景lod设置组ID</param>
        ///	<param machineGrade> 主键：机型级别</param>
        ///	<param spriteType> 主键：精灵类型</param>
        ///
        public static Table_Scene_Lod_Setting GetPrimary ( int _groupId , int _machineGrade , int _spriteType ){        
            Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Scene_Lod_Setting > _map1=null;        
            _map0. TryGetValue(_machineGrade,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Scene_Lod_Setting _map2=null;        
            _map1. TryGetValue(_spriteType,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Scene_Lod_Setting > > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Lod_Setting> GetAllPrimaryList()
        {
            return all_Table_Scene_Lod_Setting_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("machine_grade", out _currValue))
            {
                this.machine_grade = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sprite_type", out _currValue))
            {
                this.sprite_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("show_min_num", out _currValue))
            {
                this.show_min_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_num", out _currValue))
            {
                this.show_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_distance", out _currValue))
            {
                this.show_distance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_weight", out _currValue))
            {
                this.show_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_priority", out _currValue))
            {
                this.show_priority = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_sound_num", out _currValue))
            {
                this.max_sound_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_play_weight", out _currValue))
            {
                this.sound_play_weight = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_lod_setting";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "group_id":
                    return this.group_id;
                case "machine_grade":
                    return this.machine_grade;
                case "sprite_type":
                    return this.sprite_type;
                case "remark":
                    return this.remark;
                case "show_min_num":
                    return this.show_min_num;
                case "show_num":
                    return this.show_num;
                case "show_distance":
                    return this.show_distance;
                case "show_weight":
                    return this.show_weight;
                case "show_priority":
                    return this.show_priority;
                case "max_sound_num":
                    return this.max_sound_num;
                case "sound_play_weight":
                    return this.sound_play_weight;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Lod_Setting> rows = _rows as List<Table_Scene_Lod_Setting>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Scene_Lod_Setting > ( rows, "map", "group_id", "machine_grade", "sprite_type" );
            all_Table_Scene_Lod_Setting_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Lod_Setting_List.Clear();
        }
    }
}
