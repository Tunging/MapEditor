using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 对话组表
    ///</summary>
    [Serializable]
    [TableName("dialog")]
    public partial class Table_Dialog : TableContent
    {

        private static List<Table_Dialog> all_Table_Dialog_List = new List<Table_Dialog>();
        //primary | 主键
        public static Dictionary<int, Table_Dialog > pool_primary = new Dictionary<int, Table_Dialog > ();
        //currentDialogGroup | 当前对话组的全部内容
        public static Dictionary<int, List<Table_Dialog> > pool_currentDialogGroup = new Dictionary<int, List<Table_Dialog> > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 对话组id
        ///</summary>
        public int dialog_group_id;
        
        
        ///<summary>
        /// 控件类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 控件参数１
        ///</summary>
        public int param1;
        
        
        ///<summary>
        /// 控件参数２
        ///</summary>
        public int param2;
        
        
        ///<summary>
        /// 控件参数3
        ///</summary>
        public int param3;
        
        
        ///<summary>
        /// 显示顺序
        ///</summary>
        public int order;
        
        
        ///<summary>
        /// 触发条件类型
        ///</summary>
        public int condition_type;
        
        
        ///<summary>
        /// 条件参数１
        ///</summary>
        public int condition_param1;
        
        
        ///<summary>
        /// 条件参数２
        ///</summary>
        public int condition_param2;
        
        
        ///<summary>
        /// 条件参数３
        ///</summary>
        public int condition_param3;
        
        
        ///<summary>
        /// 触发行为类型
        ///</summary>
        public int function_type;
        
        
        ///<summary>
        /// 行为参数１
        ///</summary>
        public int function_param1;
        
        
        ///<summary>
        /// 行为参数２
        ///</summary>
        public int function_param2;
        
        
        ///<summary>
        /// 行为参数３
        ///</summary>
        public string function_param3;
        
        
        ///<summary>
        /// 触发行为类型2
        ///</summary>
        public int function_2_type;
        
        
        ///<summary>
        /// 行为2参数１
        ///</summary>
        public int function_2_param1;
        
        
        ///<summary>
        /// 行为2参数2
        ///</summary>
        public int function_2_param2;
        
        
        ///<summary>
        /// 行为2参数3
        ///</summary>
        public string function_2_param3;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Dialog GetPrimary ( int _id ){        
            Table_Dialog _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Dialog > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 当前对话组的全部内容
        /// 查询数据
        ///</summary>
        ///	<param dialogGroupId> 对话组id</param>
        ///
        public static List<Table_Dialog> GetCurrentDialogGroup ( int _dialogGroupId ){        
            List<Table_Dialog> _map0=null;        
            pool_currentDialogGroup. TryGetValue(_dialogGroupId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///当前对话组的全部内容
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Dialog> > GetAllCurrentDialogGroup()
        {
            return pool_currentDialogGroup;
        }


        ///查询出所有的数据
        public static List<Table_Dialog> GetAllPrimaryList()
        {
            return all_Table_Dialog_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_group_id", out _currValue))
            {
                this.dialog_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param1", out _currValue))
            {
                this.param1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param2", out _currValue))
            {
                this.param2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param3", out _currValue))
            {
                this.param3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("order", out _currValue))
            {
                this.order = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("condition_type", out _currValue))
            {
                this.condition_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("condition_param1", out _currValue))
            {
                this.condition_param1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("condition_param2", out _currValue))
            {
                this.condition_param2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("condition_param3", out _currValue))
            {
                this.condition_param3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_type", out _currValue))
            {
                this.function_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_param1", out _currValue))
            {
                this.function_param1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_param2", out _currValue))
            {
                this.function_param2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_param3", out _currValue))
            {
                this.function_param3 = _currValue;
            }
            if(_itemData.TryGetValue("function_2_type", out _currValue))
            {
                this.function_2_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_2_param1", out _currValue))
            {
                this.function_2_param1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_2_param2", out _currValue))
            {
                this.function_2_param2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("function_2_param3", out _currValue))
            {
                this.function_2_param3 = _currValue;
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "dialog";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "dialog_group_id":
                    return this.dialog_group_id;
                case "type":
                    return this.type;
                case "param1":
                    return this.param1;
                case "param2":
                    return this.param2;
                case "param3":
                    return this.param3;
                case "order":
                    return this.order;
                case "condition_type":
                    return this.condition_type;
                case "condition_param1":
                    return this.condition_param1;
                case "condition_param2":
                    return this.condition_param2;
                case "condition_param3":
                    return this.condition_param3;
                case "function_type":
                    return this.function_type;
                case "function_param1":
                    return this.function_param1;
                case "function_param2":
                    return this.function_param2;
                case "function_param3":
                    return this.function_param3;
                case "function_2_type":
                    return this.function_2_type;
                case "function_2_param1":
                    return this.function_2_param1;
                case "function_2_param2":
                    return this.function_2_param2;
                case "function_2_param3":
                    return this.function_2_param3;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Dialog> rows = _rows as List<Table_Dialog>;
            pool_primary=TableContent.ListToPool < int, Table_Dialog > ( rows, "map", "id" );
            pool_currentDialogGroup=TableContent.ListToPoolList < int, Table_Dialog > ( rows, "list", "dialog_group_id" );
            all_Table_Dialog_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_currentDialogGroup.Clear();
            all_Table_Dialog_List.Clear();
        }
    }
}
