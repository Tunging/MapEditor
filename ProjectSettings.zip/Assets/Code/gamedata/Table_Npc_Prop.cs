using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc属性配置
    ///</summary>
    [Serializable]
    [TableName("npc_prop")]
    public partial class Table_Npc_Prop : TableContent
    {

        private static List<Table_Npc_Prop> all_Table_Npc_Prop_List = new List<Table_Npc_Prop>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Prop > pool_primary = new Dictionary<int, Table_Npc_Prop > ();
        
        
        ///<summary>
        /// 主键：配置ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 品质
        ///</summary>
        public int quality;
        
        
        ///<summary>
        /// 血条层数
        ///</summary>
        public int hp_ui_layer;
        
        
        ///<summary>
        /// 是不是无法被选中
        ///</summary>
        public bool is_no_selected;
        
        
        ///<summary>
        /// 是不是无法被攻击
        ///</summary>
        public bool is_no_attacked;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：配置ID</param>
        ///
        public static Table_Npc_Prop GetPrimary ( int _id ){        
            Table_Npc_Prop _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Prop > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Prop> GetAllPrimaryList()
        {
            return all_Table_Npc_Prop_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("quality", out _currValue))
            {
                this.quality = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("hp_ui_layer", out _currValue))
            {
                this.hp_ui_layer = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_selected", out _currValue))
            {
                this.is_no_selected = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_attacked", out _currValue))
            {
                this.is_no_attacked = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_prop";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "quality":
                    return this.quality;
                case "hp_ui_layer":
                    return this.hp_ui_layer;
                case "is_no_selected":
                    return this.is_no_selected;
                case "is_no_attacked":
                    return this.is_no_attacked;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Prop> rows = _rows as List<Table_Npc_Prop>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Prop > ( rows, "map", "id" );
            all_Table_Npc_Prop_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Prop_List.Clear();
        }
    }
}
