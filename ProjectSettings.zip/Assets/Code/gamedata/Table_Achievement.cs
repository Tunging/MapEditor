using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 成就
    ///</summary>
    [Serializable]
    [TableName("achievement")]
    public partial class Table_Achievement : TableContent
    {

        private static List<Table_Achievement> all_Table_Achievement_List = new List<Table_Achievement>();
        //primary | 主键
        public static Dictionary<int, Table_Achievement > pool_primary = new Dictionary<int, Table_Achievement > ();
        
        
        ///<summary>
        /// ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 需要达到的值
        ///</summary>
        public int need_value;
        
        
        ///<summary>
        /// 成就条件达成方式
        ///</summary>
        public int complete_type;
        
        
        ///<summary>
        /// 奖励id
        ///</summary>
        public int reward_id;
        
        
        ///<summary>
        /// 成就分类
        ///</summary>
        public int classify;
        
        
        ///<summary>
        /// 章节id
        ///</summary>
        public int chapter;
        
        
        ///<summary>
        /// 国际化名字
        ///</summary>
        public string achievement_name_i18n;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string des_i18n;
        
        
        ///<summary>
        /// 是否显示百分比
        ///</summary>
        public bool show_as_percent;
        
        
        ///<summary>
        /// 图标id
        ///</summary>
        public int Icon_Id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> ID</param>
        ///
        public static Table_Achievement GetPrimary ( int _id ){        
            Table_Achievement _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Achievement > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Achievement> GetAllPrimaryList()
        {
            return all_Table_Achievement_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("need_value", out _currValue))
            {
                this.need_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("complete_type", out _currValue))
            {
                this.complete_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward_id", out _currValue))
            {
                this.reward_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("classify", out _currValue))
            {
                this.classify = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chapter", out _currValue))
            {
                this.chapter = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("achievement_name_i18n", out _currValue))
            {
                this.achievement_name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("des_i18n", out _currValue))
            {
                this.des_i18n = _currValue;
            }
            if(_itemData.TryGetValue("show_as_percent", out _currValue))
            {
                this.show_as_percent = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("Icon_Id", out _currValue))
            {
                this.Icon_Id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "achievement";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "need_value":
                    return this.need_value;
                case "complete_type":
                    return this.complete_type;
                case "reward_id":
                    return this.reward_id;
                case "classify":
                    return this.classify;
                case "chapter":
                    return this.chapter;
                case "achievement_name_i18n":
                    return this.achievement_name_i18n;
                case "des_i18n":
                    return this.des_i18n;
                case "show_as_percent":
                    return this.show_as_percent;
                case "Icon_Id":
                    return this.Icon_Id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Achievement> rows = _rows as List<Table_Achievement>;
            pool_primary=TableContent.ListToPool < int, Table_Achievement > ( rows, "map", "id" );
            all_Table_Achievement_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Achievement_List.Clear();
        }
    }
}
