using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 生活技能分组
    ///</summary>
    [Serializable]
    [TableName("life_skill_group")]
    public partial class Table_Life_Skill_Group : TableContent
    {

        private static List<Table_Life_Skill_Group> all_Table_Life_Skill_Group_List = new List<Table_Life_Skill_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Life_Skill_Group > pool_primary = new Dictionary<int, Table_Life_Skill_Group > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名字
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 名字国际化
        ///</summary>
        public string name_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Life_Skill_Group GetPrimary ( int _id ){        
            Table_Life_Skill_Group _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Life_Skill_Group > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Life_Skill_Group> GetAllPrimaryList()
        {
            return all_Table_Life_Skill_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "life_skill_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Life_Skill_Group> rows = _rows as List<Table_Life_Skill_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Life_Skill_Group > ( rows, "map", "id" );
            all_Table_Life_Skill_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Life_Skill_Group_List.Clear();
        }
    }
}
