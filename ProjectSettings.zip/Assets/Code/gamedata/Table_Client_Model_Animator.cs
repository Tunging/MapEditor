using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：模型动作状态机
    ///</summary>
    [Serializable]
    [TableName("client_model_animator")]
    public partial class Table_Client_Model_Animator : TableContent
    {

        private static List<Table_Client_Model_Animator> all_Table_Client_Model_Animator_List = new List<Table_Client_Model_Animator>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Model_Animator > pool_primary = new Dictionary<int, Table_Client_Model_Animator > ();
        
        
        ///<summary>
        /// ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 资源路径
        ///</summary>
        public string path;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> ID</param>
        ///
        public static Table_Client_Model_Animator GetPrimary ( int _id ){        
            Table_Client_Model_Animator _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Model_Animator > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Model_Animator> GetAllPrimaryList()
        {
            return all_Table_Client_Model_Animator_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_model_animator";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "path":
                    return this.path;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Model_Animator> rows = _rows as List<Table_Client_Model_Animator>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Model_Animator > ( rows, "map", "id" );
            all_Table_Client_Model_Animator_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Model_Animator_List.Clear();
        }
    }
}
