using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 提示消息
    ///</summary>
    [Serializable]
    [TableName("msg_tip")]
    public partial class Table_Msg_Tip : TableContent
    {

        private static List<Table_Msg_Tip> all_Table_Msg_Tip_List = new List<Table_Msg_Tip>();
        //primary | 主键
        public static Dictionary<int, Table_Msg_Tip > pool_primary = new Dictionary<int, Table_Msg_Tip > ();
        
        
        ///<summary>
        /// 主键：消息ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string msg_key;
        
        
        ///<summary>
        /// 显示类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 模块名
        ///</summary>
        public string module;
        
        
        ///<summary>
        /// 消息内容
        ///</summary>
        public string value;
        
        
        ///<summary>
        /// 消息内容国际化
        ///</summary>
        public string value_i18n;
        
        
        ///<summary>
        /// 优先级
        ///</summary>
        public int priority;
        
        
        ///<summary>
        /// 播放次数
        ///</summary>
        public int play_times;
        
        
        ///<summary>
        /// 是否可以被顶
        ///</summary>
        public bool can_replace;
        
        
        ///<summary>
        /// 播放声音ID
        ///</summary>
        public int sound_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：消息ID</param>
        ///
        public static Table_Msg_Tip GetPrimary ( int _id ){        
            Table_Msg_Tip _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Msg_Tip > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Msg_Tip> GetAllPrimaryList()
        {
            return all_Table_Msg_Tip_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("msg_key", out _currValue))
            {
                this.msg_key = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("module", out _currValue))
            {
                this.module = _currValue;
            }
            if(_itemData.TryGetValue("value", out _currValue))
            {
                this.value = _currValue;
            }
            if(_itemData.TryGetValue("value_i18n", out _currValue))
            {
                this.value_i18n = _currValue;
            }
            if(_itemData.TryGetValue("priority", out _currValue))
            {
                this.priority = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("play_times", out _currValue))
            {
                this.play_times = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_replace", out _currValue))
            {
                this.can_replace = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "msg_tip";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "msg_key":
                    return this.msg_key;
                case "type":
                    return this.type;
                case "module":
                    return this.module;
                case "value":
                    return this.value;
                case "value_i18n":
                    return this.value_i18n;
                case "priority":
                    return this.priority;
                case "play_times":
                    return this.play_times;
                case "can_replace":
                    return this.can_replace;
                case "sound_id":
                    return this.sound_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Msg_Tip> rows = _rows as List<Table_Msg_Tip>;
            pool_primary=TableContent.ListToPool < int, Table_Msg_Tip > ( rows, "map", "id" );
            all_Table_Msg_Tip_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Msg_Tip_List.Clear();
        }
    }
}
