using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 小宝箱奖励对应表
    ///</summary>
    [Serializable]
    [TableName("npc_small_treasure_reward")]
    public partial class Table_Npc_Small_Treasure_Reward : TableContent
    {

        private static List<Table_Npc_Small_Treasure_Reward> all_Table_Npc_Small_Treasure_Reward_List = new List<Table_Npc_Small_Treasure_Reward>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Small_Treasure_Reward > pool_primary = new Dictionary<int, Table_Npc_Small_Treasure_Reward > ();
        
        
        ///<summary>
        /// npc guid
        ///</summary>
        public int npc_guid;
        
        
        ///<summary>
        /// 小宝箱奖励
        ///</summary>
        public string rewards;
        
        
        ///<summary>
        /// 场景完成度ID
        ///</summary>
        public int scene_completion_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcGuid> npc guid</param>
        ///
        public static Table_Npc_Small_Treasure_Reward GetPrimary ( int _npcGuid ){        
            Table_Npc_Small_Treasure_Reward _map0=null;        
            pool_primary. TryGetValue(_npcGuid,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Small_Treasure_Reward > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Small_Treasure_Reward> GetAllPrimaryList()
        {
            return all_Table_Npc_Small_Treasure_Reward_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_guid", out _currValue))
            {
                this.npc_guid = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("rewards", out _currValue))
            {
                this.rewards = _currValue;
            }
            if(_itemData.TryGetValue("scene_completion_id", out _currValue))
            {
                this.scene_completion_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_small_treasure_reward";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_guid":
                    return this.npc_guid;
                case "rewards":
                    return this.rewards;
                case "scene_completion_id":
                    return this.scene_completion_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Small_Treasure_Reward> rows = _rows as List<Table_Npc_Small_Treasure_Reward>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Small_Treasure_Reward > ( rows, "map", "npc_guid" );
            all_Table_Npc_Small_Treasure_Reward_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Small_Treasure_Reward_List.Clear();
        }
    }
}
