using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：动作转换条件
    ///</summary>
    [Serializable]
    [TableName("client_action")]
    public partial class Table_Client_Action : TableContent
    {

        private static List<Table_Client_Action> all_Table_Client_Action_List = new List<Table_Client_Action>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Action > pool_primary = new Dictionary<int, Table_Client_Action > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 动作转换条件(int)
        ///</summary>
        public string action_condition;
        
        
        ///<summary>
        /// 动作转换条件(float)
        ///</summary>
        public string action_condition_float;
        
        
        ///<summary>
        /// 动作转换条件(trigger)
        ///</summary>
        public string action_condition_trigger;
        
        
        ///<summary>
        /// 动作图层0
        ///</summary>
        public string action_layer;
        
        
        ///<summary>
        /// 移动状态动作融合度（0-1）
        ///</summary>
        public float action_layer_fusion;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 动作时长（毫秒）
        ///</summary>
        public int action_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Client_Action GetPrimary ( int _id ){        
            Table_Client_Action _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Action > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Action> GetAllPrimaryList()
        {
            return all_Table_Client_Action_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("action_condition", out _currValue))
            {
                this.action_condition = _currValue;
            }
            if(_itemData.TryGetValue("action_condition_float", out _currValue))
            {
                this.action_condition_float = _currValue;
            }
            if(_itemData.TryGetValue("action_condition_trigger", out _currValue))
            {
                this.action_condition_trigger = _currValue;
            }
            if(_itemData.TryGetValue("action_layer", out _currValue))
            {
                this.action_layer = _currValue;
            }
            if(_itemData.TryGetValue("action_layer_fusion", out _currValue))
            {
                this.action_layer_fusion = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("action_time", out _currValue))
            {
                this.action_time = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_action";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "action_condition":
                    return this.action_condition;
                case "action_condition_float":
                    return this.action_condition_float;
                case "action_condition_trigger":
                    return this.action_condition_trigger;
                case "action_layer":
                    return this.action_layer;
                case "action_layer_fusion":
                    return this.action_layer_fusion;
                case "remark":
                    return this.remark;
                case "action_time":
                    return this.action_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Action> rows = _rows as List<Table_Client_Action>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Action > ( rows, "map", "id" );
            all_Table_Client_Action_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Action_List.Clear();
        }
    }
}
