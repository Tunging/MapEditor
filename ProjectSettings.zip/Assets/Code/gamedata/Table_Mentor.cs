using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 职业导师表
    ///</summary>
    [Serializable]
    [TableName("mentor")]
    public partial class Table_Mentor : TableContent
    {

        private static List<Table_Mentor> all_Table_Mentor_List = new List<Table_Mentor>();
        //primary | 主键
        public static Dictionary<int, Table_Mentor > pool_primary = new Dictionary<int, Table_Mentor > ();
        
        
        ///<summary>
        /// 导师ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// NPC模板ID
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 对话ID
        ///</summary>
        public int dialog_id;
        
        
        ///<summary>
        /// 关联职业ID
        ///</summary>
        public int profession_id;
        
        
        ///<summary>
        /// 转职副本ID
        ///</summary>
        public int intance_id;
        
        
        ///<summary>
        /// 日常副本进入次数
        ///</summary>
        public int daily_instance_num;
        
        
        ///<summary>
        /// 转职导师等级限制
        ///</summary>
        public int zhuanzhi_level_limit;
        
        
        ///<summary>
        /// 背景图片ID
        ///</summary>
        public int groud_image_id;
        
        
        ///<summary>
        /// 界面上模型偏移X
        ///</summary>
        public int panel_model_offset_x;
        
        
        ///<summary>
        /// 界面上模型偏移Y
        ///</summary>
        public int panel_model_offset_y;
        
        
        ///<summary>
        /// 界面上模型偏移Z
        ///</summary>
        public int panel_model_offset_z;
        
        
        ///<summary>
        /// 界面上模型缩放
        ///</summary>
        public float panel_model_scale;
        
        
        ///<summary>
        /// 背景故事
        ///</summary>
        public string story;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 导师ID</param>
        ///
        public static Table_Mentor GetPrimary ( int _id ){        
            Table_Mentor _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mentor > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mentor> GetAllPrimaryList()
        {
            return all_Table_Mentor_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_id", out _currValue))
            {
                this.dialog_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("profession_id", out _currValue))
            {
                this.profession_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("intance_id", out _currValue))
            {
                this.intance_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("daily_instance_num", out _currValue))
            {
                this.daily_instance_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("zhuanzhi_level_limit", out _currValue))
            {
                this.zhuanzhi_level_limit = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("groud_image_id", out _currValue))
            {
                this.groud_image_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("panel_model_offset_x", out _currValue))
            {
                this.panel_model_offset_x = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("panel_model_offset_y", out _currValue))
            {
                this.panel_model_offset_y = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("panel_model_offset_z", out _currValue))
            {
                this.panel_model_offset_z = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("panel_model_scale", out _currValue))
            {
                this.panel_model_scale = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("story", out _currValue))
            {
                this.story = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mentor";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "npc_id":
                    return this.npc_id;
                case "dialog_id":
                    return this.dialog_id;
                case "profession_id":
                    return this.profession_id;
                case "intance_id":
                    return this.intance_id;
                case "daily_instance_num":
                    return this.daily_instance_num;
                case "zhuanzhi_level_limit":
                    return this.zhuanzhi_level_limit;
                case "groud_image_id":
                    return this.groud_image_id;
                case "panel_model_offset_x":
                    return this.panel_model_offset_x;
                case "panel_model_offset_y":
                    return this.panel_model_offset_y;
                case "panel_model_offset_z":
                    return this.panel_model_offset_z;
                case "panel_model_scale":
                    return this.panel_model_scale;
                case "story":
                    return this.story;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mentor> rows = _rows as List<Table_Mentor>;
            pool_primary=TableContent.ListToPool < int, Table_Mentor > ( rows, "map", "id" );
            all_Table_Mentor_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mentor_List.Clear();
        }
    }
}
