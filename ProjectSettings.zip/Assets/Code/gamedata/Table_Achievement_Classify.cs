using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 成就分类标签
    ///</summary>
    [Serializable]
    [TableName("achievement_classify")]
    public partial class Table_Achievement_Classify : TableContent
    {

        private static List<Table_Achievement_Classify> all_Table_Achievement_Classify_List = new List<Table_Achievement_Classify>();
        //primary | 主键
        public static Dictionary<int, Table_Achievement_Classify > pool_primary = new Dictionary<int, Table_Achievement_Classify > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 徽章图标id
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// ckey
        ///</summary>
        public string ckey;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Achievement_Classify GetPrimary ( int _id ){        
            Table_Achievement_Classify _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Achievement_Classify > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Achievement_Classify> GetAllPrimaryList()
        {
            return all_Table_Achievement_Classify_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "achievement_classify";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "icon_id":
                    return this.icon_id;
                case "ckey":
                    return this.ckey;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Achievement_Classify> rows = _rows as List<Table_Achievement_Classify>;
            pool_primary=TableContent.ListToPool < int, Table_Achievement_Classify > ( rows, "map", "id" );
            all_Table_Achievement_Classify_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Achievement_Classify_List.Clear();
        }
    }
}
