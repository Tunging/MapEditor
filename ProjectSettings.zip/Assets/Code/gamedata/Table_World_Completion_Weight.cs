using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 地图完成度权重表
    ///</summary>
    [Serializable]
    [TableName("world_completion_weight")]
    public partial class Table_World_Completion_Weight : TableContent
    {

        private static List<Table_World_Completion_Weight> all_Table_World_Completion_Weight_List = new List<Table_World_Completion_Weight>();
        //primary | 主键
        public static Dictionary<int, Table_World_Completion_Weight > pool_primary = new Dictionary<int, Table_World_Completion_Weight > ();
        
        
        ///<summary>
        /// 场景完成度类型
        ///</summary>
        public int complete_type;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param completeType> 场景完成度类型</param>
        ///
        public static Table_World_Completion_Weight GetPrimary ( int _completeType ){        
            Table_World_Completion_Weight _map0=null;        
            pool_primary. TryGetValue(_completeType,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_World_Completion_Weight > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_World_Completion_Weight> GetAllPrimaryList()
        {
            return all_Table_World_Completion_Weight_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("complete_type", out _currValue))
            {
                this.complete_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "world_completion_weight";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "complete_type":
                    return this.complete_type;
                case "weight":
                    return this.weight;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_World_Completion_Weight> rows = _rows as List<Table_World_Completion_Weight>;
            pool_primary=TableContent.ListToPool < int, Table_World_Completion_Weight > ( rows, "map", "complete_type" );
            all_Table_World_Completion_Weight_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_World_Completion_Weight_List.Clear();
        }
    }
}
