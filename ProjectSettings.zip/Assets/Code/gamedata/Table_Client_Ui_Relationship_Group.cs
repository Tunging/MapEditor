using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端ui系统关系组
    ///</summary>
    [Serializable]
    [TableName("client_ui_relationship_group")]
    public partial class Table_Client_Ui_Relationship_Group : TableContent
    {

        private static List<Table_Client_Ui_Relationship_Group> all_Table_Client_Ui_Relationship_Group_List = new List<Table_Client_Ui_Relationship_Group>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Client_Ui_Relationship_Group > > pool_primary = new Dictionary<int, Dictionary<int, Table_Client_Ui_Relationship_Group > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 组ID
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 分组名字
        ///</summary>
        public string group_name;
        
        
        ///<summary>
        /// 面板ID
        ///</summary>
        public int panel_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Dictionary<int, Table_Client_Ui_Relationship_Group > GetPrimary ( int _id ){        
            Dictionary<int, Table_Client_Ui_Relationship_Group > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///	<param groupId> 组ID</param>
        ///
        public static Table_Client_Ui_Relationship_Group GetPrimary ( int _id , int _groupId ){        
            Dictionary<int, Table_Client_Ui_Relationship_Group > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Client_Ui_Relationship_Group _map1=null;        
            _map0. TryGetValue(_groupId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Client_Ui_Relationship_Group > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Ui_Relationship_Group> GetAllPrimaryList()
        {
            return all_Table_Client_Ui_Relationship_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_name", out _currValue))
            {
                this.group_name = _currValue;
            }
            if(_itemData.TryGetValue("panel_id", out _currValue))
            {
                this.panel_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_ui_relationship_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "group_id":
                    return this.group_id;
                case "group_name":
                    return this.group_name;
                case "panel_id":
                    return this.panel_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Ui_Relationship_Group> rows = _rows as List<Table_Client_Ui_Relationship_Group>;
            pool_primary=TableContent.ListToPool < int, int, Table_Client_Ui_Relationship_Group > ( rows, "map", "id", "group_id" );
            all_Table_Client_Ui_Relationship_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Ui_Relationship_Group_List.Clear();
        }
    }
}
