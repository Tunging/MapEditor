using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能组详细配置
    ///</summary>
    [Serializable]
    [TableName("skill_group_item")]
    public partial class Table_Skill_Group_Item : TableContent
    {

        private static List<Table_Skill_Group_Item> all_Table_Skill_Group_Item_List = new List<Table_Skill_Group_Item>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Skill_Group_Item > > pool_primary = new Dictionary<int, Dictionary<int, Table_Skill_Group_Item > > ();
        
        
        ///<summary>
        /// 主键：技能组ID
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 主键：技能ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 切换条件
        ///</summary>
        public int switch_type;
        
        
        ///<summary>
        /// 切换条件对应的参数
        ///</summary>
        public int switch_param;
        
        
        ///<summary>
        /// 点亮条件（1、拥有指定BUFF, 2、二级能量达到某值， 3、当前目标血量低于x%），4、一级能量大于等于x%
        ///</summary>
        public int lighting_condition_type;
        
        
        ///<summary>
        /// 点亮条件参数 
        ///</summary>
        public int lighting_condition_param;
        
        
        ///<summary>
        /// 核心技能：显示描述用
        ///</summary>
        public bool skills_core;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 主键：技能组ID</param>
        ///
        public static Dictionary<int, Table_Skill_Group_Item > GetPrimary ( int _groupId ){        
            Dictionary<int, Table_Skill_Group_Item > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 主键：技能组ID</param>
        ///	<param skillId> 主键：技能ID</param>
        ///
        public static Table_Skill_Group_Item GetPrimary ( int _groupId , int _skillId ){        
            Dictionary<int, Table_Skill_Group_Item > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Skill_Group_Item _map1=null;        
            _map0. TryGetValue(_skillId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Skill_Group_Item > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Group_Item> GetAllPrimaryList()
        {
            return all_Table_Skill_Group_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("switch_type", out _currValue))
            {
                this.switch_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("switch_param", out _currValue))
            {
                this.switch_param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("lighting_condition_type", out _currValue))
            {
                this.lighting_condition_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("lighting_condition_param", out _currValue))
            {
                this.lighting_condition_param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skills_core", out _currValue))
            {
                this.skills_core = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_group_item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "group_id":
                    return this.group_id;
                case "skill_id":
                    return this.skill_id;
                case "switch_type":
                    return this.switch_type;
                case "switch_param":
                    return this.switch_param;
                case "lighting_condition_type":
                    return this.lighting_condition_type;
                case "lighting_condition_param":
                    return this.lighting_condition_param;
                case "skills_core":
                    return this.skills_core;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Group_Item> rows = _rows as List<Table_Skill_Group_Item>;
            pool_primary=TableContent.ListToPool < int, int, Table_Skill_Group_Item > ( rows, "map", "group_id", "skill_id" );
            all_Table_Skill_Group_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Group_Item_List.Clear();
        }
    }
}
