using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物被动buff
    ///</summary>
    [Serializable]
    [TableName("pet_buff")]
    public partial class Table_Pet_Buff : TableContent
    {

        private static List<Table_Pet_Buff> all_Table_Pet_Buff_List = new List<Table_Pet_Buff>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Pet_Buff > > pool_primary = new Dictionary<int, Dictionary<int, Table_Pet_Buff > > ();
        //buff | 
        public static Dictionary<int, List<Table_Pet_Buff> > pool_buff = new Dictionary<int, List<Table_Pet_Buff> > ();
        
        
        ///<summary>
        /// 主键：ID 宠物id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// buffId
        ///</summary>
        public int buff_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID 宠物id</param>
        ///
        public static Dictionary<int, Table_Pet_Buff > GetPrimary ( int _id ){        
            Dictionary<int, Table_Pet_Buff > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID 宠物id</param>
        ///	<param buffId> buffId</param>
        ///
        public static Table_Pet_Buff GetPrimary ( int _id , int _buffId ){        
            Dictionary<int, Table_Pet_Buff > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Pet_Buff _map1=null;        
            _map0. TryGetValue(_buffId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Pet_Buff > > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID 宠物id</param>
        ///
        public static List<Table_Pet_Buff> GetBuff ( int _id ){        
            List<Table_Pet_Buff> _map0=null;        
            pool_buff. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Pet_Buff> > GetAllBuff()
        {
            return pool_buff;
        }


        ///查询出所有的数据
        public static List<Table_Pet_Buff> GetAllPrimaryList()
        {
            return all_Table_Pet_Buff_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("buff_id", out _currValue))
            {
                this.buff_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet_buff";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "buff_id":
                    return this.buff_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet_Buff> rows = _rows as List<Table_Pet_Buff>;
            pool_primary=TableContent.ListToPool < int, int, Table_Pet_Buff > ( rows, "map", "id", "buff_id" );
            pool_buff=TableContent.ListToPoolList < int, Table_Pet_Buff > ( rows, "list", "id" );
            all_Table_Pet_Buff_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_buff.Clear();
            all_Table_Pet_Buff_List.Clear();
        }
    }
}
