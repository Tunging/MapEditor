using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 公会捐献转换表
    ///</summary>
    [Serializable]
    [TableName("guild_donate_conversion")]
    public partial class Table_Guild_Donate_Conversion : TableContent
    {

        private static List<Table_Guild_Donate_Conversion> all_Table_Guild_Donate_Conversion_List = new List<Table_Guild_Donate_Conversion>();
        //primary | 主键
        public static Dictionary<int, Table_Guild_Donate_Conversion > pool_primary = new Dictionary<int, Table_Guild_Donate_Conversion > ();
        
        
        ///<summary>
        /// 主键=道具ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 转换公会活跃度
        ///</summary>
        public int liveness;
        
        
        ///<summary>
        /// 转换公会资金
        ///</summary>
        public int capital;
        
        
        ///<summary>
        /// 转换公会矿石
        ///</summary>
        public int mineral;
        
        
        ///<summary>
        /// 转换个人公会声望
        ///</summary>
        public int prestige;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键=道具ID</param>
        ///
        public static Table_Guild_Donate_Conversion GetPrimary ( int _id ){        
            Table_Guild_Donate_Conversion _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Guild_Donate_Conversion > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Guild_Donate_Conversion> GetAllPrimaryList()
        {
            return all_Table_Guild_Donate_Conversion_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("liveness", out _currValue))
            {
                this.liveness = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("capital", out _currValue))
            {
                this.capital = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("mineral", out _currValue))
            {
                this.mineral = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prestige", out _currValue))
            {
                this.prestige = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "guild_donate_conversion";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "type":
                    return this.type;
                case "liveness":
                    return this.liveness;
                case "capital":
                    return this.capital;
                case "mineral":
                    return this.mineral;
                case "prestige":
                    return this.prestige;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Guild_Donate_Conversion> rows = _rows as List<Table_Guild_Donate_Conversion>;
            pool_primary=TableContent.ListToPool < int, Table_Guild_Donate_Conversion > ( rows, "map", "id" );
            all_Table_Guild_Donate_Conversion_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Guild_Donate_Conversion_List.Clear();
        }
    }
}
