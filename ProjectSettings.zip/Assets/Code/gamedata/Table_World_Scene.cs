using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 世界场景
    ///</summary>
    [Serializable]
    [TableName("world_scene")]
    public partial class Table_World_Scene : TableContent
    {

        private static List<Table_World_Scene> all_Table_World_Scene_List = new List<Table_World_Scene>();
        //primary | 主键
        public static Dictionary<int, Table_World_Scene > pool_primary = new Dictionary<int, Table_World_Scene > ();
        
        
        ///<summary>
        /// 主键：场景ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 是否显示在世界地图中
        ///</summary>
        public bool show_in_world_map;
        
        
        ///<summary>
        /// 大世界场景x坐标
        ///</summary>
        public float big_scene_x;
        
        
        ///<summary>
        /// 大世界场景y坐标
        ///</summary>
        public float big_scene_y;
        
        
        ///<summary>
        /// 在世界地图上的显示资源ID
        ///</summary>
        public int big_map_res_id;
        
        
        ///<summary>
        /// 文字在世界地图上的x坐标
        ///</summary>
        public float name_x;
        
        
        ///<summary>
        /// 文字在世界地图上的y坐标
        ///</summary>
        public float name_y;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：场景ID</param>
        ///
        public static Table_World_Scene GetPrimary ( int _id ){        
            Table_World_Scene _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_World_Scene > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_World_Scene> GetAllPrimaryList()
        {
            return all_Table_World_Scene_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_in_world_map", out _currValue))
            {
                this.show_in_world_map = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("big_scene_x", out _currValue))
            {
                this.big_scene_x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("big_scene_y", out _currValue))
            {
                this.big_scene_y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("big_map_res_id", out _currValue))
            {
                this.big_map_res_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_x", out _currValue))
            {
                this.name_x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_y", out _currValue))
            {
                this.name_y = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "world_scene";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "show_in_world_map":
                    return this.show_in_world_map;
                case "big_scene_x":
                    return this.big_scene_x;
                case "big_scene_y":
                    return this.big_scene_y;
                case "big_map_res_id":
                    return this.big_map_res_id;
                case "name_x":
                    return this.name_x;
                case "name_y":
                    return this.name_y;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_World_Scene> rows = _rows as List<Table_World_Scene>;
            pool_primary=TableContent.ListToPool < int, Table_World_Scene > ( rows, "map", "id" );
            all_Table_World_Scene_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_World_Scene_List.Clear();
        }
    }
}
