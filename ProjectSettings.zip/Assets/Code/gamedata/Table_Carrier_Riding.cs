using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 载具骑乘
    ///</summary>
    [Serializable]
    [TableName("carrier_riding")]
    public partial class Table_Carrier_Riding : TableContent
    {

        private static List<Table_Carrier_Riding> all_Table_Carrier_Riding_List = new List<Table_Carrier_Riding>();
        //primary | 主键
        public static Dictionary<int, Table_Carrier_Riding > pool_primary = new Dictionary<int, Table_Carrier_Riding > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 默认动作
        ///</summary>
        public int default_action;
        
        
        ///<summary>
        /// 死亡动作
        ///</summary>
        public int death_action;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Carrier_Riding GetPrimary ( int _id ){        
            Table_Carrier_Riding _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Carrier_Riding > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Carrier_Riding> GetAllPrimaryList()
        {
            return all_Table_Carrier_Riding_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("default_action", out _currValue))
            {
                this.default_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("death_action", out _currValue))
            {
                this.death_action = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "carrier_riding";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "default_action":
                    return this.default_action;
                case "death_action":
                    return this.death_action;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Carrier_Riding> rows = _rows as List<Table_Carrier_Riding>;
            pool_primary=TableContent.ListToPool < int, Table_Carrier_Riding > ( rows, "map", "id" );
            all_Table_Carrier_Riding_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Carrier_Riding_List.Clear();
        }
    }
}
