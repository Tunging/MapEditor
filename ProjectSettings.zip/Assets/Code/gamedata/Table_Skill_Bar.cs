using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能栏配置
    ///</summary>
    [Serializable]
    [TableName("skill_bar")]
    public partial class Table_Skill_Bar : TableContent
    {

        private static List<Table_Skill_Bar> all_Table_Skill_Bar_List = new List<Table_Skill_Bar>();
        //primary | 主键
        public static Dictionary<int, Table_Skill_Bar > pool_primary = new Dictionary<int, Table_Skill_Bar > ();
        //role | 
        public static Dictionary<bool, List<Table_Skill_Bar> > pool_role = new Dictionary<bool, List<Table_Skill_Bar> > ();
        //taskId | 
        public static Dictionary<int, List<Table_Skill_Bar> > pool_taskId = new Dictionary<int, List<Table_Skill_Bar> > ();
        
        
        ///<summary>
        /// 主键：技能栏索引
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 是否是玩家技能
        ///</summary>
        public bool is_role;
        
        
        ///<summary>
        /// 解锁任务id
        ///</summary>
        public int unlock_task_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：技能栏索引</param>
        ///
        public static Table_Skill_Bar GetPrimary ( int _id ){        
            Table_Skill_Bar _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Skill_Bar > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param isRole> 是否是玩家技能</param>
        ///
        public static List<Table_Skill_Bar> GetRole ( bool _isRole ){        
            List<Table_Skill_Bar> _map0=null;        
            pool_role. TryGetValue(_isRole,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<bool, List<Table_Skill_Bar> > GetAllRole()
        {
            return pool_role;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockTaskId> 解锁任务id</param>
        ///
        public static List<Table_Skill_Bar> GetTaskId ( int _unlockTaskId ){        
            List<Table_Skill_Bar> _map0=null;        
            pool_taskId. TryGetValue(_unlockTaskId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Skill_Bar> > GetAllTaskId()
        {
            return pool_taskId;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Bar> GetAllPrimaryList()
        {
            return all_Table_Skill_Bar_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("is_role", out _currValue))
            {
                this.is_role = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_task_id", out _currValue))
            {
                this.unlock_task_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_bar";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                case "is_role":
                    return this.is_role;
                case "unlock_task_id":
                    return this.unlock_task_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Bar> rows = _rows as List<Table_Skill_Bar>;
            pool_primary=TableContent.ListToPool < int, Table_Skill_Bar > ( rows, "map", "id" );
            pool_role=TableContent.ListToPoolList < bool, Table_Skill_Bar > ( rows, "list", "is_role" );
            pool_taskId=TableContent.ListToPoolList < int, Table_Skill_Bar > ( rows, "list", "unlock_task_id" );
            all_Table_Skill_Bar_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_role.Clear();
            pool_taskId.Clear();
            all_Table_Skill_Bar_List.Clear();
        }
    }
}
