using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本配置
    ///</summary>
    [Serializable]
    [TableName("instance")]
    public partial class Table_Instance : TableContent
    {

        private static List<Table_Instance> all_Table_Instance_List = new List<Table_Instance>();
        //primary | 主键
        public static Dictionary<int, Table_Instance > pool_primary = new Dictionary<int, Table_Instance > ();
        
        
        ///<summary>
        /// 主键：位面ID=副本ID=场景ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 副本描述
        ///</summary>
        public string des;
        
        
        ///<summary>
        /// 副本模板ID
        ///</summary>
        public int template_id;
        
        
        ///<summary>
        /// 副本持续时间(ms)，-1代表一直持续
        ///</summary>
        public long duration;
        
        
        ///<summary>
        /// 所属的世界场景ID
        ///</summary>
        public int dimension_scene_id;
        
        
        ///<summary>
        /// 位面区域1（内）
        ///</summary>
        public string dimension_area1;
        
        
        ///<summary>
        /// 位面区域1（外）
        ///</summary>
        public string dimension_area2;
        
        
        ///<summary>
        /// 能否翻滚
        ///</summary>
        public bool is_roll;
        
        
        ///<summary>
        /// 能否跳跃
        ///</summary>
        public bool is_jump;
        
        
        ///<summary>
        /// 是不是提升同步频率（PVP副本使用）
        ///</summary>
        public bool is_high_sync;
        
        
        ///<summary>
        /// 场景音乐
        ///</summary>
        public int backgroup_video;
        
        
        ///<summary>
        /// 是否显示离开按钮
        ///</summary>
        public bool can_leave;
        
        
        ///<summary>
        /// 是否可以返回
        ///</summary>
        public bool can_return;
        
        
        ///<summary>
        /// 是否可以打开小地图
        ///</summary>
        public bool can_open_map;
        
        
        ///<summary>
        /// 是否显示边界特效
        ///</summary>
        public bool is_show_border;
        
        
        ///<summary>
        /// 是否显示切位面水波纹
        ///</summary>
        public bool is_show_water_wave;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：位面ID=副本ID=场景ID</param>
        ///
        public static Table_Instance GetPrimary ( int _id ){        
            Table_Instance _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Instance > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance> GetAllPrimaryList()
        {
            return all_Table_Instance_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("des", out _currValue))
            {
                this.des = _currValue;
            }
            if(_itemData.TryGetValue("template_id", out _currValue))
            {
                this.template_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("duration", out _currValue))
            {
                this.duration = Utils.GetLongFromString(_currValue);
            }
            if(_itemData.TryGetValue("dimension_scene_id", out _currValue))
            {
                this.dimension_scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dimension_area1", out _currValue))
            {
                this.dimension_area1 = _currValue;
            }
            if(_itemData.TryGetValue("dimension_area2", out _currValue))
            {
                this.dimension_area2 = _currValue;
            }
            if(_itemData.TryGetValue("is_roll", out _currValue))
            {
                this.is_roll = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_jump", out _currValue))
            {
                this.is_jump = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_high_sync", out _currValue))
            {
                this.is_high_sync = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("backgroup_video", out _currValue))
            {
                this.backgroup_video = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_leave", out _currValue))
            {
                this.can_leave = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_return", out _currValue))
            {
                this.can_return = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_open_map", out _currValue))
            {
                this.can_open_map = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_border", out _currValue))
            {
                this.is_show_border = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_water_wave", out _currValue))
            {
                this.is_show_water_wave = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "des":
                    return this.des;
                case "template_id":
                    return this.template_id;
                case "duration":
                    return this.duration;
                case "dimension_scene_id":
                    return this.dimension_scene_id;
                case "dimension_area1":
                    return this.dimension_area1;
                case "dimension_area2":
                    return this.dimension_area2;
                case "is_roll":
                    return this.is_roll;
                case "is_jump":
                    return this.is_jump;
                case "is_high_sync":
                    return this.is_high_sync;
                case "backgroup_video":
                    return this.backgroup_video;
                case "can_leave":
                    return this.can_leave;
                case "can_return":
                    return this.can_return;
                case "can_open_map":
                    return this.can_open_map;
                case "is_show_border":
                    return this.is_show_border;
                case "is_show_water_wave":
                    return this.is_show_water_wave;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance> rows = _rows as List<Table_Instance>;
            pool_primary=TableContent.ListToPool < int, Table_Instance > ( rows, "map", "id" );
            all_Table_Instance_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_List.Clear();
        }
    }
}
