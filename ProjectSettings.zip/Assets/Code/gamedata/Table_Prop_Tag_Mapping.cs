using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 属性标签对应的属性
    ///</summary>
    [Serializable]
    [TableName("prop_tag_mapping")]
    public partial class Table_Prop_Tag_Mapping : TableContent
    {

        private static List<Table_Prop_Tag_Mapping> all_Table_Prop_Tag_Mapping_List = new List<Table_Prop_Tag_Mapping>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Prop_Tag_Mapping > > pool_primary = new Dictionary<int, Dictionary<int, Table_Prop_Tag_Mapping > > ();
        
        
        ///<summary>
        /// 标签ID
        ///</summary>
        public int tag_id;
        
        
        ///<summary>
        /// 属性类型ID
        ///</summary>
        public int prop_id;
        
        
        ///<summary>
        /// 编辑时的默认值
        ///</summary>
        public int default_value;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param tagId> 标签ID</param>
        ///
        public static Dictionary<int, Table_Prop_Tag_Mapping > GetPrimary ( int _tagId ){        
            Dictionary<int, Table_Prop_Tag_Mapping > _map0=null;        
            pool_primary. TryGetValue(_tagId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param tagId> 标签ID</param>
        ///	<param propId> 属性类型ID</param>
        ///
        public static Table_Prop_Tag_Mapping GetPrimary ( int _tagId , int _propId ){        
            Dictionary<int, Table_Prop_Tag_Mapping > _map0=null;        
            pool_primary. TryGetValue(_tagId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Prop_Tag_Mapping _map1=null;        
            _map0. TryGetValue(_propId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Prop_Tag_Mapping > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Prop_Tag_Mapping> GetAllPrimaryList()
        {
            return all_Table_Prop_Tag_Mapping_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("tag_id", out _currValue))
            {
                this.tag_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prop_id", out _currValue))
            {
                this.prop_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("default_value", out _currValue))
            {
                this.default_value = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "prop_tag_mapping";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "tag_id":
                    return this.tag_id;
                case "prop_id":
                    return this.prop_id;
                case "default_value":
                    return this.default_value;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Prop_Tag_Mapping> rows = _rows as List<Table_Prop_Tag_Mapping>;
            pool_primary=TableContent.ListToPool < int, int, Table_Prop_Tag_Mapping > ( rows, "map", "tag_id", "prop_id" );
            all_Table_Prop_Tag_Mapping_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Prop_Tag_Mapping_List.Clear();
        }
    }
}
