using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc表演脚本
    ///</summary>
    [Serializable]
    [TableName("npc_script")]
    public partial class Table_Npc_Script : TableContent
    {

        private static List<Table_Npc_Script> all_Table_Npc_Script_List = new List<Table_Npc_Script>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Npc_Script > > pool_primary = new Dictionary<int, Dictionary<int, Table_Npc_Script > > ();
        
        
        ///<summary>
        /// 主键：脚本分组
        ///</summary>
        public int script_group;
        
        
        ///<summary>
        /// 主键：脚本编号
        ///</summary>
        public int script_num;
        
        
        ///<summary>
        /// 场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// npc的guid
        ///</summary>
        public int npc_guid;
        
        
        ///<summary>
        /// 等待时间(ms)
        ///</summary>
        public int wait_time;
        
        
        ///<summary>
        /// 表演时间
        ///</summary>
        public int show_time;
        
        
        ///<summary>
        /// 表演动作
        ///</summary>
        public int action;
        
        
        ///<summary>
        /// 说话内容，国际化
        ///</summary>
        public string talk_i18n;
        
        
        ///<summary>
        /// 说话的声音id
        ///</summary>
        public int sound_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param scriptGroup> 主键：脚本分组</param>
        ///
        public static Dictionary<int, Table_Npc_Script > GetPrimary ( int _scriptGroup ){        
            Dictionary<int, Table_Npc_Script > _map0=null;        
            pool_primary. TryGetValue(_scriptGroup,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param scriptGroup> 主键：脚本分组</param>
        ///	<param scriptNum> 主键：脚本编号</param>
        ///
        public static Table_Npc_Script GetPrimary ( int _scriptGroup , int _scriptNum ){        
            Dictionary<int, Table_Npc_Script > _map0=null;        
            pool_primary. TryGetValue(_scriptGroup,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Npc_Script _map1=null;        
            _map0. TryGetValue(_scriptNum,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Npc_Script > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Script> GetAllPrimaryList()
        {
            return all_Table_Npc_Script_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("script_group", out _currValue))
            {
                this.script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("script_num", out _currValue))
            {
                this.script_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_guid", out _currValue))
            {
                this.npc_guid = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wait_time", out _currValue))
            {
                this.wait_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_time", out _currValue))
            {
                this.show_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action", out _currValue))
            {
                this.action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talk_i18n", out _currValue))
            {
                this.talk_i18n = _currValue;
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_script";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "script_group":
                    return this.script_group;
                case "script_num":
                    return this.script_num;
                case "scene_id":
                    return this.scene_id;
                case "npc_guid":
                    return this.npc_guid;
                case "wait_time":
                    return this.wait_time;
                case "show_time":
                    return this.show_time;
                case "action":
                    return this.action;
                case "talk_i18n":
                    return this.talk_i18n;
                case "sound_id":
                    return this.sound_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Script> rows = _rows as List<Table_Npc_Script>;
            pool_primary=TableContent.ListToPool < int, int, Table_Npc_Script > ( rows, "map", "script_group", "script_num" );
            all_Table_Npc_Script_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Script_List.Clear();
        }
    }
}
