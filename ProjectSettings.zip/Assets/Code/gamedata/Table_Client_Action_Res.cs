using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：动作资源
    ///</summary>
    [Serializable]
    [TableName("client_action_res")]
    public partial class Table_Client_Action_Res : TableContent
    {

        private static List<Table_Client_Action_Res> all_Table_Client_Action_Res_List = new List<Table_Client_Action_Res>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Action_Res > pool_primary = new Dictionary<int, Table_Client_Action_Res > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 路径
        ///</summary>
        public string path;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Client_Action_Res GetPrimary ( int _id ){        
            Table_Client_Action_Res _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Action_Res > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Action_Res> GetAllPrimaryList()
        {
            return all_Table_Client_Action_Res_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_action_res";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "path":
                    return this.path;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Action_Res> rows = _rows as List<Table_Client_Action_Res>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Action_Res > ( rows, "map", "id" );
            all_Table_Client_Action_Res_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Action_Res_List.Clear();
        }
    }
}
