using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 道具品质
    ///</summary>
    [Serializable]
    [TableName("item_quality")]
    public partial class Table_Item_Quality : TableContent
    {

        private static List<Table_Item_Quality> all_Table_Item_Quality_List = new List<Table_Item_Quality>();
        //primary | 主键
        public static Dictionary<int, Table_Item_Quality > pool_primary = new Dictionary<int, Table_Item_Quality > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 方块品质图片icon
        ///</summary>
        public int block_icon;
        
        
        ///<summary>
        /// 名字颜色
        ///</summary>
        public string name_color;
        
        
        ///<summary>
        /// 提示颜色
        ///</summary>
        public string tip_color;
        
        
        ///<summary>
        /// 条形品质icon
        ///</summary>
        public int bat_icon;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Item_Quality GetPrimary ( int _id ){        
            Table_Item_Quality _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Item_Quality > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Item_Quality> GetAllPrimaryList()
        {
            return all_Table_Item_Quality_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("block_icon", out _currValue))
            {
                this.block_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_color", out _currValue))
            {
                this.name_color = _currValue;
            }
            if(_itemData.TryGetValue("tip_color", out _currValue))
            {
                this.tip_color = _currValue;
            }
            if(_itemData.TryGetValue("bat_icon", out _currValue))
            {
                this.bat_icon = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "item_quality";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "block_icon":
                    return this.block_icon;
                case "name_color":
                    return this.name_color;
                case "tip_color":
                    return this.tip_color;
                case "bat_icon":
                    return this.bat_icon;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Item_Quality> rows = _rows as List<Table_Item_Quality>;
            pool_primary=TableContent.ListToPool < int, Table_Item_Quality > ( rows, "map", "id" );
            all_Table_Item_Quality_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Item_Quality_List.Clear();
        }
    }
}
