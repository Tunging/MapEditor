using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 职业技能配置
    ///</summary>
    [Serializable]
    [TableName("profession_skill")]
    public partial class Table_Profession_Skill : TableContent
    {

        private static List<Table_Profession_Skill> all_Table_Profession_Skill_List = new List<Table_Profession_Skill>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Profession_Skill > > pool_primary = new Dictionary<int, Dictionary<int, Table_Profession_Skill > > ();
        
        
        ///<summary>
        /// 主键：职业ID
        ///</summary>
        public int profession_id;
        
        
        ///<summary>
        /// 主键：技能栏ID
        ///</summary>
        public int skill_bar_id;
        
        
        ///<summary>
        /// 技能1
        ///</summary>
        public int skill_group_id1;
        
        
        ///<summary>
        /// 技能1开放等级
        ///</summary>
        public int level1;
        
        
        ///<summary>
        /// 技能2
        ///</summary>
        public int skill_group_id2;
        
        
        ///<summary>
        /// 技能2开放等级
        ///</summary>
        public int level2;
        
        
        ///<summary>
        /// 技能3
        ///</summary>
        public int skill_group_id3;
        
        
        ///<summary>
        /// 技能3开放等级
        ///</summary>
        public int level3;
        
        
        ///<summary>
        /// 解锁引导id
        ///</summary>
        public int guide_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param professionId> 主键：职业ID</param>
        ///
        public static Dictionary<int, Table_Profession_Skill > GetPrimary ( int _professionId ){        
            Dictionary<int, Table_Profession_Skill > _map0=null;        
            pool_primary. TryGetValue(_professionId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param professionId> 主键：职业ID</param>
        ///	<param skillBarId> 主键：技能栏ID</param>
        ///
        public static Table_Profession_Skill GetPrimary ( int _professionId , int _skillBarId ){        
            Dictionary<int, Table_Profession_Skill > _map0=null;        
            pool_primary. TryGetValue(_professionId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Profession_Skill _map1=null;        
            _map0. TryGetValue(_skillBarId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Profession_Skill > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Profession_Skill> GetAllPrimaryList()
        {
            return all_Table_Profession_Skill_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("profession_id", out _currValue))
            {
                this.profession_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_bar_id", out _currValue))
            {
                this.skill_bar_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group_id1", out _currValue))
            {
                this.skill_group_id1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level1", out _currValue))
            {
                this.level1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group_id2", out _currValue))
            {
                this.skill_group_id2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level2", out _currValue))
            {
                this.level2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_group_id3", out _currValue))
            {
                this.skill_group_id3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level3", out _currValue))
            {
                this.level3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("guide_id", out _currValue))
            {
                this.guide_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "profession_skill";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "profession_id":
                    return this.profession_id;
                case "skill_bar_id":
                    return this.skill_bar_id;
                case "skill_group_id1":
                    return this.skill_group_id1;
                case "level1":
                    return this.level1;
                case "skill_group_id2":
                    return this.skill_group_id2;
                case "level2":
                    return this.level2;
                case "skill_group_id3":
                    return this.skill_group_id3;
                case "level3":
                    return this.level3;
                case "guide_id":
                    return this.guide_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Profession_Skill> rows = _rows as List<Table_Profession_Skill>;
            pool_primary=TableContent.ListToPool < int, int, Table_Profession_Skill > ( rows, "map", "profession_id", "skill_bar_id" );
            all_Table_Profession_Skill_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Profession_Skill_List.Clear();
        }
    }
}
