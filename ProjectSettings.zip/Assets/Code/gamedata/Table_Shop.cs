using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc商店
    ///</summary>
    [Serializable]
    [TableName("shop")]
    public partial class Table_Shop : TableContent
    {

        private static List<Table_Shop> all_Table_Shop_List = new List<Table_Shop>();
        //primary | 主键
        public static Dictionary<int, Table_Shop > pool_primary = new Dictionary<int, Table_Shop > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 刷新消耗的道具
        ///</summary>
        public int refresh_item_id;
        
        
        ///<summary>
        /// 刷新消耗道具数量
        ///</summary>
        public int refresh_item_num;
        
        
        ///<summary>
        /// 刷新间隔（毫秒）
        ///</summary>
        public int refresh_interval;
        
        
        ///<summary>
        /// 免费刷新次数上限
        ///</summary>
        public int refresh_count_limit;
        
        
        ///<summary>
        /// 商店每一个物品的购买次数
        ///</summary>
        public int buy_count_limit;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Table_Shop GetPrimary ( int _id ){        
            Table_Shop _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Shop > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Shop> GetAllPrimaryList()
        {
            return all_Table_Shop_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refresh_item_id", out _currValue))
            {
                this.refresh_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refresh_item_num", out _currValue))
            {
                this.refresh_item_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refresh_interval", out _currValue))
            {
                this.refresh_interval = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("refresh_count_limit", out _currValue))
            {
                this.refresh_count_limit = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("buy_count_limit", out _currValue))
            {
                this.buy_count_limit = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "shop";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "refresh_item_id":
                    return this.refresh_item_id;
                case "refresh_item_num":
                    return this.refresh_item_num;
                case "refresh_interval":
                    return this.refresh_interval;
                case "refresh_count_limit":
                    return this.refresh_count_limit;
                case "buy_count_limit":
                    return this.buy_count_limit;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Shop> rows = _rows as List<Table_Shop>;
            pool_primary=TableContent.ListToPool < int, Table_Shop > ( rows, "map", "id" );
            all_Table_Shop_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Shop_List.Clear();
        }
    }
}
