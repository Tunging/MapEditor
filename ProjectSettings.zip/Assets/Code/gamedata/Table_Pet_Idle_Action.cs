using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物休闲动作
    ///</summary>
    [Serializable]
    [TableName("pet_idle_action")]
    public partial class Table_Pet_Idle_Action : TableContent
    {

        private static List<Table_Pet_Idle_Action> all_Table_Pet_Idle_Action_List = new List<Table_Pet_Idle_Action>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Pet_Idle_Action > > pool_primary = new Dictionary<int, Dictionary<int, Table_Pet_Idle_Action > > ();
        
        
        ///<summary>
        /// 主键：ID  宠物id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 主键 : ID  动作id
        ///</summary>
        public int action_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID  宠物id</param>
        ///
        public static Dictionary<int, Table_Pet_Idle_Action > GetPrimary ( int _id ){        
            Dictionary<int, Table_Pet_Idle_Action > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID  宠物id</param>
        ///	<param actionId> 主键 : ID  动作id</param>
        ///
        public static Table_Pet_Idle_Action GetPrimary ( int _id , int _actionId ){        
            Dictionary<int, Table_Pet_Idle_Action > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Pet_Idle_Action _map1=null;        
            _map0. TryGetValue(_actionId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Pet_Idle_Action > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Pet_Idle_Action> GetAllPrimaryList()
        {
            return all_Table_Pet_Idle_Action_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet_idle_action";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "action_id":
                    return this.action_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet_Idle_Action> rows = _rows as List<Table_Pet_Idle_Action>;
            pool_primary=TableContent.ListToPool < int, int, Table_Pet_Idle_Action > ( rows, "map", "id", "action_id" );
            all_Table_Pet_Idle_Action_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Pet_Idle_Action_List.Clear();
        }
    }
}
