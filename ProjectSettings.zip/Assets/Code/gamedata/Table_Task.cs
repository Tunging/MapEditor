using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 任务表
    ///</summary>
    [Serializable]
    [TableName("task")]
    public partial class Table_Task : TableContent
    {

        private static List<Table_Task> all_Table_Task_List = new List<Table_Task>();
        //primary | 主键
        public static Dictionary<int, Table_Task > pool_primary = new Dictionary<int, Table_Task > ();
        //receiveNpc | 
        public static Dictionary<int, Dictionary<int, Table_Task > > pool_receiveNpc = new Dictionary<int, Dictionary<int, Table_Task > > ();
        //commitNpc | 
        public static Dictionary<int, Dictionary<int, Table_Task > > pool_commitNpc = new Dictionary<int, Dictionary<int, Table_Task > > ();
        //unlockWayRefreshNpc | 
        public static Dictionary<int, Dictionary<int, Table_Task > > pool_unlockWayRefreshNpc = new Dictionary<int, Dictionary<int, Table_Task > > ();
        //unlockWayGatheringNpc | 
        public static Dictionary<int, Dictionary<int, Table_Task > > pool_unlockWayGatheringNpc = new Dictionary<int, Dictionary<int, Table_Task > > ();
        //unlockWayEnterRegion | 
        public static Dictionary<int, Dictionary<int, Table_Task > > pool_unlockWayEnterRegion = new Dictionary<int, Dictionary<int, Table_Task > > ();
        
        
        ///<summary>
        /// 任务ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 任务类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 任务名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 任务描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 任务等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 任务领取场景
        ///</summary>
        public int receive_scene_id;
        
        
        ///<summary>
        /// 任务提交场景
        ///</summary>
        public int commit_scene_id;
        
        
        ///<summary>
        /// 显示场景
        ///</summary>
        public int show_scene;
        
        
        ///<summary>
        /// 离线是否计时
        ///</summary>
        public bool offline_timing;
        
        
        ///<summary>
        /// 可否放弃
        ///</summary>
        public bool give_up;
        
        
        ///<summary>
        /// 永久追踪
        ///</summary>
        public bool track_forever;
        
        
        ///<summary>
        /// 组队共享方式
        ///</summary>
        public int team_share_way;
        
        
        ///<summary>
        /// 任务领取指引
        ///</summary>
        public string receive_guidance;
        
        
        ///<summary>
        /// 任务领取指引国际化
        ///</summary>
        public string receive_guidance_i18n;
        
        
        ///<summary>
        /// 领取时触发新手引导
        ///</summary>
        public int receive_guide;
        
        
        ///<summary>
        /// 领取时触发剧情动画
        ///</summary>
        public int receive_plot_script_group;
        
        
        ///<summary>
        /// 领取时进入副本
        ///</summary>
        public int receive_enter_instance;
        
        
        ///<summary>
        /// 任务提交指引
        ///</summary>
        public string commit_guidance;
        
        
        ///<summary>
        /// 任务提交指引国际化
        ///</summary>
        public string commit_guidance_i18n;
        
        
        ///<summary>
        /// 提交时触发新手引导
        ///</summary>
        public int commit_guide;
        
        
        ///<summary>
        /// 提交时触发剧情动画
        ///</summary>
        public int commit_plot_script_group;
        
        
        ///<summary>
        /// 提交任务后进入副本
        ///</summary>
        public int commit_enter_instance;
        
        
        ///<summary>
        /// 解锁条件：角色等级
        ///</summary>
        public int unlock_condition_role_level;
        
        
        ///<summary>
        /// 解锁条件：种族
        ///</summary>
        public int unlock_condition_race;
        
        
        ///<summary>
        /// 解锁条件：职业
        ///</summary>
        public int unlock_condtion_profession;
        
        
        ///<summary>
        /// 解锁条件：完成前置任务（分号分隔）
        ///</summary>
        public string unlock_condition_complete_task;
        
        
        ///<summary>
        /// 解锁条件：前置任务逻辑(true:与，false:或)
        ///</summary>
        public bool unlock_condition_pretask_logic;
        
        
        ///<summary>
        /// 解锁条件：导师ID
        ///</summary>
        public int unlock_condtion_mentor_id;
        
        
        ///<summary>
        /// 解锁条件：导师好感度等级
        ///</summary>
        public int unlock_condtion_mentor_preference_level;
        
        
        ///<summary>
        /// 解锁方式：副本中刷出NPC
        ///</summary>
        public int unlock_way_refresh_npc;
        
        
        ///<summary>
        /// 解锁方式：采集NPC
        ///</summary>
        public int unlock_way_gathering_npc;
        
        
        ///<summary>
        /// 解锁方式：进入区域
        ///</summary>
        public int unlock_way_enter_region;
        
        
        ///<summary>
        /// 领取条件：角色等级
        ///</summary>
        public int receive_condtion_role_level;
        
        
        ///<summary>
        /// 领取条件：开始时间
        ///</summary>
        public string receive_condtion_start_time;
        
        
        ///<summary>
        /// 领取条件：结束时间
        ///</summary>
        public string receive_condtion_end_time;
        
        
        ///<summary>
        /// 领取条件：当前职业
        ///</summary>
        public int receive_condtion_profession;
        
        
        ///<summary>
        /// 领取条件：导师ID
        ///</summary>
        public int receive_condtion_mentor_id;
        
        
        ///<summary>
        /// 领取条件：导师好感度等级
        ///</summary>
        public int receive_condtion_mentor_preference_level;
        
        
        ///<summary>
        /// 领取条件：需要道具(id*num;id*num)
        ///</summary>
        public string receive_condtion_need_items;
        
        
        ///<summary>
        /// 领取条件：是否消耗道具
        ///</summary>
        public bool receive_condtion_consume_item;
        
        
        ///<summary>
        /// 领取条件：组队状态
        ///</summary>
        public bool receive_condtion_team_state;
        
        
        ///<summary>
        /// 领取条件：队长领取
        ///</summary>
        public bool receive_condtion_team_leader;
        
        
        ///<summary>
        /// 领取条件：队伍人数
        ///</summary>
        public int receive_condtion_team_role_num;
        
        
        ///<summary>
        /// 领取方式：采集NPC
        ///</summary>
        public int receive_way_gathering_npc;
        
        
        ///<summary>
        /// 领取方式：对话NPC
        ///</summary>
        public int receive_way_dialog_npc;
        
        
        ///<summary>
        /// 提交方式：对话NPC
        ///</summary>
        public int commit_way_dialog_npc;
        
        
        ///<summary>
        /// 提交条件：队长提交
        ///</summary>
        public bool commit_way_team_leader;
        
        
        ///<summary>
        /// 提交后是否可以重复解锁
        ///</summary>
        public bool commit_repeat_unlock;
        
        
        ///<summary>
        /// 成功奖励：经验
        ///</summary>
        public int success_reward_exp;
        
        
        ///<summary>
        /// 成功奖励：专精经验
        ///</summary>
        public int success_reward_mastery_value;
        
        
        ///<summary>
        /// 成功奖励：金币
        ///</summary>
        public int success_reward_coin;
        
        
        ///<summary>
        /// 成功奖励：钻石
        ///</summary>
        public int success_reward_diamond;
        
        
        ///<summary>
        /// 成功奖励：必给道具（id*num;id*num）
        ///</summary>
        public string success_reward_fixed_items;
        
        
        ///<summary>
        /// 成功奖励：可选道具（id*num;id*num）
        ///</summary>
        public string success_reward_optional_items;
        
        
        ///<summary>
        /// 成功奖励：导师好感度
        ///</summary>
        public int success_reward_mentor_preference;
        
        
        ///<summary>
        /// 好感度奖励导师ID（0：职业对应导师）
        ///</summary>
        public int reward_mentor_id;
        
        
        ///<summary>
        /// 成功奖励：升华天赋点
        ///</summary>
        public int success_reward_talent_hight_point;
        
        
        ///<summary>
        /// 成功奖励：宠物ID
        ///</summary>
        public int success_reward_pet_id;
        
        
        ///<summary>
        /// 失败条件：限制时间(s)
        ///</summary>
        public int failure_condtion_limit_time;
        
        
        ///<summary>
        /// 失败条件：离开副本（ID）
        ///</summary>
        public int failure_condtion_leave_instance_id;
        
        
        ///<summary>
        /// 完成任务进度后离开副本是否失败
        ///</summary>
        public bool leave_instance_fail_on_finished;
        
        
        ///<summary>
        /// 提交任务退出载具状态
        ///</summary>
        public bool commit_exit_carrier;
        
        
        ///<summary>
        /// 领取时触发npc表演脚本id组
        ///</summary>
        public int receive_script_group;
        
        
        ///<summary>
        /// 提交时触发npc表演脚本id组
        ///</summary>
        public int finish_script_group;
        
        
        ///<summary>
        /// 任务对话时是否展示模型
        ///</summary>
        public bool is_show_talk_model;
        
        
        ///<summary>
        /// 提交时召唤镜像npc
        ///</summary>
        public int commit_call_mirror_npc_id;
        
        
        ///<summary>
        /// 提交时销毁镜像npc
        ///</summary>
        public bool commit_destory_mirror_npc_id;
        
        
        ///<summary>
        /// 接受时召唤镜像npc
        ///</summary>
        public int receive_call_mirror_npc_id;
        
        
        ///<summary>
        /// 接受时销毁镜像npc
        ///</summary>
        public bool receive_destory_mirror_npc_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 任务ID</param>
        ///
        public static Table_Task GetPrimary ( int _id ){        
            Table_Task _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Task > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param receiveWayDialogNpc> 领取方式：对话NPC</param>
        ///
        public static Dictionary<int, Table_Task > GetReceiveNpc ( int _receiveWayDialogNpc ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_receiveNpc. TryGetValue(_receiveWayDialogNpc,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param receiveWayDialogNpc> 领取方式：对话NPC</param>
        ///	<param id> 任务ID</param>
        ///
        public static Table_Task GetReceiveNpc ( int _receiveWayDialogNpc , int _id ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_receiveNpc. TryGetValue(_receiveWayDialogNpc,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task > > GetAllReceiveNpc()
        {
            return pool_receiveNpc;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param commitWayDialogNpc> 提交方式：对话NPC</param>
        ///
        public static Dictionary<int, Table_Task > GetCommitNpc ( int _commitWayDialogNpc ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_commitNpc. TryGetValue(_commitWayDialogNpc,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param commitWayDialogNpc> 提交方式：对话NPC</param>
        ///	<param id> 任务ID</param>
        ///
        public static Table_Task GetCommitNpc ( int _commitWayDialogNpc , int _id ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_commitNpc. TryGetValue(_commitWayDialogNpc,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task > > GetAllCommitNpc()
        {
            return pool_commitNpc;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockWayRefreshNpc> 解锁方式：副本中刷出NPC</param>
        ///
        public static Dictionary<int, Table_Task > GetUnlockWayRefreshNpc ( int _unlockWayRefreshNpc ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_unlockWayRefreshNpc. TryGetValue(_unlockWayRefreshNpc,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockWayRefreshNpc> 解锁方式：副本中刷出NPC</param>
        ///	<param id> 任务ID</param>
        ///
        public static Table_Task GetUnlockWayRefreshNpc ( int _unlockWayRefreshNpc , int _id ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_unlockWayRefreshNpc. TryGetValue(_unlockWayRefreshNpc,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task > > GetAllUnlockWayRefreshNpc()
        {
            return pool_unlockWayRefreshNpc;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockWayGatheringNpc> 解锁方式：采集NPC</param>
        ///
        public static Dictionary<int, Table_Task > GetUnlockWayGatheringNpc ( int _unlockWayGatheringNpc ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_unlockWayGatheringNpc. TryGetValue(_unlockWayGatheringNpc,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockWayGatheringNpc> 解锁方式：采集NPC</param>
        ///	<param id> 任务ID</param>
        ///
        public static Table_Task GetUnlockWayGatheringNpc ( int _unlockWayGatheringNpc , int _id ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_unlockWayGatheringNpc. TryGetValue(_unlockWayGatheringNpc,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task > > GetAllUnlockWayGatheringNpc()
        {
            return pool_unlockWayGatheringNpc;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockWayEnterRegion> 解锁方式：进入区域</param>
        ///
        public static Dictionary<int, Table_Task > GetUnlockWayEnterRegion ( int _unlockWayEnterRegion ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_unlockWayEnterRegion. TryGetValue(_unlockWayEnterRegion,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param unlockWayEnterRegion> 解锁方式：进入区域</param>
        ///	<param id> 任务ID</param>
        ///
        public static Table_Task GetUnlockWayEnterRegion ( int _unlockWayEnterRegion , int _id ){        
            Dictionary<int, Table_Task > _map0=null;        
            pool_unlockWayEnterRegion. TryGetValue(_unlockWayEnterRegion,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task > > GetAllUnlockWayEnterRegion()
        {
            return pool_unlockWayEnterRegion;
        }


        ///查询出所有的数据
        public static List<Table_Task> GetAllPrimaryList()
        {
            return all_Table_Task_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_scene_id", out _currValue))
            {
                this.receive_scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_scene_id", out _currValue))
            {
                this.commit_scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_scene", out _currValue))
            {
                this.show_scene = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("offline_timing", out _currValue))
            {
                this.offline_timing = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("give_up", out _currValue))
            {
                this.give_up = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("track_forever", out _currValue))
            {
                this.track_forever = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("team_share_way", out _currValue))
            {
                this.team_share_way = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_guidance", out _currValue))
            {
                this.receive_guidance = _currValue;
            }
            if(_itemData.TryGetValue("receive_guidance_i18n", out _currValue))
            {
                this.receive_guidance_i18n = _currValue;
            }
            if(_itemData.TryGetValue("receive_guide", out _currValue))
            {
                this.receive_guide = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_plot_script_group", out _currValue))
            {
                this.receive_plot_script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_enter_instance", out _currValue))
            {
                this.receive_enter_instance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_guidance", out _currValue))
            {
                this.commit_guidance = _currValue;
            }
            if(_itemData.TryGetValue("commit_guidance_i18n", out _currValue))
            {
                this.commit_guidance_i18n = _currValue;
            }
            if(_itemData.TryGetValue("commit_guide", out _currValue))
            {
                this.commit_guide = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_plot_script_group", out _currValue))
            {
                this.commit_plot_script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_enter_instance", out _currValue))
            {
                this.commit_enter_instance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_condition_role_level", out _currValue))
            {
                this.unlock_condition_role_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_condition_race", out _currValue))
            {
                this.unlock_condition_race = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_condtion_profession", out _currValue))
            {
                this.unlock_condtion_profession = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_condition_complete_task", out _currValue))
            {
                this.unlock_condition_complete_task = _currValue;
            }
            if(_itemData.TryGetValue("unlock_condition_pretask_logic", out _currValue))
            {
                this.unlock_condition_pretask_logic = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_condtion_mentor_id", out _currValue))
            {
                this.unlock_condtion_mentor_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_condtion_mentor_preference_level", out _currValue))
            {
                this.unlock_condtion_mentor_preference_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_way_refresh_npc", out _currValue))
            {
                this.unlock_way_refresh_npc = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_way_gathering_npc", out _currValue))
            {
                this.unlock_way_gathering_npc = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unlock_way_enter_region", out _currValue))
            {
                this.unlock_way_enter_region = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_role_level", out _currValue))
            {
                this.receive_condtion_role_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_start_time", out _currValue))
            {
                this.receive_condtion_start_time = _currValue;
            }
            if(_itemData.TryGetValue("receive_condtion_end_time", out _currValue))
            {
                this.receive_condtion_end_time = _currValue;
            }
            if(_itemData.TryGetValue("receive_condtion_profession", out _currValue))
            {
                this.receive_condtion_profession = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_mentor_id", out _currValue))
            {
                this.receive_condtion_mentor_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_mentor_preference_level", out _currValue))
            {
                this.receive_condtion_mentor_preference_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_need_items", out _currValue))
            {
                this.receive_condtion_need_items = _currValue;
            }
            if(_itemData.TryGetValue("receive_condtion_consume_item", out _currValue))
            {
                this.receive_condtion_consume_item = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_team_state", out _currValue))
            {
                this.receive_condtion_team_state = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_team_leader", out _currValue))
            {
                this.receive_condtion_team_leader = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_condtion_team_role_num", out _currValue))
            {
                this.receive_condtion_team_role_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_way_gathering_npc", out _currValue))
            {
                this.receive_way_gathering_npc = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_way_dialog_npc", out _currValue))
            {
                this.receive_way_dialog_npc = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_way_dialog_npc", out _currValue))
            {
                this.commit_way_dialog_npc = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_way_team_leader", out _currValue))
            {
                this.commit_way_team_leader = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_repeat_unlock", out _currValue))
            {
                this.commit_repeat_unlock = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_exp", out _currValue))
            {
                this.success_reward_exp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_mastery_value", out _currValue))
            {
                this.success_reward_mastery_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_coin", out _currValue))
            {
                this.success_reward_coin = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_diamond", out _currValue))
            {
                this.success_reward_diamond = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_fixed_items", out _currValue))
            {
                this.success_reward_fixed_items = _currValue;
            }
            if(_itemData.TryGetValue("success_reward_optional_items", out _currValue))
            {
                this.success_reward_optional_items = _currValue;
            }
            if(_itemData.TryGetValue("success_reward_mentor_preference", out _currValue))
            {
                this.success_reward_mentor_preference = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward_mentor_id", out _currValue))
            {
                this.reward_mentor_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_talent_hight_point", out _currValue))
            {
                this.success_reward_talent_hight_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("success_reward_pet_id", out _currValue))
            {
                this.success_reward_pet_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("failure_condtion_limit_time", out _currValue))
            {
                this.failure_condtion_limit_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("failure_condtion_leave_instance_id", out _currValue))
            {
                this.failure_condtion_leave_instance_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("leave_instance_fail_on_finished", out _currValue))
            {
                this.leave_instance_fail_on_finished = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_exit_carrier", out _currValue))
            {
                this.commit_exit_carrier = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_script_group", out _currValue))
            {
                this.receive_script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("finish_script_group", out _currValue))
            {
                this.finish_script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_show_talk_model", out _currValue))
            {
                this.is_show_talk_model = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_call_mirror_npc_id", out _currValue))
            {
                this.commit_call_mirror_npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("commit_destory_mirror_npc_id", out _currValue))
            {
                this.commit_destory_mirror_npc_id = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_call_mirror_npc_id", out _currValue))
            {
                this.receive_call_mirror_npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("receive_destory_mirror_npc_id", out _currValue))
            {
                this.receive_destory_mirror_npc_id = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "task";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "type":
                    return this.type;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "description":
                    return this.description;
                case "description_i18n":
                    return this.description_i18n;
                case "level":
                    return this.level;
                case "receive_scene_id":
                    return this.receive_scene_id;
                case "commit_scene_id":
                    return this.commit_scene_id;
                case "show_scene":
                    return this.show_scene;
                case "offline_timing":
                    return this.offline_timing;
                case "give_up":
                    return this.give_up;
                case "track_forever":
                    return this.track_forever;
                case "team_share_way":
                    return this.team_share_way;
                case "receive_guidance":
                    return this.receive_guidance;
                case "receive_guidance_i18n":
                    return this.receive_guidance_i18n;
                case "receive_guide":
                    return this.receive_guide;
                case "receive_plot_script_group":
                    return this.receive_plot_script_group;
                case "receive_enter_instance":
                    return this.receive_enter_instance;
                case "commit_guidance":
                    return this.commit_guidance;
                case "commit_guidance_i18n":
                    return this.commit_guidance_i18n;
                case "commit_guide":
                    return this.commit_guide;
                case "commit_plot_script_group":
                    return this.commit_plot_script_group;
                case "commit_enter_instance":
                    return this.commit_enter_instance;
                case "unlock_condition_role_level":
                    return this.unlock_condition_role_level;
                case "unlock_condition_race":
                    return this.unlock_condition_race;
                case "unlock_condtion_profession":
                    return this.unlock_condtion_profession;
                case "unlock_condition_complete_task":
                    return this.unlock_condition_complete_task;
                case "unlock_condition_pretask_logic":
                    return this.unlock_condition_pretask_logic;
                case "unlock_condtion_mentor_id":
                    return this.unlock_condtion_mentor_id;
                case "unlock_condtion_mentor_preference_level":
                    return this.unlock_condtion_mentor_preference_level;
                case "unlock_way_refresh_npc":
                    return this.unlock_way_refresh_npc;
                case "unlock_way_gathering_npc":
                    return this.unlock_way_gathering_npc;
                case "unlock_way_enter_region":
                    return this.unlock_way_enter_region;
                case "receive_condtion_role_level":
                    return this.receive_condtion_role_level;
                case "receive_condtion_start_time":
                    return this.receive_condtion_start_time;
                case "receive_condtion_end_time":
                    return this.receive_condtion_end_time;
                case "receive_condtion_profession":
                    return this.receive_condtion_profession;
                case "receive_condtion_mentor_id":
                    return this.receive_condtion_mentor_id;
                case "receive_condtion_mentor_preference_level":
                    return this.receive_condtion_mentor_preference_level;
                case "receive_condtion_need_items":
                    return this.receive_condtion_need_items;
                case "receive_condtion_consume_item":
                    return this.receive_condtion_consume_item;
                case "receive_condtion_team_state":
                    return this.receive_condtion_team_state;
                case "receive_condtion_team_leader":
                    return this.receive_condtion_team_leader;
                case "receive_condtion_team_role_num":
                    return this.receive_condtion_team_role_num;
                case "receive_way_gathering_npc":
                    return this.receive_way_gathering_npc;
                case "receive_way_dialog_npc":
                    return this.receive_way_dialog_npc;
                case "commit_way_dialog_npc":
                    return this.commit_way_dialog_npc;
                case "commit_way_team_leader":
                    return this.commit_way_team_leader;
                case "commit_repeat_unlock":
                    return this.commit_repeat_unlock;
                case "success_reward_exp":
                    return this.success_reward_exp;
                case "success_reward_mastery_value":
                    return this.success_reward_mastery_value;
                case "success_reward_coin":
                    return this.success_reward_coin;
                case "success_reward_diamond":
                    return this.success_reward_diamond;
                case "success_reward_fixed_items":
                    return this.success_reward_fixed_items;
                case "success_reward_optional_items":
                    return this.success_reward_optional_items;
                case "success_reward_mentor_preference":
                    return this.success_reward_mentor_preference;
                case "reward_mentor_id":
                    return this.reward_mentor_id;
                case "success_reward_talent_hight_point":
                    return this.success_reward_talent_hight_point;
                case "success_reward_pet_id":
                    return this.success_reward_pet_id;
                case "failure_condtion_limit_time":
                    return this.failure_condtion_limit_time;
                case "failure_condtion_leave_instance_id":
                    return this.failure_condtion_leave_instance_id;
                case "leave_instance_fail_on_finished":
                    return this.leave_instance_fail_on_finished;
                case "commit_exit_carrier":
                    return this.commit_exit_carrier;
                case "receive_script_group":
                    return this.receive_script_group;
                case "finish_script_group":
                    return this.finish_script_group;
                case "is_show_talk_model":
                    return this.is_show_talk_model;
                case "commit_call_mirror_npc_id":
                    return this.commit_call_mirror_npc_id;
                case "commit_destory_mirror_npc_id":
                    return this.commit_destory_mirror_npc_id;
                case "receive_call_mirror_npc_id":
                    return this.receive_call_mirror_npc_id;
                case "receive_destory_mirror_npc_id":
                    return this.receive_destory_mirror_npc_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Task> rows = _rows as List<Table_Task>;
            pool_primary=TableContent.ListToPool < int, Table_Task > ( rows, "map", "id" );
            pool_receiveNpc=TableContent.ListToPool < int, int, Table_Task > ( rows, "map", "receive_way_dialog_npc", "id" );
            pool_commitNpc=TableContent.ListToPool < int, int, Table_Task > ( rows, "map", "commit_way_dialog_npc", "id" );
            pool_unlockWayRefreshNpc=TableContent.ListToPool < int, int, Table_Task > ( rows, "map", "unlock_way_refresh_npc", "id" );
            pool_unlockWayGatheringNpc=TableContent.ListToPool < int, int, Table_Task > ( rows, "map", "unlock_way_gathering_npc", "id" );
            pool_unlockWayEnterRegion=TableContent.ListToPool < int, int, Table_Task > ( rows, "map", "unlock_way_enter_region", "id" );
            all_Table_Task_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_receiveNpc.Clear();
            pool_commitNpc.Clear();
            pool_unlockWayRefreshNpc.Clear();
            pool_unlockWayGatheringNpc.Clear();
            pool_unlockWayEnterRegion.Clear();
            all_Table_Task_List.Clear();
        }
    }
}
