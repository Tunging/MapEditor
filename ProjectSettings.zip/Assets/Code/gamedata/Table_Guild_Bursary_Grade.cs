using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 公会金库等级表
    ///</summary>
    [Serializable]
    [TableName("guild_bursary_grade")]
    public partial class Table_Guild_Bursary_Grade : TableContent
    {

        private static List<Table_Guild_Bursary_Grade> all_Table_Guild_Bursary_Grade_List = new List<Table_Guild_Bursary_Grade>();
        //primary | 主键
        public static Dictionary<int, Table_Guild_Bursary_Grade > pool_primary = new Dictionary<int, Table_Guild_Bursary_Grade > ();
        
        
        ///<summary>
        /// 主键：金库等级
        ///</summary>
        public int grade;
        
        
        ///<summary>
        /// 容量上限
        ///</summary>
        public int capacity_max;
        
        
        ///<summary>
        /// 升级条件(分号分隔)
        ///</summary>
        public string upgrade_conditions;
        
        
        ///<summary>
        /// 金库升级时npc模板
        ///</summary>
        public int npc_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param grade> 主键：金库等级</param>
        ///
        public static Table_Guild_Bursary_Grade GetPrimary ( int _grade ){        
            Table_Guild_Bursary_Grade _map0=null;        
            pool_primary. TryGetValue(_grade,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Guild_Bursary_Grade > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Guild_Bursary_Grade> GetAllPrimaryList()
        {
            return all_Table_Guild_Bursary_Grade_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("grade", out _currValue))
            {
                this.grade = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("capacity_max", out _currValue))
            {
                this.capacity_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("upgrade_conditions", out _currValue))
            {
                this.upgrade_conditions = _currValue;
            }
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "guild_bursary_grade";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "grade":
                    return this.grade;
                case "capacity_max":
                    return this.capacity_max;
                case "upgrade_conditions":
                    return this.upgrade_conditions;
                case "npc_id":
                    return this.npc_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Guild_Bursary_Grade> rows = _rows as List<Table_Guild_Bursary_Grade>;
            pool_primary=TableContent.ListToPool < int, Table_Guild_Bursary_Grade > ( rows, "map", "grade" );
            all_Table_Guild_Bursary_Grade_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Guild_Bursary_Grade_List.Clear();
        }
    }
}
