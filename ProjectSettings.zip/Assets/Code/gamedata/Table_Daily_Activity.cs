using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 日常活动
    ///</summary>
    [Serializable]
    [TableName("daily_activity")]
    public partial class Table_Daily_Activity : TableContent
    {

        private static List<Table_Daily_Activity> all_Table_Daily_Activity_List = new List<Table_Daily_Activity>();
        //primary | 主键
        public static Dictionary<int, Table_Daily_Activity > pool_primary = new Dictionary<int, Table_Daily_Activity > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 活动名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 活动类型（逗号分隔）
        ///</summary>
        public string type;
        
        
        ///<summary>
        /// 前往参数
        ///</summary>
        public string goto_param;
        
        
        ///<summary>
        /// 目标总进度
        ///</summary>
        public int total_progress;
        
        
        ///<summary>
        /// 是否显示进度
        ///</summary>
        public bool show_progress;
        
        
        ///<summary>
        /// 单次增加活跃度
        ///</summary>
        public int activeness;
        
        
        ///<summary>
        /// 等级限制下限
        ///</summary>
        public int level_min;
        
        
        ///<summary>
        /// 等级限制上限
        ///</summary>
        public int level_max;
        
        
        ///<summary>
        /// 开始时间
        ///</summary>
        public string start_time;
        
        
        ///<summary>
        /// 结束时间
        ///</summary>
        public string end_time;
        
        
        ///<summary>
        /// 排序索引
        ///</summary>
        public int sort_index;
        
        
        ///<summary>
        /// 活动描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 活动图标
        ///</summary>
        public int icon;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Daily_Activity GetPrimary ( int _id ){        
            Table_Daily_Activity _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Daily_Activity > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Daily_Activity> GetAllPrimaryList()
        {
            return all_Table_Daily_Activity_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = _currValue;
            }
            if(_itemData.TryGetValue("goto_param", out _currValue))
            {
                this.goto_param = _currValue;
            }
            if(_itemData.TryGetValue("total_progress", out _currValue))
            {
                this.total_progress = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_progress", out _currValue))
            {
                this.show_progress = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("activeness", out _currValue))
            {
                this.activeness = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level_min", out _currValue))
            {
                this.level_min = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level_max", out _currValue))
            {
                this.level_max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("start_time", out _currValue))
            {
                this.start_time = _currValue;
            }
            if(_itemData.TryGetValue("end_time", out _currValue))
            {
                this.end_time = _currValue;
            }
            if(_itemData.TryGetValue("sort_index", out _currValue))
            {
                this.sort_index = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "daily_activity";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "type":
                    return this.type;
                case "goto_param":
                    return this.goto_param;
                case "total_progress":
                    return this.total_progress;
                case "show_progress":
                    return this.show_progress;
                case "activeness":
                    return this.activeness;
                case "level_min":
                    return this.level_min;
                case "level_max":
                    return this.level_max;
                case "start_time":
                    return this.start_time;
                case "end_time":
                    return this.end_time;
                case "sort_index":
                    return this.sort_index;
                case "description_i18n":
                    return this.description_i18n;
                case "icon":
                    return this.icon;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Daily_Activity> rows = _rows as List<Table_Daily_Activity>;
            pool_primary=TableContent.ListToPool < int, Table_Daily_Activity > ( rows, "map", "id" );
            all_Table_Daily_Activity_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Daily_Activity_List.Clear();
        }
    }
}
