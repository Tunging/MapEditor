using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 蘑菇人等级
    ///</summary>
    [Serializable]
    [TableName("mushroom_level")]
    public partial class Table_Mushroom_Level : TableContent
    {

        private static List<Table_Mushroom_Level> all_Table_Mushroom_Level_List = new List<Table_Mushroom_Level>();
        //primary | 主键
        public static Dictionary<int, Table_Mushroom_Level > pool_primary = new Dictionary<int, Table_Mushroom_Level > ();
        
        
        ///<summary>
        /// 主键：等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 升级需要经验
        ///</summary>
        public int experience;
        
        
        ///<summary>
        /// 变身后模型ID
        ///</summary>
        public int transfer_model_id;
        
        
        ///<summary>
        /// 升级提示文字
        ///</summary>
        public string prompt_text;
        
        
        ///<summary>
        /// 称号文本
        ///</summary>
        public string honor_text;
        
        
        ///<summary>
        /// 是否弹出结算面板
        ///</summary>
        public bool popup_panel;
        
        
        ///<summary>
        /// 特效ID
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 给机器人添加的技能1
        ///</summary>
        public int npc_skill1;
        
        
        ///<summary>
        /// 给机器人添加的技能2
        ///</summary>
        public int npc_skill2;
        
        
        ///<summary>
        /// 给玩家添加的技能组1
        ///</summary>
        public int role_skill_group1;
        
        
        ///<summary>
        /// 给玩家添加的技能组2
        ///</summary>
        public int role_skill_group2;
        
        
        ///<summary>
        /// 等级图标id
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 变大buff
        ///</summary>
        public int zoom_buff;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param level> 主键：等级</param>
        ///
        public static Table_Mushroom_Level GetPrimary ( int _level ){        
            Table_Mushroom_Level _map0=null;        
            pool_primary. TryGetValue(_level,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mushroom_Level > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mushroom_Level> GetAllPrimaryList()
        {
            return all_Table_Mushroom_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("experience", out _currValue))
            {
                this.experience = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("transfer_model_id", out _currValue))
            {
                this.transfer_model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prompt_text", out _currValue))
            {
                this.prompt_text = _currValue;
            }
            if(_itemData.TryGetValue("honor_text", out _currValue))
            {
                this.honor_text = _currValue;
            }
            if(_itemData.TryGetValue("popup_panel", out _currValue))
            {
                this.popup_panel = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_skill1", out _currValue))
            {
                this.npc_skill1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_skill2", out _currValue))
            {
                this.npc_skill2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_skill_group1", out _currValue))
            {
                this.role_skill_group1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_skill_group2", out _currValue))
            {
                this.role_skill_group2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("zoom_buff", out _currValue))
            {
                this.zoom_buff = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mushroom_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "level":
                    return this.level;
                case "experience":
                    return this.experience;
                case "transfer_model_id":
                    return this.transfer_model_id;
                case "prompt_text":
                    return this.prompt_text;
                case "honor_text":
                    return this.honor_text;
                case "popup_panel":
                    return this.popup_panel;
                case "effect_id":
                    return this.effect_id;
                case "npc_skill1":
                    return this.npc_skill1;
                case "npc_skill2":
                    return this.npc_skill2;
                case "role_skill_group1":
                    return this.role_skill_group1;
                case "role_skill_group2":
                    return this.role_skill_group2;
                case "icon_id":
                    return this.icon_id;
                case "zoom_buff":
                    return this.zoom_buff;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mushroom_Level> rows = _rows as List<Table_Mushroom_Level>;
            pool_primary=TableContent.ListToPool < int, Table_Mushroom_Level > ( rows, "map", "level" );
            all_Table_Mushroom_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mushroom_Level_List.Clear();
        }
    }
}
