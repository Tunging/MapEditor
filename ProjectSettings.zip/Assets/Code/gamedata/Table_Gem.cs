using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宝石
    ///</summary>
    [Serializable]
    [TableName("gem")]
    public partial class Table_Gem : TableContent
    {

        private static List<Table_Gem> all_Table_Gem_List = new List<Table_Gem>();
        //primary | 主键
        public static Dictionary<int, Table_Gem > pool_primary = new Dictionary<int, Table_Gem > ();
        
        
        ///<summary>
        /// 宝石ID:道具ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 魔力消耗倍率
        ///</summary>
        public int mp_cost_rate;
        
        
        ///<summary>
        /// 宝石大分类
        ///</summary>
        public int gem_class;
        
        
        ///<summary>
        /// 宝石子类型
        ///</summary>
        public int gem_subclass;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 宝石ID:道具ID</param>
        ///
        public static Table_Gem GetPrimary ( int _id ){        
            Table_Gem _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Gem > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Gem> GetAllPrimaryList()
        {
            return all_Table_Gem_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("mp_cost_rate", out _currValue))
            {
                this.mp_cost_rate = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gem_class", out _currValue))
            {
                this.gem_class = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gem_subclass", out _currValue))
            {
                this.gem_subclass = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "gem";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "mp_cost_rate":
                    return this.mp_cost_rate;
                case "gem_class":
                    return this.gem_class;
                case "gem_subclass":
                    return this.gem_subclass;
                case "remark":
                    return this.remark;
                case "description_i18n":
                    return this.description_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Gem> rows = _rows as List<Table_Gem>;
            pool_primary=TableContent.ListToPool < int, Table_Gem > ( rows, "map", "id" );
            all_Table_Gem_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Gem_List.Clear();
        }
    }
}
