using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 技能属性组属性
    ///</summary>
    [Serializable]
    [TableName("skill_prop_item")]
    public partial class Table_Skill_Prop_Item : TableContent
    {

        private static List<Table_Skill_Prop_Item> all_Table_Skill_Prop_Item_List = new List<Table_Skill_Prop_Item>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > > ();
        
        
        ///<summary>
        /// 主键：技能ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 主键：标签ID
        ///</summary>
        public int tag_id;
        
        
        ///<summary>
        /// 主键：属性ID
        ///</summary>
        public int prop_id;
        
        
        ///<summary>
        /// 属性值
        ///</summary>
        public int prop_value;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > GetPrimary ( int _skillId ){        
            Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///	<param tagId> 主键：标签ID</param>
        ///
        public static Dictionary<int, Table_Skill_Prop_Item > GetPrimary ( int _skillId , int _tagId ){        
            Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Skill_Prop_Item > _map1=null;        
            _map0. TryGetValue(_tagId,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///	<param tagId> 主键：标签ID</param>
        ///	<param propId> 主键：属性ID</param>
        ///
        public static Table_Skill_Prop_Item GetPrimary ( int _skillId , int _tagId , int _propId ){        
            Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Skill_Prop_Item > _map1=null;        
            _map0. TryGetValue(_tagId,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Skill_Prop_Item _map2=null;        
            _map1. TryGetValue(_propId,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Skill_Prop_Item > > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skill_Prop_Item> GetAllPrimaryList()
        {
            return all_Table_Skill_Prop_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("tag_id", out _currValue))
            {
                this.tag_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prop_id", out _currValue))
            {
                this.prop_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prop_value", out _currValue))
            {
                this.prop_value = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skill_prop_item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_id":
                    return this.skill_id;
                case "tag_id":
                    return this.tag_id;
                case "prop_id":
                    return this.prop_id;
                case "prop_value":
                    return this.prop_value;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skill_Prop_Item> rows = _rows as List<Table_Skill_Prop_Item>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Skill_Prop_Item > ( rows, "map", "skill_id", "tag_id", "prop_id" );
            all_Table_Skill_Prop_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skill_Prop_Item_List.Clear();
        }
    }
}
