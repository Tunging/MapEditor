using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 交易物品
    ///</summary>
    [Serializable]
    [TableName("trade_item")]
    public partial class Table_Trade_Item : TableContent
    {

        private static List<Table_Trade_Item> all_Table_Trade_Item_List = new List<Table_Trade_Item>();
        //primary | 主键
        public static Dictionary<int, Table_Trade_Item > pool_primary = new Dictionary<int, Table_Trade_Item > ();
        
        
        ///<summary>
        /// 物品id
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 3级标签id
        ///</summary>
        public int label_id;
        
        
        ///<summary>
        /// 1,高级;2,普通
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 推荐价格
        ///</summary>
        public int recommend_price;
        
        
        ///<summary>
        /// 最低价格
        ///</summary>
        public int price_down;
        
        
        ///<summary>
        /// 最高价格
        ///</summary>
        public int price_up;
        
        
        ///<summary>
        /// 进入审核价格
        ///</summary>
        public int examine_price;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param itemId> 物品id</param>
        ///
        public static Table_Trade_Item GetPrimary ( int _itemId ){        
            Table_Trade_Item _map0=null;        
            pool_primary. TryGetValue(_itemId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Trade_Item > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Trade_Item> GetAllPrimaryList()
        {
            return all_Table_Trade_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("label_id", out _currValue))
            {
                this.label_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("recommend_price", out _currValue))
            {
                this.recommend_price = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("price_down", out _currValue))
            {
                this.price_down = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("price_up", out _currValue))
            {
                this.price_up = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("examine_price", out _currValue))
            {
                this.examine_price = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "trade_item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "item_id":
                    return this.item_id;
                case "label_id":
                    return this.label_id;
                case "type":
                    return this.type;
                case "recommend_price":
                    return this.recommend_price;
                case "price_down":
                    return this.price_down;
                case "price_up":
                    return this.price_up;
                case "examine_price":
                    return this.examine_price;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Trade_Item> rows = _rows as List<Table_Trade_Item>;
            pool_primary=TableContent.ListToPool < int, Table_Trade_Item > ( rows, "map", "item_id" );
            all_Table_Trade_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Trade_Item_List.Clear();
        }
    }
}
