using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 商店折扣权重配置
    ///</summary>
    [Serializable]
    [TableName("shop_discount")]
    public partial class Table_Shop_Discount : TableContent
    {

        private static List<Table_Shop_Discount> all_Table_Shop_Discount_List = new List<Table_Shop_Discount>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Shop_Discount > > pool_primary = new Dictionary<int, Dictionary<int, Table_Shop_Discount > > ();
        
        
        ///<summary>
        /// 
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 打折数
        ///</summary>
        public int discount;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> </param>
        ///
        public static Dictionary<int, Table_Shop_Discount > GetPrimary ( int _id ){        
            Dictionary<int, Table_Shop_Discount > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> </param>
        ///	<param discount> 打折数</param>
        ///
        public static Table_Shop_Discount GetPrimary ( int _id , int _discount ){        
            Dictionary<int, Table_Shop_Discount > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Shop_Discount _map1=null;        
            _map0. TryGetValue(_discount,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Shop_Discount > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Shop_Discount> GetAllPrimaryList()
        {
            return all_Table_Shop_Discount_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("discount", out _currValue))
            {
                this.discount = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "shop_discount";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "discount":
                    return this.discount;
                case "weight":
                    return this.weight;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Shop_Discount> rows = _rows as List<Table_Shop_Discount>;
            pool_primary=TableContent.ListToPool < int, int, Table_Shop_Discount > ( rows, "map", "id", "discount" );
            all_Table_Shop_Discount_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Shop_Discount_List.Clear();
        }
    }
}
