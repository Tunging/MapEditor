using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc模板
    ///</summary>
    [Serializable]
    [TableName("npc")]
    public partial class Table_Npc : TableContent
    {

        private static List<Table_Npc> all_Table_Npc_List = new List<Table_Npc>();
        //primary | 主键
        public static Dictionary<int, Table_Npc > pool_primary = new Dictionary<int, Table_Npc > ();
        
        
        ///<summary>
        /// 主键：模板ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 阵营ID
        ///</summary>
        public int camp_id;
        
        
        ///<summary>
        /// 资源配置ID
        ///</summary>
        public int resource_id;
        
        
        ///<summary>
        /// 显示配置ID
        ///</summary>
        public int show_config_id;
        
        
        ///<summary>
        /// 对话组ID
        ///</summary>
        public int dialog_id;
        
        
        ///<summary>
        /// 属性配置ID
        ///</summary>
        public int prop_config_id;
        
        
        ///<summary>
        /// 受到攻击后的掉落物品
        ///</summary>
        public int attacked_drop_reward_id;
        
        
        ///<summary>
        /// 受攻击后掉落概率
        ///</summary>
        public int attacked_drop_rate;
        
        
        ///<summary>
        /// 受击动作播放优先级模式
        ///</summary>
        public int hit_priority;
        
        
        ///<summary>
        /// 当血量一次受击血量减少x百分比时播放高级受击动作
        ///</summary>
        public int high_hit_action_hp_reduce_percent;
        
        
        ///<summary>
        /// LOD是否优先显示
        ///</summary>
        public bool is_high_priority_show;
        
        
        ///<summary>
        /// 是否浮空
        ///</summary>
        public bool float_npc;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：模板ID</param>
        ///
        public static Table_Npc GetPrimary ( int _id ){        
            Table_Npc _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc> GetAllPrimaryList()
        {
            return all_Table_Npc_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("camp_id", out _currValue))
            {
                this.camp_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("resource_id", out _currValue))
            {
                this.resource_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_config_id", out _currValue))
            {
                this.show_config_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_id", out _currValue))
            {
                this.dialog_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("prop_config_id", out _currValue))
            {
                this.prop_config_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("attacked_drop_reward_id", out _currValue))
            {
                this.attacked_drop_reward_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("attacked_drop_rate", out _currValue))
            {
                this.attacked_drop_rate = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("hit_priority", out _currValue))
            {
                this.hit_priority = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("high_hit_action_hp_reduce_percent", out _currValue))
            {
                this.high_hit_action_hp_reduce_percent = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_high_priority_show", out _currValue))
            {
                this.is_high_priority_show = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("float_npc", out _currValue))
            {
                this.float_npc = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "camp_id":
                    return this.camp_id;
                case "resource_id":
                    return this.resource_id;
                case "show_config_id":
                    return this.show_config_id;
                case "dialog_id":
                    return this.dialog_id;
                case "prop_config_id":
                    return this.prop_config_id;
                case "attacked_drop_reward_id":
                    return this.attacked_drop_reward_id;
                case "attacked_drop_rate":
                    return this.attacked_drop_rate;
                case "hit_priority":
                    return this.hit_priority;
                case "high_hit_action_hp_reduce_percent":
                    return this.high_hit_action_hp_reduce_percent;
                case "is_high_priority_show":
                    return this.is_high_priority_show;
                case "float_npc":
                    return this.float_npc;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc> rows = _rows as List<Table_Npc>;
            pool_primary=TableContent.ListToPool < int, Table_Npc > ( rows, "map", "id" );
            all_Table_Npc_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_List.Clear();
        }
    }
}
