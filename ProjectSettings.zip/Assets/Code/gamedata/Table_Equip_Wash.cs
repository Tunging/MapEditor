using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 装备洗炼表
    ///</summary>
    [Serializable]
    [TableName("equip_wash")]
    public partial class Table_Equip_Wash : TableContent
    {

        private static List<Table_Equip_Wash> all_Table_Equip_Wash_List = new List<Table_Equip_Wash>();
        //primary | 主键
        public static Dictionary<int, Table_Equip_Wash > pool_primary = new Dictionary<int, Table_Equip_Wash > ();
        
        
        ///<summary>
        /// 主键：装备星级
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 洗出0条权重
        ///</summary>
        public int wash_num0_weight;
        
        
        ///<summary>
        /// 洗出1条权重
        ///</summary>
        public int wash_num1_weight;
        
        
        ///<summary>
        /// 洗出2条权重
        ///</summary>
        public int wash_num2_weight;
        
        
        ///<summary>
        /// 洗出3条权重
        ///</summary>
        public int wash_num3_weight;
        
        
        ///<summary>
        /// 洗出4条权重
        ///</summary>
        public int wash_num4_weight;
        
        
        ///<summary>
        /// 洗出5条权重
        ///</summary>
        public int wash_num5_weight;
        
        
        ///<summary>
        /// 洗出6条权重
        ///</summary>
        public int wash_num6_weight;
        
        
        ///<summary>
        /// 锁定0条消耗（id*num;id*num）
        ///</summary>
        public string lock_cost_items0;
        
        
        ///<summary>
        /// 锁定1条消耗
        ///</summary>
        public string lock_cost_items1;
        
        
        ///<summary>
        /// 锁定2条消耗
        ///</summary>
        public string lock_cost_items2;
        
        
        ///<summary>
        /// 锁定3条消耗
        ///</summary>
        public string lock_cost_items3;
        
        
        ///<summary>
        /// 锁定4条消耗
        ///</summary>
        public string lock_cost_items4;
        
        
        ///<summary>
        /// 锁定5条消耗
        ///</summary>
        public string lock_cost_items5;
        
        
        ///<summary>
        /// 锁定条目上限
        ///</summary>
        public int lock_num_max;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：装备星级</param>
        ///
        public static Table_Equip_Wash GetPrimary ( int _id ){        
            Table_Equip_Wash _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Equip_Wash > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Equip_Wash> GetAllPrimaryList()
        {
            return all_Table_Equip_Wash_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num0_weight", out _currValue))
            {
                this.wash_num0_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num1_weight", out _currValue))
            {
                this.wash_num1_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num2_weight", out _currValue))
            {
                this.wash_num2_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num3_weight", out _currValue))
            {
                this.wash_num3_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num4_weight", out _currValue))
            {
                this.wash_num4_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num5_weight", out _currValue))
            {
                this.wash_num5_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("wash_num6_weight", out _currValue))
            {
                this.wash_num6_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("lock_cost_items0", out _currValue))
            {
                this.lock_cost_items0 = _currValue;
            }
            if(_itemData.TryGetValue("lock_cost_items1", out _currValue))
            {
                this.lock_cost_items1 = _currValue;
            }
            if(_itemData.TryGetValue("lock_cost_items2", out _currValue))
            {
                this.lock_cost_items2 = _currValue;
            }
            if(_itemData.TryGetValue("lock_cost_items3", out _currValue))
            {
                this.lock_cost_items3 = _currValue;
            }
            if(_itemData.TryGetValue("lock_cost_items4", out _currValue))
            {
                this.lock_cost_items4 = _currValue;
            }
            if(_itemData.TryGetValue("lock_cost_items5", out _currValue))
            {
                this.lock_cost_items5 = _currValue;
            }
            if(_itemData.TryGetValue("lock_num_max", out _currValue))
            {
                this.lock_num_max = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "equip_wash";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "wash_num0_weight":
                    return this.wash_num0_weight;
                case "wash_num1_weight":
                    return this.wash_num1_weight;
                case "wash_num2_weight":
                    return this.wash_num2_weight;
                case "wash_num3_weight":
                    return this.wash_num3_weight;
                case "wash_num4_weight":
                    return this.wash_num4_weight;
                case "wash_num5_weight":
                    return this.wash_num5_weight;
                case "wash_num6_weight":
                    return this.wash_num6_weight;
                case "lock_cost_items0":
                    return this.lock_cost_items0;
                case "lock_cost_items1":
                    return this.lock_cost_items1;
                case "lock_cost_items2":
                    return this.lock_cost_items2;
                case "lock_cost_items3":
                    return this.lock_cost_items3;
                case "lock_cost_items4":
                    return this.lock_cost_items4;
                case "lock_cost_items5":
                    return this.lock_cost_items5;
                case "lock_num_max":
                    return this.lock_num_max;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Equip_Wash> rows = _rows as List<Table_Equip_Wash>;
            pool_primary=TableContent.ListToPool < int, Table_Equip_Wash > ( rows, "map", "id" );
            all_Table_Equip_Wash_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Equip_Wash_List.Clear();
        }
    }
}
