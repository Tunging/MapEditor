using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 角色选择界面动作
    ///</summary>
    [Serializable]
    [TableName("role_select_action")]
    public partial class Table_Role_Select_Action : TableContent
    {

        private static List<Table_Role_Select_Action> all_Table_Role_Select_Action_List = new List<Table_Role_Select_Action>();
        //primary | 主键
        public static Dictionary<int, Table_Role_Select_Action > pool_primary = new Dictionary<int, Table_Role_Select_Action > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 职业id
        ///</summary>
        public int proffesion_id;
        
        
        ///<summary>
        /// 选人第几步
        ///</summary>
        public int oprate_index;
        
        
        ///<summary>
        ///  动作id
        ///</summary>
        public int action_id;
        
        
        ///<summary>
        /// 时长(毫秒)
        ///</summary>
        public int action_time;
        
        
        ///<summary>
        /// 特效id
        ///</summary>
        public string effect_id;
        
        
        ///<summary>
        /// 相机动作
        ///</summary>
        public string camera_action_id;
        
        
        ///<summary>
        /// 特效延迟时间
        ///</summary>
        public string effect_delay;
        
        
        ///<summary>
        /// 模糊开始时间
        ///</summary>
        public float mohu_start_time;
        
        
        ///<summary>
        /// 模糊持续时间
        ///</summary>
        public float mohu_time;
        
        
        ///<summary>
        /// 模糊采样距离
        ///</summary>
        public float sample_dist;
        
        
        ///<summary>
        /// 模糊采样强度
        ///</summary>
        public float sample_strength;
        
        
        ///<summary>
        /// 某一步ui动作播放的延时(毫秒)
        ///</summary>
        public int ui_action_delay_time;
        
        
        ///<summary>
        /// 摄像机视野
        ///</summary>
        public float camera_range;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Table_Role_Select_Action GetPrimary ( int _id ){        
            Table_Role_Select_Action _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Role_Select_Action > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Role_Select_Action> GetAllPrimaryList()
        {
            return all_Table_Role_Select_Action_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("proffesion_id", out _currValue))
            {
                this.proffesion_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("oprate_index", out _currValue))
            {
                this.oprate_index = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_time", out _currValue))
            {
                this.action_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = _currValue;
            }
            if(_itemData.TryGetValue("camera_action_id", out _currValue))
            {
                this.camera_action_id = _currValue;
            }
            if(_itemData.TryGetValue("effect_delay", out _currValue))
            {
                this.effect_delay = _currValue;
            }
            if(_itemData.TryGetValue("mohu_start_time", out _currValue))
            {
                this.mohu_start_time = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("mohu_time", out _currValue))
            {
                this.mohu_time = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("sample_dist", out _currValue))
            {
                this.sample_dist = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("sample_strength", out _currValue))
            {
                this.sample_strength = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_action_delay_time", out _currValue))
            {
                this.ui_action_delay_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_range", out _currValue))
            {
                this.camera_range = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "role_select_action";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "proffesion_id":
                    return this.proffesion_id;
                case "oprate_index":
                    return this.oprate_index;
                case "action_id":
                    return this.action_id;
                case "action_time":
                    return this.action_time;
                case "effect_id":
                    return this.effect_id;
                case "camera_action_id":
                    return this.camera_action_id;
                case "effect_delay":
                    return this.effect_delay;
                case "mohu_start_time":
                    return this.mohu_start_time;
                case "mohu_time":
                    return this.mohu_time;
                case "sample_dist":
                    return this.sample_dist;
                case "sample_strength":
                    return this.sample_strength;
                case "ui_action_delay_time":
                    return this.ui_action_delay_time;
                case "camera_range":
                    return this.camera_range;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Role_Select_Action> rows = _rows as List<Table_Role_Select_Action>;
            pool_primary=TableContent.ListToPool < int, Table_Role_Select_Action > ( rows, "map", "id" );
            all_Table_Role_Select_Action_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Role_Select_Action_List.Clear();
        }
    }
}
