using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc资源配置
    ///</summary>
    [Serializable]
    [TableName("npc_resource")]
    public partial class Table_Npc_Resource : TableContent
    {

        private static List<Table_Npc_Resource> all_Table_Npc_Resource_List = new List<Table_Npc_Resource>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Resource > pool_primary = new Dictionary<int, Table_Npc_Resource > ();
        
        
        ///<summary>
        /// 主键：配置ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称，备注
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 技能配置ID
        ///</summary>
        public int skill_config_id;
        
        
        ///<summary>
        /// 模型资源ID
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 模型缩放倍数
        ///</summary>
        public float model_scale;
        
        
        ///<summary>
        /// 脚底光圈缩放大小
        ///</summary>
        public float foot_aperture_size;
        
        
        ///<summary>
        /// 出现交互按钮的距离
        ///</summary>
        public int interact_distance;
        
        
        ///<summary>
        /// 穿戴的武器模型ID
        ///</summary>
        public int weapon_model_id;
        
        
        ///<summary>
        /// 特效资源ID
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 头像图标ID
        ///</summary>
        public int header_icon_id;
        
        
        ///<summary>
        /// 出生时间(ms)
        ///</summary>
        public int birth_time;
        
        
        ///<summary>
        /// 出生动作类型
        ///</summary>
        public int birth_type;
        
        
        ///<summary>
        /// 出生动作ID
        ///</summary>
        public int birth_action;
        
        
        ///<summary>
        /// 受击效果参数
        ///</summary>
        public string flash_hurt_param;
        
        
        ///<summary>
        /// boss 摄像头参数（距离_高度）
        ///</summary>
        public string boss_camera_param;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：配置ID</param>
        ///
        public static Table_Npc_Resource GetPrimary ( int _id ){        
            Table_Npc_Resource _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Resource > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Resource> GetAllPrimaryList()
        {
            return all_Table_Npc_Resource_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("skill_config_id", out _currValue))
            {
                this.skill_config_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_scale", out _currValue))
            {
                this.model_scale = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("foot_aperture_size", out _currValue))
            {
                this.foot_aperture_size = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("interact_distance", out _currValue))
            {
                this.interact_distance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weapon_model_id", out _currValue))
            {
                this.weapon_model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("header_icon_id", out _currValue))
            {
                this.header_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("birth_time", out _currValue))
            {
                this.birth_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("birth_type", out _currValue))
            {
                this.birth_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("birth_action", out _currValue))
            {
                this.birth_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("flash_hurt_param", out _currValue))
            {
                this.flash_hurt_param = _currValue;
            }
            if(_itemData.TryGetValue("boss_camera_param", out _currValue))
            {
                this.boss_camera_param = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_resource";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "skill_config_id":
                    return this.skill_config_id;
                case "model_id":
                    return this.model_id;
                case "model_scale":
                    return this.model_scale;
                case "foot_aperture_size":
                    return this.foot_aperture_size;
                case "interact_distance":
                    return this.interact_distance;
                case "weapon_model_id":
                    return this.weapon_model_id;
                case "effect_id":
                    return this.effect_id;
                case "header_icon_id":
                    return this.header_icon_id;
                case "birth_time":
                    return this.birth_time;
                case "birth_type":
                    return this.birth_type;
                case "birth_action":
                    return this.birth_action;
                case "flash_hurt_param":
                    return this.flash_hurt_param;
                case "boss_camera_param":
                    return this.boss_camera_param;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Resource> rows = _rows as List<Table_Npc_Resource>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Resource > ( rows, "map", "id" );
            all_Table_Npc_Resource_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Resource_List.Clear();
        }
    }
}
