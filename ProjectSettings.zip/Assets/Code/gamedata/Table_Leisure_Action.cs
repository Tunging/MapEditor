using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 休闲动作
    ///</summary>
    [Serializable]
    [TableName("leisure_action")]
    public partial class Table_Leisure_Action : TableContent
    {

        private static List<Table_Leisure_Action> all_Table_Leisure_Action_List = new List<Table_Leisure_Action>();
        //primary | 主键
        public static Dictionary<int, Table_Leisure_Action > pool_primary = new Dictionary<int, Table_Leisure_Action > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 模型id
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 动作ID
        ///</summary>
        public int action_id;
        
        
        ///<summary>
        /// 持续时间
        ///</summary>
        public int last_time;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        
        
        ///<summary>
        /// 最小间隔时间
        ///</summary>
        public int min_interval_time;
        
        
        ///<summary>
        /// 最大间隔时间
        ///</summary>
        public int max_interval_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Leisure_Action GetPrimary ( int _id ){        
            Table_Leisure_Action _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Leisure_Action > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Leisure_Action> GetAllPrimaryList()
        {
            return all_Table_Leisure_Action_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("last_time", out _currValue))
            {
                this.last_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("min_interval_time", out _currValue))
            {
                this.min_interval_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max_interval_time", out _currValue))
            {
                this.max_interval_time = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "leisure_action";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "model_id":
                    return this.model_id;
                case "action_id":
                    return this.action_id;
                case "last_time":
                    return this.last_time;
                case "weight":
                    return this.weight;
                case "min_interval_time":
                    return this.min_interval_time;
                case "max_interval_time":
                    return this.max_interval_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Leisure_Action> rows = _rows as List<Table_Leisure_Action>;
            pool_primary=TableContent.ListToPool < int, Table_Leisure_Action > ( rows, "map", "id" );
            all_Table_Leisure_Action_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Leisure_Action_List.Clear();
        }
    }
}
