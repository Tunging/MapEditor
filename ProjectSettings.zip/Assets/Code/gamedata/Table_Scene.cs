using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景基础配置
    ///</summary>
    [Serializable]
    [TableName("scene")]
    public partial class Table_Scene : TableContent
    {

        private static List<Table_Scene> all_Table_Scene_List = new List<Table_Scene>();
        //primary | 主键
        public static Dictionary<int, Table_Scene > pool_primary = new Dictionary<int, Table_Scene > ();
        
        
        ///<summary>
        /// 主键：场景ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 场景类型
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 引用的地图ID
        ///</summary>
        public int map_id;
        
        
        ///<summary>
        /// 小地图路径
        ///</summary>
        public string small_map_path;
        
        
        ///<summary>
        /// 场景物件加载配置ID
        ///</summary>
        public int object_loading_id;
        
        
        ///<summary>
        /// 相机屏幕后期文件名
        ///</summary>
        public string processing_profile_path;
        
        
        ///<summary>
        /// 场景lod设置组ID
        ///</summary>
        public int scene_lod_setting_id;
        
        
        ///<summary>
        /// 是否禁止跟随
        ///</summary>
        public bool forbidden_tam_follow;
        
        
        ///<summary>
        /// 救援总进度(单位m，速度单位为m/ms)
        ///</summary>
        public int rescue_progress;
        
        
        ///<summary>
        /// 场景BGM sound id
        ///</summary>
        public int scene_bgm_sound_id;
        
        
        ///<summary>
        /// 背景音效
        ///</summary>
        public int ambient_sound_id;
        
        
        ///<summary>
        /// 区域音效组id
        ///</summary>
        public int scene_soundgroup_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：场景ID</param>
        ///
        public static Table_Scene GetPrimary ( int _id ){        
            Table_Scene _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene> GetAllPrimaryList()
        {
            return all_Table_Scene_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("map_id", out _currValue))
            {
                this.map_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("small_map_path", out _currValue))
            {
                this.small_map_path = _currValue;
            }
            if(_itemData.TryGetValue("object_loading_id", out _currValue))
            {
                this.object_loading_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("processing_profile_path", out _currValue))
            {
                this.processing_profile_path = _currValue;
            }
            if(_itemData.TryGetValue("scene_lod_setting_id", out _currValue))
            {
                this.scene_lod_setting_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("forbidden_tam_follow", out _currValue))
            {
                this.forbidden_tam_follow = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("rescue_progress", out _currValue))
            {
                this.rescue_progress = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_bgm_sound_id", out _currValue))
            {
                this.scene_bgm_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ambient_sound_id", out _currValue))
            {
                this.ambient_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("scene_soundgroup_id", out _currValue))
            {
                this.scene_soundgroup_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "type":
                    return this.type;
                case "map_id":
                    return this.map_id;
                case "small_map_path":
                    return this.small_map_path;
                case "object_loading_id":
                    return this.object_loading_id;
                case "processing_profile_path":
                    return this.processing_profile_path;
                case "scene_lod_setting_id":
                    return this.scene_lod_setting_id;
                case "forbidden_tam_follow":
                    return this.forbidden_tam_follow;
                case "rescue_progress":
                    return this.rescue_progress;
                case "scene_bgm_sound_id":
                    return this.scene_bgm_sound_id;
                case "ambient_sound_id":
                    return this.ambient_sound_id;
                case "scene_soundgroup_id":
                    return this.scene_soundgroup_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene> rows = _rows as List<Table_Scene>;
            pool_primary=TableContent.ListToPool < int, Table_Scene > ( rows, "map", "id" );
            all_Table_Scene_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_List.Clear();
        }
    }
}
