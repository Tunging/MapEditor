using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 传送门
    ///</summary>
    [Serializable]
    [TableName("transit_door")]
    public partial class Table_Transit_Door : TableContent
    {

        private static List<Table_Transit_Door> all_Table_Transit_Door_List = new List<Table_Transit_Door>();
        //primary | 主键
        public static Dictionary<int, Table_Transit_Door > pool_primary = new Dictionary<int, Table_Transit_Door > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 标注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 场景id
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// x坐标
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// y坐标
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// z坐标
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 角色落点x
        ///</summary>
        public int role_x;
        
        
        ///<summary>
        /// 角色落点y
        ///</summary>
        public int role_y;
        
        
        ///<summary>
        /// 角色落点z
        ///</summary>
        public int role_z;
        
        
        ///<summary>
        /// y轴旋转值
        ///</summary>
        public float y_rotation;
        
        
        ///<summary>
        /// 图标id
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 特效
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 前置任务id
        ///</summary>
        public int pre_quest;
        
        
        ///<summary>
        /// 传送需要等级
        ///</summary>
        public int need_level;
        
        
        ///<summary>
        /// 触发范围
        ///</summary>
        public int trigger_region;
        
        
        ///<summary>
        /// 目标传送们id
        ///</summary>
        public int target_door_id;
        
        
        ///<summary>
        /// 目标传送点id
        ///</summary>
        public int target_position_id;
        
        
        ///<summary>
        /// 是否会消失
        ///</summary>
        public bool can_disappear;
        
        
        ///<summary>
        /// 消失时间（秒）
        ///</summary>
        public int disappear_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Table_Transit_Door GetPrimary ( int _id ){        
            Table_Transit_Door _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Transit_Door > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Transit_Door> GetAllPrimaryList()
        {
            return all_Table_Transit_Door_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_x", out _currValue))
            {
                this.role_x = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_y", out _currValue))
            {
                this.role_y = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_z", out _currValue))
            {
                this.role_z = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("y_rotation", out _currValue))
            {
                this.y_rotation = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pre_quest", out _currValue))
            {
                this.pre_quest = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("need_level", out _currValue))
            {
                this.need_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_region", out _currValue))
            {
                this.trigger_region = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_door_id", out _currValue))
            {
                this.target_door_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_position_id", out _currValue))
            {
                this.target_position_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_disappear", out _currValue))
            {
                this.can_disappear = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("disappear_time", out _currValue))
            {
                this.disappear_time = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "transit_door";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "name":
                    return this.name;
                case "scene_id":
                    return this.scene_id;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "role_x":
                    return this.role_x;
                case "role_y":
                    return this.role_y;
                case "role_z":
                    return this.role_z;
                case "y_rotation":
                    return this.y_rotation;
                case "icon":
                    return this.icon;
                case "model_id":
                    return this.model_id;
                case "pre_quest":
                    return this.pre_quest;
                case "need_level":
                    return this.need_level;
                case "trigger_region":
                    return this.trigger_region;
                case "target_door_id":
                    return this.target_door_id;
                case "target_position_id":
                    return this.target_position_id;
                case "can_disappear":
                    return this.can_disappear;
                case "disappear_time":
                    return this.disappear_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Transit_Door> rows = _rows as List<Table_Transit_Door>;
            pool_primary=TableContent.ListToPool < int, Table_Transit_Door > ( rows, "map", "id" );
            all_Table_Transit_Door_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Transit_Door_List.Clear();
        }
    }
}
