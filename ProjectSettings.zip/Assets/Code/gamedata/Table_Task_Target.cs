using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 任务目标表
    ///</summary>
    [Serializable]
    [TableName("task_target")]
    public partial class Table_Task_Target : TableContent
    {

        private static List<Table_Task_Target> all_Table_Task_Target_List = new List<Table_Task_Target>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Task_Target > > pool_primary = new Dictionary<int, Dictionary<int, Table_Task_Target > > ();
        
        
        ///<summary>
        /// 主键：任务ID
        ///</summary>
        public int task_id;
        
        
        ///<summary>
        /// 主键：目标编号
        ///</summary>
        public int target_no;
        
        
        ///<summary>
        /// 目标所属分组
        ///</summary>
        public int target_group;
        
        
        ///<summary>
        /// 目标场景
        ///</summary>
        public int target_scene;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 区域中心点X坐标
        ///</summary>
        public float regionx;
        
        
        ///<summary>
        /// 区域中心点Y坐标
        ///</summary>
        public float regiony;
        
        
        ///<summary>
        /// 区域中心点Z坐标
        ///</summary>
        public float regionz;
        
        
        ///<summary>
        /// 区域半径
        ///</summary>
        public int regionr;
        
        
        ///<summary>
        /// 目标总进度
        ///</summary>
        public int total_process;
        
        
        ///<summary>
        /// 单次增加进度
        ///</summary>
        public int add_process;
        
        
        ///<summary>
        /// 目标类型
        ///</summary>
        public int target_type;
        
        
        ///<summary>
        /// 参数1
        ///</summary>
        public int param;
        
        
        ///<summary>
        /// 参数2
        ///</summary>
        public int param2;
        
        
        ///<summary>
        /// 参数3
        ///</summary>
        public int param3;
        
        
        ///<summary>
        /// 参数4
        ///</summary>
        public int param4;
        
        
        ///<summary>
        /// 参数5
        ///</summary>
        public int param5;
        
        
        ///<summary>
        /// 目标特效
        ///</summary>
        public int target_effect;
        
        
        ///<summary>
        /// 目标图标
        ///</summary>
        public int target_icon;
        
        
        ///<summary>
        /// 是否显示目标名字
        ///</summary>
        public bool show_target_name;
        
        
        ///<summary>
        /// 指引方式（1：通用目标，2 某一个NPC，3：区域位置，对应上边的区域）
        ///</summary>
        public int guide_way;
        
        
        ///<summary>
        /// 指引NPC 
        ///</summary>
        public int guide_npc_id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 是否弹出目标达成的提示
        ///</summary>
        public bool show_complete_msg;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param taskId> 主键：任务ID</param>
        ///
        public static Dictionary<int, Table_Task_Target > GetPrimary ( int _taskId ){        
            Dictionary<int, Table_Task_Target > _map0=null;        
            pool_primary. TryGetValue(_taskId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param taskId> 主键：任务ID</param>
        ///	<param targetNo> 主键：目标编号</param>
        ///
        public static Table_Task_Target GetPrimary ( int _taskId , int _targetNo ){        
            Dictionary<int, Table_Task_Target > _map0=null;        
            pool_primary. TryGetValue(_taskId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Task_Target _map1=null;        
            _map0. TryGetValue(_targetNo,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Task_Target > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Task_Target> GetAllPrimaryList()
        {
            return all_Table_Task_Target_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("task_id", out _currValue))
            {
                this.task_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_no", out _currValue))
            {
                this.target_no = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_group", out _currValue))
            {
                this.target_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_scene", out _currValue))
            {
                this.target_scene = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("regionx", out _currValue))
            {
                this.regionx = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("regiony", out _currValue))
            {
                this.regiony = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("regionz", out _currValue))
            {
                this.regionz = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("regionr", out _currValue))
            {
                this.regionr = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("total_process", out _currValue))
            {
                this.total_process = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("add_process", out _currValue))
            {
                this.add_process = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_type", out _currValue))
            {
                this.target_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param", out _currValue))
            {
                this.param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param2", out _currValue))
            {
                this.param2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param3", out _currValue))
            {
                this.param3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param4", out _currValue))
            {
                this.param4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param5", out _currValue))
            {
                this.param5 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_effect", out _currValue))
            {
                this.target_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_icon", out _currValue))
            {
                this.target_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_target_name", out _currValue))
            {
                this.show_target_name = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("guide_way", out _currValue))
            {
                this.guide_way = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("guide_npc_id", out _currValue))
            {
                this.guide_npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("show_complete_msg", out _currValue))
            {
                this.show_complete_msg = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "task_target";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "task_id":
                    return this.task_id;
                case "target_no":
                    return this.target_no;
                case "target_group":
                    return this.target_group;
                case "target_scene":
                    return this.target_scene;
                case "description":
                    return this.description;
                case "description_i18n":
                    return this.description_i18n;
                case "regionx":
                    return this.regionx;
                case "regiony":
                    return this.regiony;
                case "regionz":
                    return this.regionz;
                case "regionr":
                    return this.regionr;
                case "total_process":
                    return this.total_process;
                case "add_process":
                    return this.add_process;
                case "target_type":
                    return this.target_type;
                case "param":
                    return this.param;
                case "param2":
                    return this.param2;
                case "param3":
                    return this.param3;
                case "param4":
                    return this.param4;
                case "param5":
                    return this.param5;
                case "target_effect":
                    return this.target_effect;
                case "target_icon":
                    return this.target_icon;
                case "show_target_name":
                    return this.show_target_name;
                case "guide_way":
                    return this.guide_way;
                case "guide_npc_id":
                    return this.guide_npc_id;
                case "remark":
                    return this.remark;
                case "show_complete_msg":
                    return this.show_complete_msg;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Task_Target> rows = _rows as List<Table_Task_Target>;
            pool_primary=TableContent.ListToPool < int, int, Table_Task_Target > ( rows, "map", "task_id", "target_no" );
            all_Table_Task_Target_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Task_Target_List.Clear();
        }
    }
}
