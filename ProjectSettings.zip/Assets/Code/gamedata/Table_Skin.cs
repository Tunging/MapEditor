using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 皮肤配置表
    ///</summary>
    [Serializable]
    [TableName("skin")]
    public partial class Table_Skin : TableContent
    {

        private static List<Table_Skin> all_Table_Skin_List = new List<Table_Skin>();
        //primary | 主键
        public static Dictionary<int, Table_Skin > pool_primary = new Dictionary<int, Table_Skin > ();
        
        
        ///<summary>
        /// 背景选择问题配置表
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 种族id
        ///</summary>
        public int race_id;
        
        
        ///<summary>
        /// 名字国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 皮肤模型ID
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 选中状态的图标
        ///</summary>
        public int icon_select;
        
        
        ///<summary>
        /// 未选中状态的图标
        ///</summary>
        public int icon_unselect;
        
        
        ///<summary>
        /// 材质路径
        ///</summary>
        public string material_path;
        
        
        ///<summary>
        /// 头像id
        ///</summary>
        public int avatar_icon;
        
        
        ///<summary>
        /// 创角界面颜色选择
        ///</summary>
        public int avator_color;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 背景选择问题配置表</param>
        ///
        public static Table_Skin GetPrimary ( int _id ){        
            Table_Skin _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Skin > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Skin> GetAllPrimaryList()
        {
            return all_Table_Skin_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race_id", out _currValue))
            {
                this.race_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_select", out _currValue))
            {
                this.icon_select = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_unselect", out _currValue))
            {
                this.icon_unselect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("material_path", out _currValue))
            {
                this.material_path = _currValue;
            }
            if(_itemData.TryGetValue("avatar_icon", out _currValue))
            {
                this.avatar_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("avator_color", out _currValue))
            {
                this.avator_color = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "skin";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "race_id":
                    return this.race_id;
                case "name_i18n":
                    return this.name_i18n;
                case "model_id":
                    return this.model_id;
                case "icon_select":
                    return this.icon_select;
                case "icon_unselect":
                    return this.icon_unselect;
                case "material_path":
                    return this.material_path;
                case "avatar_icon":
                    return this.avatar_icon;
                case "avator_color":
                    return this.avator_color;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Skin> rows = _rows as List<Table_Skin>;
            pool_primary=TableContent.ListToPool < int, Table_Skin > ( rows, "map", "id" );
            all_Table_Skin_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Skin_List.Clear();
        }
    }
}
