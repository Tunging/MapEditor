using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 悬赏任务组
    ///</summary>
    [Serializable]
    [TableName("offer_task_group")]
    public partial class Table_Offer_Task_Group : TableContent
    {

        private static List<Table_Offer_Task_Group> all_Table_Offer_Task_Group_List = new List<Table_Offer_Task_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Offer_Task_Group > pool_primary = new Dictionary<int, Table_Offer_Task_Group > ();
        
        
        ///<summary>
        /// 主键：任务组ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 角色等级限制
        ///</summary>
        public int role_level_limit;
        
        
        ///<summary>
        /// 任务环长度
        ///</summary>
        public int circle_length;
        
        
        ///<summary>
        /// 任务组大小
        ///</summary>
        public int group_size;
        
        
        ///<summary>
        /// 是不是最终任务组
        ///</summary>
        public bool finally_group;
        
        
        ///<summary>
        /// 是否顺序解锁任务
        ///</summary>
        public bool orderly_unlock;
        
        
        ///<summary>
        /// 备选任务ID1
        ///</summary>
        public int task1_id;
        
        
        ///<summary>
        /// 备选任务ID2
        ///</summary>
        public int task2_id;
        
        
        ///<summary>
        /// 备选任务ID3
        ///</summary>
        public int task3_id;
        
        
        ///<summary>
        /// 备选任务ID4
        ///</summary>
        public int task4_id;
        
        
        ///<summary>
        /// 备选任务ID5
        ///</summary>
        public int task5_id;
        
        
        ///<summary>
        /// 备选任务ID6
        ///</summary>
        public int task6_id;
        
        
        ///<summary>
        /// 备选任务ID7
        ///</summary>
        public int task7_id;
        
        
        ///<summary>
        /// 备选任务ID8
        ///</summary>
        public int task8_id;
        
        
        ///<summary>
        /// 备选任务ID9
        ///</summary>
        public int task9_id;
        
        
        ///<summary>
        /// 备选任务ID10
        ///</summary>
        public int task10_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：任务组ID</param>
        ///
        public static Table_Offer_Task_Group GetPrimary ( int _id ){        
            Table_Offer_Task_Group _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Offer_Task_Group > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Offer_Task_Group> GetAllPrimaryList()
        {
            return all_Table_Offer_Task_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("role_level_limit", out _currValue))
            {
                this.role_level_limit = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("circle_length", out _currValue))
            {
                this.circle_length = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_size", out _currValue))
            {
                this.group_size = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("finally_group", out _currValue))
            {
                this.finally_group = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("orderly_unlock", out _currValue))
            {
                this.orderly_unlock = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("task1_id", out _currValue))
            {
                this.task1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task2_id", out _currValue))
            {
                this.task2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task3_id", out _currValue))
            {
                this.task3_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task4_id", out _currValue))
            {
                this.task4_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task5_id", out _currValue))
            {
                this.task5_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task6_id", out _currValue))
            {
                this.task6_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task7_id", out _currValue))
            {
                this.task7_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task8_id", out _currValue))
            {
                this.task8_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task9_id", out _currValue))
            {
                this.task9_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("task10_id", out _currValue))
            {
                this.task10_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "offer_task_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "role_level_limit":
                    return this.role_level_limit;
                case "circle_length":
                    return this.circle_length;
                case "group_size":
                    return this.group_size;
                case "finally_group":
                    return this.finally_group;
                case "orderly_unlock":
                    return this.orderly_unlock;
                case "task1_id":
                    return this.task1_id;
                case "task2_id":
                    return this.task2_id;
                case "task3_id":
                    return this.task3_id;
                case "task4_id":
                    return this.task4_id;
                case "task5_id":
                    return this.task5_id;
                case "task6_id":
                    return this.task6_id;
                case "task7_id":
                    return this.task7_id;
                case "task8_id":
                    return this.task8_id;
                case "task9_id":
                    return this.task9_id;
                case "task10_id":
                    return this.task10_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Offer_Task_Group> rows = _rows as List<Table_Offer_Task_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Offer_Task_Group > ( rows, "map", "id" );
            all_Table_Offer_Task_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Offer_Task_Group_List.Clear();
        }
    }
}
