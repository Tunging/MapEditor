using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景资源加载配置
    ///</summary>
    [Serializable]
    [TableName("scene_loading")]
    public partial class Table_Scene_Loading : TableContent
    {

        private static List<Table_Scene_Loading> all_Table_Scene_Loading_List = new List<Table_Scene_Loading>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Loading > pool_primary = new Dictionary<int, Table_Scene_Loading > ();
        
        
        ///<summary>
        /// 主键：配置ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 加载1级配置
        ///</summary>
        public int load_config1;
        
        
        ///<summary>
        /// 加载2级配置
        ///</summary>
        public int load_config2;
        
        
        ///<summary>
        /// 加载3级配置
        ///</summary>
        public int load_config3;
        
        
        ///<summary>
        /// 加载4级配置
        ///</summary>
        public int load_config4;
        
        
        ///<summary>
        /// 裁切1级配置
        ///</summary>
        public int culling_config1;
        
        
        ///<summary>
        /// 裁切2级配置
        ///</summary>
        public int culling_config2;
        
        
        ///<summary>
        /// 裁切3级配置
        ///</summary>
        public int culling_config3;
        
        
        ///<summary>
        /// 裁切4级配置
        ///</summary>
        public int culling_config4;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：配置ID</param>
        ///
        public static Table_Scene_Loading GetPrimary ( int _id ){        
            Table_Scene_Loading _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Loading > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Loading> GetAllPrimaryList()
        {
            return all_Table_Scene_Loading_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("load_config1", out _currValue))
            {
                this.load_config1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("load_config2", out _currValue))
            {
                this.load_config2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("load_config3", out _currValue))
            {
                this.load_config3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("load_config4", out _currValue))
            {
                this.load_config4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("culling_config1", out _currValue))
            {
                this.culling_config1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("culling_config2", out _currValue))
            {
                this.culling_config2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("culling_config3", out _currValue))
            {
                this.culling_config3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("culling_config4", out _currValue))
            {
                this.culling_config4 = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_loading";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "load_config1":
                    return this.load_config1;
                case "load_config2":
                    return this.load_config2;
                case "load_config3":
                    return this.load_config3;
                case "load_config4":
                    return this.load_config4;
                case "culling_config1":
                    return this.culling_config1;
                case "culling_config2":
                    return this.culling_config2;
                case "culling_config3":
                    return this.culling_config3;
                case "culling_config4":
                    return this.culling_config4;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Loading> rows = _rows as List<Table_Scene_Loading>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Loading > ( rows, "map", "id" );
            all_Table_Scene_Loading_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Loading_List.Clear();
        }
    }
}
