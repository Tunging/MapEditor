using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc对话选项（废弃）
    ///</summary>
    [Serializable]
    [TableName("npc_dialog_item")]
    public partial class Table_Npc_Dialog_Item : TableContent
    {

        private static List<Table_Npc_Dialog_Item> all_Table_Npc_Dialog_Item_List = new List<Table_Npc_Dialog_Item>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Dialog_Item > pool_primary = new Dictionary<int, Table_Npc_Dialog_Item > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 所属的对话分组ID
        ///</summary>
        public int dialog_id;
        
        
        ///<summary>
        /// 所属对话选项组ID
        ///</summary>
        public int dialog_item_id;
        
        
        ///<summary>
        /// 下一对话选项组ID
        ///</summary>
        public int next_dialog_item_id;
        
        
        ///<summary>
        /// 显示顺序
        ///</summary>
        public int show_num;
        
        
        ///<summary>
        /// 对话内容国际化
        ///</summary>
        public string content_i18n;
        
        
        ///<summary>
        /// 播放声音ID
        ///</summary>
        public int content_sound_id;
        
        
        ///<summary>
        /// 响应对话内容国际化
        ///</summary>
        public string response_content_i18n;
        
        
        ///<summary>
        /// 展示剧情id
        ///</summary>
        public int drama_show;
        
        
        ///<summary>
        /// 是否触发采集
        ///</summary>
        public int is_gather;
        
        
        ///<summary>
        /// 选项图标ID
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 电梯ID GUID
        ///</summary>
        public int npc_elevator_id;
        
        
        ///<summary>
        /// 是否通知服务器
        ///</summary>
        public bool notify_server;
        
        
        ///<summary>
        /// 导师对话操作ID
        ///</summary>
        public int mentor_operation;
        
        
        ///<summary>
        /// 开启功能面板
        ///</summary>
        public string open_function;
        
        
        ///<summary>
        /// 对话行为
        ///</summary>
        public int action;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Npc_Dialog_Item GetPrimary ( int _id ){        
            Table_Npc_Dialog_Item _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Dialog_Item > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Dialog_Item> GetAllPrimaryList()
        {
            return all_Table_Npc_Dialog_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_id", out _currValue))
            {
                this.dialog_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dialog_item_id", out _currValue))
            {
                this.dialog_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("next_dialog_item_id", out _currValue))
            {
                this.next_dialog_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_num", out _currValue))
            {
                this.show_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("content_i18n", out _currValue))
            {
                this.content_i18n = _currValue;
            }
            if(_itemData.TryGetValue("content_sound_id", out _currValue))
            {
                this.content_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("response_content_i18n", out _currValue))
            {
                this.response_content_i18n = _currValue;
            }
            if(_itemData.TryGetValue("drama_show", out _currValue))
            {
                this.drama_show = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_gather", out _currValue))
            {
                this.is_gather = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_elevator_id", out _currValue))
            {
                this.npc_elevator_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("notify_server", out _currValue))
            {
                this.notify_server = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("mentor_operation", out _currValue))
            {
                this.mentor_operation = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("open_function", out _currValue))
            {
                this.open_function = _currValue;
            }
            if(_itemData.TryGetValue("action", out _currValue))
            {
                this.action = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_dialog_item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "dialog_id":
                    return this.dialog_id;
                case "dialog_item_id":
                    return this.dialog_item_id;
                case "next_dialog_item_id":
                    return this.next_dialog_item_id;
                case "show_num":
                    return this.show_num;
                case "content_i18n":
                    return this.content_i18n;
                case "content_sound_id":
                    return this.content_sound_id;
                case "response_content_i18n":
                    return this.response_content_i18n;
                case "drama_show":
                    return this.drama_show;
                case "is_gather":
                    return this.is_gather;
                case "icon_id":
                    return this.icon_id;
                case "npc_elevator_id":
                    return this.npc_elevator_id;
                case "notify_server":
                    return this.notify_server;
                case "mentor_operation":
                    return this.mentor_operation;
                case "open_function":
                    return this.open_function;
                case "action":
                    return this.action;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Dialog_Item> rows = _rows as List<Table_Npc_Dialog_Item>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Dialog_Item > ( rows, "map", "id" );
            all_Table_Npc_Dialog_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Dialog_Item_List.Clear();
        }
    }
}
