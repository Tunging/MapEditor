using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// TG_common_askBoxWindow 通用提示窗口
    ///</summary>
    [Serializable]
    [TableName("common_ask_window_config")]
    public partial class Table_Common_Ask_Window_Config : TableContent
    {

        private static List<Table_Common_Ask_Window_Config> all_Table_Common_Ask_Window_Config_List = new List<Table_Common_Ask_Window_Config>();
        //primary | 主键
        public static Dictionary<int, Table_Common_Ask_Window_Config > pool_primary = new Dictionary<int, Table_Common_Ask_Window_Config > ();
        
        
        ///<summary>
        /// 主键：ID   提示信息ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称，备注
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 配置key 常量key, 唯一标识，英文串
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 是否需要立即显示(2个优先级)
        ///</summary>
        public bool show_immediately;
        
        
        ///<summary>
        /// 窗口标题文本ID
        ///</summary>
        public int title_id;
        
        
        ///<summary>
        /// 询问的具体内容文本ID
        ///</summary>
        public int text1_id;
        
        
        ///<summary>
        /// 勾选问题文本ID
        ///</summary>
        public int text2_id;
        
        
        ///<summary>
        /// 特别提示文本ID
        ///</summary>
        public int text3_id;
        
        
        ///<summary>
        /// 确定意向的按钮文本ID
        ///</summary>
        public int button_text1_id;
        
        
        ///<summary>
        /// 否定意向的按键文本ID
        ///</summary>
        public int button_text2_id;
        
        
        ///<summary>
        /// 需要显示的图标id, 可能是货币吧
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 图标右边的描述（可能是货币的数量）
        ///</summary>
        public string icon_des;
        
        
        ///<summary>
        /// 倒计时多少秒后自动确认， 0或空表示没有这个功能
        ///</summary>
        public int count_down;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID   提示信息ID</param>
        ///
        public static Table_Common_Ask_Window_Config GetPrimary ( int _id ){        
            Table_Common_Ask_Window_Config _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Common_Ask_Window_Config > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Common_Ask_Window_Config> GetAllPrimaryList()
        {
            return all_Table_Common_Ask_Window_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("show_immediately", out _currValue))
            {
                this.show_immediately = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("title_id", out _currValue))
            {
                this.title_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text1_id", out _currValue))
            {
                this.text1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text2_id", out _currValue))
            {
                this.text2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text3_id", out _currValue))
            {
                this.text3_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("button_text1_id", out _currValue))
            {
                this.button_text1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("button_text2_id", out _currValue))
            {
                this.button_text2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_des", out _currValue))
            {
                this.icon_des = _currValue;
            }
            if(_itemData.TryGetValue("count_down", out _currValue))
            {
                this.count_down = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "common_ask_window_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "ckey":
                    return this.ckey;
                case "show_immediately":
                    return this.show_immediately;
                case "title_id":
                    return this.title_id;
                case "text1_id":
                    return this.text1_id;
                case "text2_id":
                    return this.text2_id;
                case "text3_id":
                    return this.text3_id;
                case "button_text1_id":
                    return this.button_text1_id;
                case "button_text2_id":
                    return this.button_text2_id;
                case "icon_id":
                    return this.icon_id;
                case "icon_des":
                    return this.icon_des;
                case "count_down":
                    return this.count_down;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Common_Ask_Window_Config> rows = _rows as List<Table_Common_Ask_Window_Config>;
            pool_primary=TableContent.ListToPool < int, Table_Common_Ask_Window_Config > ( rows, "map", "id" );
            all_Table_Common_Ask_Window_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Common_Ask_Window_Config_List.Clear();
        }
    }
}
