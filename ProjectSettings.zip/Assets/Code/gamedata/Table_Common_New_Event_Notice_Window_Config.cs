using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// TG_NewEvenNoticeWindow 美术字提示
    ///</summary>
    [Serializable]
    [TableName("common_new_event_notice_window_config")]
    public partial class Table_Common_New_Event_Notice_Window_Config : TableContent
    {

        private static List<Table_Common_New_Event_Notice_Window_Config> all_Table_Common_New_Event_Notice_Window_Config_List = new List<Table_Common_New_Event_Notice_Window_Config>();
        //primary | 主键
        public static Dictionary<int, Table_Common_New_Event_Notice_Window_Config > pool_primary = new Dictionary<int, Table_Common_New_Event_Notice_Window_Config > ();
        
        
        ///<summary>
        /// 主键：ID  输入文档框的ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称，备注
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 配置key   样式名： area，task_new，teleport，task_complete，task_failed  ，客户端用于生成常量枚举
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 图片提示框的类型
        ///</summary>
        public int note_type;
        
        
        ///<summary>
        /// 类型1_图片资源_ID
        ///</summary>
        public int image1_id;
        
        
        ///<summary>
        /// 类型1_图片对应特效资源_ID
        ///</summary>
        public int image1_effect_id;
        
        
        ///<summary>
        /// 类型2_上部图片资源_ID
        ///</summary>
        public int image2_id;
        
        
        ///<summary>
        /// 类型2_图片对应特效资源_ID
        ///</summary>
        public int image2_effect_id;
        
        
        ///<summary>
        /// 类型2_下部图片资源_ID
        ///</summary>
        public int image3_id;
        
        
        ///<summary>
        /// 显示时长（秒）
        ///</summary>
        public float animation_time;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID  输入文档框的ID</param>
        ///
        public static Table_Common_New_Event_Notice_Window_Config GetPrimary ( int _id ){        
            Table_Common_New_Event_Notice_Window_Config _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Common_New_Event_Notice_Window_Config > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Common_New_Event_Notice_Window_Config> GetAllPrimaryList()
        {
            return all_Table_Common_New_Event_Notice_Window_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("note_type", out _currValue))
            {
                this.note_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("image1_id", out _currValue))
            {
                this.image1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("image1_effect_id", out _currValue))
            {
                this.image1_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("image2_id", out _currValue))
            {
                this.image2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("image2_effect_id", out _currValue))
            {
                this.image2_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("image3_id", out _currValue))
            {
                this.image3_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("animation_time", out _currValue))
            {
                this.animation_time = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "common_new_event_notice_window_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "ckey":
                    return this.ckey;
                case "note_type":
                    return this.note_type;
                case "image1_id":
                    return this.image1_id;
                case "image1_effect_id":
                    return this.image1_effect_id;
                case "image2_id":
                    return this.image2_id;
                case "image2_effect_id":
                    return this.image2_effect_id;
                case "image3_id":
                    return this.image3_id;
                case "animation_time":
                    return this.animation_time;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Common_New_Event_Notice_Window_Config> rows = _rows as List<Table_Common_New_Event_Notice_Window_Config>;
            pool_primary=TableContent.ListToPool < int, Table_Common_New_Event_Notice_Window_Config > ( rows, "map", "id" );
            all_Table_Common_New_Event_Notice_Window_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Common_New_Event_Notice_Window_Config_List.Clear();
        }
    }
}
