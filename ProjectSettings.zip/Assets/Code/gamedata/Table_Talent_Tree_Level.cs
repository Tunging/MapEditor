using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 天赋树等级限制表
    ///</summary>
    [Serializable]
    [TableName("talent_tree_level")]
    public partial class Table_Talent_Tree_Level : TableContent
    {

        private static List<Table_Talent_Tree_Level> all_Table_Talent_Tree_Level_List = new List<Table_Talent_Tree_Level>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Talent_Tree_Level > > pool_primary = new Dictionary<int, Dictionary<int, Table_Talent_Tree_Level > > ();
        
        
        ///<summary>
        /// 主键：天赋树ID
        ///</summary>
        public int tree_id;
        
        
        ///<summary>
        /// 主键：层级ID
        ///</summary>
        public int hierarchy_id;
        
        
        ///<summary>
        /// 限制角色等级
        ///</summary>
        public int role_level;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param treeId> 主键：天赋树ID</param>
        ///
        public static Dictionary<int, Table_Talent_Tree_Level > GetPrimary ( int _treeId ){        
            Dictionary<int, Table_Talent_Tree_Level > _map0=null;        
            pool_primary. TryGetValue(_treeId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param treeId> 主键：天赋树ID</param>
        ///	<param hierarchyId> 主键：层级ID</param>
        ///
        public static Table_Talent_Tree_Level GetPrimary ( int _treeId , int _hierarchyId ){        
            Dictionary<int, Table_Talent_Tree_Level > _map0=null;        
            pool_primary. TryGetValue(_treeId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Talent_Tree_Level _map1=null;        
            _map0. TryGetValue(_hierarchyId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Talent_Tree_Level > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Talent_Tree_Level> GetAllPrimaryList()
        {
            return all_Table_Talent_Tree_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("tree_id", out _currValue))
            {
                this.tree_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("hierarchy_id", out _currValue))
            {
                this.hierarchy_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_level", out _currValue))
            {
                this.role_level = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "talent_tree_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "tree_id":
                    return this.tree_id;
                case "hierarchy_id":
                    return this.hierarchy_id;
                case "role_level":
                    return this.role_level;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Talent_Tree_Level> rows = _rows as List<Table_Talent_Tree_Level>;
            pool_primary=TableContent.ListToPool < int, int, Table_Talent_Tree_Level > ( rows, "map", "tree_id", "hierarchy_id" );
            all_Table_Talent_Tree_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Talent_Tree_Level_List.Clear();
        }
    }
}
