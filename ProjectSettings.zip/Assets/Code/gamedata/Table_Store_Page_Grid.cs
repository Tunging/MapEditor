using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 商店格子
    ///</summary>
    [Serializable]
    [TableName("store_page_grid")]
    public partial class Table_Store_Page_Grid : TableContent
    {

        private static List<Table_Store_Page_Grid> all_Table_Store_Page_Grid_List = new List<Table_Store_Page_Grid>();
        //primary | 主键
        public static Dictionary<int, Table_Store_Page_Grid > pool_primary = new Dictionary<int, Table_Store_Page_Grid > ();
        
        
        ///<summary>
        /// 主键:ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 商店页id
        ///</summary>
        public int page_id;
        
        
        ///<summary>
        /// 格子序号
        ///</summary>
        public int number;
        
        
        ///<summary>
        /// 商品组id
        ///</summary>
        public int item_group_id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键:ID</param>
        ///
        public static Table_Store_Page_Grid GetPrimary ( int _id ){        
            Table_Store_Page_Grid _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Store_Page_Grid > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Store_Page_Grid> GetAllPrimaryList()
        {
            return all_Table_Store_Page_Grid_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("page_id", out _currValue))
            {
                this.page_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("number", out _currValue))
            {
                this.number = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_group_id", out _currValue))
            {
                this.item_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "store_page_grid";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "page_id":
                    return this.page_id;
                case "number":
                    return this.number;
                case "item_group_id":
                    return this.item_group_id;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Store_Page_Grid> rows = _rows as List<Table_Store_Page_Grid>;
            pool_primary=TableContent.ListToPool < int, Table_Store_Page_Grid > ( rows, "map", "id" );
            all_Table_Store_Page_Grid_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Store_Page_Grid_List.Clear();
        }
    }
}
