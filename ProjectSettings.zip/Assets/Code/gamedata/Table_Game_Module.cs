using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 游戏模块配置
    ///</summary>
	[Serializable]
	[TableName("game_module")]
    public partial class Table_Game_Module :TableContent
    {

                private static  List< Table_Game_Module > all_Table_Game_Module_List=new  List< Table_Game_Module >();
                //primary | 主键
				public static 	Dictionary <int, Table_Game_Module > pool_primary=new Dictionary <int, Table_Game_Module > ();
        		///<summary>
        		/// 主键：ID
        		///</summary>
        		public int id;
        		///<summary>
        		/// 配置key
        		///</summary>
        		public string ckey;
        		///<summary>
        		/// 名称国际化
        		///</summary>
        		public string name_i18n;
        		///<summary>
        		/// 开启条件类型
        		///</summary>
        		public int open_condition_type;
        		///<summary>
        		/// 开启条件参数
        		///</summary>
        		public int open_condition_param;
        		///<summary>
        		/// 开启条件参数2
        		///</summary>
        		public int open_condition_param2;
        		///<summary>
        		/// 升级面板描述国际化
        		///</summary>
        		public string levelup_panel_i18n;
        		///<summary>
        		/// 升级预告描述国际化
        		///</summary>
        		public string levelup_forecast_i18n;
        		///<summary>
        		/// 是否隐藏
        		///</summary>
        		public bool is_hidden;
        		///<summary>
        		/// 隐藏按钮描述
        		///</summary>
        		public string hidden_button_name;
        		///<summary>
        		/// 是否显示动画提示
        		///</summary>
        		public bool show_tip;
        		///<summary>
        		/// 显示动画图标id(上)
        		///</summary>
        		public int show_tip_icon_id_up;
        		///<summary>
        		/// 显示动画图标id(下)
        		///</summary>
        		public int show_tip_icon_id_down;
        		///<summary>
        		/// 显示图标ID
        		///</summary>
        		public int icon_id;
        		///<summary>
        		/// 图标上是否自带名称
        		///</summary>
        		public bool icon_own_name;
        		///<summary>
        		/// 开启效果ui类型
        		///</summary>
        		public int ui_type;

				///<summary>
                /// 主键
                /// 查询数据
                ///</summary>
				///	<param id> 主键：ID</param>
          		///
				public static 	Table_Game_Module GetPrimary ( int _id ){
                        Table_Game_Module _map0=null;
						pool_primary. TryGetValue(_id,out _map0);
						return  _map0;
				}
        		 ///<summary>
                ///主键
                ///查询所有数据
                ///</summary>
				public static Dictionary <int, Table_Game_Module > GetAllPrimary(){
						return pool_primary;
				}


				///查询出所有的数据
				public static List<Table_Game_Module> GetAllPrimaryList(){
						return all_Table_Game_Module_List;
				}


    	        public override void ParseFrom(Dictionary<string, string> _itemData) {
					string _currValue = "";
					if(_itemData.TryGetValue("id", out _currValue)){
        		        this.id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("ckey", out _currValue)){
        		        this.ckey = _currValue;
					}

					if(_itemData.TryGetValue("name_i18n", out _currValue)){
        		        this.name_i18n = _currValue;
					}

					if(_itemData.TryGetValue("open_condition_type", out _currValue)){
        		        this.open_condition_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("open_condition_param", out _currValue)){
        		        this.open_condition_param = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("open_condition_param2", out _currValue)){
        		        this.open_condition_param2 = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("levelup_panel_i18n", out _currValue)){
        		        this.levelup_panel_i18n = _currValue;
					}

					if(_itemData.TryGetValue("levelup_forecast_i18n", out _currValue)){
        		        this.levelup_forecast_i18n = _currValue;
					}

					if(_itemData.TryGetValue("is_hidden", out _currValue)){
        		        this.is_hidden = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("hidden_button_name", out _currValue)){
        		        this.hidden_button_name = _currValue;
					}

					if(_itemData.TryGetValue("show_tip", out _currValue)){
        		        this.show_tip = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("show_tip_icon_id_up", out _currValue)){
        		        this.show_tip_icon_id_up = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("show_tip_icon_id_down", out _currValue)){
        		        this.show_tip_icon_id_down = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("icon_id", out _currValue)){
        		        this.icon_id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("icon_own_name", out _currValue)){
        		        this.icon_own_name = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("ui_type", out _currValue)){
        		        this.ui_type = Utils.GetIntFromString(_currValue);
					}

				}

                 public override string Table()
                 {
                    return "game_module";
                 }

                 public  override object GetValue(string column) {
        	            switch (column) {
        		            case "id":
            	            return this.id;
        		            case "ckey":
            	            return this.ckey;
        		            case "name_i18n":
            	            return this.name_i18n;
        		            case "open_condition_type":
            	            return this.open_condition_type;
        		            case "open_condition_param":
            	            return this.open_condition_param;
        		            case "open_condition_param2":
            	            return this.open_condition_param2;
        		            case "levelup_panel_i18n":
            	            return this.levelup_panel_i18n;
        		            case "levelup_forecast_i18n":
            	            return this.levelup_forecast_i18n;
        		            case "is_hidden":
            	            return this.is_hidden;
        		            case "hidden_button_name":
            	            return this.hidden_button_name;
        		            case "show_tip":
            	            return this.show_tip;
        		            case "show_tip_icon_id_up":
            	            return this.show_tip_icon_id_up;
        		            case "show_tip_icon_id_down":
            	            return this.show_tip_icon_id_down;
        		            case "icon_id":
            	            return this.icon_id;
        		            case "icon_own_name":
            	            return this.icon_own_name;
        		            case "ui_type":
            	            return this.ui_type;
        		            default:
                        return null;
			            }
		         }
                 public static void InitPool(IList _rows){
							List<Table_Game_Module> rows = _rows as List<Table_Game_Module>;
                      		pool_primary=TableContent.ListToPool < int, Table_Game_Module > ( rows, "map", "id" );
							all_Table_Game_Module_List=rows;
                 }

                public static void Clear()
                {
                       pool_primary.Clear();
                       all_Table_Game_Module_List.Clear();

                }
    }
}
