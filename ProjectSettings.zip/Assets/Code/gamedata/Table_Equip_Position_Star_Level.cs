using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 装备部位星级表
    ///</summary>
    [Serializable]
    [TableName("equip_position_star_level")]
    public partial class Table_Equip_Position_Star_Level : TableContent
    {

        private static List<Table_Equip_Position_Star_Level> all_Table_Equip_Position_Star_Level_List = new List<Table_Equip_Position_Star_Level>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Equip_Position_Star_Level > > pool_primary = new Dictionary<int, Dictionary<int, Table_Equip_Position_Star_Level > > ();
        
        
        ///<summary>
        /// 部位
        ///</summary>
        public int postion;
        
        
        ///<summary>
        /// 星级
        ///</summary>
        public int star_level;
        
        
        ///<summary>
        /// 基础价值
        ///</summary>
        public int basic_value;
        
        
        ///<summary>
        /// 耐久系数
        ///</summary>
        public int durability_ratio;
        
        
        ///<summary>
        /// 解绑消耗道具ID
        ///</summary>
        public int unbind_cost_item_id;
        
        
        ///<summary>
        /// 解绑消耗道具数量
        ///</summary>
        public int unbind_cost_item_num;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param postion> 部位</param>
        ///
        public static Dictionary<int, Table_Equip_Position_Star_Level > GetPrimary ( int _postion ){        
            Dictionary<int, Table_Equip_Position_Star_Level > _map0=null;        
            pool_primary. TryGetValue(_postion,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param postion> 部位</param>
        ///	<param starLevel> 星级</param>
        ///
        public static Table_Equip_Position_Star_Level GetPrimary ( int _postion , int _starLevel ){        
            Dictionary<int, Table_Equip_Position_Star_Level > _map0=null;        
            pool_primary. TryGetValue(_postion,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Equip_Position_Star_Level _map1=null;        
            _map0. TryGetValue(_starLevel,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Equip_Position_Star_Level > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Equip_Position_Star_Level> GetAllPrimaryList()
        {
            return all_Table_Equip_Position_Star_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("postion", out _currValue))
            {
                this.postion = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star_level", out _currValue))
            {
                this.star_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_value", out _currValue))
            {
                this.basic_value = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("durability_ratio", out _currValue))
            {
                this.durability_ratio = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unbind_cost_item_id", out _currValue))
            {
                this.unbind_cost_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("unbind_cost_item_num", out _currValue))
            {
                this.unbind_cost_item_num = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "equip_position_star_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "postion":
                    return this.postion;
                case "star_level":
                    return this.star_level;
                case "basic_value":
                    return this.basic_value;
                case "durability_ratio":
                    return this.durability_ratio;
                case "unbind_cost_item_id":
                    return this.unbind_cost_item_id;
                case "unbind_cost_item_num":
                    return this.unbind_cost_item_num;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Equip_Position_Star_Level> rows = _rows as List<Table_Equip_Position_Star_Level>;
            pool_primary=TableContent.ListToPool < int, int, Table_Equip_Position_Star_Level > ( rows, "map", "postion", "star_level" );
            all_Table_Equip_Position_Star_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Equip_Position_Star_Level_List.Clear();
        }
    }
}
