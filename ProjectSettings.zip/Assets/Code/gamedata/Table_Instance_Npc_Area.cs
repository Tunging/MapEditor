using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 触发器刷怪区域
    ///</summary>
    [Serializable]
    [TableName("instance_npc_area")]
    public partial class Table_Instance_Npc_Area : TableContent
    {

        private static List<Table_Instance_Npc_Area> all_Table_Instance_Npc_Area_List = new List<Table_Instance_Npc_Area>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Instance_Npc_Area > > pool_primary = new Dictionary<int, Dictionary<int, Table_Instance_Npc_Area > > ();
        
        
        ///<summary>
        /// 场景id
        ///</summary>
        public int instance_id;
        
        
        ///<summary>
        /// 区域id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 半径
        ///</summary>
        public float radius;
        
        
        ///<summary>
        /// x坐标
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// y坐标
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// z坐标
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 最小随机角度(朝向)
        ///</summary>
        public int angle_from;
        
        
        ///<summary>
        /// 最大随机角度（朝向）
        ///</summary>
        public int angle_to;
        
        
        ///<summary>
        /// 引导事件顺序
        ///</summary>
        public int event_order;
        
        
        ///<summary>
        /// 关联的必现副本特性类型
        ///</summary>
        public int feature_type;
        
        
        ///<summary>
        /// npc种类数量
        ///</summary>
        public int npc_type_num;
        
        
        ///<summary>
        /// 引导事件类型
        ///</summary>
        public int guid_event_type;
        
        
        ///<summary>
        /// 怪物池1
        ///</summary>
        public int group1;
        
        
        ///<summary>
        /// 怪物池1npc数量
        ///</summary>
        public int group1_npc_count;
        
        
        ///<summary>
        /// 怪物池1权重
        ///</summary>
        public int group1_weight;
        
        
        ///<summary>
        /// 怪物池2
        ///</summary>
        public int group2;
        
        
        ///<summary>
        /// 怪物池2npc数量
        ///</summary>
        public int group2_npc_count;
        
        
        ///<summary>
        /// 怪物池2权重
        ///</summary>
        public int group2_weight;
        
        
        ///<summary>
        /// 怪物池3
        ///</summary>
        public int group3;
        
        
        ///<summary>
        /// 怪物池3npc数量
        ///</summary>
        public int group3_npc_count;
        
        
        ///<summary>
        /// 怪物池3权重
        ///</summary>
        public int group3_weight;
        
        
        ///<summary>
        /// 注释
        ///</summary>
        public string mark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param instanceId> 场景id</param>
        ///
        public static Dictionary<int, Table_Instance_Npc_Area > GetPrimary ( int _instanceId ){        
            Dictionary<int, Table_Instance_Npc_Area > _map0=null;        
            pool_primary. TryGetValue(_instanceId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param instanceId> 场景id</param>
        ///	<param id> 区域id</param>
        ///
        public static Table_Instance_Npc_Area GetPrimary ( int _instanceId , int _id ){        
            Dictionary<int, Table_Instance_Npc_Area > _map0=null;        
            pool_primary. TryGetValue(_instanceId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Instance_Npc_Area _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Instance_Npc_Area > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance_Npc_Area> GetAllPrimaryList()
        {
            return all_Table_Instance_Npc_Area_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("instance_id", out _currValue))
            {
                this.instance_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("radius", out _currValue))
            {
                this.radius = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("angle_from", out _currValue))
            {
                this.angle_from = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("angle_to", out _currValue))
            {
                this.angle_to = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("event_order", out _currValue))
            {
                this.event_order = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("feature_type", out _currValue))
            {
                this.feature_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_type_num", out _currValue))
            {
                this.npc_type_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("guid_event_type", out _currValue))
            {
                this.guid_event_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group1", out _currValue))
            {
                this.group1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group1_npc_count", out _currValue))
            {
                this.group1_npc_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group1_weight", out _currValue))
            {
                this.group1_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group2", out _currValue))
            {
                this.group2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group2_npc_count", out _currValue))
            {
                this.group2_npc_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group2_weight", out _currValue))
            {
                this.group2_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group3", out _currValue))
            {
                this.group3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group3_npc_count", out _currValue))
            {
                this.group3_npc_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group3_weight", out _currValue))
            {
                this.group3_weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("mark", out _currValue))
            {
                this.mark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance_npc_area";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "instance_id":
                    return this.instance_id;
                case "id":
                    return this.id;
                case "radius":
                    return this.radius;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "angle_from":
                    return this.angle_from;
                case "angle_to":
                    return this.angle_to;
                case "event_order":
                    return this.event_order;
                case "feature_type":
                    return this.feature_type;
                case "npc_type_num":
                    return this.npc_type_num;
                case "guid_event_type":
                    return this.guid_event_type;
                case "group1":
                    return this.group1;
                case "group1_npc_count":
                    return this.group1_npc_count;
                case "group1_weight":
                    return this.group1_weight;
                case "group2":
                    return this.group2;
                case "group2_npc_count":
                    return this.group2_npc_count;
                case "group2_weight":
                    return this.group2_weight;
                case "group3":
                    return this.group3;
                case "group3_npc_count":
                    return this.group3_npc_count;
                case "group3_weight":
                    return this.group3_weight;
                case "mark":
                    return this.mark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance_Npc_Area> rows = _rows as List<Table_Instance_Npc_Area>;
            pool_primary=TableContent.ListToPool < int, int, Table_Instance_Npc_Area > ( rows, "map", "instance_id", "id" );
            all_Table_Instance_Npc_Area_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_Npc_Area_List.Clear();
        }
    }
}
