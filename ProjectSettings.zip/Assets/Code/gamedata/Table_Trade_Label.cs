using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 交易标签
    ///</summary>
    [Serializable]
    [TableName("trade_label")]
    public partial class Table_Trade_Label : TableContent
    {

        private static List<Table_Trade_Label> all_Table_Trade_Label_List = new List<Table_Trade_Label>();
        //primary | 主键
        public static Dictionary<int, Table_Trade_Label > pool_primary = new Dictionary<int, Table_Trade_Label > ();
        
        
        ///<summary>
        /// ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 层级（1,2,3）
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 上级标签
        ///</summary>
        public int first_parent;
        
        
        ///<summary>
        /// 图标
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 排序
        ///</summary>
        public int order;
        
        
        ///<summary>
        /// 是否显示品质过滤
        ///</summary>
        public bool show_quality_condition;
        
        
        ///<summary>
        /// 是否显示等级过滤
        ///</summary>
        public bool show_level_condition;
        
        
        ///<summary>
        /// 是否显示在公示中
        ///</summary>
        public bool show_in_announce;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> ID</param>
        ///
        public static Table_Trade_Label GetPrimary ( int _id ){        
            Table_Trade_Label _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Trade_Label > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Trade_Label> GetAllPrimaryList()
        {
            return all_Table_Trade_Label_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("first_parent", out _currValue))
            {
                this.first_parent = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("order", out _currValue))
            {
                this.order = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_quality_condition", out _currValue))
            {
                this.show_quality_condition = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_level_condition", out _currValue))
            {
                this.show_level_condition = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_in_announce", out _currValue))
            {
                this.show_in_announce = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "trade_label";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "level":
                    return this.level;
                case "first_parent":
                    return this.first_parent;
                case "icon":
                    return this.icon;
                case "order":
                    return this.order;
                case "show_quality_condition":
                    return this.show_quality_condition;
                case "show_level_condition":
                    return this.show_level_condition;
                case "show_in_announce":
                    return this.show_in_announce;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Trade_Label> rows = _rows as List<Table_Trade_Label>;
            pool_primary=TableContent.ListToPool < int, Table_Trade_Label > ( rows, "map", "id" );
            all_Table_Trade_Label_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Trade_Label_List.Clear();
        }
    }
}
