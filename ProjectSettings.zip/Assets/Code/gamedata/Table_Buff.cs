using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// BUFF
    ///</summary>
    [Serializable]
    [TableName("buff")]
    public partial class Table_Buff : TableContent
    {

        private static List<Table_Buff> all_Table_Buff_List = new List<Table_Buff>();
        //primary | 主键
        public static Dictionary<int, Table_Buff > pool_primary = new Dictionary<int, Table_Buff > ();
        //skillGroupId | 
        public static Dictionary<int, List<Table_Buff> > pool_skillGroupId = new Dictionary<int, List<Table_Buff> > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 是否在UI上显示
        ///</summary>
        public bool is_show_ui;
        
        
        ///<summary>
        /// 特效ID
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 关联载具ID
        ///</summary>
        public int carrier_id;
        
        
        ///<summary>
        /// 触发的技能
        ///</summary>
        public int use_skill_id;
        
        
        ///<summary>
        /// 需要替换的技能栏位id
        ///</summary>
        public int replace_skillbar_id;
        
        
        ///<summary>
        /// 需要替换的技能组id
        ///</summary>
        public int replace_skill_group_id;
        
        
        ///<summary>
        /// 替换后的新技能组id
        ///</summary>
        public int new_skill_group_id;
        
        
        ///<summary>
        /// 全屏特效 id
        ///</summary>
        public int ui_full_screen_effect;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Buff GetPrimary ( int _id ){        
            Table_Buff _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Buff > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param newSkillGroupId> 替换后的新技能组id</param>
        ///
        public static List<Table_Buff> GetSkillGroupId ( int _newSkillGroupId ){        
            List<Table_Buff> _map0=null;        
            pool_skillGroupId. TryGetValue(_newSkillGroupId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Buff> > GetAllSkillGroupId()
        {
            return pool_skillGroupId;
        }


        ///查询出所有的数据
        public static List<Table_Buff> GetAllPrimaryList()
        {
            return all_Table_Buff_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("is_show_ui", out _currValue))
            {
                this.is_show_ui = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("carrier_id", out _currValue))
            {
                this.carrier_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("use_skill_id", out _currValue))
            {
                this.use_skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("replace_skillbar_id", out _currValue))
            {
                this.replace_skillbar_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("replace_skill_group_id", out _currValue))
            {
                this.replace_skill_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("new_skill_group_id", out _currValue))
            {
                this.new_skill_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_full_screen_effect", out _currValue))
            {
                this.ui_full_screen_effect = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "buff";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "is_show_ui":
                    return this.is_show_ui;
                case "effect_id":
                    return this.effect_id;
                case "carrier_id":
                    return this.carrier_id;
                case "use_skill_id":
                    return this.use_skill_id;
                case "replace_skillbar_id":
                    return this.replace_skillbar_id;
                case "replace_skill_group_id":
                    return this.replace_skill_group_id;
                case "new_skill_group_id":
                    return this.new_skill_group_id;
                case "ui_full_screen_effect":
                    return this.ui_full_screen_effect;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Buff> rows = _rows as List<Table_Buff>;
            pool_primary=TableContent.ListToPool < int, Table_Buff > ( rows, "map", "id" );
            pool_skillGroupId=TableContent.ListToPoolList < int, Table_Buff > ( rows, "list", "new_skill_group_id" );
            all_Table_Buff_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_skillGroupId.Clear();
            all_Table_Buff_List.Clear();
        }
    }
}
