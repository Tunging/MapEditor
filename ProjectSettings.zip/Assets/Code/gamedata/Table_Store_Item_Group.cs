using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 商品组
    ///</summary>
    [Serializable]
    [TableName("store_item_group")]
    public partial class Table_Store_Item_Group : TableContent
    {

        private static List<Table_Store_Item_Group> all_Table_Store_Item_Group_List = new List<Table_Store_Item_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Store_Item_Group > pool_primary = new Dictionary<int, Table_Store_Item_Group > ();
        
        
        ///<summary>
        /// 主键:ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 商品组id
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 物品id
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 得到物品是否绑定
        ///</summary>
        public bool bind;
        
        
        ///<summary>
        /// 物品数量
        ///</summary>
        public int item_count;
        
        
        ///<summary>
        /// 最多购买次数
        ///</summary>
        public int buy_count;
        
        
        ///<summary>
        /// 时间限制
        ///</summary>
        public bool time_limit;
        
        
        ///<summary>
        /// 开始时间
        ///</summary>
        public string begin_time;
        
        
        ///<summary>
        /// 结束时间
        ///</summary>
        public string end_time;
        
        
        ///<summary>
        /// 消耗物品id
        ///</summary>
        public int cost_item_id;
        
        
        ///<summary>
        /// 消耗物品数量
        ///</summary>
        public int cost_item_count;
        
        
        ///<summary>
        /// 折扣
        ///</summary>
        public int discount;
        
        
        ///<summary>
        /// 是否是特殊商品
        ///</summary>
        public bool special;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键:ID</param>
        ///
        public static Table_Store_Item_Group GetPrimary ( int _id ){        
            Table_Store_Item_Group _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Store_Item_Group > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Store_Item_Group> GetAllPrimaryList()
        {
            return all_Table_Store_Item_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("bind", out _currValue))
            {
                this.bind = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_count", out _currValue))
            {
                this.item_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("buy_count", out _currValue))
            {
                this.buy_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("time_limit", out _currValue))
            {
                this.time_limit = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("begin_time", out _currValue))
            {
                this.begin_time = _currValue;
            }
            if(_itemData.TryGetValue("end_time", out _currValue))
            {
                this.end_time = _currValue;
            }
            if(_itemData.TryGetValue("cost_item_id", out _currValue))
            {
                this.cost_item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("cost_item_count", out _currValue))
            {
                this.cost_item_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("discount", out _currValue))
            {
                this.discount = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("special", out _currValue))
            {
                this.special = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "store_item_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "group_id":
                    return this.group_id;
                case "item_id":
                    return this.item_id;
                case "bind":
                    return this.bind;
                case "item_count":
                    return this.item_count;
                case "buy_count":
                    return this.buy_count;
                case "time_limit":
                    return this.time_limit;
                case "begin_time":
                    return this.begin_time;
                case "end_time":
                    return this.end_time;
                case "cost_item_id":
                    return this.cost_item_id;
                case "cost_item_count":
                    return this.cost_item_count;
                case "discount":
                    return this.discount;
                case "special":
                    return this.special;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Store_Item_Group> rows = _rows as List<Table_Store_Item_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Store_Item_Group > ( rows, "map", "id" );
            all_Table_Store_Item_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Store_Item_Group_List.Clear();
        }
    }
}
