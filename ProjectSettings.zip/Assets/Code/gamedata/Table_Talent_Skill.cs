using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 天赋技能
    ///</summary>
    [Serializable]
    [TableName("talent_skill")]
    public partial class Table_Talent_Skill : TableContent
    {

        private static List<Table_Talent_Skill> all_Table_Talent_Skill_List = new List<Table_Talent_Skill>();
        //primary | 主键
        public static Dictionary<int, Table_Talent_Skill > pool_primary = new Dictionary<int, Table_Talent_Skill > ();
        
        
        ///<summary>
        /// 主键：天赋技能ID
        ///</summary>
        public int talent_skill_id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 天赋技能图标
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 词条ID
        ///</summary>
        public int entry_id;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string skill_desc_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param talentSkillId> 主键：天赋技能ID</param>
        ///
        public static Table_Talent_Skill GetPrimary ( int _talentSkillId ){        
            Table_Talent_Skill _map0=null;        
            pool_primary. TryGetValue(_talentSkillId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Talent_Skill > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Talent_Skill> GetAllPrimaryList()
        {
            return all_Table_Talent_Skill_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("talent_skill_id", out _currValue))
            {
                this.talent_skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("entry_id", out _currValue))
            {
                this.entry_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_desc_i18n", out _currValue))
            {
                this.skill_desc_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "talent_skill";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "talent_skill_id":
                    return this.talent_skill_id;
                case "remark":
                    return this.remark;
                case "icon":
                    return this.icon;
                case "entry_id":
                    return this.entry_id;
                case "skill_desc_i18n":
                    return this.skill_desc_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Talent_Skill> rows = _rows as List<Table_Talent_Skill>;
            pool_primary=TableContent.ListToPool < int, Table_Talent_Skill > ( rows, "map", "talent_skill_id" );
            all_Table_Talent_Skill_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Talent_Skill_List.Clear();
        }
    }
}
