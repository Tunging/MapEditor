using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：摄像机层级裁切
    ///</summary>
    [Serializable]
    [TableName("client_camera_culling")]
    public partial class Table_Client_Camera_Culling : TableContent
    {

        private static List<Table_Client_Camera_Culling> all_Table_Client_Camera_Culling_List = new List<Table_Client_Camera_Culling>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Camera_Culling > pool_primary = new Dictionary<int, Table_Client_Camera_Culling > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 超大物件层级的裁切距离
        ///</summary>
        public int layer1;
        
        
        ///<summary>
        /// 大物件层级的裁切距离
        ///</summary>
        public int layer2;
        
        
        ///<summary>
        /// 中物件层级的裁切距离
        ///</summary>
        public int layer3;
        
        
        ///<summary>
        /// 小物件层级的裁切距离
        ///</summary>
        public int layer4;
        
        
        ///<summary>
        /// 特效层级的裁切距离
        ///</summary>
        public int layer5;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Client_Camera_Culling GetPrimary ( int _id ){        
            Table_Client_Camera_Culling _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Camera_Culling > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Camera_Culling> GetAllPrimaryList()
        {
            return all_Table_Client_Camera_Culling_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("layer1", out _currValue))
            {
                this.layer1 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("layer2", out _currValue))
            {
                this.layer2 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("layer3", out _currValue))
            {
                this.layer3 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("layer4", out _currValue))
            {
                this.layer4 = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("layer5", out _currValue))
            {
                this.layer5 = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_camera_culling";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "layer1":
                    return this.layer1;
                case "layer2":
                    return this.layer2;
                case "layer3":
                    return this.layer3;
                case "layer4":
                    return this.layer4;
                case "layer5":
                    return this.layer5;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Camera_Culling> rows = _rows as List<Table_Client_Camera_Culling>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Camera_Culling > ( rows, "map", "id" );
            all_Table_Client_Camera_Culling_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Camera_Culling_List.Clear();
        }
    }
}
