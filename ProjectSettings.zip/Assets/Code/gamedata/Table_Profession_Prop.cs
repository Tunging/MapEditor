using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 角色职业属性
    ///</summary>
    [Serializable]
    [TableName("profession_prop")]
    public partial class Table_Profession_Prop : TableContent
    {

        private static List<Table_Profession_Prop> all_Table_Profession_Prop_List = new List<Table_Profession_Prop>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Profession_Prop > > pool_primary = new Dictionary<int, Dictionary<int, Table_Profession_Prop > > ();
        
        
        ///<summary>
        /// 主键：职业ID
        ///</summary>
        public int profession_id;
        
        
        ///<summary>
        /// 主键：等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 基础生命值
        ///</summary>
        public int basic_hp;
        
        
        ///<summary>
        /// 移动速度
        ///</summary>
        public int run_speed;
        
        
        ///<summary>
        /// 战斗中移动速度
        ///</summary>
        public int fight_run_speed;
        
        
        ///<summary>
        /// 滑翔速度
        ///</summary>
        public int gliding_speed;
        
        
        ///<summary>
        /// 游泳速度
        ///</summary>
        public int swimming_speed;
        
        
        ///<summary>
        /// 基础最大物理攻击力
        ///</summary>
        public int basic_max_physical_atk;
        
        
        ///<summary>
        /// 基础最大法术攻击力
        ///</summary>
        public int basic_max_magical_atk;
        
        
        ///<summary>
        /// 基础物理防御力
        ///</summary>
        public int basic_physical_def;
        
        
        ///<summary>
        /// 基础法术防御力
        ///</summary>
        public int basic_magical_def;
        
        
        ///<summary>
        /// 基础恢复强度
        ///</summary>
        public int basic_regeneration_power;
        
        
        ///<summary>
        /// 基础最大冰霜攻击力
        ///</summary>
        public int basic_max_ice_atk;
        
        
        ///<summary>
        /// 基础冰霜抗性
        ///</summary>
        public int basic_ice_def;
        
        
        ///<summary>
        /// 基础最大火焰攻击力
        ///</summary>
        public int basic_max_fire_atk;
        
        
        ///<summary>
        /// 基础火焰抗性
        ///</summary>
        public int basic_fire_def;
        
        
        ///<summary>
        /// 基础最大雷电攻击力
        ///</summary>
        public int basic_max_thunder_atk;
        
        
        ///<summary>
        /// 基础雷电抗性
        ///</summary>
        public int basic_thunder_def;
        
        
        ///<summary>
        /// 物理暴击值
        ///</summary>
        public int physical_critical_point;
        
        
        ///<summary>
        /// 物理韧性
        ///</summary>
        public int physical_unticritical_point;
        
        
        ///<summary>
        /// 物理暴击伤害值
        ///</summary>
        public int physical_critical_damage_point;
        
        
        ///<summary>
        /// 抗物理暴击伤害值
        ///</summary>
        public int physical_unticritical_damage_point;
        
        
        ///<summary>
        /// 法术暴击值
        ///</summary>
        public int magical_critical_point;
        
        
        ///<summary>
        /// 法术韧性
        ///</summary>
        public int magical_unticritical_point;
        
        
        ///<summary>
        /// 法术暴击伤害值
        ///</summary>
        public int magical_critical_damage_point;
        
        
        ///<summary>
        /// 抗法术暴击伤害值
        ///</summary>
        public int magical_unticritical_damage_point;
        
        
        ///<summary>
        /// 恢复暴击
        ///</summary>
        public int regeneration_critical_point;
        
        
        ///<summary>
        /// 物理命中值
        ///</summary>
        public int physical_hit_rate_point;
        
        
        ///<summary>
        /// 物理闪避值
        ///</summary>
        public int physical_dodge_rate_point;
        
        
        ///<summary>
        /// 法术命中值
        ///</summary>
        public int magical_hit_rate_point;
        
        
        ///<summary>
        /// 法术闪避值
        ///</summary>
        public int magical_dodge_rate_point;
        
        
        ///<summary>
        /// 物理破甲
        ///</summary>
        public int physical_penetration;
        
        
        ///<summary>
        /// 法术破甲
        ///</summary>
        public int magiccal_penetration;
        
        
        ///<summary>
        /// 战斗状态下生命恢复速度
        ///</summary>
        public int health_regen_in_combat;
        
        
        ///<summary>
        /// 非战斗状态下生命恢复速度
        ///</summary>
        public int health_regen_out_combat;
        
        
        ///<summary>
        /// 仇恨系数
        ///</summary>
        public int hate_ratio;
        
        
        ///<summary>
        /// 跳跃高度
        ///</summary>
        public int jump_height;
        
        
        ///<summary>
        /// 被救援恢复hp数值，千分比
        ///</summary>
        public int rescue_recover_hp;
        
        
        ///<summary>
        /// 被救援恢复mp数值，千分比
        ///</summary>
        public int rescue_recover_mp;
        
        
        ///<summary>
        /// 救援速度，单位m/ms
        ///</summary>
        public int rescue_speed;
        
        
        ///<summary>
        /// 一级消耗上限
        ///</summary>
        public int chakra_total;
        
        
        ///<summary>
        /// 一级消耗战斗中恢复速度
        ///</summary>
        public int chakra_fight_recover;
        
        
        ///<summary>
        /// 一级消耗非战斗中恢复速度
        ///</summary>
        public int chakra_nofight_recover;
        
        
        ///<summary>
        /// 一级消耗保留值
        ///</summary>
        public int chakra_retain;
        
        
        ///<summary>
        /// 受击时获得一级消耗值
        ///</summary>
        public int chakra_be_attack;
        
        
        ///<summary>
        /// 连击点上限
        ///</summary>
        public int total_combo_point;
        
        
        ///<summary>
        /// 二段跳跳跃高度
        ///</summary>
        public int two_jump_high;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param professionId> 主键：职业ID</param>
        ///
        public static Dictionary<int, Table_Profession_Prop > GetPrimary ( int _professionId ){        
            Dictionary<int, Table_Profession_Prop > _map0=null;        
            pool_primary. TryGetValue(_professionId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param professionId> 主键：职业ID</param>
        ///	<param level> 主键：等级</param>
        ///
        public static Table_Profession_Prop GetPrimary ( int _professionId , int _level ){        
            Dictionary<int, Table_Profession_Prop > _map0=null;        
            pool_primary. TryGetValue(_professionId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Profession_Prop _map1=null;        
            _map0. TryGetValue(_level,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Profession_Prop > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Profession_Prop> GetAllPrimaryList()
        {
            return all_Table_Profession_Prop_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("profession_id", out _currValue))
            {
                this.profession_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("basic_hp", out _currValue))
            {
                this.basic_hp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("run_speed", out _currValue))
            {
                this.run_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fight_run_speed", out _currValue))
            {
                this.fight_run_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gliding_speed", out _currValue))
            {
                this.gliding_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("swimming_speed", out _currValue))
            {
                this.swimming_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_max_physical_atk", out _currValue))
            {
                this.basic_max_physical_atk = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_max_magical_atk", out _currValue))
            {
                this.basic_max_magical_atk = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_physical_def", out _currValue))
            {
                this.basic_physical_def = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_magical_def", out _currValue))
            {
                this.basic_magical_def = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_regeneration_power", out _currValue))
            {
                this.basic_regeneration_power = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_max_ice_atk", out _currValue))
            {
                this.basic_max_ice_atk = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_ice_def", out _currValue))
            {
                this.basic_ice_def = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_max_fire_atk", out _currValue))
            {
                this.basic_max_fire_atk = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_fire_def", out _currValue))
            {
                this.basic_fire_def = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_max_thunder_atk", out _currValue))
            {
                this.basic_max_thunder_atk = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("basic_thunder_def", out _currValue))
            {
                this.basic_thunder_def = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_critical_point", out _currValue))
            {
                this.physical_critical_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_unticritical_point", out _currValue))
            {
                this.physical_unticritical_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_critical_damage_point", out _currValue))
            {
                this.physical_critical_damage_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_unticritical_damage_point", out _currValue))
            {
                this.physical_unticritical_damage_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magical_critical_point", out _currValue))
            {
                this.magical_critical_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magical_unticritical_point", out _currValue))
            {
                this.magical_unticritical_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magical_critical_damage_point", out _currValue))
            {
                this.magical_critical_damage_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magical_unticritical_damage_point", out _currValue))
            {
                this.magical_unticritical_damage_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("regeneration_critical_point", out _currValue))
            {
                this.regeneration_critical_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_hit_rate_point", out _currValue))
            {
                this.physical_hit_rate_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_dodge_rate_point", out _currValue))
            {
                this.physical_dodge_rate_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magical_hit_rate_point", out _currValue))
            {
                this.magical_hit_rate_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magical_dodge_rate_point", out _currValue))
            {
                this.magical_dodge_rate_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("physical_penetration", out _currValue))
            {
                this.physical_penetration = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("magiccal_penetration", out _currValue))
            {
                this.magiccal_penetration = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("health_regen_in_combat", out _currValue))
            {
                this.health_regen_in_combat = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("health_regen_out_combat", out _currValue))
            {
                this.health_regen_out_combat = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("hate_ratio", out _currValue))
            {
                this.hate_ratio = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("jump_height", out _currValue))
            {
                this.jump_height = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("rescue_recover_hp", out _currValue))
            {
                this.rescue_recover_hp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("rescue_recover_mp", out _currValue))
            {
                this.rescue_recover_mp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("rescue_speed", out _currValue))
            {
                this.rescue_speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_total", out _currValue))
            {
                this.chakra_total = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_fight_recover", out _currValue))
            {
                this.chakra_fight_recover = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_nofight_recover", out _currValue))
            {
                this.chakra_nofight_recover = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_retain", out _currValue))
            {
                this.chakra_retain = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_be_attack", out _currValue))
            {
                this.chakra_be_attack = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("total_combo_point", out _currValue))
            {
                this.total_combo_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("two_jump_high", out _currValue))
            {
                this.two_jump_high = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "profession_prop";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "profession_id":
                    return this.profession_id;
                case "level":
                    return this.level;
                case "name":
                    return this.name;
                case "basic_hp":
                    return this.basic_hp;
                case "run_speed":
                    return this.run_speed;
                case "fight_run_speed":
                    return this.fight_run_speed;
                case "gliding_speed":
                    return this.gliding_speed;
                case "swimming_speed":
                    return this.swimming_speed;
                case "basic_max_physical_atk":
                    return this.basic_max_physical_atk;
                case "basic_max_magical_atk":
                    return this.basic_max_magical_atk;
                case "basic_physical_def":
                    return this.basic_physical_def;
                case "basic_magical_def":
                    return this.basic_magical_def;
                case "basic_regeneration_power":
                    return this.basic_regeneration_power;
                case "basic_max_ice_atk":
                    return this.basic_max_ice_atk;
                case "basic_ice_def":
                    return this.basic_ice_def;
                case "basic_max_fire_atk":
                    return this.basic_max_fire_atk;
                case "basic_fire_def":
                    return this.basic_fire_def;
                case "basic_max_thunder_atk":
                    return this.basic_max_thunder_atk;
                case "basic_thunder_def":
                    return this.basic_thunder_def;
                case "physical_critical_point":
                    return this.physical_critical_point;
                case "physical_unticritical_point":
                    return this.physical_unticritical_point;
                case "physical_critical_damage_point":
                    return this.physical_critical_damage_point;
                case "physical_unticritical_damage_point":
                    return this.physical_unticritical_damage_point;
                case "magical_critical_point":
                    return this.magical_critical_point;
                case "magical_unticritical_point":
                    return this.magical_unticritical_point;
                case "magical_critical_damage_point":
                    return this.magical_critical_damage_point;
                case "magical_unticritical_damage_point":
                    return this.magical_unticritical_damage_point;
                case "regeneration_critical_point":
                    return this.regeneration_critical_point;
                case "physical_hit_rate_point":
                    return this.physical_hit_rate_point;
                case "physical_dodge_rate_point":
                    return this.physical_dodge_rate_point;
                case "magical_hit_rate_point":
                    return this.magical_hit_rate_point;
                case "magical_dodge_rate_point":
                    return this.magical_dodge_rate_point;
                case "physical_penetration":
                    return this.physical_penetration;
                case "magiccal_penetration":
                    return this.magiccal_penetration;
                case "health_regen_in_combat":
                    return this.health_regen_in_combat;
                case "health_regen_out_combat":
                    return this.health_regen_out_combat;
                case "hate_ratio":
                    return this.hate_ratio;
                case "jump_height":
                    return this.jump_height;
                case "rescue_recover_hp":
                    return this.rescue_recover_hp;
                case "rescue_recover_mp":
                    return this.rescue_recover_mp;
                case "rescue_speed":
                    return this.rescue_speed;
                case "chakra_total":
                    return this.chakra_total;
                case "chakra_fight_recover":
                    return this.chakra_fight_recover;
                case "chakra_nofight_recover":
                    return this.chakra_nofight_recover;
                case "chakra_retain":
                    return this.chakra_retain;
                case "chakra_be_attack":
                    return this.chakra_be_attack;
                case "total_combo_point":
                    return this.total_combo_point;
                case "two_jump_high":
                    return this.two_jump_high;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Profession_Prop> rows = _rows as List<Table_Profession_Prop>;
            pool_primary=TableContent.ListToPool < int, int, Table_Profession_Prop > ( rows, "map", "profession_id", "level" );
            all_Table_Profession_Prop_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Profession_Prop_List.Clear();
        }
    }
}
