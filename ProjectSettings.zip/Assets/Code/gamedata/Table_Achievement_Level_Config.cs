using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 成就等级相关配置数据
    ///</summary>
    [Serializable]
    [TableName("achievement_level_config")]
    public partial class Table_Achievement_Level_Config : TableContent
    {

        private static List<Table_Achievement_Level_Config> all_Table_Achievement_Level_Config_List = new List<Table_Achievement_Level_Config>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Achievement_Level_Config > > pool_primary = new Dictionary<int, Dictionary<int, Table_Achievement_Level_Config > > ();
        
        
        ///<summary>
        /// 分类id
        ///</summary>
        public int classify_id;
        
        
        ///<summary>
        /// 等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 需要的总进度
        ///</summary>
        public int total_need_progress;
        
        
        ///<summary>
        /// 奖励id
        ///</summary>
        public int reward_id;
        
        
        ///<summary>
        /// 等级图标id
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param classifyId> 分类id</param>
        ///
        public static Dictionary<int, Table_Achievement_Level_Config > GetPrimary ( int _classifyId ){        
            Dictionary<int, Table_Achievement_Level_Config > _map0=null;        
            pool_primary. TryGetValue(_classifyId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param classifyId> 分类id</param>
        ///	<param level> 等级</param>
        ///
        public static Table_Achievement_Level_Config GetPrimary ( int _classifyId , int _level ){        
            Dictionary<int, Table_Achievement_Level_Config > _map0=null;        
            pool_primary. TryGetValue(_classifyId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Achievement_Level_Config _map1=null;        
            _map0. TryGetValue(_level,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Achievement_Level_Config > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Achievement_Level_Config> GetAllPrimaryList()
        {
            return all_Table_Achievement_Level_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("classify_id", out _currValue))
            {
                this.classify_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("total_need_progress", out _currValue))
            {
                this.total_need_progress = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward_id", out _currValue))
            {
                this.reward_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "achievement_level_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "classify_id":
                    return this.classify_id;
                case "level":
                    return this.level;
                case "total_need_progress":
                    return this.total_need_progress;
                case "reward_id":
                    return this.reward_id;
                case "icon_id":
                    return this.icon_id;
                case "name_i18n":
                    return this.name_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Achievement_Level_Config> rows = _rows as List<Table_Achievement_Level_Config>;
            pool_primary=TableContent.ListToPool < int, int, Table_Achievement_Level_Config > ( rows, "map", "classify_id", "level" );
            all_Table_Achievement_Level_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Achievement_Level_Config_List.Clear();
        }
    }
}
