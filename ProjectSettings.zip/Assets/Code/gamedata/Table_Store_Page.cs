using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 商店页
    ///</summary>
    [Serializable]
    [TableName("store_page")]
    public partial class Table_Store_Page : TableContent
    {

        private static List<Table_Store_Page> all_Table_Store_Page_List = new List<Table_Store_Page>();
        //primary | 主键
        public static Dictionary<int, Table_Store_Page > pool_primary = new Dictionary<int, Table_Store_Page > ();
        
        
        ///<summary>
        /// 主键:ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 商店id
        ///</summary>
        public int store_id;
        
        
        ///<summary>
        /// 页序号
        ///</summary>
        public int number;
        
        
        ///<summary>
        /// 页签icon
        ///</summary>
        public int icon;
        
        
        ///<summary>
        /// 页名称国际化
        ///</summary>
        public string name_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键:ID</param>
        ///
        public static Table_Store_Page GetPrimary ( int _id ){        
            Table_Store_Page _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Store_Page > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Store_Page> GetAllPrimaryList()
        {
            return all_Table_Store_Page_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("store_id", out _currValue))
            {
                this.store_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("number", out _currValue))
            {
                this.number = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon", out _currValue))
            {
                this.icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "store_page";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "store_id":
                    return this.store_id;
                case "number":
                    return this.number;
                case "icon":
                    return this.icon;
                case "name_i18n":
                    return this.name_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Store_Page> rows = _rows as List<Table_Store_Page>;
            pool_primary=TableContent.ListToPool < int, Table_Store_Page > ( rows, "map", "id" );
            all_Table_Store_Page_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Store_Page_List.Clear();
        }
    }
}
