using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 配置表常量定义
    ///</summary>
    [Serializable]
    [TableName("config_consts_def")]
    public partial class Table_Config_Consts_Def : TableContent
    {

        private static List<Table_Config_Consts_Def> all_Table_Config_Consts_Def_List = new List<Table_Config_Consts_Def>();
        //primary | 主键
        public static Dictionary<string, Dictionary<string, Table_Config_Consts_Def > > pool_primary = new Dictionary<string, Dictionary<string, Table_Config_Consts_Def > > ();
        
        
        ///<summary>
        /// 主键：包名
        ///</summary>
        public string package_name;
        
        
        ///<summary>
        /// 主键：类名
        ///</summary>
        public string class_name;
        
        
        ///<summary>
        /// 表名
        ///</summary>
        public string table_name;
        
        
        ///<summary>
        /// 模板名
        ///</summary>
        public string template_name;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packageName> 主键：包名</param>
        ///
        public static Dictionary<string, Table_Config_Consts_Def > GetPrimary ( string _packageName ){        
            Dictionary<string, Table_Config_Consts_Def > _map0=null;        
            pool_primary. TryGetValue(_packageName,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packageName> 主键：包名</param>
        ///	<param className> 主键：类名</param>
        ///
        public static Table_Config_Consts_Def GetPrimary ( string _packageName , string _className ){        
            Dictionary<string, Table_Config_Consts_Def > _map0=null;        
            pool_primary. TryGetValue(_packageName,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Config_Consts_Def _map1=null;        
            _map0. TryGetValue(_className,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<string, Dictionary<string, Table_Config_Consts_Def > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Config_Consts_Def> GetAllPrimaryList()
        {
            return all_Table_Config_Consts_Def_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("package_name", out _currValue))
            {
                this.package_name = _currValue;
            }
            if(_itemData.TryGetValue("class_name", out _currValue))
            {
                this.class_name = _currValue;
            }
            if(_itemData.TryGetValue("table_name", out _currValue))
            {
                this.table_name = _currValue;
            }
            if(_itemData.TryGetValue("template_name", out _currValue))
            {
                this.template_name = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "config_consts_def";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "package_name":
                    return this.package_name;
                case "class_name":
                    return this.class_name;
                case "table_name":
                    return this.table_name;
                case "template_name":
                    return this.template_name;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Config_Consts_Def> rows = _rows as List<Table_Config_Consts_Def>;
            pool_primary=TableContent.ListToPool < string, string, Table_Config_Consts_Def > ( rows, "map", "package_name", "class_name" );
            all_Table_Config_Consts_Def_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Config_Consts_Def_List.Clear();
        }
    }
}
