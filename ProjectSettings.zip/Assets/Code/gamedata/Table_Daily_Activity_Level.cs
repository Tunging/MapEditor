using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 日常活动活跃度档位表
    ///</summary>
    [Serializable]
    [TableName("daily_activity_level")]
    public partial class Table_Daily_Activity_Level : TableContent
    {

        private static List<Table_Daily_Activity_Level> all_Table_Daily_Activity_Level_List = new List<Table_Daily_Activity_Level>();
        //primary | 主键
        public static Dictionary<int, Table_Daily_Activity_Level > pool_primary = new Dictionary<int, Table_Daily_Activity_Level > ();
        
        
        ///<summary>
        /// 主键：活跃度档位
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 要求活跃度
        ///</summary>
        public int activeness;
        
        
        ///<summary>
        /// 奖励ID
        ///</summary>
        public int reward_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：活跃度档位</param>
        ///
        public static Table_Daily_Activity_Level GetPrimary ( int _id ){        
            Table_Daily_Activity_Level _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Daily_Activity_Level > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Daily_Activity_Level> GetAllPrimaryList()
        {
            return all_Table_Daily_Activity_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("activeness", out _currValue))
            {
                this.activeness = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reward_id", out _currValue))
            {
                this.reward_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "daily_activity_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "activeness":
                    return this.activeness;
                case "reward_id":
                    return this.reward_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Daily_Activity_Level> rows = _rows as List<Table_Daily_Activity_Level>;
            pool_primary=TableContent.ListToPool < int, Table_Daily_Activity_Level > ( rows, "map", "id" );
            all_Table_Daily_Activity_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Daily_Activity_Level_List.Clear();
        }
    }
}
