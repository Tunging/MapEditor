using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// GM模板参数
    ///</summary>
    [Serializable]
    [TableName("gm_param")]
    public partial class Table_Gm_Param : TableContent
    {

        private static List<Table_Gm_Param> all_Table_Gm_Param_List = new List<Table_Gm_Param>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Gm_Param > > pool_primary = new Dictionary<int, Dictionary<int, Table_Gm_Param > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 主键：参数索引
        ///</summary>
        public int param_index;
        
        
        ///<summary>
        /// 属性名
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 属性名注释
        ///</summary>
        public string lable;
        
        
        ///<summary>
        /// 参数类型
        ///</summary>
        public string type;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Dictionary<int, Table_Gm_Param > GetPrimary ( int _id ){        
            Dictionary<int, Table_Gm_Param > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///	<param paramIndex> 主键：参数索引</param>
        ///
        public static Table_Gm_Param GetPrimary ( int _id , int _paramIndex ){        
            Dictionary<int, Table_Gm_Param > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Gm_Param _map1=null;        
            _map0. TryGetValue(_paramIndex,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Gm_Param > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Gm_Param> GetAllPrimaryList()
        {
            return all_Table_Gm_Param_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("param_index", out _currValue))
            {
                this.param_index = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("lable", out _currValue))
            {
                this.lable = _currValue;
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "gm_param";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "param_index":
                    return this.param_index;
                case "name":
                    return this.name;
                case "lable":
                    return this.lable;
                case "type":
                    return this.type;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Gm_Param> rows = _rows as List<Table_Gm_Param>;
            pool_primary=TableContent.ListToPool < int, int, Table_Gm_Param > ( rows, "map", "id", "param_index" );
            all_Table_Gm_Param_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Gm_Param_List.Clear();
        }
    }
}
