using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc喊话
    ///</summary>
    [Serializable]
    [TableName("npc_text")]
    public partial class Table_Npc_Text : TableContent
    {

        private static List<Table_Npc_Text> all_Table_Npc_Text_List = new List<Table_Npc_Text>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Text > pool_primary = new Dictionary<int, Table_Npc_Text > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 说话内容，国际化
        ///</summary>
        public string text_i18n;
        
        
        ///<summary>
        /// 表演时间
        ///</summary>
        public int show_time;
        
        
        ///<summary>
        /// 声音id
        ///</summary>
        public int sound_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Npc_Text GetPrimary ( int _id ){        
            Table_Npc_Text _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Text > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Text> GetAllPrimaryList()
        {
            return all_Table_Npc_Text_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text_i18n", out _currValue))
            {
                this.text_i18n = _currValue;
            }
            if(_itemData.TryGetValue("show_time", out _currValue))
            {
                this.show_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_text";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "text_i18n":
                    return this.text_i18n;
                case "show_time":
                    return this.show_time;
                case "sound_id":
                    return this.sound_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Text> rows = _rows as List<Table_Npc_Text>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Text > ( rows, "map", "id" );
            all_Table_Npc_Text_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Text_List.Clear();
        }
    }
}
