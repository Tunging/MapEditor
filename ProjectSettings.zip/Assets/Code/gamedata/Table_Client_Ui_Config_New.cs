using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 新的客户端资源配置表
    ///</summary>
    [Serializable]
    [TableName("client_ui_config_new")]
    public partial class Table_Client_Ui_Config_New : TableContent
    {

        private static List<Table_Client_Ui_Config_New> all_Table_Client_Ui_Config_New_List = new List<Table_Client_Ui_Config_New>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Ui_Config_New > pool_primary = new Dictionary<int, Table_Client_Ui_Config_New > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 界面的枚举名字
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// UI的外链显示名字
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// ui的资源名字
        ///</summary>
        public string ui_res_name;
        
        
        ///<summary>
        /// 父界面的编号
        ///</summary>
        public int ui_parent_id;
        
        
        ///<summary>
        /// 在父界面中的索引值
        ///</summary>
        public int ui_inparent_tabindex;
        
        
        ///<summary>
        /// 在父面板的挂点
        ///</summary>
        public string ui_parent_link_point;
        
        
        ///<summary>
        /// 面板深度类型
        ///</summary>
        public int ui_depth_type;
        
        
        ///<summary>
        /// UI外显名称 需要配置在国际化的表中
        ///</summary>
        public int ui_show_name;
        
        
        ///<summary>
        /// UI Icon的名字
        ///</summary>
        public int ui_icon_id;
        
        
        ///<summary>
        /// 定义窗口的级别
        ///</summary>
        public int ui_type;
        
        
        ///<summary>
        /// UI背景界面的类型
        ///</summary>
        public int ui_background_type;
        
        
        ///<summary>
        /// 打开的UI的时候的动画处理ID
        ///</summary>
        public int ui_open_animtion_id;
        
        
        ///<summary>
        /// 关闭的UI的时候的动画处理ID
        ///</summary>
        public int ui_close_animation_id;
        
        
        ///<summary>
        /// 打开UI的时候的声音ID
        ///</summary>
        public int ui_open_sound_id;
        
        
        ///<summary>
        /// 关闭UI的时候的声音ID
        ///</summary>
        public int ui_close_sound_id;
        
        
        ///<summary>
        /// ui互斥关系
        ///</summary>
        public int ui_mutex;
        
        
        ///<summary>
        /// ui共存关系
        ///</summary>
        public int ui_coexist;
        
        
        ///<summary>
        /// ui共存关闭关系
        ///</summary>
        public int ui_close_coexist;
        
        
        ///<summary>
        /// ui是否能打开的开关控制
        ///</summary>
        public int ui_can_open;
        
        
        ///<summary>
        /// ui不能打开的时候的原因
        ///</summary>
        public int ui_cannot_open_reson;
        
        
        ///<summary>
        /// Tips出现的时候的偏移X轴坐标
        ///</summary>
        public int tips_offset_x;
        
        
        ///<summary>
        /// Tips出现的时候的偏移Y轴坐标
        ///</summary>
        public int tips_offset_y;
        
        
        ///<summary>
        /// 窗口堆栈关系，有关闭时候相互关系的同类面板
        ///</summary>
        public int ui_stack_group;
        
        
        ///<summary>
        /// 当前界面打开时，摇杆是否可用
        ///</summary>
        public bool can_use_joystick;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Client_Ui_Config_New GetPrimary ( int _id ){        
            Table_Client_Ui_Config_New _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Ui_Config_New > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Ui_Config_New> GetAllPrimaryList()
        {
            return all_Table_Client_Ui_Config_New_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("ui_res_name", out _currValue))
            {
                this.ui_res_name = _currValue;
            }
            if(_itemData.TryGetValue("ui_parent_id", out _currValue))
            {
                this.ui_parent_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_inparent_tabindex", out _currValue))
            {
                this.ui_inparent_tabindex = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_parent_link_point", out _currValue))
            {
                this.ui_parent_link_point = _currValue;
            }
            if(_itemData.TryGetValue("ui_depth_type", out _currValue))
            {
                this.ui_depth_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_show_name", out _currValue))
            {
                this.ui_show_name = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_icon_id", out _currValue))
            {
                this.ui_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_type", out _currValue))
            {
                this.ui_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_background_type", out _currValue))
            {
                this.ui_background_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_open_animtion_id", out _currValue))
            {
                this.ui_open_animtion_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_close_animation_id", out _currValue))
            {
                this.ui_close_animation_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_open_sound_id", out _currValue))
            {
                this.ui_open_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_close_sound_id", out _currValue))
            {
                this.ui_close_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_mutex", out _currValue))
            {
                this.ui_mutex = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_coexist", out _currValue))
            {
                this.ui_coexist = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_close_coexist", out _currValue))
            {
                this.ui_close_coexist = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_can_open", out _currValue))
            {
                this.ui_can_open = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_cannot_open_reson", out _currValue))
            {
                this.ui_cannot_open_reson = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("tips_offset_x", out _currValue))
            {
                this.tips_offset_x = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("tips_offset_y", out _currValue))
            {
                this.tips_offset_y = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ui_stack_group", out _currValue))
            {
                this.ui_stack_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("can_use_joystick", out _currValue))
            {
                this.can_use_joystick = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_ui_config_new";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                case "ui_res_name":
                    return this.ui_res_name;
                case "ui_parent_id":
                    return this.ui_parent_id;
                case "ui_inparent_tabindex":
                    return this.ui_inparent_tabindex;
                case "ui_parent_link_point":
                    return this.ui_parent_link_point;
                case "ui_depth_type":
                    return this.ui_depth_type;
                case "ui_show_name":
                    return this.ui_show_name;
                case "ui_icon_id":
                    return this.ui_icon_id;
                case "ui_type":
                    return this.ui_type;
                case "ui_background_type":
                    return this.ui_background_type;
                case "ui_open_animtion_id":
                    return this.ui_open_animtion_id;
                case "ui_close_animation_id":
                    return this.ui_close_animation_id;
                case "ui_open_sound_id":
                    return this.ui_open_sound_id;
                case "ui_close_sound_id":
                    return this.ui_close_sound_id;
                case "ui_mutex":
                    return this.ui_mutex;
                case "ui_coexist":
                    return this.ui_coexist;
                case "ui_close_coexist":
                    return this.ui_close_coexist;
                case "ui_can_open":
                    return this.ui_can_open;
                case "ui_cannot_open_reson":
                    return this.ui_cannot_open_reson;
                case "tips_offset_x":
                    return this.tips_offset_x;
                case "tips_offset_y":
                    return this.tips_offset_y;
                case "ui_stack_group":
                    return this.ui_stack_group;
                case "can_use_joystick":
                    return this.can_use_joystick;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Ui_Config_New> rows = _rows as List<Table_Client_Ui_Config_New>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Ui_Config_New > ( rows, "map", "id" );
            all_Table_Client_Ui_Config_New_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Ui_Config_New_List.Clear();
        }
    }
}
