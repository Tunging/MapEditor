using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 固定奖励表
    ///</summary>
    [Serializable]
    [TableName("reward_pack_fix")]
    public partial class Table_Reward_Pack_Fix : TableContent
    {

        private static List<Table_Reward_Pack_Fix> all_Table_Reward_Pack_Fix_List = new List<Table_Reward_Pack_Fix>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Reward_Pack_Fix > > pool_primary = new Dictionary<int, Dictionary<int, Table_Reward_Pack_Fix > > ();
        
        
        ///<summary>
        /// 固定奖励包id
        ///</summary>
        public int pack_id;
        
        
        ///<summary>
        /// 序号
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 物品id
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 数量下限
        ///</summary>
        public int item_num_down;
        
        
        ///<summary>
        /// 数量上限
        ///</summary>
        public int item_num_up;
        
        
        ///<summary>
        /// 策划备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packId> 固定奖励包id</param>
        ///
        public static Dictionary<int, Table_Reward_Pack_Fix > GetPrimary ( int _packId ){        
            Dictionary<int, Table_Reward_Pack_Fix > _map0=null;        
            pool_primary. TryGetValue(_packId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packId> 固定奖励包id</param>
        ///	<param id> 序号</param>
        ///
        public static Table_Reward_Pack_Fix GetPrimary ( int _packId , int _id ){        
            Dictionary<int, Table_Reward_Pack_Fix > _map0=null;        
            pool_primary. TryGetValue(_packId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Reward_Pack_Fix _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Reward_Pack_Fix > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Reward_Pack_Fix> GetAllPrimaryList()
        {
            return all_Table_Reward_Pack_Fix_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("pack_id", out _currValue))
            {
                this.pack_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_num_down", out _currValue))
            {
                this.item_num_down = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_num_up", out _currValue))
            {
                this.item_num_up = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "reward_pack_fix";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "pack_id":
                    return this.pack_id;
                case "id":
                    return this.id;
                case "item_id":
                    return this.item_id;
                case "item_num_down":
                    return this.item_num_down;
                case "item_num_up":
                    return this.item_num_up;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Reward_Pack_Fix> rows = _rows as List<Table_Reward_Pack_Fix>;
            pool_primary=TableContent.ListToPool < int, int, Table_Reward_Pack_Fix > ( rows, "map", "pack_id", "id" );
            all_Table_Reward_Pack_Fix_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Reward_Pack_Fix_List.Clear();
        }
    }
}
