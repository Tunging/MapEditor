using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 生活技能等级
    ///</summary>
    [Serializable]
    [TableName("life_skill_level")]
    public partial class Table_Life_Skill_Level : TableContent
    {

        private static List<Table_Life_Skill_Level> all_Table_Life_Skill_Level_List = new List<Table_Life_Skill_Level>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Life_Skill_Level > > pool_primary = new Dictionary<int, Dictionary<int, Table_Life_Skill_Level > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 等级
        ///</summary>
        public int level;
        
        
        ///<summary>
        /// 星级
        ///</summary>
        public int star;
        
        
        ///<summary>
        /// 评星名称
        ///</summary>
        public string star_name;
        
        
        ///<summary>
        /// 评星名称国际化
        ///</summary>
        public string star_name_i18n;
        
        
        ///<summary>
        /// 升级所需经验
        ///</summary>
        public int exp;
        
        
        ///<summary>
        /// 进阶任务ID
        ///</summary>
        public int advance_task;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：ID</param>
        ///
        public static Dictionary<int, Table_Life_Skill_Level > GetPrimary ( int _skillId ){        
            Dictionary<int, Table_Life_Skill_Level > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：ID</param>
        ///	<param level> 等级</param>
        ///
        public static Table_Life_Skill_Level GetPrimary ( int _skillId , int _level ){        
            Dictionary<int, Table_Life_Skill_Level > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Life_Skill_Level _map1=null;        
            _map0. TryGetValue(_level,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Life_Skill_Level > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Life_Skill_Level> GetAllPrimaryList()
        {
            return all_Table_Life_Skill_Level_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("level", out _currValue))
            {
                this.level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star", out _currValue))
            {
                this.star = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("star_name", out _currValue))
            {
                this.star_name = _currValue;
            }
            if(_itemData.TryGetValue("star_name_i18n", out _currValue))
            {
                this.star_name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("exp", out _currValue))
            {
                this.exp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("advance_task", out _currValue))
            {
                this.advance_task = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "life_skill_level";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_id":
                    return this.skill_id;
                case "level":
                    return this.level;
                case "star":
                    return this.star;
                case "star_name":
                    return this.star_name;
                case "star_name_i18n":
                    return this.star_name_i18n;
                case "exp":
                    return this.exp;
                case "advance_task":
                    return this.advance_task;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Life_Skill_Level> rows = _rows as List<Table_Life_Skill_Level>;
            pool_primary=TableContent.ListToPool < int, int, Table_Life_Skill_Level > ( rows, "map", "skill_id", "level" );
            all_Table_Life_Skill_Level_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Life_Skill_Level_List.Clear();
        }
    }
}
