using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 天赋树
    ///</summary>
    [Serializable]
    [TableName("talent_tree")]
    public partial class Table_Talent_Tree : TableContent
    {

        private static List<Table_Talent_Tree> all_Table_Talent_Tree_List = new List<Table_Talent_Tree>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Talent_Tree > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Talent_Tree > > > ();
        
        
        ///<summary>
        /// 天赋树ID
        ///</summary>
        public int tree_id;
        
        
        ///<summary>
        /// 层级ID
        ///</summary>
        public int hierarchy_id;
        
        
        ///<summary>
        /// 编号
        ///</summary>
        public int num;
        
        
        ///<summary>
        /// 天赋技能ID
        ///</summary>
        public int talent_skill_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param treeId> 天赋树ID</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Talent_Tree > > GetPrimary ( int _treeId ){        
            Dictionary<int, Dictionary<int, Table_Talent_Tree > > _map0=null;        
            pool_primary. TryGetValue(_treeId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param treeId> 天赋树ID</param>
        ///	<param hierarchyId> 层级ID</param>
        ///
        public static Dictionary<int, Table_Talent_Tree > GetPrimary ( int _treeId , int _hierarchyId ){        
            Dictionary<int, Dictionary<int, Table_Talent_Tree > > _map0=null;        
            pool_primary. TryGetValue(_treeId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Talent_Tree > _map1=null;        
            _map0. TryGetValue(_hierarchyId,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param treeId> 天赋树ID</param>
        ///	<param hierarchyId> 层级ID</param>
        ///	<param num> 编号</param>
        ///
        public static Table_Talent_Tree GetPrimary ( int _treeId , int _hierarchyId , int _num ){        
            Dictionary<int, Dictionary<int, Table_Talent_Tree > > _map0=null;        
            pool_primary. TryGetValue(_treeId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Talent_Tree > _map1=null;        
            _map0. TryGetValue(_hierarchyId,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Talent_Tree _map2=null;        
            _map1. TryGetValue(_num,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Talent_Tree > > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Talent_Tree> GetAllPrimaryList()
        {
            return all_Table_Talent_Tree_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("tree_id", out _currValue))
            {
                this.tree_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("hierarchy_id", out _currValue))
            {
                this.hierarchy_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("num", out _currValue))
            {
                this.num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("talent_skill_id", out _currValue))
            {
                this.talent_skill_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "talent_tree";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "tree_id":
                    return this.tree_id;
                case "hierarchy_id":
                    return this.hierarchy_id;
                case "num":
                    return this.num;
                case "talent_skill_id":
                    return this.talent_skill_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Talent_Tree> rows = _rows as List<Table_Talent_Tree>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Talent_Tree > ( rows, "map", "tree_id", "hierarchy_id", "num" );
            all_Table_Talent_Tree_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Talent_Tree_List.Clear();
        }
    }
}
