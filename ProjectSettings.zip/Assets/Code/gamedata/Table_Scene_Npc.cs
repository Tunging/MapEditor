using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景里的NPC布置
    ///</summary>
    [Serializable]
    [TableName("scene_npc")]
    public partial class Table_Scene_Npc : TableContent
    {

        private static List<Table_Scene_Npc> all_Table_Scene_Npc_List = new List<Table_Scene_Npc>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Npc > pool_primary = new Dictionary<int, Table_Scene_Npc > ();
        //sceneNpc | 
        public static Dictionary<int, Dictionary<int, Table_Scene_Npc > > pool_sceneNpc = new Dictionary<int, Dictionary<int, Table_Scene_Npc > > ();
        //sceneGroupNpc | 
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Scene_Npc > > > pool_sceneGroupNpc = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Scene_Npc > > > ();
        //templateSceneNpc | npc_id在所有场景scene的npc
        public static Dictionary<int, Dictionary<int, List<Table_Scene_Npc> > > pool_templateSceneNpc = new Dictionary<int, Dictionary<int, List<Table_Scene_Npc> > > ();
        
        
        ///<summary>
        /// 主键：guid
        ///</summary>
        public int guid;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// npc模板ID
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 分组id（如果不填默认为0）
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// X坐标
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// Y坐标
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// Z坐标
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 旋转角度（从正北方向顺时针旋转）
        ///</summary>
        public float angle;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string descrption_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param guid> 主键：guid</param>
        ///
        public static Table_Scene_Npc GetPrimary ( int _guid ){        
            Table_Scene_Npc _map0=null;        
            pool_primary. TryGetValue(_guid,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Npc > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景ID</param>
        ///
        public static Dictionary<int, Table_Scene_Npc > GetSceneNpc ( int _sceneId ){        
            Dictionary<int, Table_Scene_Npc > _map0=null;        
            pool_sceneNpc. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景ID</param>
        ///	<param guid> 主键：guid</param>
        ///
        public static Table_Scene_Npc GetSceneNpc ( int _sceneId , int _guid ){        
            Dictionary<int, Table_Scene_Npc > _map0=null;        
            pool_sceneNpc. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Scene_Npc _map1=null;        
            _map0. TryGetValue(_guid,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Scene_Npc > > GetAllSceneNpc()
        {
            return pool_sceneNpc;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景ID</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Scene_Npc > > GetSceneGroupNpc ( int _sceneId ){        
            Dictionary<int, Dictionary<int, Table_Scene_Npc > > _map0=null;        
            pool_sceneGroupNpc. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景ID</param>
        ///	<param groupId> 分组id（如果不填默认为0）</param>
        ///
        public static Dictionary<int, Table_Scene_Npc > GetSceneGroupNpc ( int _sceneId , int _groupId ){        
            Dictionary<int, Dictionary<int, Table_Scene_Npc > > _map0=null;        
            pool_sceneGroupNpc. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Scene_Npc > _map1=null;        
            _map0. TryGetValue(_groupId,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param sceneId> 场景ID</param>
        ///	<param groupId> 分组id（如果不填默认为0）</param>
        ///	<param guid> 主键：guid</param>
        ///
        public static Table_Scene_Npc GetSceneGroupNpc ( int _sceneId , int _groupId , int _guid ){        
            Dictionary<int, Dictionary<int, Table_Scene_Npc > > _map0=null;        
            pool_sceneGroupNpc. TryGetValue(_sceneId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Scene_Npc > _map1=null;        
            _map0. TryGetValue(_groupId,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Scene_Npc _map2=null;        
            _map1. TryGetValue(_guid,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Scene_Npc > > > GetAllSceneGroupNpc()
        {
            return pool_sceneGroupNpc;
        }



        ///<summary>
        /// npc_id在所有场景scene的npc
        /// 查询数据
        ///</summary>
        ///	<param npcId> npc模板ID</param>
        ///
        public static Dictionary<int, List<Table_Scene_Npc> > GetTemplateSceneNpc ( int _npcId ){        
            Dictionary<int, List<Table_Scene_Npc> > _map0=null;        
            pool_templateSceneNpc. TryGetValue(_npcId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// npc_id在所有场景scene的npc
        /// 查询数据
        ///</summary>
        ///	<param npcId> npc模板ID</param>
        ///	<param sceneId> 场景ID</param>
        ///
        public static List<Table_Scene_Npc> GetTemplateSceneNpc ( int _npcId , int _sceneId ){        
            Dictionary<int, List<Table_Scene_Npc> > _map0=null;        
            pool_templateSceneNpc. TryGetValue(_npcId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            List<Table_Scene_Npc> _map1=null;        
            _map0. TryGetValue(_sceneId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///npc_id在所有场景scene的npc
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, List<Table_Scene_Npc> > > GetAllTemplateSceneNpc()
        {
            return pool_templateSceneNpc;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Npc> GetAllPrimaryList()
        {
            return all_Table_Scene_Npc_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("guid", out _currValue))
            {
                this.guid = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("angle", out _currValue))
            {
                this.angle = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("descrption_i18n", out _currValue))
            {
                this.descrption_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_npc";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "guid":
                    return this.guid;
                case "name_i18n":
                    return this.name_i18n;
                case "scene_id":
                    return this.scene_id;
                case "npc_id":
                    return this.npc_id;
                case "group_id":
                    return this.group_id;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "angle":
                    return this.angle;
                case "descrption_i18n":
                    return this.descrption_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Npc> rows = _rows as List<Table_Scene_Npc>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Npc > ( rows, "map", "guid" );
            pool_sceneNpc=TableContent.ListToPool < int, int, Table_Scene_Npc > ( rows, "map", "scene_id", "guid" );
            pool_sceneGroupNpc=TableContent.ListToPool < int, int, int, Table_Scene_Npc > ( rows, "map", "scene_id", "group_id", "guid" );
            pool_templateSceneNpc=TableContent.ListToPoolList < int, int, Table_Scene_Npc > ( rows, "list", "npc_id", "scene_id" );
            all_Table_Scene_Npc_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_sceneNpc.Clear();
            pool_sceneGroupNpc.Clear();
            pool_templateSceneNpc.Clear();
            all_Table_Scene_Npc_List.Clear();
        }
    }
}
