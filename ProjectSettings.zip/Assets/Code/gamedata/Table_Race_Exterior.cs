using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 种族外观表
    ///</summary>
    [Serializable]
    [TableName("race_exterior")]
    public partial class Table_Race_Exterior : TableContent
    {

        private static List<Table_Race_Exterior> all_Table_Race_Exterior_List = new List<Table_Race_Exterior>();
        //primary | 主键
        public static Dictionary<int, Table_Race_Exterior > pool_primary = new Dictionary<int, Table_Race_Exterior > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 种族
        ///</summary>
        public int race_id;
        
        
        ///<summary>
        /// 种族出场动作
        ///</summary>
        public int race_action;
        
        
        ///<summary>
        /// 种族出场动作时间
        ///</summary>
        public int race_action_time;
        
        
        ///<summary>
        /// 休闲动作
        ///</summary>
        public string play_action;
        
        
        ///<summary>
        /// 角色模型id
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 部位1颜色(分号分割)
        ///</summary>
        public string part1_color;
        
        
        ///<summary>
        /// 部位2颜色(分号分割)
        ///</summary>
        public string part2_color;
        
        
        ///<summary>
        /// 部位3颜色(分号分割)
        ///</summary>
        public string part3_color;
        
        
        ///<summary>
        /// 部位4颜色(分号分割)
        ///</summary>
        public string part4_color;
        
        
        ///<summary>
        /// 头像按钮icon
        ///</summary>
        public int head_button_icon;
        
        
        ///<summary>
        /// 出生坐标点
        ///</summary>
        public string pos;
        
        
        ///<summary>
        /// 朝向
        ///</summary>
        public float toward;
        
        
        ///<summary>
        /// 角色对应的皮肤id
        ///</summary>
        public string skin_id;
        
        
        ///<summary>
        /// 人物展示语音
        ///</summary>
        public int sound_vo_id;
        
        
        ///<summary>
        /// 故事语音
        ///</summary>
        public int sound_story_id;
        
        
        ///<summary>
        /// 故事语音切换文本时间节点
        ///</summary>
        public string sound_time;
        
        
        ///<summary>
        /// 故事语音各段文本内容
        ///</summary>
        public string sound_text;
        
        
        ///<summary>
        /// 搭配故事语音的动作
        ///</summary>
        public int story_action_id;
        
        
        ///<summary>
        /// 播放故事语音时摄像机照射位置
        ///</summary>
        public string lookat_position;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Race_Exterior GetPrimary ( int _id ){        
            Table_Race_Exterior _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Race_Exterior > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Race_Exterior> GetAllPrimaryList()
        {
            return all_Table_Race_Exterior_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race_id", out _currValue))
            {
                this.race_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race_action", out _currValue))
            {
                this.race_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race_action_time", out _currValue))
            {
                this.race_action_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("play_action", out _currValue))
            {
                this.play_action = _currValue;
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("part1_color", out _currValue))
            {
                this.part1_color = _currValue;
            }
            if(_itemData.TryGetValue("part2_color", out _currValue))
            {
                this.part2_color = _currValue;
            }
            if(_itemData.TryGetValue("part3_color", out _currValue))
            {
                this.part3_color = _currValue;
            }
            if(_itemData.TryGetValue("part4_color", out _currValue))
            {
                this.part4_color = _currValue;
            }
            if(_itemData.TryGetValue("head_button_icon", out _currValue))
            {
                this.head_button_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pos", out _currValue))
            {
                this.pos = _currValue;
            }
            if(_itemData.TryGetValue("toward", out _currValue))
            {
                this.toward = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("skin_id", out _currValue))
            {
                this.skin_id = _currValue;
            }
            if(_itemData.TryGetValue("sound_vo_id", out _currValue))
            {
                this.sound_vo_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_story_id", out _currValue))
            {
                this.sound_story_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_time", out _currValue))
            {
                this.sound_time = _currValue;
            }
            if(_itemData.TryGetValue("sound_text", out _currValue))
            {
                this.sound_text = _currValue;
            }
            if(_itemData.TryGetValue("story_action_id", out _currValue))
            {
                this.story_action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("lookat_position", out _currValue))
            {
                this.lookat_position = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "race_exterior";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "race_id":
                    return this.race_id;
                case "race_action":
                    return this.race_action;
                case "race_action_time":
                    return this.race_action_time;
                case "play_action":
                    return this.play_action;
                case "model_id":
                    return this.model_id;
                case "part1_color":
                    return this.part1_color;
                case "part2_color":
                    return this.part2_color;
                case "part3_color":
                    return this.part3_color;
                case "part4_color":
                    return this.part4_color;
                case "head_button_icon":
                    return this.head_button_icon;
                case "pos":
                    return this.pos;
                case "toward":
                    return this.toward;
                case "skin_id":
                    return this.skin_id;
                case "sound_vo_id":
                    return this.sound_vo_id;
                case "sound_story_id":
                    return this.sound_story_id;
                case "sound_time":
                    return this.sound_time;
                case "sound_text":
                    return this.sound_text;
                case "story_action_id":
                    return this.story_action_id;
                case "lookat_position":
                    return this.lookat_position;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Race_Exterior> rows = _rows as List<Table_Race_Exterior>;
            pool_primary=TableContent.ListToPool < int, Table_Race_Exterior > ( rows, "map", "id" );
            all_Table_Race_Exterior_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Race_Exterior_List.Clear();
        }
    }
}
