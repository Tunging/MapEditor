using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 区域事件
    ///</summary>
    [Serializable]
    [TableName("zone_event")]
    public partial class Table_Zone_Event : TableContent
    {

        private static List<Table_Zone_Event> all_Table_Zone_Event_List = new List<Table_Zone_Event>();
        //primary | 主键
        public static Dictionary<int, Table_Zone_Event > pool_primary = new Dictionary<int, Table_Zone_Event > ();
        
        
        ///<summary>
        /// 主键：事件ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 事件场景ID
        ///</summary>
        public int scene_id;
        
        
        ///<summary>
        /// 事件区域ID
        ///</summary>
        public int region_id;
        
        
        ///<summary>
        /// 限制时间(s)
        ///</summary>
        public int limit_time;
        
        
        ///<summary>
        /// 超时是否成功
        ///</summary>
        public bool timeout_success;
        
        
        ///<summary>
        /// 冷却时间(s)
        ///</summary>
        public int cooling_time;
        
        
        ///<summary>
        /// 触发方式：周期(s)
        ///</summary>
        public int trigger_way_period;
        
        
        ///<summary>
        /// 触发方式：进入区域
        ///</summary>
        public bool trigger_way_enter_region;
        
        
        ///<summary>
        /// 触发方式：对话
        ///</summary>
        public int trigger_way_dialog;
        
        
        ///<summary>
        /// 触发方式：完成前置事件
        ///</summary>
        public int trigger_way_finish_event;
        
        
        ///<summary>
        /// 背景音乐
        ///</summary>
        public int background_music;
        
        
        ///<summary>
        /// 评价S要求贡献
        ///</summary>
        public int evaluation1_need_contribution;
        
        
        ///<summary>
        /// 评价S奖励
        ///</summary>
        public int evaluation1_reward;
        
        
        ///<summary>
        /// 评价S图标
        ///</summary>
        public int evaluation1_icon;
        
        
        ///<summary>
        /// 评价A要求贡献
        ///</summary>
        public int evaluation2_need_contribution;
        
        
        ///<summary>
        /// 评价A奖励
        ///</summary>
        public int evaluation2_reward;
        
        
        ///<summary>
        /// 评价A图标
        ///</summary>
        public int evaluation2_icon;
        
        
        ///<summary>
        /// 评价B要求贡献
        ///</summary>
        public int evaluation3_need_contribution;
        
        
        ///<summary>
        /// 评价B奖励
        ///</summary>
        public int evaluation3_reward;
        
        
        ///<summary>
        /// 评价B图标
        ///</summary>
        public int evaluation3_icon;
        
        
        ///<summary>
        /// 失败奖励
        ///</summary>
        public int failed_reward;
        
        
        ///<summary>
        /// 失败图标
        ///</summary>
        public int failed_icon;
        
        
        ///<summary>
        /// 关联的触发器组
        ///</summary>
        public int trigger_group_id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：事件ID</param>
        ///
        public static Table_Zone_Event GetPrimary ( int _id ){        
            Table_Zone_Event _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Zone_Event > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Zone_Event> GetAllPrimaryList()
        {
            return all_Table_Zone_Event_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("scene_id", out _currValue))
            {
                this.scene_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("region_id", out _currValue))
            {
                this.region_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_time", out _currValue))
            {
                this.limit_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("timeout_success", out _currValue))
            {
                this.timeout_success = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("cooling_time", out _currValue))
            {
                this.cooling_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_way_period", out _currValue))
            {
                this.trigger_way_period = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_way_enter_region", out _currValue))
            {
                this.trigger_way_enter_region = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_way_dialog", out _currValue))
            {
                this.trigger_way_dialog = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_way_finish_event", out _currValue))
            {
                this.trigger_way_finish_event = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("background_music", out _currValue))
            {
                this.background_music = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation1_need_contribution", out _currValue))
            {
                this.evaluation1_need_contribution = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation1_reward", out _currValue))
            {
                this.evaluation1_reward = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation1_icon", out _currValue))
            {
                this.evaluation1_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation2_need_contribution", out _currValue))
            {
                this.evaluation2_need_contribution = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation2_reward", out _currValue))
            {
                this.evaluation2_reward = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation2_icon", out _currValue))
            {
                this.evaluation2_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation3_need_contribution", out _currValue))
            {
                this.evaluation3_need_contribution = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation3_reward", out _currValue))
            {
                this.evaluation3_reward = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("evaluation3_icon", out _currValue))
            {
                this.evaluation3_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("failed_reward", out _currValue))
            {
                this.failed_reward = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("failed_icon", out _currValue))
            {
                this.failed_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_group_id", out _currValue))
            {
                this.trigger_group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "zone_event";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "scene_id":
                    return this.scene_id;
                case "region_id":
                    return this.region_id;
                case "limit_time":
                    return this.limit_time;
                case "timeout_success":
                    return this.timeout_success;
                case "cooling_time":
                    return this.cooling_time;
                case "trigger_way_period":
                    return this.trigger_way_period;
                case "trigger_way_enter_region":
                    return this.trigger_way_enter_region;
                case "trigger_way_dialog":
                    return this.trigger_way_dialog;
                case "trigger_way_finish_event":
                    return this.trigger_way_finish_event;
                case "background_music":
                    return this.background_music;
                case "evaluation1_need_contribution":
                    return this.evaluation1_need_contribution;
                case "evaluation1_reward":
                    return this.evaluation1_reward;
                case "evaluation1_icon":
                    return this.evaluation1_icon;
                case "evaluation2_need_contribution":
                    return this.evaluation2_need_contribution;
                case "evaluation2_reward":
                    return this.evaluation2_reward;
                case "evaluation2_icon":
                    return this.evaluation2_icon;
                case "evaluation3_need_contribution":
                    return this.evaluation3_need_contribution;
                case "evaluation3_reward":
                    return this.evaluation3_reward;
                case "evaluation3_icon":
                    return this.evaluation3_icon;
                case "failed_reward":
                    return this.failed_reward;
                case "failed_icon":
                    return this.failed_icon;
                case "trigger_group_id":
                    return this.trigger_group_id;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Zone_Event> rows = _rows as List<Table_Zone_Event>;
            pool_primary=TableContent.ListToPool < int, Table_Zone_Event > ( rows, "map", "id" );
            all_Table_Zone_Event_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Zone_Event_List.Clear();
        }
    }
}
