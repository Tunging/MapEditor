using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本旁白
    ///</summary>
    [Serializable]
    [TableName("instance_aside")]
    public partial class Table_Instance_Aside : TableContent
    {

        private static List<Table_Instance_Aside> all_Table_Instance_Aside_List = new List<Table_Instance_Aside>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Instance_Aside > > pool_primary = new Dictionary<int, Dictionary<int, Table_Instance_Aside > > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 序列ID
        ///</summary>
        public int sequence_id;
        
        
        ///<summary>
        /// 文字国际化
        ///</summary>
        public string text_i18n;
        
        
        ///<summary>
        /// 显示时间(毫秒)
        ///</summary>
        public int show_time;
        
        
        ///<summary>
        /// 配音ID
        ///</summary>
        public int voice_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Dictionary<int, Table_Instance_Aside > GetPrimary ( int _id ){        
            Dictionary<int, Table_Instance_Aside > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///	<param sequenceId> 序列ID</param>
        ///
        public static Table_Instance_Aside GetPrimary ( int _id , int _sequenceId ){        
            Dictionary<int, Table_Instance_Aside > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Instance_Aside _map1=null;        
            _map0. TryGetValue(_sequenceId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Instance_Aside > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance_Aside> GetAllPrimaryList()
        {
            return all_Table_Instance_Aside_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("sequence_id", out _currValue))
            {
                this.sequence_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text_i18n", out _currValue))
            {
                this.text_i18n = _currValue;
            }
            if(_itemData.TryGetValue("show_time", out _currValue))
            {
                this.show_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("voice_id", out _currValue))
            {
                this.voice_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance_aside";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "sequence_id":
                    return this.sequence_id;
                case "text_i18n":
                    return this.text_i18n;
                case "show_time":
                    return this.show_time;
                case "voice_id":
                    return this.voice_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance_Aside> rows = _rows as List<Table_Instance_Aside>;
            pool_primary=TableContent.ListToPool < int, int, Table_Instance_Aside > ( rows, "map", "id", "sequence_id" );
            all_Table_Instance_Aside_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_Aside_List.Clear();
        }
    }
}
