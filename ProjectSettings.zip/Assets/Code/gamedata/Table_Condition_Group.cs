using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 条件组
    ///</summary>
    [Serializable]
    [TableName("condition_group")]
    public partial class Table_Condition_Group : TableContent
    {

        private static List<Table_Condition_Group> all_Table_Condition_Group_List = new List<Table_Condition_Group>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Condition_Group > > pool_primary = new Dictionary<int, Dictionary<int, Table_Condition_Group > > ();
        
        
        ///<summary>
        /// ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 子条件id
        ///</summary>
        public int condition_id;
        
        
        ///<summary>
        /// 策划备注
        ///</summary>
        public string remark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> ID</param>
        ///
        public static Dictionary<int, Table_Condition_Group > GetPrimary ( int _id ){        
            Dictionary<int, Table_Condition_Group > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> ID</param>
        ///	<param conditionId> 子条件id</param>
        ///
        public static Table_Condition_Group GetPrimary ( int _id , int _conditionId ){        
            Dictionary<int, Table_Condition_Group > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Condition_Group _map1=null;        
            _map0. TryGetValue(_conditionId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Condition_Group > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Condition_Group> GetAllPrimaryList()
        {
            return all_Table_Condition_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("condition_id", out _currValue))
            {
                this.condition_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "condition_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "condition_id":
                    return this.condition_id;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Condition_Group> rows = _rows as List<Table_Condition_Group>;
            pool_primary=TableContent.ListToPool < int, int, Table_Condition_Group > ( rows, "map", "id", "condition_id" );
            all_Table_Condition_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Condition_Group_List.Clear();
        }
    }
}
