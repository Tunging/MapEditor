using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本npc池
    ///</summary>
    [Serializable]
    [TableName("instance_npc_pool")]
    public partial class Table_Instance_Npc_Pool : TableContent
    {

        private static List<Table_Instance_Npc_Pool> all_Table_Instance_Npc_Pool_List = new List<Table_Instance_Npc_Pool>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Instance_Npc_Pool > > pool_primary = new Dictionary<int, Dictionary<int, Table_Instance_Npc_Pool > > ();
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// npc模板id
        ///</summary>
        public int npc_template_id;
        
        
        ///<summary>
        /// npc guid（非数字隔开,默认空着就行）
        ///</summary>
        public string guid;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string mark;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///
        public static Dictionary<int, Table_Instance_Npc_Pool > GetPrimary ( int _id ){        
            Dictionary<int, Table_Instance_Npc_Pool > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> id</param>
        ///	<param npcTemplateId> npc模板id</param>
        ///
        public static Table_Instance_Npc_Pool GetPrimary ( int _id , int _npcTemplateId ){        
            Dictionary<int, Table_Instance_Npc_Pool > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Instance_Npc_Pool _map1=null;        
            _map0. TryGetValue(_npcTemplateId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Instance_Npc_Pool > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance_Npc_Pool> GetAllPrimaryList()
        {
            return all_Table_Instance_Npc_Pool_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_template_id", out _currValue))
            {
                this.npc_template_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("guid", out _currValue))
            {
                this.guid = _currValue;
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("mark", out _currValue))
            {
                this.mark = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance_npc_pool";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "npc_template_id":
                    return this.npc_template_id;
                case "guid":
                    return this.guid;
                case "weight":
                    return this.weight;
                case "mark":
                    return this.mark;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance_Npc_Pool> rows = _rows as List<Table_Instance_Npc_Pool>;
            pool_primary=TableContent.ListToPool < int, int, Table_Instance_Npc_Pool > ( rows, "map", "id", "npc_template_id" );
            all_Table_Instance_Npc_Pool_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_Npc_Pool_List.Clear();
        }
    }
}
