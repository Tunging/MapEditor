using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 开服活动配置表
    ///</summary>
    [Serializable]
    [TableName("open_server_day")]
    public partial class Table_Open_Server_Day : TableContent
    {

        private static List<Table_Open_Server_Day> all_Table_Open_Server_Day_List = new List<Table_Open_Server_Day>();
        //primary | 主键
        public static Dictionary<int, Table_Open_Server_Day > pool_primary = new Dictionary<int, Table_Open_Server_Day > ();
        
        
        ///<summary>
        /// 主键：开服第几日
        ///</summary>
        public int day;
        
        
        ///<summary>
        /// 奖励道具1ID
        ///</summary>
        public int item1_id;
        
        
        ///<summary>
        /// 奖励道具1数量
        ///</summary>
        public int item1_num;
        
        
        ///<summary>
        /// 奖励道具2ID
        ///</summary>
        public int item2_id;
        
        
        ///<summary>
        /// 奖励道具2数量
        ///</summary>
        public int item2_num;
        
        
        ///<summary>
        /// 奖励道具3ID
        ///</summary>
        public int item3_id;
        
        
        ///<summary>
        /// 奖励道具3数量
        ///</summary>
        public int item3_num;
        
        
        ///<summary>
        /// 奖励道具4ID
        ///</summary>
        public int item4_id;
        
        
        ///<summary>
        /// 奖励道具4数量
        ///</summary>
        public int item4_num;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param day> 主键：开服第几日</param>
        ///
        public static Table_Open_Server_Day GetPrimary ( int _day ){        
            Table_Open_Server_Day _map0=null;        
            pool_primary. TryGetValue(_day,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Open_Server_Day > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Open_Server_Day> GetAllPrimaryList()
        {
            return all_Table_Open_Server_Day_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("day", out _currValue))
            {
                this.day = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item1_id", out _currValue))
            {
                this.item1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item1_num", out _currValue))
            {
                this.item1_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item2_id", out _currValue))
            {
                this.item2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item2_num", out _currValue))
            {
                this.item2_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item3_id", out _currValue))
            {
                this.item3_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item3_num", out _currValue))
            {
                this.item3_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item4_id", out _currValue))
            {
                this.item4_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item4_num", out _currValue))
            {
                this.item4_num = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "open_server_day";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "day":
                    return this.day;
                case "item1_id":
                    return this.item1_id;
                case "item1_num":
                    return this.item1_num;
                case "item2_id":
                    return this.item2_id;
                case "item2_num":
                    return this.item2_num;
                case "item3_id":
                    return this.item3_id;
                case "item3_num":
                    return this.item3_num;
                case "item4_id":
                    return this.item4_id;
                case "item4_num":
                    return this.item4_num;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Open_Server_Day> rows = _rows as List<Table_Open_Server_Day>;
            pool_primary=TableContent.ListToPool < int, Table_Open_Server_Day > ( rows, "map", "day" );
            all_Table_Open_Server_Day_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Open_Server_Day_List.Clear();
        }
    }
}
