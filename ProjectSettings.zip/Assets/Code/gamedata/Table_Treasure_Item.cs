using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宝箱道具
    ///</summary>
    [Serializable]
    [TableName("treasure_item")]
    public partial class Table_Treasure_Item : TableContent
    {

        private static List<Table_Treasure_Item> all_Table_Treasure_Item_List = new List<Table_Treasure_Item>();
        //primary | 主键
        public static Dictionary<int, Table_Treasure_Item > pool_primary = new Dictionary<int, Table_Treasure_Item > ();
        
        
        ///<summary>
        /// 主键ID=道具ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 道具库(id*num;id*num)
        ///</summary>
        public string items_library;
        
        
        ///<summary>
        /// 道具种类数量下限
        ///</summary>
        public int item_num_min;
        
        
        ///<summary>
        /// 道具种类数量上限
        ///</summary>
        public int item_num_max;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键ID=道具ID</param>
        ///
        public static Table_Treasure_Item GetPrimary ( int _id ){        
            Table_Treasure_Item _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Treasure_Item > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Treasure_Item> GetAllPrimaryList()
        {
            return all_Table_Treasure_Item_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("items_library", out _currValue))
            {
                this.items_library = _currValue;
            }
            if(_itemData.TryGetValue("item_num_min", out _currValue))
            {
                this.item_num_min = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_num_max", out _currValue))
            {
                this.item_num_max = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "treasure_item";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "remark":
                    return this.remark;
                case "items_library":
                    return this.items_library;
                case "item_num_min":
                    return this.item_num_min;
                case "item_num_max":
                    return this.item_num_max;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Treasure_Item> rows = _rows as List<Table_Treasure_Item>;
            pool_primary=TableContent.ListToPool < int, Table_Treasure_Item > ( rows, "map", "id" );
            all_Table_Treasure_Item_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Treasure_Item_List.Clear();
        }
    }
}
