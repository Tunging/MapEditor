using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// NPC扩展：采集物配置
    ///</summary>
    [Serializable]
    [TableName("npc_gather")]
    public partial class Table_Npc_Gather : TableContent
    {

        private static List<Table_Npc_Gather> all_Table_Npc_Gather_List = new List<Table_Npc_Gather>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Gather > pool_primary = new Dictionary<int, Table_Npc_Gather > ();
        
        
        ///<summary>
        /// 主键：NPC模板ID
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 有相应任务时才可见
        ///</summary>
        public bool show_by_task;
        
        
        ///<summary>
        /// 战斗状态是否可采集
        ///</summary>
        public bool gather_on_fight;
        
        
        ///<summary>
        /// 总采集次数
        ///</summary>
        public int total_count;
        
        
        ///<summary>
        /// 采集次数重置时间，单位毫秒，只针对采集后不离开场景使用
        ///</summary>
        public int reset_time;
        
        
        ///<summary>
        /// 是否显示采集次数
        ///</summary>
        public bool show_count;
        
        
        ///<summary>
        /// 限制生活技能ID
        ///</summary>
        public int life_skill_id;
        
        
        ///<summary>
        /// 生活技能星级
        ///</summary>
        public int life_skill_star_level;
        
        
        ///<summary>
        /// 采集完成后，扣除活力
        ///</summary>
        public int finish_dynamic;
        
        
        ///<summary>
        /// 采集需要时间，毫秒
        ///</summary>
        public int time;
        
        
        ///<summary>
        /// 拥有指定的BUFF时才能采集，0=不限制
        ///</summary>
        public int limit_by_buff_id;
        
        
        ///<summary>
        /// 有相应任务时才能采集
        ///</summary>
        public bool limit_by_task;
        
        
        ///<summary>
        /// 限制同时采集的人数，0=不限制
        ///</summary>
        public int limit_role_count;
        
        
        ///<summary>
        /// 是否直接触发采集
        ///</summary>
        public bool is_direct_gather;
        
        
        ///<summary>
        /// 采集完成后增加的熟练度，生活技能用
        ///</summary>
        public int finish_lifeskill_exp;
        
        
        ///<summary>
        /// 获取地点描述
        ///</summary>
        public string get_address;
        
        
        ///<summary>
        /// 角色采集动作
        ///</summary>
        public int role_action;
        
        
        ///<summary>
        /// NPC采集开始动作
        ///</summary>
        public int npc_start_action;
        
        
        ///<summary>
        /// NPC采集开始特效
        ///</summary>
        public int npc_start_effect;
        
        
        ///<summary>
        /// NPC采集开始声音
        ///</summary>
        public int npc_start_sound;
        
        
        ///<summary>
        /// NPC采集完成动作
        ///</summary>
        public int npc_finish_action;
        
        
        ///<summary>
        /// NPC采集完成特效
        ///</summary>
        public int npc_finish_effect;
        
        
        ///<summary>
        /// 采集完成后的提示文字国际化
        ///</summary>
        public string finish_tips_i18n;
        
        
        ///<summary>
        /// 采集图标
        ///</summary>
        public int gather_icon;
        
        
        ///<summary>
        /// 采集之前按钮文本国际化
        ///</summary>
        public int gather_before_button_text_i18n;
        
        
        ///<summary>
        /// 采集按钮文本国际化
        ///</summary>
        public string gather_button_text_i18n;
        
        
        ///<summary>
        /// 开始采集时的npc表演脚本id组
        ///</summary>
        public int start_script_group;
        
        
        ///<summary>
        /// 成功采集时的npc表演脚本id组
        ///</summary>
        public int end_script_group;
        
        
        ///<summary>
        /// 采集成功时触发的摄像机行为id
        ///</summary>
        public int camera_behaviour_id;
        
        
        ///<summary>
        /// 采集物对应在item表中的id
        ///</summary>
        public int item_id;
        
        
        ///<summary>
        /// 采集完成后召唤NPC
        ///</summary>
        public int call_npc_id;
        
        
        ///<summary>
        /// 采集完成后召唤NPC数量
        ///</summary>
        public int call_npc_count;
        
        
        ///<summary>
        /// 采集完成后召唤NPC概率，万分比
        ///</summary>
        public int call_npc_pro;
        
        
        ///<summary>
        /// 采集完成后召唤NPC范围半径
        ///</summary>
        public int call_npc_radius;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcId> 主键：NPC模板ID</param>
        ///
        public static Table_Npc_Gather GetPrimary ( int _npcId ){        
            Table_Npc_Gather _map0=null;        
            pool_primary. TryGetValue(_npcId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Gather > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Gather> GetAllPrimaryList()
        {
            return all_Table_Npc_Gather_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_by_task", out _currValue))
            {
                this.show_by_task = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_on_fight", out _currValue))
            {
                this.gather_on_fight = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("total_count", out _currValue))
            {
                this.total_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("reset_time", out _currValue))
            {
                this.reset_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_count", out _currValue))
            {
                this.show_count = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("life_skill_id", out _currValue))
            {
                this.life_skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("life_skill_star_level", out _currValue))
            {
                this.life_skill_star_level = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("finish_dynamic", out _currValue))
            {
                this.finish_dynamic = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("time", out _currValue))
            {
                this.time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_by_buff_id", out _currValue))
            {
                this.limit_by_buff_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_by_task", out _currValue))
            {
                this.limit_by_task = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("limit_role_count", out _currValue))
            {
                this.limit_role_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_direct_gather", out _currValue))
            {
                this.is_direct_gather = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("finish_lifeskill_exp", out _currValue))
            {
                this.finish_lifeskill_exp = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("get_address", out _currValue))
            {
                this.get_address = _currValue;
            }
            if(_itemData.TryGetValue("role_action", out _currValue))
            {
                this.role_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_start_action", out _currValue))
            {
                this.npc_start_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_start_effect", out _currValue))
            {
                this.npc_start_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_start_sound", out _currValue))
            {
                this.npc_start_sound = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_finish_action", out _currValue))
            {
                this.npc_finish_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_finish_effect", out _currValue))
            {
                this.npc_finish_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("finish_tips_i18n", out _currValue))
            {
                this.finish_tips_i18n = _currValue;
            }
            if(_itemData.TryGetValue("gather_icon", out _currValue))
            {
                this.gather_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_before_button_text_i18n", out _currValue))
            {
                this.gather_before_button_text_i18n = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("gather_button_text_i18n", out _currValue))
            {
                this.gather_button_text_i18n = _currValue;
            }
            if(_itemData.TryGetValue("start_script_group", out _currValue))
            {
                this.start_script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("end_script_group", out _currValue))
            {
                this.end_script_group = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_behaviour_id", out _currValue))
            {
                this.camera_behaviour_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("item_id", out _currValue))
            {
                this.item_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_npc_id", out _currValue))
            {
                this.call_npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_npc_count", out _currValue))
            {
                this.call_npc_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_npc_pro", out _currValue))
            {
                this.call_npc_pro = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_npc_radius", out _currValue))
            {
                this.call_npc_radius = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_gather";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_id":
                    return this.npc_id;
                case "show_by_task":
                    return this.show_by_task;
                case "gather_on_fight":
                    return this.gather_on_fight;
                case "total_count":
                    return this.total_count;
                case "reset_time":
                    return this.reset_time;
                case "show_count":
                    return this.show_count;
                case "life_skill_id":
                    return this.life_skill_id;
                case "life_skill_star_level":
                    return this.life_skill_star_level;
                case "finish_dynamic":
                    return this.finish_dynamic;
                case "time":
                    return this.time;
                case "limit_by_buff_id":
                    return this.limit_by_buff_id;
                case "limit_by_task":
                    return this.limit_by_task;
                case "limit_role_count":
                    return this.limit_role_count;
                case "is_direct_gather":
                    return this.is_direct_gather;
                case "finish_lifeskill_exp":
                    return this.finish_lifeskill_exp;
                case "get_address":
                    return this.get_address;
                case "role_action":
                    return this.role_action;
                case "npc_start_action":
                    return this.npc_start_action;
                case "npc_start_effect":
                    return this.npc_start_effect;
                case "npc_start_sound":
                    return this.npc_start_sound;
                case "npc_finish_action":
                    return this.npc_finish_action;
                case "npc_finish_effect":
                    return this.npc_finish_effect;
                case "finish_tips_i18n":
                    return this.finish_tips_i18n;
                case "gather_icon":
                    return this.gather_icon;
                case "gather_before_button_text_i18n":
                    return this.gather_before_button_text_i18n;
                case "gather_button_text_i18n":
                    return this.gather_button_text_i18n;
                case "start_script_group":
                    return this.start_script_group;
                case "end_script_group":
                    return this.end_script_group;
                case "camera_behaviour_id":
                    return this.camera_behaviour_id;
                case "item_id":
                    return this.item_id;
                case "call_npc_id":
                    return this.call_npc_id;
                case "call_npc_count":
                    return this.call_npc_count;
                case "call_npc_pro":
                    return this.call_npc_pro;
                case "call_npc_radius":
                    return this.call_npc_radius;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Gather> rows = _rows as List<Table_Npc_Gather>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Gather > ( rows, "map", "npc_id" );
            all_Table_Npc_Gather_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Gather_List.Clear();
        }
    }
}
