using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// puff类型
    ///</summary>
    [Serializable]
    [TableName("puff_type")]
    public partial class Table_Puff_Type : TableContent
    {

        private static List<Table_Puff_Type> all_Table_Puff_Type_List = new List<Table_Puff_Type>();
        //primary | 主键
        public static Dictionary<int, Table_Puff_Type > pool_primary = new Dictionary<int, Table_Puff_Type > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string ckey;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string description;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 是不是控制效果
        ///</summary>
        public bool is_control_puff;
        
        
        ///<summary>
        /// 是不是元素异常
        ///</summary>
        public bool is_abnormal_puff;
        
        
        ///<summary>
        /// 是否禁止移动
        ///</summary>
        public bool is_no_move;
        
        
        ///<summary>
        /// 是否禁止施法
        ///</summary>
        public bool is_no_cast_skill;
        
        
        ///<summary>
        /// 是否禁止普攻
        ///</summary>
        public bool is_no_normal_skill;
        
        
        ///<summary>
        /// 是否禁止药瓶
        ///</summary>
        public bool is_no_potion;
        
        
        ///<summary>
        /// 是否禁止采集
        ///</summary>
        public bool is_no_gather;
        
        
        ///<summary>
        /// 是否免疫法术伤害
        ///</summary>
        public bool is_immune_magical_hurt;
        
        
        ///<summary>
        /// 是否免疫物理伤害
        ///</summary>
        public bool is_immune_physical_hurt;
        
        
        ///<summary>
        /// 是否免疫元素伤害
        ///</summary>
        public bool is_immune_element_hurt;
        
        
        ///<summary>
        /// 是否免疫直接伤害
        ///</summary>
        public bool is_immune_direct_hurt;
        
        
        ///<summary>
        /// 是否免疫控制
        ///</summary>
        public bool is_immune_control;
        
        
        ///<summary>
        /// 是否隐身
        ///</summary>
        public bool is_stealth;
        
        
        ///<summary>
        /// 是否不能被选中
        ///</summary>
        public bool is_no_selected;
        
        
        ///<summary>
        /// 效果优先级
        ///</summary>
        public int priority;
        
        
        ///<summary>
        /// 图标
        ///</summary>
        public int icon_id;
        
        
        ///<summary>
        /// 特效
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 动作
        ///</summary>
        public int action_id;
        
        
        ///<summary>
        /// 特效是否定帧
        ///</summary>
        public bool is_frame_fixed;
        
        
        ///<summary>
        /// 是否替换死亡效果
        ///</summary>
        public bool is_replace_die;
        
        
        ///<summary>
        /// 死亡类型：1溶解，2隐藏
        ///</summary>
        public int die_type;
        
        
        ///<summary>
        /// 死亡特效
        ///</summary>
        public int die_effect_id;
        
        
        ///<summary>
        /// 死亡动作
        ///</summary>
        public int die_action_id;
        
        
        ///<summary>
        /// 材质球效果ID
        ///</summary>
        public int material_effect_id;
        
        
        ///<summary>
        /// 死亡材质球效果ID
        ///</summary>
        public int death_material_effect_id;
        
        
        ///<summary>
        /// 出现时是否飘字
        ///</summary>
        public bool is_floating_on_add;
        
        
        ///<summary>
        /// 出现时飘字模板ID
        ///</summary>
        public int floating_template_id_on_add;
        
        
        ///<summary>
        /// 出现时飘字文本
        ///</summary>
        public string floating_text_on_add;
        
        
        ///<summary>
        /// 出现时飘字文本国际化
        ///</summary>
        public string floating_text_on_add_i18n;
        
        
        ///<summary>
        /// 消失时是否飘字
        ///</summary>
        public bool is_floating_on_remove;
        
        
        ///<summary>
        /// 消失时飘字模板ID
        ///</summary>
        public int floating_template_id_on_remove;
        
        
        ///<summary>
        /// 消失时飘字文本
        ///</summary>
        public string floating_text_on_remove;
        
        
        ///<summary>
        /// 消失时飘字文本国际化
        ///</summary>
        public string floating_text_on_remove_i18n;
        
        
        ///<summary>
        /// 是不是坏puff
        ///</summary>
        public bool is_bad_skill_effect;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Puff_Type GetPrimary ( int _id ){        
            Table_Puff_Type _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Puff_Type > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Puff_Type> GetAllPrimaryList()
        {
            return all_Table_Puff_Type_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("description", out _currValue))
            {
                this.description = _currValue;
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("is_control_puff", out _currValue))
            {
                this.is_control_puff = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_abnormal_puff", out _currValue))
            {
                this.is_abnormal_puff = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_move", out _currValue))
            {
                this.is_no_move = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_cast_skill", out _currValue))
            {
                this.is_no_cast_skill = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_normal_skill", out _currValue))
            {
                this.is_no_normal_skill = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_potion", out _currValue))
            {
                this.is_no_potion = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_gather", out _currValue))
            {
                this.is_no_gather = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_immune_magical_hurt", out _currValue))
            {
                this.is_immune_magical_hurt = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_immune_physical_hurt", out _currValue))
            {
                this.is_immune_physical_hurt = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_immune_element_hurt", out _currValue))
            {
                this.is_immune_element_hurt = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_immune_direct_hurt", out _currValue))
            {
                this.is_immune_direct_hurt = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_immune_control", out _currValue))
            {
                this.is_immune_control = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_stealth", out _currValue))
            {
                this.is_stealth = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_no_selected", out _currValue))
            {
                this.is_no_selected = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("priority", out _currValue))
            {
                this.priority = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_id", out _currValue))
            {
                this.icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_id", out _currValue))
            {
                this.action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_frame_fixed", out _currValue))
            {
                this.is_frame_fixed = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_replace_die", out _currValue))
            {
                this.is_replace_die = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("die_type", out _currValue))
            {
                this.die_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("die_effect_id", out _currValue))
            {
                this.die_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("die_action_id", out _currValue))
            {
                this.die_action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("material_effect_id", out _currValue))
            {
                this.material_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("death_material_effect_id", out _currValue))
            {
                this.death_material_effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_floating_on_add", out _currValue))
            {
                this.is_floating_on_add = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_template_id_on_add", out _currValue))
            {
                this.floating_template_id_on_add = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_text_on_add", out _currValue))
            {
                this.floating_text_on_add = _currValue;
            }
            if(_itemData.TryGetValue("floating_text_on_add_i18n", out _currValue))
            {
                this.floating_text_on_add_i18n = _currValue;
            }
            if(_itemData.TryGetValue("is_floating_on_remove", out _currValue))
            {
                this.is_floating_on_remove = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_template_id_on_remove", out _currValue))
            {
                this.floating_template_id_on_remove = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("floating_text_on_remove", out _currValue))
            {
                this.floating_text_on_remove = _currValue;
            }
            if(_itemData.TryGetValue("floating_text_on_remove_i18n", out _currValue))
            {
                this.floating_text_on_remove_i18n = _currValue;
            }
            if(_itemData.TryGetValue("is_bad_skill_effect", out _currValue))
            {
                this.is_bad_skill_effect = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "puff_type";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                case "description":
                    return this.description;
                case "description_i18n":
                    return this.description_i18n;
                case "is_control_puff":
                    return this.is_control_puff;
                case "is_abnormal_puff":
                    return this.is_abnormal_puff;
                case "is_no_move":
                    return this.is_no_move;
                case "is_no_cast_skill":
                    return this.is_no_cast_skill;
                case "is_no_normal_skill":
                    return this.is_no_normal_skill;
                case "is_no_potion":
                    return this.is_no_potion;
                case "is_no_gather":
                    return this.is_no_gather;
                case "is_immune_magical_hurt":
                    return this.is_immune_magical_hurt;
                case "is_immune_physical_hurt":
                    return this.is_immune_physical_hurt;
                case "is_immune_element_hurt":
                    return this.is_immune_element_hurt;
                case "is_immune_direct_hurt":
                    return this.is_immune_direct_hurt;
                case "is_immune_control":
                    return this.is_immune_control;
                case "is_stealth":
                    return this.is_stealth;
                case "is_no_selected":
                    return this.is_no_selected;
                case "priority":
                    return this.priority;
                case "icon_id":
                    return this.icon_id;
                case "effect_id":
                    return this.effect_id;
                case "action_id":
                    return this.action_id;
                case "is_frame_fixed":
                    return this.is_frame_fixed;
                case "is_replace_die":
                    return this.is_replace_die;
                case "die_type":
                    return this.die_type;
                case "die_effect_id":
                    return this.die_effect_id;
                case "die_action_id":
                    return this.die_action_id;
                case "material_effect_id":
                    return this.material_effect_id;
                case "death_material_effect_id":
                    return this.death_material_effect_id;
                case "is_floating_on_add":
                    return this.is_floating_on_add;
                case "floating_template_id_on_add":
                    return this.floating_template_id_on_add;
                case "floating_text_on_add":
                    return this.floating_text_on_add;
                case "floating_text_on_add_i18n":
                    return this.floating_text_on_add_i18n;
                case "is_floating_on_remove":
                    return this.is_floating_on_remove;
                case "floating_template_id_on_remove":
                    return this.floating_template_id_on_remove;
                case "floating_text_on_remove":
                    return this.floating_text_on_remove;
                case "floating_text_on_remove_i18n":
                    return this.floating_text_on_remove_i18n;
                case "is_bad_skill_effect":
                    return this.is_bad_skill_effect;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Puff_Type> rows = _rows as List<Table_Puff_Type>;
            pool_primary=TableContent.ListToPool < int, Table_Puff_Type > ( rows, "map", "id" );
            all_Table_Puff_Type_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Puff_Type_List.Clear();
        }
    }
}
