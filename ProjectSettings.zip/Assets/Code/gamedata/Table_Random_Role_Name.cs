using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 随机角色名
    ///</summary>
    [Serializable]
    [TableName("random_role_name")]
    public partial class Table_Random_Role_Name : TableContent
    {

        private static List<Table_Random_Role_Name> all_Table_Random_Role_Name_List = new List<Table_Random_Role_Name>();
        //primary | 主键
        public static Dictionary<int, Table_Random_Role_Name > pool_primary = new Dictionary<int, Table_Random_Role_Name > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 类型：1=first_name、2=last_name
        ///</summary>
        public int type;
        
        
        ///<summary>
        /// 种族
        ///</summary>
        public int race;
        
        
        ///<summary>
        /// 内容
        ///</summary>
        public string value;
        
        
        ///<summary>
        /// 男生是否可用
        ///</summary>
        public bool is_boy;
        
        
        ///<summary>
        /// 女生是否可用
        ///</summary>
        public bool is_girl;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Random_Role_Name GetPrimary ( int _id ){        
            Table_Random_Role_Name _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Random_Role_Name > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Random_Role_Name> GetAllPrimaryList()
        {
            return all_Table_Random_Role_Name_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("type", out _currValue))
            {
                this.type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race", out _currValue))
            {
                this.race = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("value", out _currValue))
            {
                this.value = _currValue;
            }
            if(_itemData.TryGetValue("is_boy", out _currValue))
            {
                this.is_boy = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_girl", out _currValue))
            {
                this.is_girl = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "random_role_name";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "type":
                    return this.type;
                case "race":
                    return this.race;
                case "value":
                    return this.value;
                case "is_boy":
                    return this.is_boy;
                case "is_girl":
                    return this.is_girl;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Random_Role_Name> rows = _rows as List<Table_Random_Role_Name>;
            pool_primary=TableContent.ListToPool < int, Table_Random_Role_Name > ( rows, "map", "id" );
            all_Table_Random_Role_Name_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Random_Role_Name_List.Clear();
        }
    }
}
