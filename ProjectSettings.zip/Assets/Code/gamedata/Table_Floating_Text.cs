using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 浮动飘字模板
    ///</summary>
    [Serializable]
    [TableName("floating_text")]
    public partial class Table_Floating_Text : TableContent
    {

        private static List<Table_Floating_Text> all_Table_Floating_Text_List = new List<Table_Floating_Text>();
        //primary | 主键
        public static Dictionary<int, Table_Floating_Text > pool_primary = new Dictionary<int, Table_Floating_Text > ();
        
        
        ///<summary>
        /// 主键：模板ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 模板内容
        ///</summary>
        public string template;
        
        
        ///<summary>
        /// 曲线索引
        ///</summary>
        public int curveIndex;
        
        
        ///<summary>
        /// 是否有背景
        ///</summary>
        public bool useBackground;
        
        
        ///<summary>
        /// 背景颜色
        ///</summary>
        public string backgroundColor;
        
        
        ///<summary>
        /// 动画时间
        ///</summary>
        public int animationTotalTime;
        
        
        ///<summary>
        /// 距离
        ///</summary>
        public int distance;
        
        
        ///<summary>
        /// 文字前缀图片名字
        ///</summary>
        public string fontPrefixImgName;
        
        
        ///<summary>
        /// 数字图片的名字前缀
        ///</summary>
        public string fontNumberImgNamePrefix;
        
        
        ///<summary>
        /// 对齐方式
        ///</summary>
        public int spriteAlignment;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：模板ID</param>
        ///
        public static Table_Floating_Text GetPrimary ( int _id ){        
            Table_Floating_Text _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Floating_Text > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Floating_Text> GetAllPrimaryList()
        {
            return all_Table_Floating_Text_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("template", out _currValue))
            {
                this.template = _currValue;
            }
            if(_itemData.TryGetValue("curveIndex", out _currValue))
            {
                this.curveIndex = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("useBackground", out _currValue))
            {
                this.useBackground = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("backgroundColor", out _currValue))
            {
                this.backgroundColor = _currValue;
            }
            if(_itemData.TryGetValue("animationTotalTime", out _currValue))
            {
                this.animationTotalTime = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("distance", out _currValue))
            {
                this.distance = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fontPrefixImgName", out _currValue))
            {
                this.fontPrefixImgName = _currValue;
            }
            if(_itemData.TryGetValue("fontNumberImgNamePrefix", out _currValue))
            {
                this.fontNumberImgNamePrefix = _currValue;
            }
            if(_itemData.TryGetValue("spriteAlignment", out _currValue))
            {
                this.spriteAlignment = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "floating_text";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "template":
                    return this.template;
                case "curveIndex":
                    return this.curveIndex;
                case "useBackground":
                    return this.useBackground;
                case "backgroundColor":
                    return this.backgroundColor;
                case "animationTotalTime":
                    return this.animationTotalTime;
                case "distance":
                    return this.distance;
                case "fontPrefixImgName":
                    return this.fontPrefixImgName;
                case "fontNumberImgNamePrefix":
                    return this.fontNumberImgNamePrefix;
                case "spriteAlignment":
                    return this.spriteAlignment;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Floating_Text> rows = _rows as List<Table_Floating_Text>;
            pool_primary=TableContent.ListToPool < int, Table_Floating_Text > ( rows, "map", "id" );
            all_Table_Floating_Text_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Floating_Text_List.Clear();
        }
    }
}
