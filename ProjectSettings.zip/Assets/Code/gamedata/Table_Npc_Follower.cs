using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc随从
    ///</summary>
    [Serializable]
    [TableName("npc_follower")]
    public partial class Table_Npc_Follower : TableContent
    {

        private static List<Table_Npc_Follower> all_Table_Npc_Follower_List = new List<Table_Npc_Follower>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Npc_Follower > > pool_primary = new Dictionary<int, Dictionary<int, Table_Npc_Follower > > ();
        
        
        ///<summary>
        /// 主键：NPC模板ID
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 主键：随从编号
        ///</summary>
        public int follower_num;
        
        
        ///<summary>
        /// 随从的NPC模板ID
        ///</summary>
        public int follower_id;
        
        
        ///<summary>
        /// 召唤位置：顺时针旋转的角度，参照领队的朝向
        ///</summary>
        public int call_position_angle;
        
        
        ///<summary>
        /// 召唤位置：延伸距离(m)
        ///</summary>
        public float call_position_distance;
        
        
        ///<summary>
        /// 召唤位置：随机范围(m)
        ///</summary>
        public float call_position_random;
        
        
        ///<summary>
        /// 召唤朝向：参照npc_follower_direction表
        ///</summary>
        public int call_direction_type;
        
        
        ///<summary>
        /// 备注
        ///</summary>
        public string remark;
        
        
        ///<summary>
        /// 召唤类型
        ///</summary>
        public int follow_type;
        
        
        ///<summary>
        /// 位置x坐标
        ///</summary>
        public float position_x;
        
        
        ///<summary>
        /// 位置y坐标
        ///</summary>
        public float position_y;
        
        
        ///<summary>
        /// 位置z坐标
        ///</summary>
        public float position_z;
        
        
        ///<summary>
        /// 朝向x坐标
        ///</summary>
        public float direction_x;
        
        
        ///<summary>
        /// 朝向y坐标
        ///</summary>
        public float direction_y;
        
        
        ///<summary>
        /// 朝向z坐标
        ///</summary>
        public float direction_z;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcId> 主键：NPC模板ID</param>
        ///
        public static Dictionary<int, Table_Npc_Follower > GetPrimary ( int _npcId ){        
            Dictionary<int, Table_Npc_Follower > _map0=null;        
            pool_primary. TryGetValue(_npcId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcId> 主键：NPC模板ID</param>
        ///	<param followerNum> 主键：随从编号</param>
        ///
        public static Table_Npc_Follower GetPrimary ( int _npcId , int _followerNum ){        
            Dictionary<int, Table_Npc_Follower > _map0=null;        
            pool_primary. TryGetValue(_npcId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Npc_Follower _map1=null;        
            _map0. TryGetValue(_followerNum,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Npc_Follower > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Follower> GetAllPrimaryList()
        {
            return all_Table_Npc_Follower_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("follower_num", out _currValue))
            {
                this.follower_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("follower_id", out _currValue))
            {
                this.follower_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_position_angle", out _currValue))
            {
                this.call_position_angle = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_position_distance", out _currValue))
            {
                this.call_position_distance = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_position_random", out _currValue))
            {
                this.call_position_random = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_direction_type", out _currValue))
            {
                this.call_direction_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
            if(_itemData.TryGetValue("follow_type", out _currValue))
            {
                this.follow_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("position_x", out _currValue))
            {
                this.position_x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("position_y", out _currValue))
            {
                this.position_y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("position_z", out _currValue))
            {
                this.position_z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("direction_x", out _currValue))
            {
                this.direction_x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("direction_y", out _currValue))
            {
                this.direction_y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("direction_z", out _currValue))
            {
                this.direction_z = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_follower";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_id":
                    return this.npc_id;
                case "follower_num":
                    return this.follower_num;
                case "follower_id":
                    return this.follower_id;
                case "call_position_angle":
                    return this.call_position_angle;
                case "call_position_distance":
                    return this.call_position_distance;
                case "call_position_random":
                    return this.call_position_random;
                case "call_direction_type":
                    return this.call_direction_type;
                case "remark":
                    return this.remark;
                case "follow_type":
                    return this.follow_type;
                case "position_x":
                    return this.position_x;
                case "position_y":
                    return this.position_y;
                case "position_z":
                    return this.position_z;
                case "direction_x":
                    return this.direction_x;
                case "direction_y":
                    return this.direction_y;
                case "direction_z":
                    return this.direction_z;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Follower> rows = _rows as List<Table_Npc_Follower>;
            pool_primary=TableContent.ListToPool < int, int, Table_Npc_Follower > ( rows, "map", "npc_id", "follower_num" );
            all_Table_Npc_Follower_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Follower_List.Clear();
        }
    }
}
