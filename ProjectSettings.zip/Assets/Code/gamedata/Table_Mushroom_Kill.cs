using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 蘑菇人连杀
    ///</summary>
    [Serializable]
    [TableName("mushroom_kill")]
    public partial class Table_Mushroom_Kill : TableContent
    {

        private static List<Table_Mushroom_Kill> all_Table_Mushroom_Kill_List = new List<Table_Mushroom_Kill>();
        //primary | 主键
        public static Dictionary<int, Table_Mushroom_Kill > pool_primary = new Dictionary<int, Table_Mushroom_Kill > ();
        
        
        ///<summary>
        /// 击杀数量
        ///</summary>
        public int kill_count;
        
        
        ///<summary>
        /// 击杀提示图标
        ///</summary>
        public int kill_icon;
        
        
        ///<summary>
        /// 音效路径
        ///</summary>
        public string video_path;
        
        
        ///<summary>
        /// 连杀积分
        ///</summary>
        public int score;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param killCount> 击杀数量</param>
        ///
        public static Table_Mushroom_Kill GetPrimary ( int _killCount ){        
            Table_Mushroom_Kill _map0=null;        
            pool_primary. TryGetValue(_killCount,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Mushroom_Kill > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Mushroom_Kill> GetAllPrimaryList()
        {
            return all_Table_Mushroom_Kill_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("kill_count", out _currValue))
            {
                this.kill_count = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("kill_icon", out _currValue))
            {
                this.kill_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("video_path", out _currValue))
            {
                this.video_path = _currValue;
            }
            if(_itemData.TryGetValue("score", out _currValue))
            {
                this.score = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "mushroom_kill";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "kill_count":
                    return this.kill_count;
                case "kill_icon":
                    return this.kill_icon;
                case "video_path":
                    return this.video_path;
                case "score":
                    return this.score;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Mushroom_Kill> rows = _rows as List<Table_Mushroom_Kill>;
            pool_primary=TableContent.ListToPool < int, Table_Mushroom_Kill > ( rows, "map", "kill_count" );
            all_Table_Mushroom_Kill_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Mushroom_Kill_List.Clear();
        }
    }
}
