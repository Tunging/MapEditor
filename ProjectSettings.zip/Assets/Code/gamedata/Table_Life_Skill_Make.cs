using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 生活技能制作
    ///</summary>
    [Serializable]
    [TableName("life_skill_make")]
    public partial class Table_Life_Skill_Make : TableContent
    {

        private static List<Table_Life_Skill_Make> all_Table_Life_Skill_Make_List = new List<Table_Life_Skill_Make>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Life_Skill_Make > > pool_primary = new Dictionary<int, Dictionary<int, Table_Life_Skill_Make > > ();
        //currentMakeList | 
        public static Dictionary<int, List<Table_Life_Skill_Make> > pool_currentMakeList = new Dictionary<int, List<Table_Life_Skill_Make> > ();
        
        
        ///<summary>
        /// 主键：技能ID
        ///</summary>
        public int skill_id;
        
        
        ///<summary>
        /// 索引标识
        ///</summary>
        public int index;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string desc;
        
        
        ///<summary>
        /// 产出道具ID
        ///</summary>
        public int goods_id;
        
        
        ///<summary>
        /// 材料道具ID
        ///</summary>
        public int material_id;
        
        
        ///<summary>
        /// 材料道具数量
        ///</summary>
        public int material_count;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///
        public static Dictionary<int, Table_Life_Skill_Make > GetPrimary ( int _skillId ){        
            Dictionary<int, Table_Life_Skill_Make > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///	<param index> 索引标识</param>
        ///
        public static Table_Life_Skill_Make GetPrimary ( int _skillId , int _index ){        
            Dictionary<int, Table_Life_Skill_Make > _map0=null;        
            pool_primary. TryGetValue(_skillId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Life_Skill_Make _map1=null;        
            _map0. TryGetValue(_index,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Life_Skill_Make > > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param skillId> 主键：技能ID</param>
        ///
        public static List<Table_Life_Skill_Make> GetCurrentMakeList ( int _skillId ){        
            List<Table_Life_Skill_Make> _map0=null;        
            pool_currentMakeList. TryGetValue(_skillId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Life_Skill_Make> > GetAllCurrentMakeList()
        {
            return pool_currentMakeList;
        }


        ///查询出所有的数据
        public static List<Table_Life_Skill_Make> GetAllPrimaryList()
        {
            return all_Table_Life_Skill_Make_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("skill_id", out _currValue))
            {
                this.skill_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("index", out _currValue))
            {
                this.index = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("desc", out _currValue))
            {
                this.desc = _currValue;
            }
            if(_itemData.TryGetValue("goods_id", out _currValue))
            {
                this.goods_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("material_id", out _currValue))
            {
                this.material_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("material_count", out _currValue))
            {
                this.material_count = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "life_skill_make";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "skill_id":
                    return this.skill_id;
                case "index":
                    return this.index;
                case "desc":
                    return this.desc;
                case "goods_id":
                    return this.goods_id;
                case "material_id":
                    return this.material_id;
                case "material_count":
                    return this.material_count;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Life_Skill_Make> rows = _rows as List<Table_Life_Skill_Make>;
            pool_primary=TableContent.ListToPool < int, int, Table_Life_Skill_Make > ( rows, "map", "skill_id", "index" );
            pool_currentMakeList=TableContent.ListToPoolList < int, Table_Life_Skill_Make > ( rows, "list", "skill_id" );
            all_Table_Life_Skill_Make_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_currentMakeList.Clear();
            all_Table_Life_Skill_Make_List.Clear();
        }
    }
}
