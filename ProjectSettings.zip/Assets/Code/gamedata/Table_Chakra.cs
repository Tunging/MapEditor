using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 一级消耗
    ///</summary>
	[Serializable]
	[TableName("chakra")]
    public partial class Table_Chakra :TableContent
    {

                private static  List< Table_Chakra > all_Table_Chakra_List=new  List< Table_Chakra >();
                //primary | 主键
				public static 	Dictionary <int, Table_Chakra > pool_primary=new Dictionary <int, Table_Chakra > ();
        		///<summary>
        		/// 主键：ID
        		///</summary>
        		public int id;
        		///<summary>
        		/// 名称
        		///</summary>
        		public string name;
        		///<summary>
        		/// 上限属性类型
        		///</summary>
        		public int total_prop_type;
        		///<summary>
        		/// 战斗中恢复属性类型
        		///</summary>
        		public int fight_recover_prop_type;
        		///<summary>
        		/// 非战斗中恢复属性类型
        		///</summary>
        		public int nofight_recover_prop_type;
        		///<summary>
        		/// 保留值属性类型
        		///</summary>
        		public int retain_prop_type;
        		///<summary>
        		/// 受击获得属性类型
        		///</summary>
        		public int be_attack_prop_type;
        		///<summary>
        		/// 恢复时间间隔，毫秒
        		///</summary>
        		public int recover_time_interval;
        		///<summary>
        		/// 升级时是否回满
        		///</summary>
        		public bool level_up_full;
        		///<summary>
        		/// 下降时是否显示二层反馈
        		///</summary>
        		public bool is_show_feedback;
        		///<summary>
        		/// 一层能量条变化的时间间隔
        		///</summary>
        		public float energy_change_animation_time_interval;
        		///<summary>
        		/// 二层能量条变化的时间间隔
        		///</summary>
        		public float energy_change_animation_time_interval2;
        		///<summary>
        		/// 二层能量条变化的开始的延迟
        		///</summary>
        		public float energy_change_animation_time_interval2_start_delay;

				///<summary>
                /// 主键
                /// 查询数据
                ///</summary>
				///	<param id> 主键：ID</param>
          		///
				public static 	Table_Chakra GetPrimary ( int _id ){
                        Table_Chakra _map0=null;
						pool_primary. TryGetValue(_id,out _map0);
						return  _map0;
				}
        		 ///<summary>
                ///主键
                ///查询所有数据
                ///</summary>
				public static Dictionary <int, Table_Chakra > GetAllPrimary(){
						return pool_primary;
				}


				///查询出所有的数据
				public static List<Table_Chakra> GetAllPrimaryList(){
						return all_Table_Chakra_List;
				}


    	        public override void ParseFrom(Dictionary<string, string> _itemData) {
					string _currValue = "";
					if(_itemData.TryGetValue("id", out _currValue)){
        		        this.id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("name", out _currValue)){
        		        this.name = _currValue;
					}

					if(_itemData.TryGetValue("total_prop_type", out _currValue)){
        		        this.total_prop_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("fight_recover_prop_type", out _currValue)){
        		        this.fight_recover_prop_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("nofight_recover_prop_type", out _currValue)){
        		        this.nofight_recover_prop_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("retain_prop_type", out _currValue)){
        		        this.retain_prop_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("be_attack_prop_type", out _currValue)){
        		        this.be_attack_prop_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("recover_time_interval", out _currValue)){
        		        this.recover_time_interval = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("level_up_full", out _currValue)){
        		        this.level_up_full = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("is_show_feedback", out _currValue)){
        		        this.is_show_feedback = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("energy_change_animation_time_interval", out _currValue)){
        		        this.energy_change_animation_time_interval = Utils.GetFloatFromString(_currValue);
					}

					if(_itemData.TryGetValue("energy_change_animation_time_interval2", out _currValue)){
        		        this.energy_change_animation_time_interval2 = Utils.GetFloatFromString(_currValue);
					}

					if(_itemData.TryGetValue("energy_change_animation_time_interval2_start_delay", out _currValue)){
        		        this.energy_change_animation_time_interval2_start_delay = Utils.GetFloatFromString(_currValue);
					}

				}

                 public override string Table()
                 {
                    return "chakra";
                 }

                 public  override object GetValue(string column) {
        	            switch (column) {
        		            case "id":
            	            return this.id;
        		            case "name":
            	            return this.name;
        		            case "total_prop_type":
            	            return this.total_prop_type;
        		            case "fight_recover_prop_type":
            	            return this.fight_recover_prop_type;
        		            case "nofight_recover_prop_type":
            	            return this.nofight_recover_prop_type;
        		            case "retain_prop_type":
            	            return this.retain_prop_type;
        		            case "be_attack_prop_type":
            	            return this.be_attack_prop_type;
        		            case "recover_time_interval":
            	            return this.recover_time_interval;
        		            case "level_up_full":
            	            return this.level_up_full;
        		            case "is_show_feedback":
            	            return this.is_show_feedback;
        		            case "energy_change_animation_time_interval":
            	            return this.energy_change_animation_time_interval;
        		            case "energy_change_animation_time_interval2":
            	            return this.energy_change_animation_time_interval2;
        		            case "energy_change_animation_time_interval2_start_delay":
            	            return this.energy_change_animation_time_interval2_start_delay;
        		            default:
                        return null;
			            }
		         }
                 public static void InitPool(IList _rows){
							List<Table_Chakra> rows = _rows as List<Table_Chakra>;
                      		pool_primary=TableContent.ListToPool < int, Table_Chakra > ( rows, "map", "id" );
							all_Table_Chakra_List=rows;
                 }

                public static void Clear()
                {
                       pool_primary.Clear();
                       all_Table_Chakra_List.Clear();

                }
    }
}
