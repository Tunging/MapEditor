using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 道具类型
    ///</summary>
	[Serializable]
	[TableName("item_type")]
    public partial class Table_Item_Type :TableContent
    {

                private static  List< Table_Item_Type > all_Table_Item_Type_List=new  List< Table_Item_Type >();
                //primary | 主键
				public static 	Dictionary <int, Table_Item_Type > pool_primary=new Dictionary <int, Table_Item_Type > ();
        		///<summary>
        		/// 主键：类型ID
        		///</summary>
        		public int id;
        		///<summary>
        		/// 配置key
        		///</summary>
        		public string ckey;
        		///<summary>
        		/// 名称国际化
        		///</summary>
        		public string name_i18n;
        		///<summary>
        		/// 显示顺序
        		///</summary>
        		public int show_order;
        		///<summary>
        		/// 背包标签
        		///</summary>
        		public int bag_tab;
        		///<summary>
        		/// 是否请求详细信息
        		///</summary>
        		public bool req_detail;
        		///<summary>
        		/// 堆叠上限
        		///</summary>
        		public int repeat_max;
        		///<summary>
        		/// 是否可以单个使用
        		///</summary>
        		public bool can_single_use;
        		///<summary>
        		/// 是否可以批量使用
        		///</summary>
        		public bool can_batch_use;
        		///<summary>
        		/// 备注
        		///</summary>
        		public string remark;
        		///<summary>
        		/// 使用类型（ 0是消耗，1是跳转, 2是弹提示）
        		///</summary>
        		public int use_type;
        		///<summary>
        		/// 使用类型为跳转的参数（panelId）
        		///</summary>
        		public int use_type_jump_panel_id;
        		///<summary>
        		/// 使用类型为弹提示的提示内容
        		///</summary>
        		public int use_type_tips_msg_id;
        		///<summary>
        		/// 获得物品小窗口
        		///</summary>
        		public bool small_use_window;

				///<summary>
                /// 主键
                /// 查询数据
                ///</summary>
				///	<param id> 主键：类型ID</param>
          		///
				public static 	Table_Item_Type GetPrimary ( int _id ){
                        Table_Item_Type _map0=null;
						pool_primary. TryGetValue(_id,out _map0);
						return  _map0;
				}
        		 ///<summary>
                ///主键
                ///查询所有数据
                ///</summary>
				public static Dictionary <int, Table_Item_Type > GetAllPrimary(){
						return pool_primary;
				}


				///查询出所有的数据
				public static List<Table_Item_Type> GetAllPrimaryList(){
						return all_Table_Item_Type_List;
				}


    	        public override void ParseFrom(Dictionary<string, string> _itemData) {
					string _currValue = "";
					if(_itemData.TryGetValue("id", out _currValue)){
        		        this.id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("ckey", out _currValue)){
        		        this.ckey = _currValue;
					}

					if(_itemData.TryGetValue("name_i18n", out _currValue)){
        		        this.name_i18n = _currValue;
					}

					if(_itemData.TryGetValue("show_order", out _currValue)){
        		        this.show_order = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("bag_tab", out _currValue)){
        		        this.bag_tab = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("req_detail", out _currValue)){
        		        this.req_detail = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("repeat_max", out _currValue)){
        		        this.repeat_max = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("can_single_use", out _currValue)){
        		        this.can_single_use = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("can_batch_use", out _currValue)){
        		        this.can_batch_use = Utils.GetBoolFromString(_currValue);
					}

					if(_itemData.TryGetValue("remark", out _currValue)){
        		        this.remark = _currValue;
					}

					if(_itemData.TryGetValue("use_type", out _currValue)){
        		        this.use_type = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("use_type_jump_panel_id", out _currValue)){
        		        this.use_type_jump_panel_id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("use_type_tips_msg_id", out _currValue)){
        		        this.use_type_tips_msg_id = Utils.GetIntFromString(_currValue);
					}

					if(_itemData.TryGetValue("small_use_window", out _currValue)){
        		        this.small_use_window = Utils.GetBoolFromString(_currValue);
					}

				}

                 public override string Table()
                 {
                    return "item_type";
                 }

                 public  override object GetValue(string column) {
        	            switch (column) {
        		            case "id":
            	            return this.id;
        		            case "ckey":
            	            return this.ckey;
        		            case "name_i18n":
            	            return this.name_i18n;
        		            case "show_order":
            	            return this.show_order;
        		            case "bag_tab":
            	            return this.bag_tab;
        		            case "req_detail":
            	            return this.req_detail;
        		            case "repeat_max":
            	            return this.repeat_max;
        		            case "can_single_use":
            	            return this.can_single_use;
        		            case "can_batch_use":
            	            return this.can_batch_use;
        		            case "remark":
            	            return this.remark;
        		            case "use_type":
            	            return this.use_type;
        		            case "use_type_jump_panel_id":
            	            return this.use_type_jump_panel_id;
        		            case "use_type_tips_msg_id":
            	            return this.use_type_tips_msg_id;
        		            case "small_use_window":
            	            return this.small_use_window;
        		            default:
                        return null;
			            }
		         }
                 public static void InitPool(IList _rows){
							List<Table_Item_Type> rows = _rows as List<Table_Item_Type>;
                      		pool_primary=TableContent.ListToPool < int, Table_Item_Type > ( rows, "map", "id" );
							all_Table_Item_Type_List=rows;
                 }

                public static void Clear()
                {
                       pool_primary.Clear();
                       all_Table_Item_Type_List.Clear();

                }
    }
}
