using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 副本进入角色数量对应buff
    ///</summary>
    [Serializable]
    [TableName("instance_dynamic_diffculty")]
    public partial class Table_Instance_Dynamic_Diffculty : TableContent
    {

        private static List<Table_Instance_Dynamic_Diffculty> all_Table_Instance_Dynamic_Diffculty_List = new List<Table_Instance_Dynamic_Diffculty>();
        //primary | 主键
        public static Dictionary<int, Table_Instance_Dynamic_Diffculty > pool_primary = new Dictionary<int, Table_Instance_Dynamic_Diffculty > ();
        
        
        ///<summary>
        /// 人数
        ///</summary>
        public int num;
        
        
        ///<summary>
        /// 给角色的buff
        ///</summary>
        public int role_buff;
        
        
        ///<summary>
        /// 给npc的buff
        ///</summary>
        public int npc_buff;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param num> 人数</param>
        ///
        public static Table_Instance_Dynamic_Diffculty GetPrimary ( int _num ){        
            Table_Instance_Dynamic_Diffculty _map0=null;        
            pool_primary. TryGetValue(_num,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Instance_Dynamic_Diffculty > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Instance_Dynamic_Diffculty> GetAllPrimaryList()
        {
            return all_Table_Instance_Dynamic_Diffculty_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("num", out _currValue))
            {
                this.num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_buff", out _currValue))
            {
                this.role_buff = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("npc_buff", out _currValue))
            {
                this.npc_buff = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "instance_dynamic_diffculty";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "num":
                    return this.num;
                case "role_buff":
                    return this.role_buff;
                case "npc_buff":
                    return this.npc_buff;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Instance_Dynamic_Diffculty> rows = _rows as List<Table_Instance_Dynamic_Diffculty>;
            pool_primary=TableContent.ListToPool < int, Table_Instance_Dynamic_Diffculty > ( rows, "map", "num" );
            all_Table_Instance_Dynamic_Diffculty_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Instance_Dynamic_Diffculty_List.Clear();
        }
    }
}
