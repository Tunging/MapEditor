using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// TG_common_inputWindow 通用输入框
    ///</summary>
    [Serializable]
    [TableName("common_input_window_config")]
    public partial class Table_Common_Input_Window_Config : TableContent
    {

        private static List<Table_Common_Input_Window_Config> all_Table_Common_Input_Window_Config_List = new List<Table_Common_Input_Window_Config>();
        //primary | 主键
        public static Dictionary<int, Table_Common_Input_Window_Config > pool_primary = new Dictionary<int, Table_Common_Input_Window_Config > ();
        
        
        ///<summary>
        /// 主键：ID 输入文档框的ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 窗口标题文本ID
        ///</summary>
        public int title_id;
        
        
        ///<summary>
        /// 输入框内显示的提示文本ID
        ///</summary>
        public int text_id;
        
        
        ///<summary>
        /// 确定意向的按钮文本ID
        ///</summary>
        public int button_text1_id;
        
        
        ///<summary>
        /// 否定意向的按键文本ID
        ///</summary>
        public int button_text2_id;
        
        
        ///<summary>
        /// 输入框类型（0-文本输入框，1-数字输入框）
        ///</summary>
        public int input_type;
        
        
        ///<summary>
        /// 可输入的文字长度
        ///</summary>
        public int input_limit;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID 输入文档框的ID</param>
        ///
        public static Table_Common_Input_Window_Config GetPrimary ( int _id ){        
            Table_Common_Input_Window_Config _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Common_Input_Window_Config > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Common_Input_Window_Config> GetAllPrimaryList()
        {
            return all_Table_Common_Input_Window_Config_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("title_id", out _currValue))
            {
                this.title_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("text_id", out _currValue))
            {
                this.text_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("button_text1_id", out _currValue))
            {
                this.button_text1_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("button_text2_id", out _currValue))
            {
                this.button_text2_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("input_type", out _currValue))
            {
                this.input_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("input_limit", out _currValue))
            {
                this.input_limit = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "common_input_window_config";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "title_id":
                    return this.title_id;
                case "text_id":
                    return this.text_id;
                case "button_text1_id":
                    return this.button_text1_id;
                case "button_text2_id":
                    return this.button_text2_id;
                case "input_type":
                    return this.input_type;
                case "input_limit":
                    return this.input_limit;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Common_Input_Window_Config> rows = _rows as List<Table_Common_Input_Window_Config>;
            pool_primary=TableContent.ListToPool < int, Table_Common_Input_Window_Config > ( rows, "map", "id" );
            all_Table_Common_Input_Window_Config_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Common_Input_Window_Config_List.Clear();
        }
    }
}
