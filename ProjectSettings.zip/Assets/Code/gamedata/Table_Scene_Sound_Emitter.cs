using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景音效触发器
    ///</summary>
    [Serializable]
    [TableName("scene_sound_emitter")]
    public partial class Table_Scene_Sound_Emitter : TableContent
    {

        private static List<Table_Scene_Sound_Emitter> all_Table_Scene_Sound_Emitter_List = new List<Table_Scene_Sound_Emitter>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Scene_Sound_Emitter > > pool_primary = new Dictionary<int, Dictionary<int, Table_Scene_Sound_Emitter > > ();
        
        
        ///<summary>
        /// 音效组id
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string des_i18n;
        
        
        ///<summary>
        /// 形状 (1,cube ;2,sphere)
        ///</summary>
        public int shape;
        
        
        ///<summary>
        /// 半径
        ///</summary>
        public float radius;
        
        
        ///<summary>
        /// 长度
        ///</summary>
        public float wall_length;
        
        
        ///<summary>
        /// 宽度
        ///</summary>
        public float wall_width;
        
        
        ///<summary>
        /// 高度
        ///</summary>
        public float wall_height;
        
        
        ///<summary>
        /// x坐标
        ///</summary>
        public float x;
        
        
        ///<summary>
        /// y坐标
        ///</summary>
        public float y;
        
        
        ///<summary>
        /// z坐标
        ///</summary>
        public float z;
        
        
        ///<summary>
        /// 旋转角度（从正北方向顺时针旋转）
        ///</summary>
        public float angle;
        
        
        ///<summary>
        /// 触发时的音效事件ID
        ///</summary>
        public int sound_id;
        
        
        ///<summary>
        /// 触发器类型
        ///</summary>
        public int trigger_type;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 音效组id</param>
        ///
        public static Dictionary<int, Table_Scene_Sound_Emitter > GetPrimary ( int _groupId ){        
            Dictionary<int, Table_Scene_Sound_Emitter > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param groupId> 音效组id</param>
        ///	<param id> id</param>
        ///
        public static Table_Scene_Sound_Emitter GetPrimary ( int _groupId , int _id ){        
            Dictionary<int, Table_Scene_Sound_Emitter > _map0=null;        
            pool_primary. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Scene_Sound_Emitter _map1=null;        
            _map0. TryGetValue(_id,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Scene_Sound_Emitter > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Sound_Emitter> GetAllPrimaryList()
        {
            return all_Table_Scene_Sound_Emitter_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("des_i18n", out _currValue))
            {
                this.des_i18n = _currValue;
            }
            if(_itemData.TryGetValue("shape", out _currValue))
            {
                this.shape = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("radius", out _currValue))
            {
                this.radius = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("wall_length", out _currValue))
            {
                this.wall_length = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("wall_width", out _currValue))
            {
                this.wall_width = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("wall_height", out _currValue))
            {
                this.wall_height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("x", out _currValue))
            {
                this.x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("y", out _currValue))
            {
                this.y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("z", out _currValue))
            {
                this.z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("angle", out _currValue))
            {
                this.angle = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("trigger_type", out _currValue))
            {
                this.trigger_type = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_sound_emitter";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "group_id":
                    return this.group_id;
                case "id":
                    return this.id;
                case "des_i18n":
                    return this.des_i18n;
                case "shape":
                    return this.shape;
                case "radius":
                    return this.radius;
                case "wall_length":
                    return this.wall_length;
                case "wall_width":
                    return this.wall_width;
                case "wall_height":
                    return this.wall_height;
                case "x":
                    return this.x;
                case "y":
                    return this.y;
                case "z":
                    return this.z;
                case "angle":
                    return this.angle;
                case "sound_id":
                    return this.sound_id;
                case "trigger_type":
                    return this.trigger_type;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Sound_Emitter> rows = _rows as List<Table_Scene_Sound_Emitter>;
            pool_primary=TableContent.ListToPool < int, int, Table_Scene_Sound_Emitter > ( rows, "map", "group_id", "id" );
            all_Table_Scene_Sound_Emitter_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Sound_Emitter_List.Clear();
        }
    }
}
