using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 场景电梯
    ///</summary>
    [Serializable]
    [TableName("scene_elevator")]
    public partial class Table_Scene_Elevator : TableContent
    {

        private static List<Table_Scene_Elevator> all_Table_Scene_Elevator_List = new List<Table_Scene_Elevator>();
        //primary | 主键
        public static Dictionary<int, Table_Scene_Elevator > pool_primary = new Dictionary<int, Table_Scene_Elevator > ();
        
        
        ///<summary>
        /// 主键：Id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 传送时的模型ID
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 开始传送时播放的特效
        ///</summary>
        public int effect_start;
        
        
        ///<summary>
        /// 传送结束时播放的特效
        ///</summary>
        public int effect_end;
        
        
        ///<summary>
        /// 电梯路径点集合
        ///</summary>
        public string path;
        
        
        ///<summary>
        /// 摄像机路径点集合
        ///</summary>
        public string camera_path;
        
        
        ///<summary>
        /// 速度
        ///</summary>
        public float speed;
        
        
        ///<summary>
        /// 目标点X坐标
        ///</summary>
        public float target_x;
        
        
        ///<summary>
        /// 目标点Y坐标
        ///</summary>
        public float target_y;
        
        
        ///<summary>
        /// 目标点Z坐标
        ///</summary>
        public float target_z;
        
        
        ///<summary>
        /// 交互图标
        ///</summary>
        public int interaction_icon;
        
        
        ///<summary>
        /// 动态模糊开始时间
        ///</summary>
        public float motionblurstarttime;
        
        
        ///<summary>
        /// 动态模糊结束时间
        ///</summary>
        public float motionblurendtime;
        
        
        ///<summary>
        /// 特效脚本参数1
        ///</summary>
        public float sample_dist;
        
        
        ///<summary>
        /// 特效脚本参数2
        ///</summary>
        public float sample_strength;
        
        
        ///<summary>
        /// 声音ID
        ///</summary>
        public int sound_bank_id;
        
        
        ///<summary>
        /// 是否在开始的时候锁定镜头,等候玩家操作
        ///</summary>
        public bool is_lock_look_direction_on_start;
        
        
        ///<summary>
        /// 载具id
        ///</summary>
        public int carrier_id;
        
        
        ///<summary>
        /// 摄像机高度
        ///</summary>
        public float camera_height;
        
        
        ///<summary>
        /// 摄像机距离
        ///</summary>
        public float camera_distance;
        
        
        ///<summary>
        /// 是否缓动到起点位置
        ///</summary>
        public bool is_lerp_to_start;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：Id</param>
        ///
        public static Table_Scene_Elevator GetPrimary ( int _id ){        
            Table_Scene_Elevator _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Scene_Elevator > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Scene_Elevator> GetAllPrimaryList()
        {
            return all_Table_Scene_Elevator_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_start", out _currValue))
            {
                this.effect_start = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_end", out _currValue))
            {
                this.effect_end = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
            if(_itemData.TryGetValue("camera_path", out _currValue))
            {
                this.camera_path = _currValue;
            }
            if(_itemData.TryGetValue("speed", out _currValue))
            {
                this.speed = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_x", out _currValue))
            {
                this.target_x = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_y", out _currValue))
            {
                this.target_y = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("target_z", out _currValue))
            {
                this.target_z = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("interaction_icon", out _currValue))
            {
                this.interaction_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("motionblurstarttime", out _currValue))
            {
                this.motionblurstarttime = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("motionblurendtime", out _currValue))
            {
                this.motionblurendtime = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("sample_dist", out _currValue))
            {
                this.sample_dist = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("sample_strength", out _currValue))
            {
                this.sample_strength = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("sound_bank_id", out _currValue))
            {
                this.sound_bank_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_lock_look_direction_on_start", out _currValue))
            {
                this.is_lock_look_direction_on_start = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("carrier_id", out _currValue))
            {
                this.carrier_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_height", out _currValue))
            {
                this.camera_height = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_distance", out _currValue))
            {
                this.camera_distance = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("is_lerp_to_start", out _currValue))
            {
                this.is_lerp_to_start = Utils.GetBoolFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "scene_elevator";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "model_id":
                    return this.model_id;
                case "effect_start":
                    return this.effect_start;
                case "effect_end":
                    return this.effect_end;
                case "path":
                    return this.path;
                case "camera_path":
                    return this.camera_path;
                case "speed":
                    return this.speed;
                case "target_x":
                    return this.target_x;
                case "target_y":
                    return this.target_y;
                case "target_z":
                    return this.target_z;
                case "interaction_icon":
                    return this.interaction_icon;
                case "motionblurstarttime":
                    return this.motionblurstarttime;
                case "motionblurendtime":
                    return this.motionblurendtime;
                case "sample_dist":
                    return this.sample_dist;
                case "sample_strength":
                    return this.sample_strength;
                case "sound_bank_id":
                    return this.sound_bank_id;
                case "is_lock_look_direction_on_start":
                    return this.is_lock_look_direction_on_start;
                case "carrier_id":
                    return this.carrier_id;
                case "camera_height":
                    return this.camera_height;
                case "camera_distance":
                    return this.camera_distance;
                case "is_lerp_to_start":
                    return this.is_lerp_to_start;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Scene_Elevator> rows = _rows as List<Table_Scene_Elevator>;
            pool_primary=TableContent.ListToPool < int, Table_Scene_Elevator > ( rows, "map", "id" );
            all_Table_Scene_Elevator_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Scene_Elevator_List.Clear();
        }
    }
}
