using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 角色职业
    ///</summary>
    [Serializable]
    [TableName("profession")]
    public partial class Table_Profession : TableContent
    {

        private static List<Table_Profession> all_Table_Profession_List = new List<Table_Profession>();
        //primary | 主键
        public static Dictionary<int, Table_Profession > pool_primary = new Dictionary<int, Table_Profession > ();
        //raceId | 
        public static Dictionary<int, List<Table_Profession> > pool_raceId = new Dictionary<int, List<Table_Profession> > ();
        
        
        ///<summary>
        /// 主键：职业ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public string name_i18n;
        
        
        ///<summary>
        /// 所属的种族
        ///</summary>
        public int race_id;
        
        
        ///<summary>
        /// 出生点
        ///</summary>
        public int birth_point;
        
        
        ///<summary>
        /// 宠物ID
        ///</summary>
        public int pet_id;
        
        
        ///<summary>
        /// 翻滚耐力值上限
        ///</summary>
        public int roll_stamina_limit;
        
        
        ///<summary>
        /// 翻滚耐力每秒回复值
        ///</summary>
        public int roll_stamina_unit;
        
        
        ///<summary>
        /// 头像图标ID
        ///</summary>
        public int header_icon_id;
        
        
        ///<summary>
        /// 模型资源ID
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 创建模型资源ID
        ///</summary>
        public int create_model_id;
        
        
        ///<summary>
        /// 技能指示图标
        ///</summary>
        public int skill_icon;
        
        
        ///<summary>
        /// 空白时的武器道具ID
        ///</summary>
        public int empty_weapon;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        
        
        ///<summary>
        /// 选中状态的图标
        ///</summary>
        public int icon_select;
        
        
        ///<summary>
        /// 未选中状态的图标
        ///</summary>
        public int icon_unselect;
        
        
        ///<summary>
        /// 职业名字对应的美术资源
        ///</summary>
        public int name_icon;
        
        
        ///<summary>
        /// 职业上手难度
        ///</summary>
        public float difficulty;
        
        
        ///<summary>
        /// 描述的图片id
        ///</summary>
        public int description_icon_id;
        
        
        ///<summary>
        /// 主界面队伍区域显示的图标
        ///</summary>
        public int main_win_team_icon;
        
        
        ///<summary>
        /// 队伍界面显示的图标
        ///</summary>
        public int team_win_icon;
        
        
        ///<summary>
        /// 副本门票界面职业图标
        ///</summary>
        public int instance_ticket_icon;
        
        
        ///<summary>
        /// 选人界面的武器（同时也是默认的武器）
        ///</summary>
        public int select_weapon_id;
        
        
        ///<summary>
        /// 职业背景描述国际化
        ///</summary>
        public string background_des_i18n;
        
        
        ///<summary>
        /// 默认武器时装ID
        ///</summary>
        public int default_weapon_fashion_id;
        
        
        ///<summary>
        /// 武器立绘ID
        ///</summary>
        public int weapon_drawing_id;
        
        
        ///<summary>
        /// 模型动作状态机ID
        ///</summary>
        public int model_fsm_id;
        
        
        ///<summary>
        /// 创建按钮的图标ID
        ///</summary>
        public int create_button_icon_id;
        
        
        ///<summary>
        /// 切换动作
        ///</summary>
        public int switch_action;
        
        
        ///<summary>
        /// 休闲动作
        ///</summary>
        public int play_action;
        
        
        ///<summary>
        /// 能力影响指数
        ///</summary>
        public string exponent;
        
        
        ///<summary>
        /// 创建时装id 
        ///</summary>
        public int create_fashion_id;
        
        
        ///<summary>
        /// 默认时装id
        ///</summary>
        public int default_fashion_id;
        
        
        ///<summary>
        /// 一级消耗
        ///</summary>
        public int chakra_id;
        
        
        ///<summary>
        /// 一级消耗 进度条资源路径
        ///</summary>
        public int chakra_icon_id;
        
        
        ///<summary>
        /// 二级消耗 图标 满
        ///</summary>
        public int chakra_full_icon;
        
        
        ///<summary>
        /// 二级消耗 图标 空
        ///</summary>
        public int chakra_empty_icon;
        
        
        ///<summary>
        /// 二级消耗 满时身上的特效id
        ///</summary>
        public int chakra_full_effect;
        
        
        ///<summary>
        /// 在创角时是否开放职业
        ///</summary>
        public bool dispark;
        
        
        ///<summary>
        /// 1级能量消耗icon
        ///</summary>
        public int first_consume_icon;
        
        
        ///<summary>
        /// 一级消耗 进度条资源路径（人物信息界面）
        ///</summary>
        public int first_consume_slider;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：职业ID</param>
        ///
        public static Table_Profession GetPrimary ( int _id ){        
            Table_Profession _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Profession > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param raceId> 所属的种族</param>
        ///
        public static List<Table_Profession> GetRaceId ( int _raceId ){        
            List<Table_Profession> _map0=null;        
            pool_raceId. TryGetValue(_raceId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, List<Table_Profession> > GetAllRaceId()
        {
            return pool_raceId;
        }


        ///查询出所有的数据
        public static List<Table_Profession> GetAllPrimaryList()
        {
            return all_Table_Profession_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = _currValue;
            }
            if(_itemData.TryGetValue("race_id", out _currValue))
            {
                this.race_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("birth_point", out _currValue))
            {
                this.birth_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pet_id", out _currValue))
            {
                this.pet_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("roll_stamina_limit", out _currValue))
            {
                this.roll_stamina_limit = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("roll_stamina_unit", out _currValue))
            {
                this.roll_stamina_unit = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("header_icon_id", out _currValue))
            {
                this.header_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("create_model_id", out _currValue))
            {
                this.create_model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("skill_icon", out _currValue))
            {
                this.skill_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("empty_weapon", out _currValue))
            {
                this.empty_weapon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
            if(_itemData.TryGetValue("icon_select", out _currValue))
            {
                this.icon_select = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("icon_unselect", out _currValue))
            {
                this.icon_unselect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_icon", out _currValue))
            {
                this.name_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("difficulty", out _currValue))
            {
                this.difficulty = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_icon_id", out _currValue))
            {
                this.description_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("main_win_team_icon", out _currValue))
            {
                this.main_win_team_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("team_win_icon", out _currValue))
            {
                this.team_win_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("instance_ticket_icon", out _currValue))
            {
                this.instance_ticket_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("select_weapon_id", out _currValue))
            {
                this.select_weapon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("background_des_i18n", out _currValue))
            {
                this.background_des_i18n = _currValue;
            }
            if(_itemData.TryGetValue("default_weapon_fashion_id", out _currValue))
            {
                this.default_weapon_fashion_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weapon_drawing_id", out _currValue))
            {
                this.weapon_drawing_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_fsm_id", out _currValue))
            {
                this.model_fsm_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("create_button_icon_id", out _currValue))
            {
                this.create_button_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("switch_action", out _currValue))
            {
                this.switch_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("play_action", out _currValue))
            {
                this.play_action = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("exponent", out _currValue))
            {
                this.exponent = _currValue;
            }
            if(_itemData.TryGetValue("create_fashion_id", out _currValue))
            {
                this.create_fashion_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("default_fashion_id", out _currValue))
            {
                this.default_fashion_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_id", out _currValue))
            {
                this.chakra_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_icon_id", out _currValue))
            {
                this.chakra_icon_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_full_icon", out _currValue))
            {
                this.chakra_full_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_empty_icon", out _currValue))
            {
                this.chakra_empty_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("chakra_full_effect", out _currValue))
            {
                this.chakra_full_effect = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("dispark", out _currValue))
            {
                this.dispark = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("first_consume_icon", out _currValue))
            {
                this.first_consume_icon = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("first_consume_slider", out _currValue))
            {
                this.first_consume_slider = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "profession";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name_i18n":
                    return this.name_i18n;
                case "race_id":
                    return this.race_id;
                case "birth_point":
                    return this.birth_point;
                case "pet_id":
                    return this.pet_id;
                case "roll_stamina_limit":
                    return this.roll_stamina_limit;
                case "roll_stamina_unit":
                    return this.roll_stamina_unit;
                case "header_icon_id":
                    return this.header_icon_id;
                case "model_id":
                    return this.model_id;
                case "create_model_id":
                    return this.create_model_id;
                case "skill_icon":
                    return this.skill_icon;
                case "empty_weapon":
                    return this.empty_weapon;
                case "description_i18n":
                    return this.description_i18n;
                case "icon_select":
                    return this.icon_select;
                case "icon_unselect":
                    return this.icon_unselect;
                case "name_icon":
                    return this.name_icon;
                case "difficulty":
                    return this.difficulty;
                case "description_icon_id":
                    return this.description_icon_id;
                case "main_win_team_icon":
                    return this.main_win_team_icon;
                case "team_win_icon":
                    return this.team_win_icon;
                case "instance_ticket_icon":
                    return this.instance_ticket_icon;
                case "select_weapon_id":
                    return this.select_weapon_id;
                case "background_des_i18n":
                    return this.background_des_i18n;
                case "default_weapon_fashion_id":
                    return this.default_weapon_fashion_id;
                case "weapon_drawing_id":
                    return this.weapon_drawing_id;
                case "model_fsm_id":
                    return this.model_fsm_id;
                case "create_button_icon_id":
                    return this.create_button_icon_id;
                case "switch_action":
                    return this.switch_action;
                case "play_action":
                    return this.play_action;
                case "exponent":
                    return this.exponent;
                case "create_fashion_id":
                    return this.create_fashion_id;
                case "default_fashion_id":
                    return this.default_fashion_id;
                case "chakra_id":
                    return this.chakra_id;
                case "chakra_icon_id":
                    return this.chakra_icon_id;
                case "chakra_full_icon":
                    return this.chakra_full_icon;
                case "chakra_empty_icon":
                    return this.chakra_empty_icon;
                case "chakra_full_effect":
                    return this.chakra_full_effect;
                case "dispark":
                    return this.dispark;
                case "first_consume_icon":
                    return this.first_consume_icon;
                case "first_consume_slider":
                    return this.first_consume_slider;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Profession> rows = _rows as List<Table_Profession>;
            pool_primary=TableContent.ListToPool < int, Table_Profession > ( rows, "map", "id" );
            pool_raceId=TableContent.ListToPoolList < int, Table_Profession > ( rows, "list", "race_id" );
            all_Table_Profession_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_raceId.Clear();
            all_Table_Profession_List.Clear();
        }
    }
}
