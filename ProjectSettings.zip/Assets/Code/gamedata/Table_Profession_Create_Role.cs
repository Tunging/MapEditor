using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 创角时候职业信息数据
    ///</summary>
    [Serializable]
    [TableName("profession_create_role")]
    public partial class Table_Profession_Create_Role : TableContent
    {

        private static List<Table_Profession_Create_Role> all_Table_Profession_Create_Role_List = new List<Table_Profession_Create_Role>();
        //primary | 主键
        public static Dictionary<int, Table_Profession_Create_Role > pool_primary = new Dictionary<int, Table_Profession_Create_Role > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 模型id
        ///</summary>
        public int model_id;
        
        
        ///<summary>
        /// 出场动作id
        ///</summary>
        public int acton_id;
        
        
        ///<summary>
        /// 出场动作时间
        ///</summary>
        public int action_time;
        
        
        ///<summary>
        /// 休闲动作id
        ///</summary>
        public string casual_action_id;
        
        
        ///<summary>
        /// 待机动作id
        ///</summary>
        public int default_action_id;
        
        
        ///<summary>
        /// 背包角色展示中，摄像机距离
        ///</summary>
        public float bag_role_show_camera_distance;
        
        
        ///<summary>
        /// 背包角色展示中，角色在屏幕位置
        ///</summary>
        public string bag_role_show_role_position;
        
        
        ///<summary>
        /// 背包角色展示中，角色初始旋转方向
        ///</summary>
        public string bag_role_show_role_init_rotation;
        
        
        ///<summary>
        /// 宠物距离主人的随机半径
        ///</summary>
        public float pet_distance_from_owner;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Profession_Create_Role GetPrimary ( int _id ){        
            Table_Profession_Create_Role _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Profession_Create_Role > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Profession_Create_Role> GetAllPrimaryList()
        {
            return all_Table_Profession_Create_Role_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("model_id", out _currValue))
            {
                this.model_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("acton_id", out _currValue))
            {
                this.acton_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_time", out _currValue))
            {
                this.action_time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("casual_action_id", out _currValue))
            {
                this.casual_action_id = _currValue;
            }
            if(_itemData.TryGetValue("default_action_id", out _currValue))
            {
                this.default_action_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("bag_role_show_camera_distance", out _currValue))
            {
                this.bag_role_show_camera_distance = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("bag_role_show_role_position", out _currValue))
            {
                this.bag_role_show_role_position = _currValue;
            }
            if(_itemData.TryGetValue("bag_role_show_role_init_rotation", out _currValue))
            {
                this.bag_role_show_role_init_rotation = _currValue;
            }
            if(_itemData.TryGetValue("pet_distance_from_owner", out _currValue))
            {
                this.pet_distance_from_owner = Utils.GetFloatFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "profession_create_role";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "model_id":
                    return this.model_id;
                case "acton_id":
                    return this.acton_id;
                case "action_time":
                    return this.action_time;
                case "casual_action_id":
                    return this.casual_action_id;
                case "default_action_id":
                    return this.default_action_id;
                case "bag_role_show_camera_distance":
                    return this.bag_role_show_camera_distance;
                case "bag_role_show_role_position":
                    return this.bag_role_show_role_position;
                case "bag_role_show_role_init_rotation":
                    return this.bag_role_show_role_init_rotation;
                case "pet_distance_from_owner":
                    return this.pet_distance_from_owner;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Profession_Create_Role> rows = _rows as List<Table_Profession_Create_Role>;
            pool_primary=TableContent.ListToPool < int, Table_Profession_Create_Role > ( rows, "map", "id" );
            all_Table_Profession_Create_Role_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Profession_Create_Role_List.Clear();
        }
    }
}
