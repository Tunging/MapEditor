using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 客户端：场景物件加载
    ///</summary>
    [Serializable]
    [TableName("client_object_loading")]
    public partial class Table_Client_Object_Loading : TableContent
    {

        private static List<Table_Client_Object_Loading> all_Table_Client_Object_Loading_List = new List<Table_Client_Object_Loading>();
        //primary | 主键
        public static Dictionary<int, Table_Client_Object_Loading > pool_primary = new Dictionary<int, Table_Client_Object_Loading > ();
        
        
        ///<summary>
        /// 主键
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 地形加载圈数
        ///</summary>
        public int terrain_circle_num;
        
        
        ///<summary>
        /// 超大物件加载圈数
        ///</summary>
        public int object_super_num;
        
        
        ///<summary>
        /// 大物件加载圈数
        ///</summary>
        public int object_big_num;
        
        
        ///<summary>
        /// 中物件加载圈数
        ///</summary>
        public int object_mid_num;
        
        
        ///<summary>
        /// 小物件加载圈数
        ///</summary>
        public int object_small_num;
        
        
        ///<summary>
        /// 雾效开始范围（米）
        ///</summary>
        public int fog_start_range;
        
        
        ///<summary>
        /// 雾效结束范围（米）
        ///</summary>
        public int fog_end_range;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键</param>
        ///
        public static Table_Client_Object_Loading GetPrimary ( int _id ){        
            Table_Client_Object_Loading _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Client_Object_Loading > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Client_Object_Loading> GetAllPrimaryList()
        {
            return all_Table_Client_Object_Loading_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("terrain_circle_num", out _currValue))
            {
                this.terrain_circle_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("object_super_num", out _currValue))
            {
                this.object_super_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("object_big_num", out _currValue))
            {
                this.object_big_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("object_mid_num", out _currValue))
            {
                this.object_mid_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("object_small_num", out _currValue))
            {
                this.object_small_num = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fog_start_range", out _currValue))
            {
                this.fog_start_range = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("fog_end_range", out _currValue))
            {
                this.fog_end_range = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "client_object_loading";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "terrain_circle_num":
                    return this.terrain_circle_num;
                case "object_super_num":
                    return this.object_super_num;
                case "object_big_num":
                    return this.object_big_num;
                case "object_mid_num":
                    return this.object_mid_num;
                case "object_small_num":
                    return this.object_small_num;
                case "fog_start_range":
                    return this.fog_start_range;
                case "fog_end_range":
                    return this.fog_end_range;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Client_Object_Loading> rows = _rows as List<Table_Client_Object_Loading>;
            pool_primary=TableContent.ListToPool < int, Table_Client_Object_Loading > ( rows, "map", "id" );
            all_Table_Client_Object_Loading_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Client_Object_Loading_List.Clear();
        }
    }
}
