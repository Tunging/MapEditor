using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 主相机动画
    ///</summary>
    [Serializable]
    [TableName("main_camera_animation")]
    public partial class Table_Main_Camera_Animation : TableContent
    {

        private static List<Table_Main_Camera_Animation> all_Table_Main_Camera_Animation_List = new List<Table_Main_Camera_Animation>();
        //primary | 主键
        public static Dictionary<int, Table_Main_Camera_Animation > pool_primary = new Dictionary<int, Table_Main_Camera_Animation > ();
        
        
        ///<summary>
        /// Id
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 资源路径
        ///</summary>
        public string path;
        
        
        ///<summary>
        /// 是否可操作左摇杆
        ///</summary>
        public bool allowLeftJoystick;
        
        
        ///<summary>
        /// 是否可操作右摇杆
        ///</summary>
        public bool allowRightJoystick;
        
        
        ///<summary>
        /// 开始时摄像机的过渡时间
        ///</summary>
        public float beginTransitTime;
        
        
        ///<summary>
        /// 结束时摄像机的过渡时间
        ///</summary>
        public float endTransitTime;
        
        
        ///<summary>
        /// 结束时摄像机的默认坐标(x,y,z)
        ///</summary>
        public string revertPosition;
        
        
        ///<summary>
        /// 结束时摄像机的默认旋转角度(x,y,z)
        ///</summary>
        public string revertEuler;
        
        
        ///<summary>
        /// 资源初始相对位置 (如果是（0,0,0），则为玩家位置)
        ///</summary>
        public string relativePosition;
        
        
        ///<summary>
        /// 资源相对npc
        ///</summary>
        public int relativeNpc;
        
        
        ///<summary>
        /// 是否无敌
        ///</summary>
        public bool canhurt;
        
        
        ///<summary>
        /// 是否显示UI
        ///</summary>
        public bool showUi;
        
        
        ///<summary>
        /// 添加指定buff
        ///</summary>
        public int buffId;
        
        
        ///<summary>
        /// 结束播放时看向目标的方式 (0：摄像机初始位置.-1:看向触发次动画的NPC)
        ///</summary>
        public int look_rotation_type_on_end;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> Id</param>
        ///
        public static Table_Main_Camera_Animation GetPrimary ( int _id ){        
            Table_Main_Camera_Animation _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Main_Camera_Animation > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Main_Camera_Animation> GetAllPrimaryList()
        {
            return all_Table_Main_Camera_Animation_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("path", out _currValue))
            {
                this.path = _currValue;
            }
            if(_itemData.TryGetValue("allowLeftJoystick", out _currValue))
            {
                this.allowLeftJoystick = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("allowRightJoystick", out _currValue))
            {
                this.allowRightJoystick = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("beginTransitTime", out _currValue))
            {
                this.beginTransitTime = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("endTransitTime", out _currValue))
            {
                this.endTransitTime = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("revertPosition", out _currValue))
            {
                this.revertPosition = _currValue;
            }
            if(_itemData.TryGetValue("revertEuler", out _currValue))
            {
                this.revertEuler = _currValue;
            }
            if(_itemData.TryGetValue("relativePosition", out _currValue))
            {
                this.relativePosition = _currValue;
            }
            if(_itemData.TryGetValue("relativeNpc", out _currValue))
            {
                this.relativeNpc = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("canhurt", out _currValue))
            {
                this.canhurt = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("showUi", out _currValue))
            {
                this.showUi = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("buffId", out _currValue))
            {
                this.buffId = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("look_rotation_type_on_end", out _currValue))
            {
                this.look_rotation_type_on_end = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "main_camera_animation";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "path":
                    return this.path;
                case "allowLeftJoystick":
                    return this.allowLeftJoystick;
                case "allowRightJoystick":
                    return this.allowRightJoystick;
                case "beginTransitTime":
                    return this.beginTransitTime;
                case "endTransitTime":
                    return this.endTransitTime;
                case "revertPosition":
                    return this.revertPosition;
                case "revertEuler":
                    return this.revertEuler;
                case "relativePosition":
                    return this.relativePosition;
                case "relativeNpc":
                    return this.relativeNpc;
                case "canhurt":
                    return this.canhurt;
                case "showUi":
                    return this.showUi;
                case "buffId":
                    return this.buffId;
                case "look_rotation_type_on_end":
                    return this.look_rotation_type_on_end;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Main_Camera_Animation> rows = _rows as List<Table_Main_Camera_Animation>;
            pool_primary=TableContent.ListToPool < int, Table_Main_Camera_Animation > ( rows, "map", "id" );
            all_Table_Main_Camera_Animation_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Main_Camera_Animation_List.Clear();
        }
    }
}
