using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 剧情动画组
    ///</summary>
    [Serializable]
    [TableName("plot_script_group")]
    public partial class Table_Plot_Script_Group : TableContent
    {

        private static List<Table_Plot_Script_Group> all_Table_Plot_Script_Group_List = new List<Table_Plot_Script_Group>();
        //primary | 主键
        public static Dictionary<int, Table_Plot_Script_Group > pool_primary = new Dictionary<int, Table_Plot_Script_Group > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string des;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Plot_Script_Group GetPrimary ( int _id ){        
            Table_Plot_Script_Group _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Plot_Script_Group > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Plot_Script_Group> GetAllPrimaryList()
        {
            return all_Table_Plot_Script_Group_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("des", out _currValue))
            {
                this.des = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "plot_script_group";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "des":
                    return this.des;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Plot_Script_Group> rows = _rows as List<Table_Plot_Script_Group>;
            pool_primary=TableContent.ListToPool < int, Table_Plot_Script_Group > ( rows, "map", "id" );
            all_Table_Plot_Script_Group_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Plot_Script_Group_List.Clear();
        }
    }
}
