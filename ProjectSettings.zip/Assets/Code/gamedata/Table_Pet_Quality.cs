using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 宠物资质
    ///</summary>
    [Serializable]
    [TableName("pet_quality")]
    public partial class Table_Pet_Quality : TableContent
    {

        private static List<Table_Pet_Quality> all_Table_Pet_Quality_List = new List<Table_Pet_Quality>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Pet_Quality > > pool_primary = new Dictionary<int, Dictionary<int, Table_Pet_Quality > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 主键：ID 属性id
        ///</summary>
        public int pro;
        
        
        ///<summary>
        /// 资质最小值
        ///</summary>
        public int min;
        
        
        ///<summary>
        /// 资质最大值
        ///</summary>
        public int max;
        
        
        ///<summary>
        /// 基础属性
        ///</summary>
        public int base_pro;
        
        
        ///<summary>
        /// 成长
        ///</summary>
        public int grow;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public int name;
        
        
        ///<summary>
        /// 名称国际化
        ///</summary>
        public int name_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Dictionary<int, Table_Pet_Quality > GetPrimary ( int _id ){        
            Dictionary<int, Table_Pet_Quality > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///	<param pro> 主键：ID 属性id</param>
        ///
        public static Table_Pet_Quality GetPrimary ( int _id , int _pro ){        
            Dictionary<int, Table_Pet_Quality > _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Pet_Quality _map1=null;        
            _map0. TryGetValue(_pro,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Pet_Quality > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Pet_Quality> GetAllPrimaryList()
        {
            return all_Table_Pet_Quality_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("pro", out _currValue))
            {
                this.pro = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("min", out _currValue))
            {
                this.min = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("max", out _currValue))
            {
                this.max = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("base_pro", out _currValue))
            {
                this.base_pro = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("grow", out _currValue))
            {
                this.grow = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name_i18n", out _currValue))
            {
                this.name_i18n = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "pet_quality";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "pro":
                    return this.pro;
                case "min":
                    return this.min;
                case "max":
                    return this.max;
                case "base_pro":
                    return this.base_pro;
                case "grow":
                    return this.grow;
                case "name":
                    return this.name;
                case "name_i18n":
                    return this.name_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Pet_Quality> rows = _rows as List<Table_Pet_Quality>;
            pool_primary=TableContent.ListToPool < int, int, Table_Pet_Quality > ( rows, "map", "id", "pro" );
            all_Table_Pet_Quality_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Pet_Quality_List.Clear();
        }
    }
}
