using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 求救文本
    ///</summary>
    [Serializable]
    [TableName("rescuer_text")]
    public partial class Table_Rescuer_Text : TableContent
    {

        private static List<Table_Rescuer_Text> all_Table_Rescuer_Text_List = new List<Table_Rescuer_Text>();
        //primary | 主键
        public static Dictionary<int, Table_Rescuer_Text > pool_primary = new Dictionary<int, Table_Rescuer_Text > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 队伍状态
        ///</summary>
        public int teamStatus;
        
        
        ///<summary>
        /// 播放时机
        ///</summary>
        public int playType;
        
        
        ///<summary>
        /// 权重
        ///</summary>
        public int weight;
        
        
        ///<summary>
        /// 求助文本
        ///</summary>
        public int role_text_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Rescuer_Text GetPrimary ( int _id ){        
            Table_Rescuer_Text _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Rescuer_Text > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Rescuer_Text> GetAllPrimaryList()
        {
            return all_Table_Rescuer_Text_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("teamStatus", out _currValue))
            {
                this.teamStatus = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("playType", out _currValue))
            {
                this.playType = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_text_id", out _currValue))
            {
                this.role_text_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "rescuer_text";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "teamStatus":
                    return this.teamStatus;
                case "playType":
                    return this.playType;
                case "weight":
                    return this.weight;
                case "role_text_id":
                    return this.role_text_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Rescuer_Text> rows = _rows as List<Table_Rescuer_Text>;
            pool_primary=TableContent.ListToPool < int, Table_Rescuer_Text > ( rows, "map", "id" );
            all_Table_Rescuer_Text_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Rescuer_Text_List.Clear();
        }
    }
}
