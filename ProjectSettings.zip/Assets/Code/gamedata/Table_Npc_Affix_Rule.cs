using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc词缀生成规则
    ///</summary>
    [Serializable]
    [TableName("npc_affix_rule")]
    public partial class Table_Npc_Affix_Rule : TableContent
    {

        private static List<Table_Npc_Affix_Rule> all_Table_Npc_Affix_Rule_List = new List<Table_Npc_Affix_Rule>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > > pool_primary = new Dictionary<int, Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > > ();
        
        
        ///<summary>
        /// 主键：词缀包ID
        ///</summary>
        public int pack_id;
        
        
        ///<summary>
        /// 主键：分组ID
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 主键：BUFF ID
        ///</summary>
        public int buff_id;
        
        
        ///<summary>
        /// 随机权重
        ///</summary>
        public int weight;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packId> 主键：词缀包ID</param>
        ///
        public static Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > GetPrimary ( int _packId ){        
            Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > _map0=null;        
            pool_primary. TryGetValue(_packId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packId> 主键：词缀包ID</param>
        ///	<param groupId> 主键：分组ID</param>
        ///
        public static Dictionary<int, Table_Npc_Affix_Rule > GetPrimary ( int _packId , int _groupId ){        
            Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > _map0=null;        
            pool_primary. TryGetValue(_packId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Npc_Affix_Rule > _map1=null;        
            _map0. TryGetValue(_groupId,out _map1);        
            if(_map1==null){
                return null;
            }
            return  _map1;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param packId> 主键：词缀包ID</param>
        ///	<param groupId> 主键：分组ID</param>
        ///	<param buffId> 主键：BUFF ID</param>
        ///
        public static Table_Npc_Affix_Rule GetPrimary ( int _packId , int _groupId , int _buffId ){        
            Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > _map0=null;        
            pool_primary. TryGetValue(_packId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Dictionary<int, Table_Npc_Affix_Rule > _map1=null;        
            _map0. TryGetValue(_groupId,out _map1);        
            if(_map1==null){
                return null;
            }
        
            Table_Npc_Affix_Rule _map2=null;        
            _map1. TryGetValue(_buffId,out _map2);        
            return  _map2;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Dictionary<int, Table_Npc_Affix_Rule > > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Affix_Rule> GetAllPrimaryList()
        {
            return all_Table_Npc_Affix_Rule_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("pack_id", out _currValue))
            {
                this.pack_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("buff_id", out _currValue))
            {
                this.buff_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("weight", out _currValue))
            {
                this.weight = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_affix_rule";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "pack_id":
                    return this.pack_id;
                case "group_id":
                    return this.group_id;
                case "buff_id":
                    return this.buff_id;
                case "weight":
                    return this.weight;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Affix_Rule> rows = _rows as List<Table_Npc_Affix_Rule>;
            pool_primary=TableContent.ListToPool < int, int, int, Table_Npc_Affix_Rule > ( rows, "map", "pack_id", "group_id", "buff_id" );
            all_Table_Npc_Affix_Rule_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Affix_Rule_List.Clear();
        }
    }
}
