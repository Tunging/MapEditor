using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 食人花配置
    ///</summary>
    [Serializable]
    [TableName("npc_eating_flower")]
    public partial class Table_Npc_Eating_Flower : TableContent
    {

        private static List<Table_Npc_Eating_Flower> all_Table_Npc_Eating_Flower_List = new List<Table_Npc_Eating_Flower>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Eating_Flower > pool_primary = new Dictionary<int, Table_Npc_Eating_Flower > ();
        
        
        ///<summary>
        /// npc模板id
        ///</summary>
        public int npc_id;
        
        
        ///<summary>
        /// 每次点击增加进度条量
        ///</summary>
        public float add_rate;
        
        
        ///<summary>
        /// 吞噬后进度条减少量
        ///</summary>
        public string reduce_rate;
        
        
        ///<summary>
        /// 食人花受击动作
        ///</summary>
        public int action_be_attack_param;
        
        
        ///<summary>
        /// 食人花吞噬状态动作
        ///</summary>
        public int action_eating_param;
        
        
        ///<summary>
        /// 食人花结束吞噬动作
        ///</summary>
        public int action_idle_param;
        
        
        ///<summary>
        /// 被食人花吞噬后的初始进度
        ///</summary>
        public float init_progress;
        
        
        ///<summary>
        /// 气泡显示(language表ID|持续时间|间隔时间|权重, ...)
        ///</summary>
        public string call_help_bubble;
        
        
        ///<summary>
        /// 挣扎界面提示文字
        ///</summary>
        public string struggle_window_tip;
        
        
        ///<summary>
        /// 挣扎成功后玩家跳跃的npc_catapult表id
        ///</summary>
        public int jump_catapult_id;
        
        
        ///<summary>
        /// 进入食人花关联相机ID
        ///</summary>
        public int in_camera_id;
        
        
        ///<summary>
        /// 退出食人花关联相机ID
        ///</summary>
        public int out_camera_id;
        
        
        ///<summary>
        ///  挣扎速度上限
        ///</summary>
        public float struggle_max_speed;
        
        
        ///<summary>
        /// 挣扎动作状态机参数
        ///</summary>
        public string strugle_param_name;
        
        
        ///<summary>
        /// 挣扎动作类型(0：点击速度，1：进度条)
        ///</summary>
        public int strugle_action_type;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param npcId> npc模板id</param>
        ///
        public static Table_Npc_Eating_Flower GetPrimary ( int _npcId ){        
            Table_Npc_Eating_Flower _map0=null;        
            pool_primary. TryGetValue(_npcId,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Eating_Flower > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Eating_Flower> GetAllPrimaryList()
        {
            return all_Table_Npc_Eating_Flower_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("add_rate", out _currValue))
            {
                this.add_rate = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("reduce_rate", out _currValue))
            {
                this.reduce_rate = _currValue;
            }
            if(_itemData.TryGetValue("action_be_attack_param", out _currValue))
            {
                this.action_be_attack_param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_eating_param", out _currValue))
            {
                this.action_eating_param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("action_idle_param", out _currValue))
            {
                this.action_idle_param = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("init_progress", out _currValue))
            {
                this.init_progress = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("call_help_bubble", out _currValue))
            {
                this.call_help_bubble = _currValue;
            }
            if(_itemData.TryGetValue("struggle_window_tip", out _currValue))
            {
                this.struggle_window_tip = _currValue;
            }
            if(_itemData.TryGetValue("jump_catapult_id", out _currValue))
            {
                this.jump_catapult_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("in_camera_id", out _currValue))
            {
                this.in_camera_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("out_camera_id", out _currValue))
            {
                this.out_camera_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("struggle_max_speed", out _currValue))
            {
                this.struggle_max_speed = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("strugle_param_name", out _currValue))
            {
                this.strugle_param_name = _currValue;
            }
            if(_itemData.TryGetValue("strugle_action_type", out _currValue))
            {
                this.strugle_action_type = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_eating_flower";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "npc_id":
                    return this.npc_id;
                case "add_rate":
                    return this.add_rate;
                case "reduce_rate":
                    return this.reduce_rate;
                case "action_be_attack_param":
                    return this.action_be_attack_param;
                case "action_eating_param":
                    return this.action_eating_param;
                case "action_idle_param":
                    return this.action_idle_param;
                case "init_progress":
                    return this.init_progress;
                case "call_help_bubble":
                    return this.call_help_bubble;
                case "struggle_window_tip":
                    return this.struggle_window_tip;
                case "jump_catapult_id":
                    return this.jump_catapult_id;
                case "in_camera_id":
                    return this.in_camera_id;
                case "out_camera_id":
                    return this.out_camera_id;
                case "struggle_max_speed":
                    return this.struggle_max_speed;
                case "strugle_param_name":
                    return this.strugle_param_name;
                case "strugle_action_type":
                    return this.strugle_action_type;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Eating_Flower> rows = _rows as List<Table_Npc_Eating_Flower>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Eating_Flower > ( rows, "map", "npc_id" );
            all_Table_Npc_Eating_Flower_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Eating_Flower_List.Clear();
        }
    }
}
