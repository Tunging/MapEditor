using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// npc对话（废弃）
    ///</summary>
    [Serializable]
    [TableName("npc_dialog")]
    public partial class Table_Npc_Dialog : TableContent
    {

        private static List<Table_Npc_Dialog> all_Table_Npc_Dialog_List = new List<Table_Npc_Dialog>();
        //primary | 主键
        public static Dictionary<int, Table_Npc_Dialog > pool_primary = new Dictionary<int, Table_Npc_Dialog > ();
        
        
        ///<summary>
        /// 主键：对话ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 标题国际化
        ///</summary>
        public string title_i18n;
        
        
        ///<summary>
        /// 名字
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 对话内容国际化
        ///</summary>
        public string content_i18n;
        
        
        ///<summary>
        /// 播放声音ID
        ///</summary>
        public int content_sound_id;
        
        
        ///<summary>
        /// 是否显示关闭对话项
        ///</summary>
        public bool show_close_item;
        
        
        ///<summary>
        /// 关闭对话内容国际化
        ///</summary>
        public string close_content_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：对话ID</param>
        ///
        public static Table_Npc_Dialog GetPrimary ( int _id ){        
            Table_Npc_Dialog _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Npc_Dialog > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Dialog> GetAllPrimaryList()
        {
            return all_Table_Npc_Dialog_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("title_i18n", out _currValue))
            {
                this.title_i18n = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("content_i18n", out _currValue))
            {
                this.content_i18n = _currValue;
            }
            if(_itemData.TryGetValue("content_sound_id", out _currValue))
            {
                this.content_sound_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("show_close_item", out _currValue))
            {
                this.show_close_item = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("close_content_i18n", out _currValue))
            {
                this.close_content_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_dialog";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "title_i18n":
                    return this.title_i18n;
                case "name":
                    return this.name;
                case "content_i18n":
                    return this.content_i18n;
                case "content_sound_id":
                    return this.content_sound_id;
                case "show_close_item":
                    return this.show_close_item;
                case "close_content_i18n":
                    return this.close_content_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Dialog> rows = _rows as List<Table_Npc_Dialog>;
            pool_primary=TableContent.ListToPool < int, Table_Npc_Dialog > ( rows, "map", "id" );
            all_Table_Npc_Dialog_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Dialog_List.Clear();
        }
    }
}
