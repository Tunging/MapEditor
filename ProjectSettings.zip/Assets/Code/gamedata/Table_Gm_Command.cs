using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// gm命令
    ///</summary>
    [Serializable]
    [TableName("gm_command")]
    public partial class Table_Gm_Command : TableContent
    {

        private static List<Table_Gm_Command> all_Table_Gm_Command_List = new List<Table_Gm_Command>();
        //primary | 主键
        public static Dictionary<int, Table_Gm_Command > pool_primary = new Dictionary<int, Table_Gm_Command > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 模块ID
        ///</summary>
        public int module_id;
        
        
        ///<summary>
        /// 模块名称
        ///</summary>
        public string module_name;
        
        
        ///<summary>
        /// 名字
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// GM对应的处理类
        ///</summary>
        public string gm_class;
        
        
        ///<summary>
        /// 配置key
        ///</summary>
        public string ckey;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Gm_Command GetPrimary ( int _id ){        
            Table_Gm_Command _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Gm_Command > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Gm_Command> GetAllPrimaryList()
        {
            return all_Table_Gm_Command_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("module_id", out _currValue))
            {
                this.module_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("module_name", out _currValue))
            {
                this.module_name = _currValue;
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("gm_class", out _currValue))
            {
                this.gm_class = _currValue;
            }
            if(_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "gm_command";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "module_id":
                    return this.module_id;
                case "module_name":
                    return this.module_name;
                case "name":
                    return this.name;
                case "gm_class":
                    return this.gm_class;
                case "ckey":
                    return this.ckey;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Gm_Command> rows = _rows as List<Table_Gm_Command>;
            pool_primary=TableContent.ListToPool < int, Table_Gm_Command > ( rows, "map", "id" );
            all_Table_Gm_Command_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Gm_Command_List.Clear();
        }
    }
}
