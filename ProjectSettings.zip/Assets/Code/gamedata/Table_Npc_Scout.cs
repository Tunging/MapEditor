using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 侦察兵配置表
    ///</summary>
    [Serializable]
    [TableName("npc_scout")]
    public partial class Table_Npc_Scout : TableContent
    {

        private static List<Table_Npc_Scout> all_Table_Npc_Scout_List = new List<Table_Npc_Scout>();
        //primary | 主键
        public static Dictionary<int, Dictionary<int, Table_Npc_Scout > > pool_primary = new Dictionary<int, Dictionary<int, Table_Npc_Scout > > ();
        
        
        ///<summary>
        /// 侦察兵ID：NPC GUID
        ///</summary>
        public int guid;
        
        
        ///<summary>
        /// 步骤ID
        ///</summary>
        public int step_id;
        
        
        ///<summary>
        /// 内容类型
        ///</summary>
        public int content_type;
        
        
        ///<summary>
        /// 内容ID
        ///</summary>
        public int content_id;
        
        
        ///<summary>
        /// 特效ID
        ///</summary>
        public int effect_id;
        
        
        ///<summary>
        /// 特效挂点
        ///</summary>
        public int effect_point;
        
        
        ///<summary>
        /// 持续时间
        ///</summary>
        public int time;
        
        
        ///<summary>
        /// 转移至下一步速度
        ///</summary>
        public int speed;
        
        
        ///<summary>
        /// 声音ID
        ///</summary>
        public int audio_id;
        
        
        ///<summary>
        /// 描述
        ///</summary>
        public string discription;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param guid> 侦察兵ID：NPC GUID</param>
        ///
        public static Dictionary<int, Table_Npc_Scout > GetPrimary ( int _guid ){        
            Dictionary<int, Table_Npc_Scout > _map0=null;        
            pool_primary. TryGetValue(_guid,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param guid> 侦察兵ID：NPC GUID</param>
        ///	<param stepId> 步骤ID</param>
        ///
        public static Table_Npc_Scout GetPrimary ( int _guid , int _stepId ){        
            Dictionary<int, Table_Npc_Scout > _map0=null;        
            pool_primary. TryGetValue(_guid,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Npc_Scout _map1=null;        
            _map0. TryGetValue(_stepId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Npc_Scout > > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Npc_Scout> GetAllPrimaryList()
        {
            return all_Table_Npc_Scout_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("guid", out _currValue))
            {
                this.guid = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("step_id", out _currValue))
            {
                this.step_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("content_type", out _currValue))
            {
                this.content_type = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("content_id", out _currValue))
            {
                this.content_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_id", out _currValue))
            {
                this.effect_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("effect_point", out _currValue))
            {
                this.effect_point = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("time", out _currValue))
            {
                this.time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("speed", out _currValue))
            {
                this.speed = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("audio_id", out _currValue))
            {
                this.audio_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("discription", out _currValue))
            {
                this.discription = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "npc_scout";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "guid":
                    return this.guid;
                case "step_id":
                    return this.step_id;
                case "content_type":
                    return this.content_type;
                case "content_id":
                    return this.content_id;
                case "effect_id":
                    return this.effect_id;
                case "effect_point":
                    return this.effect_point;
                case "time":
                    return this.time;
                case "speed":
                    return this.speed;
                case "audio_id":
                    return this.audio_id;
                case "discription":
                    return this.discription;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Npc_Scout> rows = _rows as List<Table_Npc_Scout>;
            pool_primary=TableContent.ListToPool < int, int, Table_Npc_Scout > ( rows, "map", "guid", "step_id" );
            all_Table_Npc_Scout_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Npc_Scout_List.Clear();
        }
    }
}
