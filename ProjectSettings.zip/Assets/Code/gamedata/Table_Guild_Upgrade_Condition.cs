using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 公会升级条件表
    ///</summary>
    [Serializable]
    [TableName("guild_upgrade_condition")]
    public partial class Table_Guild_Upgrade_Condition : TableContent
    {

        private static List<Table_Guild_Upgrade_Condition> all_Table_Guild_Upgrade_Condition_List = new List<Table_Guild_Upgrade_Condition>();
        //primary | 主键
        public static Dictionary<int, Table_Guild_Upgrade_Condition > pool_primary = new Dictionary<int, Table_Guild_Upgrade_Condition > ();
        
        
        ///<summary>
        /// 主键：条件ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 活跃度
        ///</summary>
        public int liveness;
        
        
        ///<summary>
        /// 矿石
        ///</summary>
        public int mineral;
        
        
        ///<summary>
        /// 资金
        ///</summary>
        public int capital;
        
        
        ///<summary>
        /// true:消耗，false:达到
        ///</summary>
        public bool consume;
        
        
        ///<summary>
        /// 描述国际化
        ///</summary>
        public string description_i18n;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：条件ID</param>
        ///
        public static Table_Guild_Upgrade_Condition GetPrimary ( int _id ){        
            Table_Guild_Upgrade_Condition _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Guild_Upgrade_Condition > GetAllPrimary()
        {
            return pool_primary;
        }


        ///查询出所有的数据
        public static List<Table_Guild_Upgrade_Condition> GetAllPrimaryList()
        {
            return all_Table_Guild_Upgrade_Condition_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("liveness", out _currValue))
            {
                this.liveness = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("mineral", out _currValue))
            {
                this.mineral = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("capital", out _currValue))
            {
                this.capital = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("consume", out _currValue))
            {
                this.consume = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("description_i18n", out _currValue))
            {
                this.description_i18n = _currValue;
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "guild_upgrade_condition";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "liveness":
                    return this.liveness;
                case "mineral":
                    return this.mineral;
                case "capital":
                    return this.capital;
                case "consume":
                    return this.consume;
                case "description_i18n":
                    return this.description_i18n;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Guild_Upgrade_Condition> rows = _rows as List<Table_Guild_Upgrade_Condition>;
            pool_primary=TableContent.ListToPool < int, Table_Guild_Upgrade_Condition > ( rows, "map", "id" );
            all_Table_Guild_Upgrade_Condition_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            all_Table_Guild_Upgrade_Condition_List.Clear();
        }
    }
}
