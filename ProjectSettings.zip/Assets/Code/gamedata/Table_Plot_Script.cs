using System.Collections;
using System.Collections.Generic;
using ZLib;
using System;
using ZTool.Table;
namespace  Tgame.Game.Table
{
    ///<summary>
    /// 剧情脚本
    ///</summary>
    [Serializable]
    [TableName("plot_script")]
    public partial class Table_Plot_Script : TableContent
    {

        private static List<Table_Plot_Script> all_Table_Plot_Script_List = new List<Table_Plot_Script>();
        //primary | 主键
        public static Dictionary<int, Table_Plot_Script > pool_primary = new Dictionary<int, Table_Plot_Script > ();
        //plotByGroup | 
        public static Dictionary<int, Dictionary<int, Table_Plot_Script > > pool_plotByGroup = new Dictionary<int, Dictionary<int, Table_Plot_Script > > ();
        
        
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;
        
        
        ///<summary>
        /// 名称
        ///</summary>
        public string name;
        
        
        ///<summary>
        /// 动画组id
        ///</summary>
        public int group_id;
        
        
        ///<summary>
        /// 种族id
        ///</summary>
        public int race_id;
        
        
        ///<summary>
        /// 播放时间
        ///</summary>
        public int time;
        
        
        ///<summary>
        /// 资源路径
        ///</summary>
        public string resource_path;
        
        
        ///<summary>
        /// 关联的视频路径
        ///</summary>
        public string video_path;
        
        
        ///<summary>
        /// 能否能跳过 
        ///</summary>
        public bool is_jump;
        
        
        ///<summary>
        /// 主摄像机恢复位置的速度
        ///</summary>
        public float camera_lerp_speed;
        
        
        ///<summary>
        /// 播放时的玩家位置，格式：x,y,z
        ///</summary>
        public string role_position;
        
        
        ///<summary>
        /// 音效ID
        ///</summary>
        public int sound_id;
        

        ///<summary>
        /// 主键
        /// 查询数据
        ///</summary>
        ///	<param id> 主键：ID</param>
        ///
        public static Table_Plot_Script GetPrimary ( int _id ){        
            Table_Plot_Script _map0=null;        
            pool_primary. TryGetValue(_id,out _map0);        
            return  _map0;
        }
         ///<summary>
        ///主键
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Table_Plot_Script > GetAllPrimary()
        {
            return pool_primary;
        }



        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param groupId> 动画组id</param>
        ///
        public static Dictionary<int, Table_Plot_Script > GetPlotByGroup ( int _groupId ){        
            Dictionary<int, Table_Plot_Script > _map0=null;        
            pool_plotByGroup. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
            return  _map0;
        }
        ///<summary>
        /// 
        /// 查询数据
        ///</summary>
        ///	<param groupId> 动画组id</param>
        ///	<param raceId> 种族id</param>
        ///
        public static Table_Plot_Script GetPlotByGroup ( int _groupId , int _raceId ){        
            Dictionary<int, Table_Plot_Script > _map0=null;        
            pool_plotByGroup. TryGetValue(_groupId,out _map0);        
            if(_map0==null){
                return null;
            }
        
            Table_Plot_Script _map1=null;        
            _map0. TryGetValue(_raceId,out _map1);        
            return  _map1;
        }
         ///<summary>
        ///
        ///查询所有数据
        ///</summary>
        public static Dictionary<int, Dictionary<int, Table_Plot_Script > > GetAllPlotByGroup()
        {
            return pool_plotByGroup;
        }


        ///查询出所有的数据
        public static List<Table_Plot_Script> GetAllPrimaryList()
        {
            return all_Table_Plot_Script_List;
        }

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData) 
        {
            string _currValue = "";
            if(_itemData.TryGetValue("id", out _currValue))
            {
                this.id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if(_itemData.TryGetValue("group_id", out _currValue))
            {
                this.group_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("race_id", out _currValue))
            {
                this.race_id = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("time", out _currValue))
            {
                this.time = Utils.GetIntFromString(_currValue);
            }
            if(_itemData.TryGetValue("resource_path", out _currValue))
            {
                this.resource_path = _currValue;
            }
            if(_itemData.TryGetValue("video_path", out _currValue))
            {
                this.video_path = _currValue;
            }
            if(_itemData.TryGetValue("is_jump", out _currValue))
            {
                this.is_jump = Utils.GetBoolFromString(_currValue);
            }
            if(_itemData.TryGetValue("camera_lerp_speed", out _currValue))
            {
                this.camera_lerp_speed = Utils.GetFloatFromString(_currValue);
            }
            if(_itemData.TryGetValue("role_position", out _currValue))
            {
                this.role_position = _currValue;
            }
            if(_itemData.TryGetValue("sound_id", out _currValue))
            {
                this.sound_id = Utils.GetIntFromString(_currValue);
            }
        }
        
        ///<summary>
        /// 获取table表名
        ///</summary>
        public override string Table()
        {
           return "plot_script";
        }
        
        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "name":
                    return this.name;
                case "group_id":
                    return this.group_id;
                case "race_id":
                    return this.race_id;
                case "time":
                    return this.time;
                case "resource_path":
                    return this.resource_path;
                case "video_path":
                    return this.video_path;
                case "is_jump":
                    return this.is_jump;
                case "camera_lerp_speed":
                    return this.camera_lerp_speed;
                case "role_position":
                    return this.role_position;
                case "sound_id":
                    return this.sound_id;
                default:
                    return null;
            }
        }
        
        ///<summary>
        /// 初始化Pool
        ///</summary>
        public static void InitPool(IList _rows){
            List<Table_Plot_Script> rows = _rows as List<Table_Plot_Script>;
            pool_primary=TableContent.ListToPool < int, Table_Plot_Script > ( rows, "map", "id" );
            pool_plotByGroup=TableContent.ListToPool < int, int, Table_Plot_Script > ( rows, "map", "group_id", "race_id" );
            all_Table_Plot_Script_List=rows;
        }
        
        ///<summary>
        /// 清理静态数据
        ///</summary>
        public static void Clear()
        {
            pool_primary.Clear();
            pool_plotByGroup.Clear();
            all_Table_Plot_Script_List.Clear();
        }
    }
}
