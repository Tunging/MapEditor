using UnityEngine;
using System.Collections;
using MapEditor;
using TransformGizmos;
using System;

namespace NavMesh.Camera
{

    /// <summary>
    /// 编辑器内WASD控制摄像机移动的脚本
    /// </summary>
    public class CameraMove : MonoBehaviour
    {


        public enum RotationAxes
        {
            MouseXAndY = 0,
            MouseX = 1,
            MouseY = 2
        }

        UnityEngine.Camera cam;

        public RotationAxes axes = RotationAxes.MouseXAndY;

        public float sensitivityX = 15F;
        public float sensitivityY = 15F;

        public float minimumX = -360F;
        public float maximumX = 360F;

        private float minimumY = -360F;
        private float maximumY = 360F;

        float rotationY = 0F;

        bool isMoving = false;

        public float fMoveSpeed = 12;

        Transform tran;

        #region 单例

        static CameraMove instance;
        public static CameraMove GetInst()
        {
            return instance;
        }

        #endregion

        void Awake()
        {
            cam = UnityEngine.Camera.main;
            if (cam != null)
            {
                tran = cam.transform;
            }

            instance = this;
        }

        void Update()
        {
            if (cam == null)
                return;

            //旋转
            RotCam();

            //鼠标移动
            MouseMoveCam();

            //按键移动
            KeyMoveCam();

        }

        #region 相机移动

        /// <summary>
        /// 旋转相机
        /// </summary>
        void RotCam()
        {
            if (Input.GetMouseButton(1))
            {

                rotationY = -tran.eulerAngles.x;
                if (axes == RotationAxes.MouseXAndY)
                {
                    float rotationX = tran.localEulerAngles.y + Input.GetAxis("Mouse X") * sensitivityX;
                    rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
                    rotationY = Mathf.Clamp(rotationY, minimumY, maximumY);

                    tran.localEulerAngles = new Vector3(-rotationY, rotationX, 0);
                    //Debug.Log("XY");
                }
                else if (axes == RotationAxes.MouseX)
                {
                    tran.Rotate(0, Input.GetAxis("Mouse X") * sensitivityX, 0);
                    //Debug.Log("X");
                }
                else if (axes == RotationAxes.MouseY)
                {
                    rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
                    //Debug.Log("Y");
                    rotationY = Mathf.Clamp(rotationY, minimumY, maximumY);

                    tran.localEulerAngles = new Vector3(-rotationY, tran.localEulerAngles.y, 0);
                }
            }


        }

        /// <summary>
        /// 鼠标移动
        /// </summary>
        void MouseMoveCam()
        {

            if (GUIUtility.hotControl != 0) return;
            //鼠标滚动，缩放场景
            if (Input.GetAxis("Mouse ScrollWheel") != 0)
            {
                //自由缩放方式;
                float m_distance = Input.GetAxis("Mouse ScrollWheel") * 10f;
                tran.position = tran.position + tran.forward * m_distance;
            }

            //按住鼠标左键移动
            if (Input.GetMouseButton(0))
            {
                //如果当前正在操作目标数据，那么就不移动相机
                if (TransformGizmo.GetInst().IsChangeTarget())
                    return;

                float delta_x = Input.GetAxis("Mouse X");
                float delta_y = Input.GetAxis("Mouse Y");
                Quaternion rotation = Quaternion.Euler(0, tran.rotation.eulerAngles.y, 0);
                tran.position = rotation * new Vector3(-delta_x, 0, -delta_y) + tran.position;
            }
        }

        /// <summary>
        /// 按键移动
        /// </summary>
        void KeyMoveCam()
        {

            if (Input.GetKeyDown(KeyCode.LeftShift))
            {
                fMoveSpeed = 36f;
            }
            if (Input.GetKeyUp(KeyCode.LeftShift))
            {
                fMoveSpeed = 12f;
            }

            Vector3 pos = Vector3.zero;

            //left
            if (Input.GetKey(KeyCode.A))
            {
                pos -= Time.deltaTime * tran.right * fMoveSpeed;
            }

            //right
            if (Input.GetKey(KeyCode.D))
            {
                pos += Time.deltaTime * tran.right * fMoveSpeed;
            }

            //forward
            if (Input.GetKey(KeyCode.W))
            {
                pos += Time.deltaTime * tran.forward * fMoveSpeed;
                pos.y = 0;
            }

            //back
            if (Input.GetKey(KeyCode.S))
            {
                pos -= Time.deltaTime * tran.forward * fMoveSpeed;
                pos.y = 0;
            }

            //down
            if (Input.GetKey(KeyCode.Q))
            {
                pos.y -= Time.deltaTime * fMoveSpeed;
            }

            //up
            if (Input.GetKey(KeyCode.E))
            {
                pos.y += Time.deltaTime * fMoveSpeed;
            }

            tran.position += pos;
        }

        #endregion

        #region 相机看向目标

        //相机看向目标时定位参数
        public Vector3 angle;
        public float dis = 15;
        public float long_dis = 215;
        public bool dis_log = false;
        public Vector3 v = new Vector3(1f, 1.5f, 1f);
        public float offset = -2f;

        /// <summary>
        /// 摄像机看向目标
        /// </summary>
        /// <param name="go"></param>
        public void CameraLookAtTarget(GameObject go)
        {
            if (go == null)
                return;

            Quaternion rot = Quaternion.Euler(angle);
            Vector3 pos = v * dis;
            tran.position = go.transform.position + rot * pos;

            //相机看向目标
            tran.LookAt(go.transform);
            tran.position = tran.position + new Vector3(offset, 0, offset);
        }

        #endregion

        private void OnGUI()
        {
            dis = GUI.HorizontalSlider(new Rect(Screen.width - 200, 200, 200, 50), dis, 0, 100);
            GUI.Label(new Rect(Screen.width-200,220,200,50), string.Format("<color=#00ff00>镜头距离调节  {0}</color>",dis));
            
        }
    }
}