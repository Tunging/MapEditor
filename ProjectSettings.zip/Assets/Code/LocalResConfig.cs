﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using ZTool.Table;
using System;
using MapEditor;


//扫描本地资源目录数据
public class LocalResConfig
{

    #region 单例

    static LocalResConfig instance;

    public static LocalResConfig GetInst()
    {
        if (instance == null)
            instance = new LocalResConfig();

        return instance;
    }

    #endregion

    #region 扫描本地目录数据

    //加载本地资源数据url
    List<string> local_res_url = new List<string>();
    public List<string> Local_Res_Url { get { return local_res_url; } }

    /// <summary>
    /// 开始扫描本地资源数据
    /// </summary>
    public void StartScanLocalRes()
    {
        //资源路径 为null
        if (string.IsNullOrEmpty(Config.LOCAL_EDITOR_PATH))
            return;

        int count = Config.LOCAL_EDITOR_PATH.Length + "update".Length + 2;
        List<string> list = GetAllFiles(Config.LOCAL_EDITOR_PATH);

        if (list == null || list.Count == 0)
            return;

        for (int i = 0; i < list.Count; i++)
        {
            if (string.IsNullOrEmpty(list[i])
                || list[i].Contains(".svn")
                || Path.GetExtension(list[i]) == ".manifest")
                continue;

            string url = list[i].Remove(0, count);
            url = url.Replace('\\', '/');

            local_res_url.Add(url);
        }
    }

    /// <summary>
    /// 获取一个目录下所有文件（包含子目录）
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    List<string> GetAllFiles(string path)
    {
        if (string.IsNullOrEmpty(path))
            return null;

        List<string> list = new List<string>();

        //如果是目录文件，那么获取目录下的文件
        if (Directory.Exists(path))
        {
            //获取此目录下的所有文件夹
            string[] dirs = Directory.GetDirectories(path);
            for (int i = 0; i < dirs.Length; i++)
            {
                List<string> l = GetAllFiles(dirs[i]);
                if (l != null && l.Count > 0)
                    list.AddRange(l);
            }

            //获取此目录下的所有文件
            string[] strs = Directory.GetFiles(path);

            list.AddRange(strs);
            return list;
        }
        else
        {
            return null;
        }
    }

    #endregion

    #region 加载配置表数据信息

    //预先加载的配表数据
    string[] pre_load_tables = new string[] { };
    bool inited = false;
    //预先加载的配表数据
    public string[] Pre_Load_Tables
    {
        get
        {

            //根据属性 获取处所有需要读取的配置文件合集
            if (!inited)
            {
                inited = true;
                Debug.Log("Init UI Pre_Load_Tables");
                var classes = typeof(LocalResConfig).Assembly.GetTypes();
                var att = typeof(TableNameAttribute);
                List<string> tableNames = new List<string>();
                for (int i = 0; i < classes.Length; i++)
                {
                    if (classes[i].Namespace != null && classes[i].Namespace.Equals("Tgame.Game.Table"))
                    {
                        Type type = classes[i];
                        object[] objs = type.GetCustomAttributes(att, false);
                        if (objs.Length > 0)
                        {
                            string tName = ((TableNameAttribute)objs[0]).tableName;
                            tableNames.Add(tName);
                        }
                    }
                }
                pre_load_tables = tableNames.ToArray();
            }
            return pre_load_tables;
        }
    }

    /// <summary>
    /// 清理预先加载的 table 表数据信息
    /// </summary>
    public void ClearPreLoadTables()
    {
        if (pre_load_tables != null
            && pre_load_tables.Length > 0)
            pre_load_tables = null;
    }

    #endregion

    public List<string> GetLocalResPaths()
    {
        List<string> result = new List<string>();
        string _configPath = string.Format("{0}/{1}", Application.streamingAssetsPath, "Resconfig.txt");
        if (File.Exists(_configPath))
        {
            var lines = File.ReadAllLines(_configPath);
            if (lines != null && lines.Length > 0)
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    var item = lines[i];

                    if (string.IsNullOrEmpty(item))
                    {
                        Debug.LogError(item + " is error");
                        continue;
                    }

                    result.Add(string.Format("{0}/{1}", Path.GetDirectoryName(item), Path.GetFileNameWithoutExtension(item)));
                }
            }
        }
        else
        {
            Debug.LogError("Error: no resconfig document");
        }
        Debug.Log("local res count " + result.Count);
        return result;
    }
}
