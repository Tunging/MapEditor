﻿using MapEditor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using ZLib;
using ZTool.Res;

/// <summary>
/// GameStart
/// author @dongzhiwei
/// date   2018/6/5 18:08:16
/// </summary>
public class GameStart : MonoBehaviour
{
    // Use this for initialization
    void Start()
    {
        Debug.Log(Config.GetInst().ToString());
        List<string> listLocalRes = new List<string>();

        listLocalRes.AddRange(LocalResConfig.GetInst().GetLocalResPaths());
        listLocalRes.AddRange(new List<string>() { Config.PATH_SHOW_PREFAB, "Config/client_model", "Config/npc", "Config/npc_templete" });

        //设置本地加载资源数据
        ResourcesLoad.instance.SetLocalResConfig(listLocalRes, null);

        CoroutineManager.Init(this.gameObject);
        CoroutineManager.instance.StartCoroutine(OnGameStart());
    }

    private IEnumerator OnGameStart()
    {
        ResVerManager.instance.OnResVerInit(null);
        yield return new WaitUntil(() => ResVerManager.instance.IsDone == true);


        //加载编辑器配置文件;
        Config.GetInst().LoadConfig(this, null);

        RenderSettings.fog = false;

        OnSetTableInfo();
    }

    /// <summary>
    /// 设置Table管理信息数据资源
    /// </summary>
    void OnSetTableInfo()
    {
        LoadResProcessor.instance.ReceivedLoadRes(OnConfigLoadOver);
    }

    /// <summary>
    /// 配置资源数据已经加载完成
    /// </summary>
    void OnConfigLoadOver()
    {
        ResConfig.instance.OnSetResLoadMaxCount(Config.MAX_LOAD_RES_COUNT);

        //设置url地址
        ResConfig.instance.OnSetResUrlInfo(Config.RES_SERVER_URL, string.Format("file://{0}", Config.LOCAL_EDITOR_PATH), Config.CACHE_URL, Config.CACHE_PATH);

        //开始加载配置资源版本数据
        ResVerManager.instance.OnResVerInit(OnResVerLoadOver);

    }


    /// <summary>
    /// 版本资源配置数据加载完成
    /// </summary>
    void OnResVerLoadOver()
    {

        //扫描本地位置数据
        LocalResConfig.GetInst().StartScanLocalRes();

        //设置本地数据加载
        if (LocalResConfig.GetInst().Local_Res_Url.Count > 0)
            ResVerManager.instance.SetUseLocalRes(ResConfig.instance.GROUP_UPDATE, LocalResConfig.GetInst().Local_Res_Url);

        //请求加载资源引用关系管理
        ResManifest.instance.Init();

        //初始化UGE
        InitUGE();

        //加载服务器列表资源数据
        SceneManager.GetInst().StartLoadServerSceneList();
    }

    #region UGE 加载地图资源设置

    /// <summary>
    /// 初始化UGE
    /// </summary>
    void InitUGE()
    {
        //01 -- 开启map load过程中的所有 加载内容
        TResConfig.isSaveMapLoadInfo = false;

        //缓存池存储时间
        UGE.poolMgr.life_sec = 30f;
        //销毁的时候，判断玩家距离，判断时间间隔
        UGE.poolMgr.distance_sec = 30f;
        //距离目标多少距离之后销毁
        UGE.poolMgr.target_distance = 50f;
        //UGE.mapMgr.bigMapContentLoader.bigMapConfig.isFixFrameLoadSurf = false;
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.isFadeInOut = false;
        //取消队列加载排序
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.isQueueLoadMap = false;
        //同一帧同一地块同时加载的草的数量
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.frame = 0;
        //队列加载个数
        UGE.mapMgr.loadQueueMgr.loadMaxCount = 1;

        //设置资源使用的时候在加载
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.isDownLoadMapData = false;
        //地形
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleNum = 32;
        //物件
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSuperNum = 32;
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleBigNum = 32;
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleMidNum = 32;
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSmallNum = 32;
        //特效
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleBigEffNum = 32;
        UGE.mapMgr.bigMapContentLoader.bigMapConfig.circleSmallEffNum = 32;

        UGE.mapMgr.bigMapContentLoader.bigMapConfig.isNeedSurfaceLoadOver = false;

        //启用日志输出
        TTrace.Enable = true;

        UGE.runtimePlatform = RuntimePlatform.WindowsPlayer;
        //remote
        TResConfig._remoteUrl = Config.RES_SERVER_URL;
        //streaming assets
        TResConfig._buildinWwwUrl = Config.LOCAL_URL;
        TResConfig._buildinUrl = Application.streamingAssetsPath;
        //disk
        TResConfig._diskDir = string.Empty;// Config.LOCAL_EDITOR_PATH;//每次都会缓存地图资源，但是有了缓存就进不去了，为啥？？？

        //快速加载模式
        //TResConfig.UseFastLoader = true;

        //设置ver中介
        UGE.loadMgr.SetRevealAction(ResLoadManager.instance.GetResStateType1, SaveVer);
        //设置依赖关系中介
        UGE.loadMgr.SetRevealDependentAction(ResManifest.instance.GetAllDependencies);
        //设置 加载卸载 中介
        UGE.loadMgr.SetLoaderAction(RequestLoaderEquals);

        //设置 UGE 启动的各种启动提示
        UGE.loadMgr.SetStartupCallbackAction(OnChangeLoadingContent, OnDownProgress, OnLocalProgress);
        //加载错误 提示
        UGE.loadMgr.SetFailCallbackAction(OnLoaderFailCallback);

        //UGE 初始化
        UGE.Startup(
            OnStartupComplete,
            new List<string>() { string.Format("game/map/map_allshader{0}", ".p") }
        );

        //设置场景资源加载完成的回调数据
        UGE.mapMgr.eventListener += SceneManager.GetInst().OnSceneLoadOver;

        ResConfig.instance.OnSetUGEResExtension(Config.UGE_CONFIG_TXT, Config.UGE_CONFIG_BIN, Config.fileSuff);

    }

    #endregion

    #region UGE Loader 回调事件

    void SaveVer(FileVer fileVer)
    {
        //???  只传path就行  ???

        //Debug.LogError(" update file info " + fileVer.name + "       " + fileVer.state);

        ResVerManager.instance.UpdateFileInfo(fileVer.name);
    }/// <summary>
     /// </summary>
     /// <param name="tLoaderRequest"></param>
     /// <param name="obj">tgame中间的回调方法</param>
     /// <returns></returns>
    bool RequestLoaderEquals(TLoaderRequest tLoaderRequest, object obj)
    {
        ResourcesLoad.RequestLoadData data = tLoaderRequest.param as ResourcesLoad.RequestLoadData;
        if (data == null)
        {
            //Debug.Log("UGE====Main.RequestLoaderEquals, data为null，说明是grouploader，此时就直接判断obj是否为方法即可  path=" + tLoaderRequest.path);
            //data为null，说明是grouploader，此时就直接判断obj是否为方法即可
            if (tLoaderRequest.onLoad.Equals(obj))
            {
                return true;
            }
            return false;
        }
        object callback = null;
        if (data.callbackOne != null)
        {
            callback = data.callbackOne;
        }
        else if (data.callbackAll != null)
        {
            callback = data.callbackAll;
        }
        if (callback == null)
        {
            Debug.Log("UGE====Main.RequestLoaderEquals, callback为null, path=" + tLoaderRequest.path);
            return false;
        }
        if (callback.Equals(obj))
        {
            return true;
        }
        return false;
    }
    /// <summary>
    /// UGE初始化完成
    /// </summary>
    void OnStartupComplete()
    {
        //TTrace.p("Main.Step2.OnStartupComplete");
        //TTrace.Enable = false;
        //mapListMgr.enabled = true;
        //mapListMgr.Init();
        Debug.LogError("   UGE init OK   ");
    }

    private void OnChangeLoadingContent(TLoaderStartupEnum startupEnum)
    {
        string title = "", tip = "不会参数任何流量";
        switch (startupEnum)
        {
            case TLoaderStartupEnum.VER_START:
                title = "验证资源...";
                break;
            case TLoaderStartupEnum.VER_END:
                title = "验证资源完成";
                break;
            case TLoaderStartupEnum.LOCAL_VERIFY_START:
                title = "修正本地资源错误...";
                break;
            case TLoaderStartupEnum.LOCAL_VERIFY_END:
                title = "修正本地资源错误完成";
                break;
            case TLoaderStartupEnum.DOWNLOAD_START:
                title = "下载资源中...";
                break;
            case TLoaderStartupEnum.DOWNLOAD_END:
                title = "下载资源完成";
                break;
            case TLoaderStartupEnum.DEPENDENT_START:
                title = "加载依赖文件...";
                break;
            case TLoaderStartupEnum.DEPENDENT_END:
                title = "加载依赖文件完成";
                break;
            case TLoaderStartupEnum.PREHEAD_SHADER_START:
                title = "预热shader...";
                break;
            case TLoaderStartupEnum.PREHEAD_SHADER_END:
                title = "预热shader完成";
                break;
        }
        //			LoadingManager.GetInstance().UpdateTextProgress(title);	//"正在加载资源......"
        //			LoadingManager.GetInstance().UpdateTextTip(tip);	//"Tip===============..."
        Debug.Log("title=" + title);
    }
    /// <summary>
    /// 资源加载进度的回调
    /// </summary>
    private void OnDownProgress(int curSize, int needSize, int current, int total)
    {
        //		switch(startupEnum){
        //		case TLoaderStartupEnum.DOWNLOAD_PROGRESS:
        //			break;
        //		}
        //			LoadingManager.GetInstance().UpdateProgress((float)current / total);
        var tip = string.Format("{0}/{1}", curSize, needSize);
        //			LoadingManager.GetInstance().UpdateTextTip(tip);
        Debug.Log("tip=" + tip);
    }
    private void OnLocalProgress(TLoaderStartupEnum startupEnum, int current, int total)
    {
        //		switch(startupEnum){
        //		case TLoaderStartupEnum.DEPENDENT_PROGRESS:
        //		case TLoaderStartupEnum.PREHEAD_SHADER_PROGRESS:
        //			break;
        //		}
        //			LoadingManager.GetInstance().UpdateProgress((float)current / total);
        var tip = string.Format("{0}/{1}", current, total);
        Debug.Log("tip=" + tip);
    }

    /// <summary>
    /// 加载模块 报错 回调
    /// </summary>
    void OnLoaderFailCallback(TLoaderFailInfo failInfo)
    {
        Debug.Log("UGE====Main.OnLoaderFailCallback, loadMgr.isStartupComplete=" + UGE.loadMgr.isStartupComplete);
        if (UGE.loadMgr.isStartupComplete == false)
        {
            //uge没有启动完成
            //UGE.Restartup();
        }
        else
        {
            //uge启动完成了
            //这里可以采用  单个回调用的判断      //TLoaderContent.failInfo != null; 说明 加载失败
        }
        //下面的，只是一个使用例子，具体的 根据项目组需求 修改。              //
        //是否联网，如果根本没有联网，那就直接报网络
        if (Application.internetReachability == NetworkReachability.NotReachable)
        {
            //无法连接到网络	-	Network unreachable
            Debug.LogError("---------- Loader Error. 无法连接到网络    Network unreachable");
            return;
        }
        //没有找到对应的ver文件          //Add Wade 7.29+
        if (failInfo.type == -1)
        {
            Debug.Log("---------- Loader Error.  filever=null, path=" + failInfo.path);
            return;
        }
        //联网了，获取不到服务器 -》如果停服了，应该是从服务器获取路径都出问题了，从那里就知道停服了
        if (failInfo.responseHeadersCount == 0)
        {
            //无法连接到服务器	-	Connection refused
            Debug.LogError("---------- Loader Error. 无法连接到服务器    Connection refused");
            return;
        }
        //下面就是判断程序返回的了
        switch (failInfo.type)
        {
            case 1:         //1 下载404	- source				-	基本不会出现 - 服务器ver和file没对上	-	让用户重新登录
                break;
            case 2:         //2 hash错误	- source			-	基本不会出现 - 解决方案，删除本地ver，让其重新登录游戏
                break;
            case 3:         //3 本地无此文件 -> 只是用于ver		-	基本不可能	 - 客户端streamingAssets中ver丢失了!这个不可能!
                break;
            case 4:         //4 buildin无此文件	-> local	//需要重新整理本地ver	//运行时	//提示重新登录，修复bug

                break;
        }
        //		Debug.Log("GameSavePrefs.GetLocalVerify()=" + GameSavePrefs.GetLocalVerify());
        Debug.LogError("---------- Loader Error. failInfo=" + failInfo.path + "|" + failInfo.type + "|" + failInfo.info + "|" + failInfo.responseHeadersCount);
    }
    #endregion

    #region UPdate

    /// <summary>
    /// 数据更新刷新
    /// </summary>
    void Update()
    {
        //数据更新
        Tick.Update();

    }

    //数据更新
    void LateUpdate()
    {
        Tick.LateUpdate();
    }
    #endregion

}