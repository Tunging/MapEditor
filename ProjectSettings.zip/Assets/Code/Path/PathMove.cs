﻿using UnityEngine;
using System.Collections;
using ZLib;
using System;

namespace MapEditor
{

    /// <summary>
    /// Camera path 移动
    /// </summary>
    public class PathMove
    {

        #region 单例

        static PathMove instance;
        public static PathMove GetInst()
        {
            if (instance == null)
                instance = new PathMove();

            return instance;
        }

        public PathMove()
        {
            //设置数据刷新
            Tick.AddUpdate(Update);
        }

        #endregion



        #region 数据刷新

        //当前是否可以进行数据更新
        bool update = false;

        /// <summary>
        /// 数据更新
        /// </summary>
        void Update()
        {
            if (!update)
                return;

            UpdatePath();
        }

        /// <summary>
        /// 更新 path 数据
        /// </summary>
        void UpdatePath()
        {
            currTime += Time.deltaTime;

            //获取进度 百分比
            percentage = currTime / totalTime;

            switch(moveToType)
            {
                case MoveToTypeEnum.LINE:
                    LineMove();
                    break;
                case MoveToTypeEnum.CURVE:
                    CurveMove();
                    break;
            }

            
        }

        /// <summary>
        /// 直线位移
        /// </summary>
        void LineMove()
        {

        }

        /// <summary>
        /// 曲线位移
        /// </summary>
        void CurveMove()
        {
            //位置更新
            tran.position = CurveInterp(points, Mathf.Clamp(percentage, 0, 1));

            //看向目标
            Vector3 p = CurveInterp(points, Mathf.Clamp(percentage + lookahead, 0, 1));
            tran.LookAt(p, Vector3.up);
        }

        #endregion

        #region 数据计算

        //移动类型枚举
        public enum MoveToTypeEnum
        {
            LINE,                                               //直线
            CURVE,                                              //曲线
        }

        //移动对象
        Transform tran;
        //path点数据
        Vector3[] points;
        //移动类型
        MoveToTypeEnum moveToType;
        //path 持续时间
        float totalTime = 0;
        float currTime = 0;
        float percentage = 0;
        //path 看向前瞻量
        float lookahead = 0.05f;


        /// <summary>
        /// path move
        /// </summary>
        /// <param name="go"></param>
        /// <param name="points"></param>
        /// <param name="time"></param>
        /// <param name="type"></param>
        public void MoveTo(GameObject go, Vector3[] points, float time = 10f, MoveToTypeEnum type = MoveToTypeEnum.LINE, float lookahead = 0.05f)
        {
            if (go == null || points == null || points.Length == 0)
                return;

            //数据清理
            Clear();

            moveToType = type;
            tran = go.transform;
            this.points = GetPoints(points);
            totalTime = time;
            this.lookahead = lookahead;

            //设置刷新数据
            update = true;
        }

        /// <summary>
        /// 获取 points 数据
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        Vector3[] GetPoints(Vector3[] p)
        {
            switch(moveToType)
            {
                case MoveToTypeEnum.LINE:
                default:
                    return p;
                case MoveToTypeEnum.CURVE:
                    points = PathControlPointGenerator(p);
                    return p;
            }
        }

        /// <summary>
        /// 数据清理
        /// </summary>
        void Clear()
        {
            currTime = 0;
            totalTime = 0;
            lookahead = 0;
            percentage = 0;
            points = null;
            tran = null;
            moveToType = MoveToTypeEnum.LINE;
        }

        #endregion


        #region Path 平滑过渡

        /// <summary>
        /// path 控制点生成
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        Vector3[] PathControlPointGenerator(Vector3[] path)
        {
            Vector3[] suppliedPath;
            Vector3[] vector3s;

            //create and store path points:
            suppliedPath = path;

            //populate calculate path;
            int offset = 2;
            vector3s = new Vector3[suppliedPath.Length + offset];
            Array.Copy(suppliedPath, 0, vector3s, 1, suppliedPath.Length);

            //populate start and end control points:
            //vector3s[0] = vector3s[1] - vector3s[2];
            vector3s[0] = vector3s[1] + (vector3s[1] - vector3s[2]);
            vector3s[vector3s.Length - 1] = vector3s[vector3s.Length - 2] + (vector3s[vector3s.Length - 2] - vector3s[vector3s.Length - 3]);

            //is this a closed, continuous loop? yes? well then so let's make a continuous Catmull-Rom spline!
            if (vector3s[1] == vector3s[vector3s.Length - 2])
            {
                Vector3[] tmpLoopSpline = new Vector3[vector3s.Length];
                Array.Copy(vector3s, tmpLoopSpline, vector3s.Length);
                tmpLoopSpline[0] = tmpLoopSpline[tmpLoopSpline.Length - 3];
                tmpLoopSpline[tmpLoopSpline.Length - 1] = tmpLoopSpline[2];
                vector3s = new Vector3[tmpLoopSpline.Length];
                Array.Copy(tmpLoopSpline, vector3s, tmpLoopSpline.Length);
            }

            return (vector3s);
        }

        //andeeee from the Unity forum's steller Catmull-Rom class ( http://forum.unity3d.com/viewtopic.php?p=218400#218400 ):
        /// <summary>
        /// 曲线过渡
        /// </summary>
        /// <param name="pts"></param>
        /// <param name="t"></param>
        /// <returns></returns>
        Vector3 CurveInterp(Vector3[] pts, float t)
        {
            int numSections = pts.Length - 3;
            int currPt = Mathf.Min(Mathf.FloorToInt(t * (float)numSections), numSections - 1);
            float u = t * (float)numSections - (float)currPt;

            Vector3 a = pts[currPt];
            Vector3 b = pts[currPt + 1];
            Vector3 c = pts[currPt + 2];
            Vector3 d = pts[currPt + 3];

            return .5f * (
                (-a + 3f * b - 3f * c + d) * (u * u * u)
                + (2f * a - 5f * b + 4f * c - d) * (u * u)
                + (-a + c) * u
                + 2f * b
            );
        }

        #endregion


        #region Line

        /// <summary>
        /// 直线过渡
        /// </summary>
        /// <param name="pts"></param>
        /// <param name="s"></param>
        /// <returns></returns>
        Vector3 LineInterp(Vector3[] pts, float s)
        {

            return Vector3.zero;
        }

        #endregion
    }

}