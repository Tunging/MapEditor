using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using ZLib;

namespace MapEditor
{
    public class QuestAreaManager
    {

        #region 单例
        static QuestAreaManager instance;

        public static QuestAreaManager Instance
        {
            get
            {
                if (null == instance)
                {
                    instance = new QuestAreaManager();
                    Tick.AddLateUpdate(instance.LateUpdate);
                }
                return instance;
            }
        }

        #endregion

        #region 当前操作的资源
        //当前鼠标操作的圆柱体
        GameObject curCylinder = null;
        Transform tran = null;

        //圆柱体的数据
        QuestInfo data = null;

        private void Clear()
        {
            curCylinder = null;
            tran = null;

            data = null;
        }

        
        #endregion

        #region 数据更新

        Vector3 pos;

        private void LateUpdate()
        {
            pos = SceneManager.MousePos;

            if (null == tran)
                return;

            //更新坐标
            tran.position = pos;
        }

        #endregion

        /// <summary>
        /// 加载圆柱体
        /// </summary>
        /// <param name="questArea_prefab"></param>
        internal void LoadCylinder(GameObject questArea_prefab)
        {
            if (null == questArea_prefab)
            {
                Debug.Log("没有圆柱体资源");
                return;
            }

            //初始化当前的圆柱体
            curCylinder = GameObject.Instantiate<GameObject>(questArea_prefab);
            tran = curCylinder.transform;
            data = curCylinder.AddComponent<QuestInfo>();

            data.scene_id = SceneManager.GetInst().CurrScene.id;
        }

        //存储所有的数据
        List<QuestInfo> newCreateQuestInfoList = new List<QuestInfo>();
        public List<QuestInfo> NewCreateQuestInfoList
        {
            get
            {
                return newCreateQuestInfoList;
            }
        }

        //存储服务器的数据
        List<QuestInfo> serverQuestInfoList = new List<QuestInfo>();
        public List<QuestInfo> ServerQuestInfoList
        {
            get
            {
                return serverQuestInfoList;
            }
        }

        //存储删除的数据
        List<int> delQuestInfoList = new List<int>();

        /// <summary>
        /// 创建新的数据
        /// </summary>
        /// <returns></returns>
        public QuestInfo CreateNewCylinder()
        {
            if (null == tran)
                return null;

            data.SetPosition(pos);

            newCreateQuestInfoList.Add(data);

            tran = null;

            return data;
        }

        /// <summary>
        /// 不显示当前预览
        /// </summary>
        internal void NotShowCylinder()
        {
            if (null == tran)
                return;

            GameObject.Destroy(curCylinder);

            Clear();

        }

        /// <summary>
        /// 获取当前点击的圆柱体
        /// </summary>
        /// <param name="transform"></param>
        /// <returns></returns>
        internal QuestInfo GetQuestFromTran(Transform transform)
        {
            if (null == transform)
                return null;

            return transform.GetComponent<QuestInfo>();
        }

        /// <summary>
        /// 设置当前点击的圆柱体
        /// </summary>
        /// <param name="questInfo"></param>
        internal void SetCurCylinder(QuestInfo questInfo)
        {
            curCylinder = questInfo.gameObject;

            data = questInfo;

            //设置编辑器信息
            QuestManager.Instance.SetShowInforEditor(data);
        }



        #region 向服务器发送请求

        /// <summary>
        /// 创建
        /// </summary>
        internal void SendNewCreateInfo()
        {
            if (null == newCreateQuestInfoList || 0 == newCreateQuestInfoList.Count)
                return;

            for (int i = 0; i < newCreateQuestInfoList.Count; i++)
            {
                QuestInfo info = newCreateQuestInfoList[i];
                if (null == info || info.isSynchronizationServer)
                    continue;

                if (info.id == 0)
                {
                    //还是初始数据，需要进行手动设置
                    Debug.LogError("id is 0");

                    GUINotice.Show("<color=red> id 为 0, 请修改后设置 </color>");
                    QuestManager.Instance.SetShowInforEditor(info);
                    return;
                }

                if (ServerQuestInfoList.Exists(q => q.id == info.id))
                {
                    //还是初始数据，需要进行手动设置
                    Debug.LogError("id 已存在");

                    GUINotice.Show("<color=red> 已存在相同id  =  " + info.id + "  数据, 请修改后设置 </color>");
                    QuestManager.Instance.SetShowInforEditor(info);
                    return;
                }

                WWWForm form = new WWWForm();
                form.AddField("id", info.id);
                form.AddField("type", info.type);
                form.AddField("name", info.name);
                form.AddField("scene_id", info.scene_id);

                //位置
                form.AddField("x", info.x.ToString());
                form.AddField("y", info.y.ToString());
                form.AddField("z", info.z.ToString());

                //半径
                form.AddField("radius", info.r.ToString());

                //高度
                form.AddField("height", info.h.ToString());


                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.QUEST_AREA_INSERT, form, SendNewCreateInfoOver, info.id));
            }
        }

        private void SendNewCreateInfoOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {
                Debug.Log("增加id " + id + " 成功");

                //数据上传成功
                for (int i = 0; i < newCreateQuestInfoList.Count; i++)
                {
                    if (newCreateQuestInfoList[i] == null
                        || newCreateQuestInfoList[i].isSynchronizationServer)
                        continue;

                    if (newCreateQuestInfoList[i].id == id)
                    {
                        //设置数据已经和服务器同步
                        newCreateQuestInfoList[i].isSynchronizationServer = true;

                        //删除并放到服务器数据表中
                        QuestInfo info = newCreateQuestInfoList[i];
                        newCreateQuestInfoList.Remove(info);
                        serverQuestInfoList.Add(info);

                        return;
                    }
                }
            }
            else
            {
                //数据上传失败
                Debug.LogError("数据id 为 " + id + " 添加失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        /// <summary>
        /// 更新
        /// </summary>
        internal void SendUpdateInfo()
        {
            if (null == serverQuestInfoList || 0 == serverQuestInfoList.Count)
                return;

            for (int i = 0; i < serverQuestInfoList.Count; i++)
            {
                QuestInfo info = serverQuestInfoList[i];
                if (null == info || info.isSynchronizationServer)
                    continue;

                WWWForm form = new WWWForm();
                form.AddField("id", info.id);
                form.AddField("name", info.name);
                form.AddField("scene_id", info.scene_id);

                //位置
                form.AddField("x", info.x.ToString());
                form.AddField("y", info.y.ToString());
                form.AddField("z", info.z.ToString());

                //半径
                form.AddField("radius", info.r.ToString());

                //高度
                form.AddField("height", info.h.ToString());

                form.AddField("type", info.type);


                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.QUEST_AREA_UPDATE, form, SendUpdateInfoOver, info.id));
            }
        }

        private void SendUpdateInfoOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {

                //数据修改成功
                for (int i = 0; i < serverQuestInfoList.Count; i++)
                {
                    if (serverQuestInfoList[i] == null
                        || serverQuestInfoList[i].isSynchronizationServer)
                        continue;

                    if (serverQuestInfoList[i].id == id)
                    {
                        //设置数据已经和服务器同步
                        serverQuestInfoList[i].isSynchronizationServer = true;
                    }
                }

                Debug.Log("修改id " + id + " 成功");
            }
            else
            {
                //数据修改失败
                Debug.LogError("数据id 为 " + id + " 修改失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        internal void SendDeleteInfo()
        {
            if (null == delQuestInfoList || 0 == delQuestInfoList.Count)
                return;

            for (int i = 0; i < delQuestInfoList.Count; i++)
            {
                WWWForm form = new WWWForm();
                form.AddField("id", delQuestInfoList[i]);

                SceneManager.GetInst().StartCoroutine(WWWSend.GetInst().SendInfo(Config.QUEST_AREA_DELETE, form, SendDeleteInfoOver, delQuestInfoList[i]));
            }
        }

        private void SendDeleteInfoOver(WWWMessage error, object parameter)
        {
            int id = (int)parameter;
            if (error.success)
            {
                Debug.Log("删除id " + id + " 成功");

                //数据删除成功
                for (int i = 0; i < delQuestInfoList.Count; i++)
                {
                    if (delQuestInfoList[i] == id)
                    {
                        delQuestInfoList.RemoveAt(i);
                        return;
                    }
                }
            }
            else
            {
                //数据删除失败
                Debug.LogError("数据id 为 " + id + " 删除失败！\n" + error);
                GUINotice.Show(error.msg[0]);
            }
        }

        #endregion

        /// <summary>
        /// 删除指定位置的圆柱体
        /// </summary>
        /// <returns></returns>
        internal QuestInfo DelCylinderFromPos()
        {
            if (0 == newCreateQuestInfoList.Count && 0 == serverQuestInfoList.Count)
                return null;

            QuestInfo info;

            //如果鼠标选中了 圆柱体，那么优先处理 鼠标选中的 圆柱体
            if (null != SceneManager.MouseTran)
            {
                info = GetQuestFromTran(SceneManager.MouseTran);
                if (null != info)
                {
                    return info;
                }
            }

            //检测新建圆柱体列表
            info = newCreateQuestInfoList.Find(item => Vector3.Distance(new Vector3(item.x, item.y, item.z), pos) <= Config.MAX_FIND_SPRITE_DIS);
            if (null != info)
            {
                return info;
            }

            //检测服务器上的列表
            info = serverQuestInfoList.Find(item => Vector3.Distance(new Vector3(item.x, item.y, item.z), pos) <= Config.MAX_FIND_SPRITE_DIS);
            if (null != info)
            {
                return info;
            }

            return null;
        }

        /// <summary>
        /// 从圆柱体列表移除一个圆柱体
        /// </summary>
        public void RemoveCylinderFormList(QuestInfo info)
        {
            if (null == info)
                return;

            //检测新建圆柱体列表
            QuestInfo delInfo = newCreateQuestInfoList.Find(item => item.id == info.id);
            if (null != delInfo)
            {
                newCreateQuestInfoList.Remove(delInfo);

                delQuestInfoList.Add(delInfo.id);

                GameObject.Destroy(delInfo.gameObject);

                return;
            }

            //检测服务器上的列表
            delInfo = serverQuestInfoList.Find(item => item.id == info.id);
            if (null != delInfo)
            {
                serverQuestInfoList.Remove(delInfo);

                delQuestInfoList.Add(delInfo.id);

                GameObject.Destroy(delInfo.gameObject);
            }
        }

        /// <summary>
        /// 解析服务器数据
        /// </summary>
        /// <param name="p"></param>
        internal void AnalysisServerData(string text)
        {
            string[] strs = text.Split('\n');
            if (null == strs || strs.Length == 0)
                return;

            //清理
            if (null == serverQuestInfoList)
                serverQuestInfoList = new List<QuestInfo>();
            serverQuestInfoList.Clear();

            //存储数据
            for (int i = 0; i < strs.Length; i++)
            {
                if (string.IsNullOrEmpty(strs[i]))
                    continue;

                JsonQuestInfo info = JsonUtility.FromJson<JsonQuestInfo>(strs[i]);
                if (null == info)
                    continue;


                var qi = QuestManager.Instance.CreateCylinderInScene(info);
                if (qi != null)
                {
                    serverQuestInfoList.Add(qi);
                }
            }
        }

        public void Reset()
        {
            for (int i = 0; i < serverQuestInfoList.Count; i++)
            {
                var itme = serverQuestInfoList[i];
                if (itme!= null)
                {
                    GameObject.Destroy(itme.gameObject);
                }
            }
            ServerQuestInfoList.Clear();

            for (int i = 0; i < NewCreateQuestInfoList.Count; i++)
            {
                var item = NewCreateQuestInfoList[i];
                if (item!=null)
                {
                    GameObject.Destroy(item.gameObject);
                }
            }
            NewCreateQuestInfoList.Clear();
        }

    }
}