﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace MapEditor
{
    public class QuestManager
    {

        #region 单例
        static QuestManager instance;
        public static QuestManager Instance
        {
            get
            {
                if (null == instance)
                {
                    instance = new QuestManager();
                }

                return instance;
            }
        }

        private QuestManager()
        {
            questInfoEditor = new QuestInfoEditor();
        }
        #endregion


        #region 属性控制

        //是否启用
        public bool Enable { get; set; }

        //区域范围属性
        QuestInfoEditor questInfoEditor;

        #endregion


        internal void Show()
        {
            if (Enable)
                return;

            Enable = true;

            QuestAreaManager.Instance.Reset();
            //获取服务器模型数据
            SceneManager.GetInst().StartCoroutine(WWWLoad.GetInst().LoadServerData(Config.SERVER_AREA_LIST, GetServerQuestAreaOver));
        }

        /// <summary>
        /// 获取服务器模型数据
        /// </summary>
        private void GetServerQuestAreaOver(string text)
        {
            if(string.IsNullOrEmpty(text))
            {
                GUINotice.Show("<color=red> 找不到 任务区域 信息数据 </color>");
                return;
            }

            QuestAreaManager.Instance.AnalysisServerData(text);
        }

        internal QuestInfo CreateCylinderInScene(JsonQuestInfo info)
        {
            return questInfoEditor.CreateCylinderInScene(info);
        }

        #region GUI绘制
        internal void OnGUI()
        {
            if (!Enable)
                return;

            //绘制区域范围属性
            if (null != questInfoEditor)
                questInfoEditor.OnGUI();

            //处理鼠标操作
            ProcessMouseEvent();
        }

        #endregion



        #region 鼠标操作种怪，取消等操作

        /// <summary>
        /// 处理鼠标事件
        /// </summary>
        void ProcessMouseEvent()
        {
            //移除对象数据
            if (Input.GetKeyDown(KeyCode.Delete))
            {
                QuestInfo info = QuestAreaManager.Instance.DelCylinderFromPos();
                if (null != info)
                {
                    QuestAreaManager.Instance.RemoveCylinderFormList(info);
                    questInfoEditor.SetDelShowEditorCylinder(info);
                }
            }

            //获取鼠标事件
            var e = Event.current;
            if (e == null || !e.isMouse)
                return;

            if (e.clickCount == 1)
            {
                //if(e.button == 0)
                //{
                //    //左键一下 选中目标
                //    var sprite = SpriteManager.GetInst().GetSpriteFromPos();
                //    if(sprite != null)
                //    {
                //        //当前选中了一个 monster
                //        SetShowEditorSprite(sprite.data);
                //    }
                //    //else
                //    //{
                //    //    //设置为未选中目标
                //    //    SetShowEditorSprite(null);
                //    //}
                //}
                //else if(e.button == 1)
                //{
                //    //右键一下 删除选中目标
                //    var sprite = SpriteManager.GetInst().GetSpriteFromPos();
                //    if(sprite != null)
                //    {
                //        SpriteManager.GetInst().RemoveSpriteFromPos();
                //        SetShowEditorSprite(null);
                //    }
                //}
            }
            else if (e.clickCount == 2)
            {
                if (e.button == 0)
                {
                    //左键两下 种下一个圆柱体
                    QuestInfo questInfo=QuestAreaManager.Instance.CreateNewCylinder();

                    SetShowInforEditor(questInfo);

                }
                else if (e.button == 1)
                {
                    //右键两下 取消当前鼠标圆柱体预览
                    QuestAreaManager.Instance.NotShowCylinder();

                    SetShowInforEditor(null);
                }
            }
        }

        /// <summary>
        /// 设置编辑器显示信息
        /// </summary>
        public void SetShowInforEditor(QuestInfo questInfo)
        {
            if(null!=questInfoEditor)
                questInfoEditor.SetShowEditorCylinder(questInfo);
        }

        #endregion
    }
}