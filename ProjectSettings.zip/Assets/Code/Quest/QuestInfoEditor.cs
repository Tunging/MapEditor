﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using NavMesh.Camera;
using TransformGizmos;

namespace MapEditor
{
    public class QuestInfoEditor
    {
        #region 初始化
        public QuestInfoEditor()
        {
            LoadQuestAreaPrefab();
        }

        GameObject questArea_prefab;
        string questAreaPath = "area_cylinder";

        /// <summary>
        /// 加载圆柱体
        /// </summary>
        void LoadQuestAreaPrefab()
        {
            if (null == questArea_prefab)
            {
                //加载范围资源
                questArea_prefab = Resources.Load<GameObject>(questAreaPath);
            }
        }
        #endregion

        //上方属性编辑
        Rect propertyRect = new Rect(300, 0, 600, 250);

        //左下方操作说明
        Rect operationRect = new Rect(0, 300, 300, Screen.height - 300 - 20);

        //右下方列表
        Rect cylinderRect = new Rect(Screen.width - 300, 300, 300, Screen.height - 300 - 20);
        Vector2 cylinderListScrollPosi = new Vector2();

        /// <summary>
        /// 数据绘制
        /// </summary>
        public void OnGUI()
        {
            propertyRect = GUI.Window(104, propertyRect, DrawPropertyWindow, "任务区域范围 属性编辑");

            operationRect = GUI.Window(2, operationRect, DrawOperationWindow, "操作说明");

            cylinderRect = GUI.Window(4, cylinderRect, DrawCylinderWindow, "圆柱体列表");
        }

        QuestInfo Data;

        int id;
        int type = 1;
        string name;

        string r, h;

        void DrawPropertyWindow(int id)
        {

            if (Data == null)
            {
                GUILayout.Label("当前未选中圆柱体");
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("保存到服务器", GUILayout.Height(30)))
                {
                    SceneManager.GetInst().SendToServer();
                }
                GUILayout.EndHorizontal();
                return;
            }

            GUILayout.Label("当前地图：" + Data.scene_id + " 当前选中圆柱体：<color=red>" + Data.name + "</color>\n" +
                "位置【x：" + Data.x + "】【y:" + Data.y + "】【z：" + Data.z + "】\n");
                //+"半径【r：" + Data.r + "】\n" +
                //"高度【h：" + Data.h + "】\n");

            GUILayout.BeginHorizontal();
            id = GUIUtils.NumberField("ID", Data.id);
            if(id!=Data.id)
            {
                Data.id = id;
                Data.isSynchronizationServer = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            type = GUIUtils.NumberField("类型：(1、区域任务2、新手引导)客户端使用", Data.type);
            if (type != Data.type)
            {
                Data.type = type;
                Data.isSynchronizationServer = false;
            }
            GUILayout.EndHorizontal();



            GUILayout.BeginHorizontal();
            name = GUIUtils.StrField("name", Data.name);
            if(name!=Data.name)
            {
                Data.name = name;
                Data.isSynchronizationServer = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("半径:");
            r= GUILayout.TextField(Data.r.ToString(), GUILayout.Width(200));
            if(!string.Equals(r,Data.r.ToString()))
            { 
                try
                {
                    float ra = float.Parse(r);
                    Data.r = ra;
                    Data.LocalScale();
                    Data.isSynchronizationServer = false;
                }
                catch
                {
                    GUILayout.Label("输入非法");
                }
                
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("高度:");
            h = GUILayout.TextField(Data.h.ToString(), GUILayout.Width(200));
            if (!string.Equals(h, Data.h.ToString()))
            {
                try
                {
                    float he = float.Parse(h);
                    Data.h = he;
                    Data.LocalScale();
                    Data.isSynchronizationServer = false;
                }
                catch
                {
                    GUILayout.Label("输入非法");
                }

            }
            GUILayout.EndHorizontal();

            if (GUILayout.Button("保存到服务器", GUILayout.Height(30)))
            {
                SceneManager.GetInst().SendToServer();
            }
        }

        private void DrawOperationWindow(int id)
        {
            GUILayout.Label("左键点击两下：种圆柱体");
            GUILayout.Label("左键点击一下：选中圆柱体");
            //GUILayout.Label("右键点击一下：删除Npc");
            GUILayout.Label("右键点击两下：清除预览");
            GUILayout.Label("Delete：删除圆柱体");

            //modelListScrollPosi = GUILayout.BeginScrollView(modelListScrollPosi);


            if (GUILayout.Button("种圆柱体"))
            {
                QuestAreaManager.Instance.LoadCylinder(questArea_prefab);
            }


            //GUILayout.EndScrollView();
        }

        private void DrawCylinderWindow(int id)
        {
            cylinderListScrollPosi = GUILayout.BeginScrollView(cylinderListScrollPosi);

            //新建的
            DrawCylinderWindow(QuestAreaManager.Instance.NewCreateQuestInfoList);

            //服务器上的
            DrawCylinderWindow(QuestAreaManager.Instance.ServerQuestInfoList);
            
            GUILayout.EndScrollView();
        }

        void DrawCylinderWindow(List<QuestInfo> questInfoList)
        {
            int count = 0;
            if (0 == (count = questInfoList.Count))
                return;

            for (int i = 0; i < count; i++)
            {
                string color = questInfoList[i].isSynchronizationServer ? "<color=green>{0}</color>" : "<color=red>{0}</color>";

                QuestInfo questInfo = questInfoList[i];

                //点击某一个圆柱体自动选中相应的圆柱体
                if (GUILayout.Button(string.Format(color, questInfo.id + "_" + questInfo.name)))
                {
                    CameraMove.GetInst().CameraLookAtTarget(questInfo.gameObject);
                    QuestAreaManager.Instance.SetCurCylinder(questInfo);
                    TransformGizmo.GetInst().SetTraget(questInfo.transform);
                }
            }
        }

        /// <summary>
        /// 设置当前的属性编辑器数据
        /// </summary>
        /// <param name="questInfo"></param>
        internal void SetShowEditorCylinder(QuestInfo questInfo)
        {
            Data = questInfo;
        }

        /// <summary>
        /// 当前删除的圆柱体
        /// </summary>
        /// <param name="info"></param>
        internal void SetDelShowEditorCylinder(QuestInfo info)
        {
            Data = Data.id == info.id ? null : Data;
        }

        /// <summary>
        /// 在场景中创建圆柱体
        /// </summary>
        /// <param name="questInfo"></param>
        internal QuestInfo CreateCylinderInScene(JsonQuestInfo jsonInfo)
        {

            if (jsonInfo.scene_id != SceneManager.GetInst().CurrScene.id) return null;

            GameObject obj = GameObject.Instantiate<GameObject>(questArea_prefab);

            obj.transform.position = new Vector3(float.Parse(jsonInfo.x), float.Parse(jsonInfo.y), float.Parse(jsonInfo.z));
            obj.transform.localScale = new Vector3(float.Parse(jsonInfo.radius) * 2, float.Parse(jsonInfo.height), float.Parse(jsonInfo.radius) * 2);

            QuestInfo info = obj.AddComponent<QuestInfo>();
            info.id = jsonInfo.id;
            info.name = jsonInfo.name;
            info.scene_id = jsonInfo.scene_id;
            info.x = float.Parse(jsonInfo.x);
            info.y = float.Parse(jsonInfo.y);
            info.z = float.Parse(jsonInfo.z);
            info.r = float.Parse(jsonInfo.radius);
            info.h = float.Parse(jsonInfo.height);

            info.isSynchronizationServer = true;

            return info;
        }
    }

}
