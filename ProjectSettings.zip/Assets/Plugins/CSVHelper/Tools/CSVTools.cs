﻿using Csv;
using EditorTable;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;

/// <summary>
/// 解析和写入csv的辅助类
/// @author LiuLeiLei
/// @data 5/22/2018
/// @desc 
/// </summary>
public static class CSVTools
{
    /// <summary>
    /// 解析的表备注dic
    /// </summary>
    private static Dictionary<string, List<ICsvLine>> headerDic = new Dictionary<string, List<ICsvLine>>();

    /// <summary>
    /// 配置文件解析
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="_url"></param>
    /// <returns></returns>
    public static List<T> ConfigRes<T>(string _url) where T : TableContent, new()
    {
        List<T> tempList = new List<T>();

        //这里是为了保存前三行数据
        List<ICsvLine> headerList;
        if (!headerDic.TryGetValue(_url, out headerList))
        {
            headerList = new List<ICsvLine>();
            headerDic[_url] = headerList;
        }

        //加载
        TextAsset ta = Resources.Load(_url, typeof(TextAsset)) as TextAsset;

        if (!ta)
        {
            Debug.LogError(string.Format("Can't get config by url : {0}", _url));
            return tempList;
        }

        //获取内容
        string content = Encoding.Default.GetString(ta.bytes);

        //Debug.LogError(content);

        byte[] bys = Encoding.UTF8.GetBytes(content);

        var ms = new MemoryStream(bys);
        var lines = CsvReader.ReadFromStream(ms).ToArray();

        Dictionary<string, string> tabDic = new Dictionary<string, string>();
        List<string> variableList = new List<string>();

        for (int i = 0; i < lines.Length; i++)
        {
            //Debug.Log("lines[" + i + "] == " + lines[i]);

            var line = lines[i];
            if (i < 3)
            {
                //缓存 header and remark
                if (headerList.Count < 3)
                    headerList.Add(line);

                //变量名
                if (i == 0)
                {
                    for (int j = 0; j < line.ColumnCount; j++)
                    {
                        variableList.Add(line[j]);
                    }
                }
            }
            else
            {
                //Debug.LogError(line.Headers);
                //Debug.Log("Raw == " + line.Raw);
                //Debug.Log("ColumnCount == " + line.ColumnCount);
                //Debug.Log("Index == " + line.Index);

                for (int j = 0; j < line.ColumnCount; j++)
                {
                    if (j < variableList.Count)
                    {
                        if (!tabDic.ContainsKey(variableList[j]))
                        {
                            tabDic[variableList[j]] = line[j];
                        }
                    }
                }

                T t = new T();
                t.ParseFrom(tabDic);
                tempList.Add(t);

                tabDic.Clear();
            }
        }

        return tempList;
    }

    /// <summary>
    /// 保存配置文件
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="_url"></param>
    /// <param name="_tableList"></param>
    public static void SaveConfig<T>(string _url, List<T> _tableList) where T : TableContent
    {
        List<ICsvLine> headerList = null;
        if (headerDic.TryGetValue(_url, out headerList))
        {
            List<string[]> valueList = new List<string[]>();

            for (int i = 0; i < headerList.Count; i++)
            {
                ICsvLine line = headerList[i];
                string[] lineArr = new string[line.ColumnCount];
                for (int j = 0; j < line.ColumnCount; j++)
                {
                    lineArr[j] = line[j];
                }

                valueList.Add(lineArr);
            }

            try
            {
                for (int i = 0; i < _tableList.Count; i++)
                {
                    FieldInfo[] fi = typeof(T).GetFields();
                    string[] valueArr = new String[fi.Length];
                    for (int j = 0; j < fi.Length; j++)
                    {
                        object value = fi[j].GetValue(_tableList[i]);
                        valueArr[j] = value == null ? "" : value.ToString();
                    }

                    valueList.Add(valueArr);
                }
            }
            catch (Exception _ex)
            {
                Debug.LogException(_ex);
            }

            string filename = string.Format("Assets/Resources/{0}.csv", _url);
            using (var stream = File.Open(filename, FileMode.Create))
            {
                using (var wtr = new StreamWriter(stream, Encoding.Default))
                {
                    CsvWriter.Write(wtr, null, valueList.ToArray());

                    //Debug.Log("wtr.Encoding == " + wtr.Encoding);
                    //Debug.Log("result == " + wtr.ToString());
                }
            }
        }
    }

    #region 数据类型转换

    /// <summary>
    /// 字符串转换为 byte
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static byte GetByteFromString(string str)
    {
        byte b = 0;
        if (byte.TryParse(str, out b))
            return b;

        return b;
    }

    /// <summary>
    /// 字符串转换为 sbyte
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static sbyte GetSByteFromString(string str)
    {
        sbyte b = -1;
        if (sbyte.TryParse(str, out b))
            return b;

        return b;
    }

    /// <summary>
    /// 字符串转换为 short
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static short GetShortFromString(string str)
    {
        short s = -1;
        if (short.TryParse(str, out s))
            return s;

        return s;
    }

    /// <summary>
    /// 字符串转换为 float
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static float GetFloatFromString(string str)
    {
        float f = -1f;
        if (float.TryParse(str, out f))
            return f;

        return f;
    }

    /// <summary>
    /// 字符串转换为 double
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static double GetDoubleFromString(string str)
    {
        double d = -1;
        if (double.TryParse(str, out d))
            return d;

        return d;
    }

    /// <summary>
    /// 字符串转换为 int
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static int GetIntFromString(string str)
    {
        int i = -1;
        if (int.TryParse(str, out i))
            return i;

        return i;
    }

    /// <summary>
    /// 字符串转换为 uint
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static uint GetUIntFromString(string str)
    {
        uint i = 0;
        if (uint.TryParse(str, out i))
            return i;

        return i;
    }

    /// <summary>
    /// 字符串转换为 long
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static long GetLongFromString(string str)
    {
        long l = -1;
        if (long.TryParse(str, out l))
            return l;

        return l;
    }

    /// <summary>
    /// 字符串转换为 bool
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static bool GetBoolFromString(string str)
    {
        bool b = false;
        if (bool.TryParse(str, out b))
            return b;

        return b;
    }

    /// <summary>
    /// 字符串转换为 char
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static char GetCharFromString(string str)
    {
        char c = char.MinValue;
        if (char.TryParse(str, out c))
            return c;

        return c;
    }

    /// <summary>
    /// 字符串转换为 UInt16
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static UInt16 GetUInt16FromString(string str)
    {
        UInt16 i = 0;
        if (UInt16.TryParse(str, out i))
            return i;

        return i;
    }

    /// <summary>
    /// 字符串转换为 UInt32
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static UInt32 GetUInt32FromString(string str)
    {
        UInt32 i = 0;
        if (UInt32.TryParse(str, out i))
            return i;

        return i;
    }

    /// <summary>
    /// 字符串转换为 UInt32
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static UInt64 GetUInt64FromString(string str)
    {
        UInt64 i = 0;
        if (UInt64.TryParse(str, out i))
            return i;

        return i;
    }

    #endregion
}
