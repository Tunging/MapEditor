using System.Collections.Generic;
using System;

namespace EditorTable
{
    ///<summary>
    /// 对话组表
    ///</summary>
    [Serializable]
    public class Table_Dialog : TableContent
    {
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;

        ///<summary>
        /// 描述
        ///</summary>
        public string discription;

        ///<summary>
        /// 对话组id
        ///</summary>
        public int dialog_group_id;

        ///<summary>
        /// 控件类型
        ///</summary>
        public int type;

        ///<summary>
        /// 控件参数１
        ///</summary>
        public int param1;

        ///<summary>
        /// 控件参数２
        ///</summary>
        public int param2;

        ///<summary>
        /// 控件参数3
        ///</summary>
        public int param3;

        ///<summary>
        /// 显示顺序
        ///</summary>
        public int order;

        ///<summary>
        /// 触发条件类型
        ///</summary>
        public int condition_type;

        ///<summary>
        /// 条件参数１
        ///</summary>
        public int condition_param1;

        ///<summary>
        /// 条件参数２
        ///</summary>
        public int condition_param2;

        ///<summary>
        /// 条件参数３
        ///</summary>
        public int condition_param3;

        ///<summary>
        /// 触发行为类型
        ///</summary>
        public int function_type;

        ///<summary>
        /// 行为参数１
        ///</summary>
        public int function_param1;

        ///<summary>
        /// 行为参数２
        ///</summary>
        public int function_param2;

        ///<summary>
        /// 行为参数３
        ///</summary>
        public string function_param3;

        ///<summary>
        /// 触发行为类型2
        ///</summary>
        public int function_2_type;

        ///<summary>
        /// 行为2参数１
        ///</summary>
        public int function_2_param1;

        ///<summary>
        /// 行为2参数2
        ///</summary>
        public int function_2_param2;

        ///<summary>
        /// 行为2参数3
        ///</summary>
        public string function_2_param3;

        ///<summary>
        /// 备注
        ///</summary>
        public string remark;

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData)
        {
            string _currValue = "";
            if (_itemData.TryGetValue("id", out _currValue))
            {
                this.id = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("discription", out _currValue))
            {
                this.discription = _currValue;
            }
            if (_itemData.TryGetValue("dialog_group_id", out _currValue))
            {
                this.dialog_group_id = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("type", out _currValue))
            {
                this.type = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("param1", out _currValue))
            {
                this.param1 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("param2", out _currValue))
            {
                this.param2 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("param3", out _currValue))
            {
                this.param3 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("order", out _currValue))
            {
                this.order = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("condition_type", out _currValue))
            {
                this.condition_type = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("condition_param1", out _currValue))
            {
                this.condition_param1 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("condition_param2", out _currValue))
            {
                this.condition_param2 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("condition_param3", out _currValue))
            {
                this.condition_param3 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_type", out _currValue))
            {
                this.function_type = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_param1", out _currValue))
            {
                this.function_param1 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_param2", out _currValue))
            {
                this.function_param2 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_param3", out _currValue))
            {
                this.function_param3 = _currValue;
            }
            if (_itemData.TryGetValue("function_2_type", out _currValue))
            {
                this.function_2_type = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_2_param1", out _currValue))
            {
                this.function_2_param1 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_2_param2", out _currValue))
            {
                this.function_2_param2 = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("function_2_param3", out _currValue))
            {
                this.function_2_param3 = _currValue;
            }
            if (_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }

        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "discription":
                    return this.discription;
                case "dialog_group_id":
                    return this.dialog_group_id;
                case "type":
                    return this.type;
                case "param1":
                    return this.param1;
                case "param2":
                    return this.param2;
                case "param3":
                    return this.param3;
                case "order":
                    return this.order;
                case "condition_type":
                    return this.condition_type;
                case "condition_param1":
                    return this.condition_param1;
                case "condition_param2":
                    return this.condition_param2;
                case "condition_param3":
                    return this.condition_param3;
                case "function_type":
                    return this.function_type;
                case "function_param1":
                    return this.function_param1;
                case "function_param2":
                    return this.function_param2;
                case "function_param3":
                    return this.function_param3;
                case "function_2_type":
                    return this.function_2_type;
                case "function_2_param1":
                    return this.function_2_param1;
                case "function_2_param2":
                    return this.function_2_param2;
                case "function_2_param3":
                    return this.function_2_param3;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
    }
}
