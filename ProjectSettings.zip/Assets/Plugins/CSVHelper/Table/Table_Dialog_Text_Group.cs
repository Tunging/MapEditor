using System.Collections.Generic;
using System;

namespace EditorTable
{
    ///<summary>
    /// 对话文字组
    ///</summary>
    [Serializable]
    public class Table_Dialog_Text_Group : TableContent
    {
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;

        ///<summary>
        /// 文字组
        ///</summary>
        public int text_group;

        ///<summary>
        /// 文字顺序
        ///</summary>
        public int text_order;

        ///<summary>
        /// 文字
        ///</summary>
        public string text;

        ///<summary>
        /// 文字国际化
        ///</summary>
        public string text_i18n;

        ///<summary>
        /// 文字对应的NPC id
        ///</summary>
        public int npc_id;

        ///<summary>
        /// 播放声音ID
        ///</summary>
        public int content_sound_id;

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData)
        {
            string _currValue = "";
            if (_itemData.TryGetValue("id", out _currValue))
            {
                this.id = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("text_group", out _currValue))
            {
                this.text_group = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("text_order", out _currValue))
            {
                this.text_order = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("text", out _currValue))
            {
                this.text = _currValue;
            }
            if (_itemData.TryGetValue("text_i18n", out _currValue))
            {
                this.text_i18n = _currValue;
            }
            if (_itemData.TryGetValue("npc_id", out _currValue))
            {
                this.npc_id = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("content_sound_id", out _currValue))
            {
                this.content_sound_id = CSVTools.GetIntFromString(_currValue);
            }
        }

        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "text_group":
                    return this.text_group;
                case "text_order":
                    return this.text_order;
                case "text":
                    return this.text;
                case "text_i18n":
                    return this.text_i18n;
                case "npc_id":
                    return this.npc_id;
                case "content_sound_id":
                    return this.content_sound_id;
                default:
                    return null;
            }
        }
    }
}
