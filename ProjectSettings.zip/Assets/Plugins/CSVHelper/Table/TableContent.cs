using System.Collections.Generic;

namespace EditorTable
{
    ///<summary>
    /// basetable
    ///</summary>
    public abstract class TableContent
    {
        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public abstract void ParseFrom(Dictionary<string, string> _itemData);

        ///<summary>
        ///根据column获取值
        ///</summary>
        public abstract object GetValue(string column);
    }
}
