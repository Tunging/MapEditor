using System.Collections.Generic;
using System;

namespace EditorTable
{
    ///<summary>
    /// 对话组件条件类型
    ///</summary>
    [Serializable]
    public class Table_Dialog_Condition_Type : TableContent
    {
        ///<summary>
        /// 主键：ID
        ///</summary>
        public int id;

        ///<summary>
        /// ckey
        ///</summary>
        public string ckey;

        ///<summary>
        /// 名字
        ///</summary>
        public string name;

        ///<summary>
        /// 备注
        ///</summary>
        public string remark;

        ///<summary>
        /// 通过字典初始化对象值
        ///</summary>
        public override void ParseFrom(Dictionary<string, string> _itemData)
        {
            string _currValue = "";
            if (_itemData.TryGetValue("id", out _currValue))
            {
                this.id = CSVTools.GetIntFromString(_currValue);
            }
            if (_itemData.TryGetValue("ckey", out _currValue))
            {
                this.ckey = _currValue;
            }
            if (_itemData.TryGetValue("name", out _currValue))
            {
                this.name = _currValue;
            }
            if (_itemData.TryGetValue("remark", out _currValue))
            {
                this.remark = _currValue;
            }
        }

        ///<summary>
        ///根据column获取值
        ///</summary>
        public override object GetValue(string column)
        {
            switch (column)
            {
                case "id":
                    return this.id;
                case "ckey":
                    return this.ckey;
                case "name":
                    return this.name;
                case "remark":
                    return this.remark;
                default:
                    return null;
            }
        }
    }
}
